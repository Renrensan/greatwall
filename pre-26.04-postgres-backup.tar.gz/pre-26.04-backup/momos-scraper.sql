--
-- PostgreSQL database cluster dump
--

\restrict v9XpdBz0SvduOqey3TyvDZzkeFNkL9BL8o0IritbxDhh49g88niurAx3vcNwOl4

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE momos_scraper_user;
ALTER ROLE momos_scraper_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:RbhczvhQW7f5eqlN35HgVA==$3OSCK2C4yqoFCHE4VCanMygsyIgKGV6EMUQ0xcgtVfA=:mpoYhnE0n7dGfrVt1ZZWPMygssWQn+NJW8ZAnhlbCrA=';

--
-- User Configurations
--








\unrestrict v9XpdBz0SvduOqey3TyvDZzkeFNkL9BL8o0IritbxDhh49g88niurAx3vcNwOl4

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict FpQ3q0pg39RuxHO8t0IEQZlhpbPtxxjoqdvmNXRIQmPbTaUF1I5VjjGmG0xEzjP

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict FpQ3q0pg39RuxHO8t0IEQZlhpbPtxxjoqdvmNXRIQmPbTaUF1I5VjjGmG0xEzjP

--
-- Database "momos_scraper_db" dump
--

--
-- PostgreSQL database dump
--

\restrict FWKIxMhdCRGVaVvIWAjMqjEqFZ4Wd6dOzyunvLig7U7vzkbwRmxIt4bJL10Q0JE

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: momos_scraper_db; Type: DATABASE; Schema: -; Owner: momos_scraper_user
--

CREATE DATABASE momos_scraper_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE momos_scraper_db OWNER TO momos_scraper_user;

\unrestrict FWKIxMhdCRGVaVvIWAjMqjEqFZ4Wd6dOzyunvLig7U7vzkbwRmxIt4bJL10Q0JE
\connect momos_scraper_db
\restrict FWKIxMhdCRGVaVvIWAjMqjEqFZ4Wd6dOzyunvLig7U7vzkbwRmxIt4bJL10Q0JE

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: momos_scraper_user
--

CREATE TABLE public.admin_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_users OWNER TO momos_scraper_user;

--
-- Name: business_leads; Type: TABLE; Schema: public; Owner: momos_scraper_user
--

CREATE TABLE public.business_leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid,
    place_id character varying(255),
    cid character varying(100),
    name character varying(255) NOT NULL,
    category character varying(255) DEFAULT ''::character varying NOT NULL,
    subcategories jsonb DEFAULT '[]'::jsonb,
    address text DEFAULT ''::text NOT NULL,
    street character varying(255) DEFAULT ''::character varying,
    city character varying(100) DEFAULT ''::character varying,
    state character varying(100) DEFAULT ''::character varying,
    postal_code character varying(50) DEFAULT ''::character varying,
    country character varying(100) DEFAULT ''::character varying,
    latitude double precision DEFAULT 0.0,
    longitude double precision DEFAULT 0.0,
    rating double precision DEFAULT 0.0,
    review_count integer DEFAULT 0,
    price_level character varying(50) DEFAULT ''::character varying,
    claimed boolean DEFAULT false,
    business_status character varying(50) DEFAULT 'OPERATIONAL'::character varying,
    website text DEFAULT ''::text,
    primary_phone character varying(100) DEFAULT ''::character varying,
    emails jsonb DEFAULT '[]'::jsonb,
    phones jsonb DEFAULT '[]'::jsonb,
    facebook_url text DEFAULT ''::text,
    instagram_url text DEFAULT ''::text,
    linkedin_url text DEFAULT ''::text,
    twitter_url text DEFAULT ''::text,
    youtube_url text DEFAULT ''::text,
    tiktok_url text DEFAULT ''::text,
    google_maps_url text DEFAULT ''::text,
    opening_hours jsonb DEFAULT '{}'::jsonb,
    photos jsonb DEFAULT '[]'::jsonb,
    enrichment_status character varying(50) DEFAULT 'NONE'::character varying,
    last_scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    last_enriched_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contacted boolean DEFAULT false NOT NULL,
    contacted_at timestamp with time zone
);


ALTER TABLE public.business_leads OWNER TO momos_scraper_user;

--
-- Name: scrape_jobs; Type: TABLE; Schema: public; Owner: momos_scraper_user
--

CREATE TABLE public.scrape_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    query character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    category character varying(255) DEFAULT ''::character varying NOT NULL,
    max_results integer DEFAULT 100 NOT NULL,
    enrich_contacts boolean DEFAULT true NOT NULL,
    total_scraped integer DEFAULT 0 NOT NULL,
    total_enriched integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    error_message text DEFAULT ''::text,
    metadata jsonb DEFAULT '{}'::jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scrape_jobs OWNER TO momos_scraper_user;

--
-- Name: scraper_keywords; Type: TABLE; Schema: public; Owner: momos_scraper_user
--

CREATE TABLE public.scraper_keywords (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    keyword character varying(255) NOT NULL,
    next_page_token text DEFAULT ''::text,
    current_page integer DEFAULT 1 NOT NULL,
    total_leads_scraped integer DEFAULT 0 NOT NULL,
    last_scraped_at timestamp with time zone,
    status character varying(50) DEFAULT 'ready'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scraper_keywords OWNER TO momos_scraper_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: momos_scraper_user
--

CREATE TABLE public.system_settings (
    key character varying(100) NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_settings OWNER TO momos_scraper_user;

--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: momos_scraper_user
--

COPY public.admin_users (id, username, email, password_hash, is_active, created_at, updated_at) FROM stdin;
5b4a3675-92fe-45be-809e-ff02134463ce	admin	admin@momos.local	$2a$12$8SPz2RiPTRtLV5B2wYByW.fxDvu/1mAh5trjlcaCxLYCjr40weWHi	t	2026-09-10 10:27:17.473013+00	2026-09-10 10:27:17.473013+00
\.


--
-- Data for Name: business_leads; Type: TABLE DATA; Schema: public; Owner: momos_scraper_user
--

COPY public.business_leads (id, job_id, place_id, cid, name, category, subcategories, address, street, city, state, postal_code, country, latitude, longitude, rating, review_count, price_level, claimed, business_status, website, primary_phone, emails, phones, facebook_url, instagram_url, linkedin_url, twitter_url, youtube_url, tiktok_url, google_maps_url, opening_hours, photos, enrichment_status, last_scraped_at, last_enriched_at, created_at, updated_at, contacted, contacted_at) FROM stdin;
1c38d2a4-6121-4977-a8c9-c00880baac95	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ-cG_ODdB0i0RNIF3Ze5iOiA		WARDANA PET CARE	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Tukad Penet Gg. II No.1, Renon, Denpasar Selatan, Kota Denpasar, Bali 80239, Indonesia	Jl. Tukad Penet Gg. II No.1	Renon	Denpasar	Selatan	Kota Denpasar	-8.674844499999999	115.2443015	5	11		t	OPERATIONAL		0857-3796-9885	null	null							https://maps.google.com/?cid=2322277333906981172&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.851926+00	\N	2026-09-11 10:47:19.821432+00	2026-09-14 06:09:28.851926+00	f	\N
fbdf42b7-4238-462c-9b9c-e6129d57b20b	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJSRzg0KNA0i0RfR3f35FWKJk		latéO	Cafe	["Cafe", "Coffee Shop", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Gn. Semeru No.3, Pemecutan, Kec. Denpasar Bar., Kota Denpasar, Bali 80111, Indonesia	Jl. Gn. Semeru No.3	Pemecutan	Kec.	Denpasar	Kota Denpasar	-8.6559143	115.2091598	4.5	858		t	OPERATIONAL		(0361) 424159	null	null							https://maps.google.com/?cid=11036166071397588349&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.439746+00	\N	2026-09-10 11:34:51.439746+00	2026-09-10 11:34:51.439746+00	f	\N
1bf3c3dd-b40c-452f-a7fa-3115c0bf4ead	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJm6w-qMpB0i0R20ce9PVa4NI		The crafe	Coffee Shop	["Coffee Shop", "Cafe", "Food Store", "Store", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Panjer, Denpasar Selatan, Denpasar City, Bali 80239, Indonesia	Panjer	Denpasar Selatan	Denpasar	City	Bali 80239	-8.6648005	115.23982409999999	4.8	992		t	OPERATIONAL			null	null							https://maps.google.com/?cid=15195245155157166043&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.444877+00	\N	2026-09-10 11:34:51.444877+00	2026-09-10 11:34:51.444877+00	f	\N
ec21ed61-a21b-40a8-b397-a56cc1326360	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJb2AkDJBH0i0R-kxVPzphjd8		Tahoma Cafe & Eatery	Coffee Shop	["Coffee Shop", "Cafe", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Nakula No.78, Pemecutan Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80111, Indonesia	Jl. Nakula No.78	Pemecutan Klod	Kec.	Denpasar	Kota Denpasar	-8.699716	115.18084749999998	4.2	1221		t	OPERATIONAL		0813-3889-3437	null	null							https://maps.google.com/?cid=16108638344972684538&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.445877+00	\N	2026-09-10 11:34:51.445877+00	2026-09-10 11:34:51.445877+00	f	\N
14113b65-bf35-4b2c-a8a0-2943e97ca7ef	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJ-9qpclVB0i0RmZQoTR3IS00		Loh & Co	Restaurant	["Restaurant", "Coffee Shop", "Cafe", "Indonesian Restaurant", "Food Store", "Store", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Tukad Musi I No.9A, Renon, Denpasar Selatan, Kota Denpasar, Bali 80226, Indonesia	Jl. Tukad Musi I No.9A	Renon	Denpasar	Selatan	Kota Denpasar	-8.6735726	115.22904069999998	4.5	1707		t	OPERATIONAL	https://lohandcobali.com/en	0812-3848-2109	null	[]	https://www.facebook.com/profile.php	https://www.instagram.com/lohandcobali/				https://www.tiktok.com/@lohandcobali	https://maps.google.com/?cid=5569765392347862169&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.433759+00	2026-09-10 11:34:53.095112+00	2026-09-10 11:34:51.433759+00	2026-09-10 11:34:53.095112+00	f	\N
a47ae4e1-89f2-490f-8e43-2e3d355b1abf	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJd3AJdFpB0i0Riz2YDVi6zjA		Over the Moon Cafe	Cafe	["Cafe", "Asian Restaurant", "Brunch Restaurant", "Bar", "Coffee Shop", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Danau Tamblingan No.19, Sanur, Denpasar Selatan, Kota Denpasar, Bali 80228, Indonesia	Jl. Danau Tamblingan No.19	Sanur	Denpasar	Selatan	Kota Denpasar	-8.6853964	115.2624084	4.6	1261		t	OPERATIONAL	https://www.overthemoonbali.com/	0812-3867-8702	["info@overthemoonbali.com", "605a7baede844d278b89dc95ae0a9123@sentry-next.wixpress.com", "8eb368c655b84e029ed79ad7a5c1718e@sentry.wixpress.com", "2062d0a4929b45348643784b5cb39c36@sentry.wixpress.com"]	[]	https://facebook.com/overthemoonbali	https://instagram.com/overthemoonbali					https://maps.google.com/?cid=3516953246370905483&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.441259+00	2026-09-10 11:34:53.316484+00	2026-09-10 11:34:51.441259+00	2026-09-10 11:34:53.316484+00	f	\N
da4b0de9-8c65-4252-8d70-69692ed6392d	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJ9VImtjJH0i0Rr2Z57kF1Lqk		9-11 Cafe	Cafe	["Cafe", "Barber Shop", "Coworking Space", "Garden", "Hair Care", "Coffee Shop", "Food Store", "Store", "Health", "Food", "Point Of Interest", "Service", "Establishment", "Cafe in Denpasar"]	Jl. Teuku Umar Barat No.337, Padangsambian, Kec. Denpasar Bar., Kota Denpasar, Bali 80119, Indonesia	Jl. Teuku Umar Barat No.337	Padangsambian	Kec.	Denpasar	Kota Denpasar	-8.6810551	115.1883774	4.6	3733		t	OPERATIONAL	https://www.instagram.com/911bali	(0361) 4717481	null	[]							https://maps.google.com/?cid=12190810167372768943&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.415067+00	2026-09-10 11:34:53.623791+00	2026-09-10 11:34:51.415067+00	2026-09-10 11:34:53.623791+00	f	\N
5c32444d-b560-452d-a2ba-44dc97f3bd83	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJa5KGCVk_0i0RzhbAnsAUhPM		NOIR Cafe	Cafe	["Cafe", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Cokroaminoto No.465, Ubung Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80116, Indonesia	Jl. Cokroaminoto No.465	Ubung Kaja	Kec.	Denpasar	Kota Denpasar	-8.613939199999999	115.19298549999999	4.7	476		t	OPERATIONAL	https://www.instagram.com/noircafe.bali/?hl=en	0877-7641-5998	null	[]							https://maps.google.com/?cid=17547172865671960270&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.428341+00	2026-09-10 11:34:53.763564+00	2026-09-10 11:34:51.428341+00	2026-09-10 11:34:53.763564+00	f	\N
d4557211-175c-4a37-9b5e-a36cc39490f9	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJv-pCBGtH0i0RtjgHkk_uF-g		Livingstone	Cafe	["Cafe", "Breakfast Restaurant", "Coffee Shop", "Bakery", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Petitenget No.88X, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Petitenget No.88X	Kerobokan Kelod	Kec.	Kuta	Kabupaten Badung	-8.6717861	115.16142219999998	4.8	14486		t	OPERATIONAL	https://www.instagram.com/livingstonebakery/	0817-5780-003	null	[]							https://maps.google.com/?cid=16724097766783400118&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.437931+00	2026-09-10 11:34:53.825656+00	2026-09-10 11:34:51.437931+00	2026-09-10 11:34:53.825656+00	f	\N
d43486fd-2dc0-4c70-8fe1-804c121686a2	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJR3tio_BH0i0RDjLJ8P-564w		Campo Saga Cafe and city space	Restaurant	["Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Mahendradatta Selatan No.7, Padangsambian, Kec. Denpasar Bar., Kota Denpasar, Bali 80119, Indonesia	Jl. Mahendradatta Selatan No.7	Padangsambian	Kec.	Denpasar	Kota Denpasar	-8.6824874	115.1885276	4.5	678		t	OPERATIONAL	https://camposagacafeandcityspace.shop/		["camposagacafeandcityspace.shop@gmail.com"]	[]		https://www.instagram.com/camposaga_cafe/					https://maps.google.com/?cid=10154414293744431630&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.442315+00	2026-09-10 11:34:53.941018+00	2026-09-10 11:34:51.442315+00	2026-09-10 11:34:53.941018+00	f	\N
4a4cbe96-d926-4cf2-b7f9-29f7bb07f739	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJj_YedmtB0i0RQMfZoxPJF_U		kyoto country club HERITAGE	Cafe	["Cafe", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Arjuna No.25, Dauh Puri Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80111, Indonesia	Jl. Arjuna No.25	Dauh Puri Kaja	Kec.	Denpasar	Kota Denpasar	-8.653921	115.21516580000001	4.9	1828		t	OPERATIONAL	https://www.instagram.com/kyotocountryclub?igsh=MW9nYWJ0ODJwZWk3Ng==	0812-3972-2668	null	[]							https://maps.google.com/?cid=17660805549947209536&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.443312+00	2026-09-10 11:34:55.511548+00	2026-09-10 11:34:51.443312+00	2026-09-10 11:34:55.511548+00	f	\N
4a220b32-0740-47d7-8ae0-c88d889b9ae4	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJOwP2UsVG0i0RXlwzT4gL2Bc		Sunset Vet Kuta	Veterinary Care	["Pet Store", "Veterinary Care", "Pet Care", "Store", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Pertokoan Nakula Plaza, Jl. Nakula Blk C, Legian, Kec. Kuta, Kabupaten Badung, Bali 80361, Indonesia	Pertokoan Nakula Plaza	Jl. Nakula Blk C	Legian		Kec. Kuta	-8.7000125	115.18040789999999	4.5	1430		t	OPERATIONAL	http://www.sunsetvetbali.com/	(0361) 9348915	["reception@sunsetvetbali.com", "ubud@sunsetvetbali.com"]	null	https://www.facebook.com/pg/	https://www.instagram.com/sunset_vet_bali/	https://www.linkedin.com/company/3005595/	https://twitter.com/SunsetVetBali			https://maps.google.com/?cid=1718135937914068062&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.36335+00	2026-09-10 11:44:29.345943+00	2026-09-10 11:44:25.574239+00	2026-09-14 06:08:46.36335+00	f	\N
e8711e30-acdc-422f-958e-6dc43f5e441d	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJgeHcAgBB0i0RkGNjyvM7Lv4		Traya	Coffee Shop	["Coffee Shop", "Coworking Space", "Cafe", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Tukad Citarum LC1 No.2a, Renon, Denpasar Selatan, Kota Denpasar, Bali 80234, Indonesia	Jl. Tukad Citarum LC1 No.2a	Renon	Denpasar	Selatan	Kota Denpasar	-8.679513799999999	115.23492189999997	4.9	561		t	OPERATIONAL		0823-4102-1981	null	null							https://maps.google.com/?cid=18315642652820988816&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.458548+00	\N	2026-09-10 11:34:51.458548+00	2026-09-10 11:34:51.458548+00	f	\N
8221364d-0617-4351-b2eb-d161ea75ffe6	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJN337YSk_0i0R8F_AEomn5fs		KOPITIAM by LOCALE & CO.	Coffee Shop	["Coffee Shop", "Cafe", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Dahlia No.18, Sumerta Kauh, Kec. Denpasar Tim., Kota Denpasar, Bali 80236, Indonesia	Jl. Dahlia No.18	Sumerta Kauh	Kec.	Denpasar	Kota Denpasar	-8.646019899999999	115.2251684	4.8	37		t	OPERATIONAL		0822-4662-2886	null	null							https://maps.google.com/?cid=18151098080353607664&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.461405+00	\N	2026-09-10 11:34:51.461405+00	2026-09-10 11:34:51.461405+00	f	\N
68e04d6a-2625-4e90-9b20-331c31c610ed	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJT2OTZb5B0i0REoyCvxoCfw4		Joglo 66 Coffee	Coffee Shop	["Coffee Shop", "Snack Bar", "Cafe", "Food Store", "Wholesaler", "Meal Takeaway", "Store", "Restaurant", "Food", "Point Of Interest", "Service", "Establishment", "Cafe in Denpasar"]	Jl. Pulau Moyo No.1A, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80222, Indonesia	Jl. Pulau Moyo No.1A	Pedungan	Denpasar	Selatan	Kota Denpasar	-8.6937763	115.2097033	4.7	84		t	OPERATIONAL		0895-3472-33410	null	null							https://maps.google.com/?cid=1044555952478653458&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:34:51.471479+00	\N	2026-09-10 11:34:51.471479+00	2026-09-10 11:34:51.471479+00	f	\N
87397597-4e27-40e6-8015-ff54ed89edbd	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJZyBMAiVB0i0Rt_YKaDbggnU		Rooftop Denpasar	Coffee Shop	["Coffee Shop", "Bar", "Cafe", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Graha Pande Residence, No.18 Lt. 4, Gg. Griya Dadi Jl. Pulau Galang No.18, Pemogan, Denpasar Selatan, Kota Denpasar, Bali 80119, Indonesia	Graha Pande Residence	No.18 Lt. 4	Gg.	Griya	Pemogan	-8.694053	115.19045600000001	4.8	266		t	OPERATIONAL	https://linktr.ee/rooftop.menu		null	[]	https://www.facebook.com/Linktree/	https://instagram.com/rooftop.denpasar	https://www.linkedin.com/company/linktree	https://x.com/Linktree_	https://www.youtube.com/channel/UC8We2IKQo4lbongz7uOn2vA	https://www.tiktok.com/@rooftop.denpasar	https://maps.google.com/?cid=8467576773688358583&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.430243+00	2026-09-10 11:34:51.724148+00	2026-09-10 11:34:51.430243+00	2026-09-10 11:34:51.724148+00	f	\N
b5cb8390-9380-4a09-93c5-bea4282f954f	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJscwk8A5B0i0RH43mOBmr_BM		Stuja di Pantai	Cafe	["Cafe", "Coffee Shop", "Food Store", "Store", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Kusuma Sari No.4, Sanur, Denpasar Selatan, Kota Denpasar, Bali 80239, Indonesia	Jl. Kusuma Sari No.4	Sanur	Denpasar	Selatan	Kota Denpasar	-8.7070527	115.26241030000001	4.5	5341		t	OPERATIONAL	https://beacons.ai/stujadipantai?	0813-3730-3010	null	[]							https://maps.google.com/?cid=1440214105668881695&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.452311+00	2026-09-10 11:34:53.887211+00	2026-09-10 11:34:51.452311+00	2026-09-10 11:34:53.887211+00	f	\N
14972809-6732-4709-920f-1245d35131d3	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJWWzAHsdB0i0RykArbhqtCVA		Flinders Cafe	Cafe	["Cafe", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Merdeka IX No.9, Panjer, Denpasar Selatan, Kota Denpasar, Bali 80235, Indonesia	Jl. Merdeka IX No.9	Panjer	Denpasar	Selatan	Kota Denpasar	-8.6667667	115.23773449999999	4.8	782		t	OPERATIONAL	https://www.instagram.com/flinderscafebali/	0812-3849-8164	null	[]							https://maps.google.com/?cid=5767331126853714122&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.463813+00	2026-09-10 11:34:55.926292+00	2026-09-10 11:34:51.463813+00	2026-09-10 11:34:55.926292+00	f	\N
08c68c1d-f7d3-4f96-a294-4db80aa102f4	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJbd5y1alB0i0R9OPdNx_UaPs		Saji Loka – Coffee & Eatery Denpasar Bali	Restaurant	["Restaurant", "Salad Shop", "Breakfast Restaurant", "Tea Store", "Juice Shop", "Coffee Shop", "Cafe", "Dessert Shop", "Indonesian Restaurant", "Confectionery", "Food Store", "Store", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Pulau Tarakan No.2b, Dauh Puri Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80113, Indonesia	Jl. Pulau Tarakan No.2b	Dauh Puri Klod	Kec.	Denpasar	Kota Denpasar	-8.6766151	115.209875	4.8	452		t	OPERATIONAL	https://wa.me/6285706550391	0857-0656-0391	null	[]	https://www.facebook.com/profile.php	https://www.instagram.com/whatsapp/		https://x.com/whatsapp	https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw		https://maps.google.com/?cid=18115962731644183540&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.446834+00	2026-09-10 11:34:57.30507+00	2026-09-10 11:34:51.446834+00	2026-09-10 11:34:57.30507+00	f	\N
912e7558-a2a5-472b-830a-47ad79ed9419	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJbXXXkHRH0i0RYMOtDuYsmhM		The Magendra	Restaurant	["Restaurant", "Coworking Space", "Coffee Shop", "Cafe", "Event Venue", "Food Store", "Store", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Jl. Teuku Umar Barat No.888, Padangsambian Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80117, Indonesia	Jl. Teuku Umar Barat No.888	Padangsambian Klod	Kec.	Denpasar	Kota Denpasar	-8.6780045	115.18634060000001	4.7	1224		t	OPERATIONAL	https://themagendra.com/	0853-3788-7788	null	[]							https://maps.google.com/?cid=1412490799734440800&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.455266+00	2026-09-10 11:35:15.842588+00	2026-09-10 11:34:51.455266+00	2026-09-10 11:35:15.842588+00	f	\N
8682d801-8725-488b-98c4-a4ab706d2967	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJqw-wyitB0i0RzA_MfijfF0k		In-laws Coffee Denpasar	Coffee Shop	["Coffee Shop", "Cafe", "Food Store", "Store", "Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	pertokoan Kerta Wijaya, Jl. Diponegoro No.b5, Dauh Puri, Kec. Denpasar Bar., Kota Denpasar, Bali 80361, Indonesia	pertokoan Kerta Wijaya	Jl. Diponegoro No.b5	Dauh	Puri	Kec. Denpasar Bar.	-8.6649114	115.2152786	4.5	751		t	OPERATIONAL	http://linktree.com/inlawscoffee.shop	0877-9011-9222	null	[]	https://www.facebook.com/Inlaws-Coffee-275700146307174	https://www.instagram.com/linktr.ee/	https://www.linkedin.com/company/linktree	https://x.com/Linktree_	https://www.youtube.com/channel/UC8We2IKQo4lbongz7uOn2vA	https://tiktok.com/@inlawscoffee	https://maps.google.com/?cid=5266923654252072908&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.459501+00	2026-09-10 11:34:55.592223+00	2026-09-10 11:34:51.459501+00	2026-09-10 11:34:55.592223+00	f	\N
f9c3e676-2aed-4cff-ac3f-a77ada6ae2dd	ce170763-0a71-462f-bfc1-6d5e422dbd53	ChIJ47QneQA_0i0RB3Z7iE5Zb0k		The People's Cafe - Living World Denpasar	Restaurant	["Restaurant", "Family Restaurant", "Food", "Point Of Interest", "Establishment", "Cafe in Denpasar"]	Lower Ground, Gate 3, Jl. Gatot Subroto Tim., Tonja, Kec. Denpasar Utara, Kota Denpasar, Bali 80235, Indonesia	Lower Ground	Gate 3	Jl.	Gatot	Tonja	-8.634376099999999	115.2323161	4.8	1883		t	OPERATIONAL	https://www.ismaya.com/brands/the-peoples-cafe	0811-2026-1829	["info@ismaya.com", "puspita.marcella@ismayagroup.com"]	[]	https://www.facebook.com/ismayagroup	https://www.instagram.com/ismayagroup	https://www.linkedin.com/company/ismayagroup	https://www.twitter.com/ismayagroup	https://www.youtube.com/@ISMAYATV		https://maps.google.com/?cid=5291546281015735815&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-10 11:34:51.475193+00	2026-09-10 11:34:56.026166+00	2026-09-10 11:34:51.475193+00	2026-09-10 11:34:56.026166+00	f	\N
6e044fe7-bb12-48b2-baf6-9290cf58e447	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJzSDc8NRA0i0RAvIMXNSq9xE		Klinik Hewan Sayang Binatang (Sayang Binatang Vet Care)	Veterinary Care	["Pet Store", "Veterinary Care", "Pet Care", "Store", "Health", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Gn. Soputan, Pemecutan Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80119, Indonesia	Jl. Gn. Soputan	Pemecutan Klod	Kec.	Denpasar	Kota Denpasar	-8.6889069	115.1911467	4.9	236		t	OPERATIONAL	https://instagram.com/sayangbinatangvet?igshid=ngo224finsdk	0812-3918-756	null	null							https://maps.google.com/?cid=1294691246946447874&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.371498+00	2026-09-10 11:44:28.628991+00	2026-09-10 11:44:25.582772+00	2026-09-14 06:08:46.371498+00	f	\N
2f14ed8a-32d8-4c1e-8b06-ee9e25d53c34	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJl8elPwBB0i0RIbtiQkcU1lg		Poco Vet Bali (Pet Shop dan Dokter Hewan)	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	P.Enggano I No.2, Pemogan, Denpasar Selatan, Kota Denpasar, Bali 80221, Indonesia	P.Enggano I No.2	Pemogan	Denpasar	Selatan	Kota Denpasar	-8.6895451	115.1986472	5	59		t	OPERATIONAL		0859-6622-7676	null	null							https://maps.google.com/?cid=6401326216642738977&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.373365+00	\N	2026-09-10 11:44:25.581183+00	2026-09-14 06:08:46.373365+00	f	\N
c4e41742-86e8-4eca-895b-23f055316f6d	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJs4sJr1ZA0i0R8L8LZKMOk3c		Listriani Vet Care ( Veterinary Clinic )	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Tukad Balian No.882, Renon, Denpasar Selatan, Kota Denpasar, Bali 80227, Indonesia	Jl. Tukad Balian No.882	Renon	Denpasar	Selatan	Kota Denpasar	-8.7036639	115.23980429999999	4.5	511		t	OPERATIONAL	https://www.instagram.com/listrianivetcare_associates/	0851-0044-9306	null	null							https://maps.google.com/?cid=8616246607010840560&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.374555+00	2026-09-10 11:44:27.774433+00	2026-09-10 11:44:25.586528+00	2026-09-14 06:08:46.374555+00	f	\N
2464e903-e4f9-4045-b7f8-8a6549a6b719	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJLXQZFuxA0i0RgHEjYLBVEDg		drh. Ari Sapto Nugroho / VET	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Ir.Ida.Bagus Oka No.12, Dauh Puri Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80234, Indonesia	Jl. Ir.Ida.Bagus Oka No.12	Dauh Puri Klod	Kec.	Denpasar	Kota Denpasar	-8.674151900000002	115.2199699	4.7	266		t	OPERATIONAL		0822-6110-1116	null	null							https://maps.google.com/?cid=4039823081766875520&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.383498+00	\N	2026-09-10 11:44:25.59149+00	2026-09-14 06:08:46.383498+00	f	\N
98b1368e-c01e-4ec3-818f-eff137e8a3be	9db7a179-c371-4b5f-82ff-70c756425086	ChIJey56orFA0i0RgHNkHx2PwvU		Dokter Hewan(PET VET - Drh.Kamal Riza, SS)	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Gn. Bromo Gg. XI No.16, Tegal Kertha, Kec. Denpasar Bar., Kota Denpasar, Bali 80119, Indonesia	Jl. Gn. Bromo Gg. XI No.16	Tegal Kertha	Kec.	Denpasar	Kota Denpasar	-8.6635717	115.1965706	4.9	276		t	OPERATIONAL		0838-3193-3740	null	null							https://maps.google.com/?cid=17708874040017712000&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.780157+00	\N	2026-09-10 11:44:25.584403+00	2026-09-14 06:09:28.780157+00	f	\N
559946b5-f8be-4195-b00b-dab3ff43d3b0	9db7a179-c371-4b5f-82ff-70c756425086	ChIJdekFbwA50i0RFz7MO4GKQHA		MASVET. Dokter Hewan, Canggu.	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Raya Padonan No.67, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Raya Padonan No.67	Tibubeneng	Kec.	Kuta	Kabupaten Badung	-8.625930799999999	115.1626634	4.7	147		t	OPERATIONAL	https://masvetbali.com/?utm_source=googlemaps&utm_medium=organic	0819-1880-8081	["masvet.bali@gmail.com"]	null	https://www.facebook.com/tr	https://www.instagram.com/masvet_bali					https://maps.google.com/?cid=8088617218416066071&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.814034+00	2026-09-10 11:45:46.292027+00	2026-09-10 11:45:38.291307+00	2026-09-14 06:09:28.814034+00	f	\N
84109ba4-43ca-4ebc-a880-85fe45639b0c	0094f278-e3ca-46e4-980f-a66ec72f987f	ChIJmVAUEh5B0i0RL740zIm2ccc		Rumah Sakit Hewan Pendidikan - Universitas Udayana	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. Markisa No.6, Sesetan, Denpasar Selatan, Kota Denpasar, Bali 80225, Indonesia	Gg. Markisa No.6	Sesetan	Denpasar	Selatan	Kota Denpasar	-8.6918566	115.2163452	4.3	547		t	OPERATIONAL		0823-4274-9338	null	null							https://maps.google.com/?cid=14371468588868746799&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-11 10:47:52.779276+00	\N	2026-09-11 10:47:19.816505+00	2026-09-11 10:47:52.779276+00	f	\N
e6279b13-1d0a-43db-96e7-f9090957d3d8	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJ47_p3A5B0i0RckIfIhOlpNM		Canifeli Vet Bali	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pendidikan No.15, Sidakarya, Denpasar Selatan, Kota Denpasar, Bali 80224, Indonesia	Jl. Pendidikan No.15	Sidakarya	Denpasar	Selatan	Kota Denpasar	-8.702664799999999	115.2292674	4.7	426		t	OPERATIONAL	https://www.instagram.com/canifelivetbali/	0811-292-187	null	null							https://maps.google.com/?cid=15250495739778777714&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.38208+00	2026-09-10 11:44:31.355626+00	2026-09-10 11:44:25.605529+00	2026-09-14 06:08:46.38208+00	f	\N
cfb02932-7908-48d0-b217-446fad96d4cb	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJQRgZT60_0i0RWaqOH-iu2W0		Gatsu Veterinary Surgery (Drh. I Bagus Made Bhaskara)	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Intan LC II/X No.1, Tonja, Kec. Denpasar Utara, Kota Denpasar, Bali 80239, Indonesia	Jl. Intan LC II/X No.1	Tonja	Kec.	Denpasar	Kota Denpasar	-8.632849799999999	115.2244591	4.7	389		t	OPERATIONAL		0819-1615-9276	null	null							https://maps.google.com/?cid=7915550132065446489&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.385971+00	\N	2026-09-10 11:44:25.597755+00	2026-09-14 06:08:46.385971+00	f	\N
9aa6d0d2-b2ca-4d4a-a29b-749468ebb144	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJeTjYoDJB0i0R1t6FqmAz7NU		Tridatu Denpasar Veterinary	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Renon, Jl. Drupadi No.66A, Sumerta Kelod, Kec. Denpasar Tim., Kota Denpasar, Bali 80234, Indonesia	Renon	Jl. Drupadi No.66A	Sumerta	Kelod	Kec. Denpasar Tim.	-8.6635209	115.23336580000002	4.8	217		t	OPERATIONAL		0818-0521-6580	null	null							https://maps.google.com/?cid=15414752114853142230&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.388559+00	\N	2026-09-10 11:44:25.598826+00	2026-09-14 06:08:46.388559+00	f	\N
721dcf22-be2c-42f5-9bd5-c7805c9cf84a	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJ4XVUMgBB0i0R1oTd44s-ocI		Yuno Vet Denpasar	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Utama Ruko, Jl. Jaya Giri No.Kavling A2, Dangin Puri Klod, Kec. Denpasar Tim., Kota Denpasar, Bali 80234, Indonesia	Utama Ruko	Jl. Jaya Giri No.Kavling A2	Dangin	Puri	Kec. Denpasar Tim.	-8.6639021	115.22790300000001	5	117		t	OPERATIONAL		0878-9280-1675	null	null							https://maps.google.com/?cid=14024559485152756950&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.3896+00	\N	2026-09-10 11:44:25.596494+00	2026-09-14 06:08:46.3896+00	f	\N
3dafe204-9bad-4303-a93b-cf919925e1b4	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJMz2QkG5B0i0R96p0u52J7uk		Elmo Petshop & Vetcare Sanur	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Danau Beratan No.59, Sanur, Denpasar Selatan, Kota Denpasar, Bali 80227, Indonesia	Jl. Danau Beratan No.59	Sanur	Denpasar	Selatan	Kota Denpasar	-8.6792841	115.2543091	4.9	152		t	OPERATIONAL	https://www.instagram.com/elmopetshop/?hl=en	0851-7336-5959	null	null							https://maps.google.com/?cid=16856561765842201335&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.392712+00	2026-09-10 11:44:30.871379+00	2026-09-10 11:44:25.604233+00	2026-09-14 06:08:46.392712+00	f	\N
1101c0b5-1a73-4acb-b7f4-2ff7bdb18e2d	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJs_AUSpxB0i0RHd6zsab8nBg		B_Agus VET	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Mukti Sari No.50, Sanur Kauh, Denpasar Selatan, Kota Denpasar, Bali 80227, Indonesia	Jl. Mukti Sari No.50	Sanur Kauh	Denpasar	Selatan	Kota Denpasar	-8.6983217	115.2552789	5	19		t	OPERATIONAL		0813-3770-0808	null	null							https://maps.google.com/?cid=1773570146153258525&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.39403+00	\N	2026-09-10 11:44:25.60025+00	2026-09-14 06:08:46.39403+00	f	\N
0ca55886-5093-4f0c-a764-96b1727cf9cc	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJw6GUVWBH0i0RrWCNlaDfgc8		Semer Vet Care	Veterinary Care	["Pet Store", "Veterinary Care", "Pet Care", "Store", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Raya Semer Dukuh Sari Kerobokan No.170, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Raya Semer Dukuh Sari Kerobokan No.170	Kerobokan Kelod	Kec.	Kuta	Kabupaten Badung	-8.659398699999999	115.16297569999998	4.5	577		t	OPERATIONAL		0819-9994-2649	null	null							https://maps.google.com/?cid=14952478118643589293&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.396943+00	\N	2026-09-10 11:44:25.603386+00	2026-09-14 06:08:46.396943+00	f	\N
21ea620a-db69-4ce9-8102-798928a8831b	9db7a179-c371-4b5f-82ff-70c756425086	ChIJf57oeAhB0i0RRkpocWcbKGk		Budiana I Made Drh	Veterinary Care	["Pet Care", "Veterinary Care", "Doctor", "Point Of Interest", "Health", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Kerta Dalem Sari 3 No.10xx, Sidakarya, Denpasar Selatan, Kota Denpasar, Bali 80224, Indonesia	Jl. Kerta Dalem Sari 3 No.10xx	Sidakarya	Denpasar	Selatan	Kota Denpasar	-8.699153899999999	115.2333215	4.7	304		t	OPERATIONAL		0851-0090-1313	null	null							https://maps.google.com/?cid=7577336504149101126&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.789575+00	\N	2026-09-10 11:45:38.288062+00	2026-09-14 06:09:28.789575+00	f	\N
3db3a666-c5b7-499a-a1f7-7f150aa4350d	9db7a179-c371-4b5f-82ff-70c756425086	ChIJI9AzumZB0i0RwUgC8GywQfA		Virgin Pet Care	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Kepundung No.58, Dangin Puri Kangin, Kec. Denpasar Utara, Kota Denpasar, Bali 80234, Indonesia	Jl. Kepundung No.58	Dangin Puri Kangin	Kec.	Denpasar	Kota Denpasar	-8.6513942	115.2208354	4.9	109		t	OPERATIONAL	https://m.facebook.com/profile.php?id=1987186508164153&ref=content_filter	0857-3718-0283	null	null							https://maps.google.com/?cid=17312312424518535361&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.801982+00	2026-09-10 11:45:41.412159+00	2026-09-10 11:45:38.286953+00	2026-09-14 06:09:28.801982+00	f	\N
8fae56ac-3206-4e93-9631-b328d8deeecd	9db7a179-c371-4b5f-82ff-70c756425086	ChIJae0UKWNE0i0RLuR9rnYRYVg		Kedonganan Veterinary	Veterinary Care	["Veterinary Care", "Pet Boarding Service", "Pet Care", "Store", "Health", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Batas Kauh No.8B, Kedonganan, Kec. Kuta, Kabupaten Badung, Bali 80361, Indonesia	Jl. Batas Kauh No.8B	Kedonganan	Kec.	Kuta	Kabupaten Badung	-8.7671175	115.17171789999999	4.3	245		t	OPERATIONAL	http://www.kedongananveterinary.com/	0811-3993-630	["info@kedongananveterinary.com"]	null	https://www.facebook.com/kvetbali	https://www.instagram.com/kedongananveterinary/		https://twitter.com/kedongananveter	https://www.youtube.com/channel/UCpSupVA_QRw8QhF7xaet_cA		https://maps.google.com/?cid=6368390549509891118&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.820537+00	2026-09-10 11:45:50.791086+00	2026-09-10 11:45:38.309995+00	2026-09-14 06:09:28.820537+00	f	\N
b0398b8c-1537-47f4-8566-f0897ee206ca	0094f278-e3ca-46e4-980f-a66ec72f987f	ChIJEVYnWhVB0i0RC2FmWD6OvcQ		KIARA Pet Care	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Hasanuddin No.95, Pemecutan, Kec. Denpasar Bar., Kota Denpasar, Bali 80232, Indonesia	Jl. Hasanuddin No.95	Pemecutan	Kec.	Denpasar	Kota Denpasar	-8.658652199999999	115.2104906	4.8	16		t	OPERATIONAL		0877-9011-0777	null	null							https://maps.google.com/?cid=14176643600454410507&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-11 10:47:52.785472+00	\N	2026-09-11 10:47:19.826048+00	2026-09-14 06:07:51.439569+00	f	\N
4256f0cc-8bdf-4132-94fa-04e6ade8cc5c	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJAdrVdOFA0i0RzHP3JNWLw7U		Denpasar Veterinary	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Kumbakarna No.2A, Pemecutan Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80118, Indonesia	Jl. Kumbakarna No.2A	Pemecutan Kaja	Kec.	Denpasar	Kota Denpasar	-8.6522649	115.2111372	5	93		t	OPERATIONAL	https://instagram.com/denpasarveterinary	0811-3891-963	null	null							https://maps.google.com/?cid=13097465888888026060&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.380619+00	2026-09-10 11:45:41.195163+00	2026-09-10 11:45:38.258758+00	2026-09-14 06:08:46.380619+00	f	\N
f3e9dcce-d3c6-4252-a846-9de6a0b7b0db	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJLTtEExk_0i0RRyldOsPLMy8		Santi Vet Care	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Sari Dana. IV No.20, Ubung Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80116, Indonesia	Jl. Sari Dana. IV No.20	Ubung Kaja	Kec.	Denpasar	Kota Denpasar	-8.6271081	115.19151559999999	4.9	92		t	OPERATIONAL		0812-3707-2009	null	null							https://maps.google.com/?cid=3401286182953101639&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.387489+00	\N	2026-09-10 11:45:38.277671+00	2026-09-14 06:08:46.387489+00	f	\N
bb580b68-df24-4f7b-81de-04a0e1a435b1	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ7yVVkxNB0i0RHeIHCrpVebQ		Mayo Vet Bali	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pulau Singkep, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80114, Indonesia	Jl. Pulau Singkep	Pedungan	Denpasar	Selatan	Kota Denpasar	-8.6887407	115.2099001	4.9	44		t	OPERATIONAL	https://www.instagram.com/mayovetbali/	0878-2238-9555	null	null							https://maps.google.com/?cid=13004519656529584669&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.785916+00	2026-09-10 11:45:40.421334+00	2026-09-10 11:45:38.272272+00	2026-09-14 06:09:28.785916+00	f	\N
29942d8b-522e-4a99-9a29-94cafaa93771	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ0QFd4mU40i0Rkk5XRlogpik		BVC24H - Bali Veterinary Clinic Pererenan. 24-HOURS Animal Hospital	Veterinary Care	["Pharmacy", "Pet Store", "Veterinary Care", "Pet Boarding Service", "Pet Care", "Store", "Health", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pantai Pererenan No.81, Pererenan, Kec. Mengwi, Kabupaten Badung, Bali 80351, Indonesia	Jl. Pantai Pererenan No.81	Pererenan	Kec.	Mengwi	Kabupaten Badung	-8.6407793	115.13055089999997	4.2	347		t	OPERATIONAL	https://balivethospital.com/	0811-3893-171	null	null	https://www.facebook.com/balivetclinic	https://www.instagram.com/baliveterinaryclinic		https://twitter.com/BaliVetClinic			https://maps.google.com/?cid=3001121773788286610&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.787813+00	2026-09-10 11:44:30.290263+00	2026-09-10 11:44:25.588556+00	2026-09-14 06:09:28.787813+00	f	\N
f8d4c52f-3db8-483e-a1b3-d0c3fe95774f	9db7a179-c371-4b5f-82ff-70c756425086	ChIJB_h6huNA0i0RdJ8xtk-bo9s		Klinik drh.Winarta	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	No, Jl. Tukad Buaji Gg. XX No.20, Sesetan, Denpasar Selatan, Denpasar City, Bali 80225, Indonesia	No	Jl. Tukad Buaji Gg. XX No.20	Sesetan		Denpasar Selatan	-8.6853397	115.2209177	4.5	208		t	OPERATIONAL		(0361) 255517	null	null							https://maps.google.com/?cid=15826664282171481972&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.792888+00	\N	2026-09-10 11:45:38.284747+00	2026-09-14 06:09:28.792888+00	f	\N
27e2f040-ef95-4cbc-9c6d-c110105c75d3	9db7a179-c371-4b5f-82ff-70c756425086	ChIJo94VqFY_0i0R7n2BXXhm204		Praktek Dokter Hewan Bersama Drh. Eka Aryana (HELLO VET BALI)	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Padma, Tonja, Kec. Denpasar Utara, Kota Denpasar, Bali 80237, Indonesia	Jl. Padma	Tonja	Kec.	Denpasar	Kota Denpasar	-8.6253726	115.23032309999998	4.8	116		t	OPERATIONAL		0812-3806-8688	null	null							https://maps.google.com/?cid=5682248022008888814&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.794544+00	\N	2026-09-10 11:45:38.282935+00	2026-09-14 06:09:28.794544+00	f	\N
a372b6b2-f085-4f8b-a316-1666088fbc31	9db7a179-c371-4b5f-82ff-70c756425086	ChIJMaJ7TyxB0i0RgO-IsuiH2dA		JJ PET HOUSE & VET CARE TUKAD BALIAN	Pet Store	["Pet Store", "Pet Care", "Veterinary Care", "Store", "Point Of Interest", "Health", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Tukad Balian No.133A, Renon, Denpasar Selatan, Kota Denpasar, Bali 80221, Indonesia	Jl. Tukad Balian No.133A	Renon	Denpasar	Selatan	Kota Denpasar	-8.6931074	115.2418638	4.7	183		t	OPERATIONAL		0811-3810-3349	null	null							https://maps.google.com/?cid=15049209063332704128&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.79709+00	\N	2026-09-10 11:45:38.279494+00	2026-09-14 06:09:28.79709+00	f	\N
897d560b-bce0-4896-bfa4-f02b74e79294	9db7a179-c371-4b5f-82ff-70c756425086	ChIJw0F1WgBB0i0RGrKkxSk8HbY		VEE VET BALI	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Tukad Tegal Wangi No.22, Sesetan, Denpasar Selatan, Kota Denpasar, Bali 80225, Indonesia	Jl. Tukad Tegal Wangi No.22	Sesetan	Denpasar	Selatan	Kota Denpasar	-8.6887755	115.2191074	4.8	27		t	OPERATIONAL		0823-3936-3030	null	null							https://maps.google.com/?cid=13122711039334724122&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.81197+00	\N	2026-09-10 11:45:38.285902+00	2026-09-14 06:09:28.81197+00	f	\N
9940f536-f894-41be-9178-4f410a9b702b	9db7a179-c371-4b5f-82ff-70c756425086	ChIJi2wneLxB0i0RjQ9A4AyRGSA		Hello Vet Bali - Sedap Malam	Veterinary Care	["Veterinary Care", "Pet Care", "Store", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Sedap Malam No.502x, Sumerta Kelod, Kec. Denpasar Tim., Kota Denpasar, Bali 80237, Indonesia	Jl. Sedap Malam No.502x	Sumerta Kelod	Kec.	Denpasar	Kota Denpasar	-8.6608269	115.24978200000001	5	25		t	OPERATIONAL		0822-2756-8756	null	null							https://maps.google.com/?cid=2313039368119390093&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.826614+00	\N	2026-09-14 06:09:28.826614+00	2026-09-14 06:09:28.826614+00	f	\N
cb33cd18-0c14-443d-b36d-84b12b731a36	9db7a179-c371-4b5f-82ff-70c756425086	ChIJxZqMCoA_0i0RXoSgEJO2J3g		Dokter Hewan Ni Luh Ariani	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jalan Wage Rudolf Supratman No. 146 Kesiman Kertalangu, Sumerta Kelod, Kec. Denpasar Tim., Kota Denpasar, Bali 80235, Indonesia	Jalan Wage Rudolf Supratman No. 146 Kesiman Kertalangu	Sumerta Kelod	Kec.	Denpasar	Kota Denpasar	-8.6484459	115.2375744	4.6	103		t	OPERATIONAL		0831-1962-1317	null	null							https://maps.google.com/?cid=8658089551398470750&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.831652+00	\N	2026-09-14 06:09:28.831652+00	2026-09-14 06:09:28.831652+00	f	\N
141cee58-5fef-4126-8b6c-e4d1820bd732	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJ0T3U66M_0i0RuOINGMsMILA		Dokter Hewan Denpasar / i gede oka darsana	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Ahmad Yani Gg. I No.3, Dauh Puri Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80111, Indonesia	Jl. Ahmad Yani Gg. I No.3	Dauh Puri Kaja	Kec.	Denpasar	Kota Denpasar	-8.6427789	115.21238690000001	5	268		t	OPERATIONAL	https://linktr.ee/deokada	0896-0373-4404	null	null	https://www.facebook.com/Linktree/	https://instagram.com/vet_clinic_denpasar	https://www.linkedin.com/company/linktree	https://x.com/Linktree_	https://www.youtube.com/channel/UC8We2IKQo4lbongz7uOn2vA	https://www.tiktok.com/@linktr.ee	https://maps.google.com/?cid=12691157816351515320&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.377813+00	2026-09-10 11:44:27.09555+00	2026-09-10 11:44:25.590338+00	2026-09-14 06:08:46.377813+00	f	\N
e98b1c99-d582-4657-b894-81a23c95e4c7	9db7a179-c371-4b5f-82ff-70c756425086	ChIJS-9zRcI_0i0R2P93QJeZB-0		VET-9 . Penitipan Anjing dan Dokter Hewan Panggilan	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Sekar Tunjung XII No.8, Kesiman Kertalangu, Kec. Denpasar Tim., Kota Denpasar, Bali 80237, Indonesia	Jl. Sekar Tunjung XII No.8	Kesiman Kertalangu	Kec.	Denpasar	Kota Denpasar	-8.638423099999999	115.24906370000001	4.9	13		t	OPERATIONAL		0819-1647-7855	null	null							https://maps.google.com/?cid=17079788986726612952&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.807701+00	\N	2026-09-10 11:45:38.294651+00	2026-09-14 06:09:28.807701+00	f	\N
ef17b3ca-c1ad-49f8-bd85-c23ce336f95a	9db7a179-c371-4b5f-82ff-70c756425086	ChIJPYUCFf0_0i0RcNwWZsJJuog		Praktek mandiri Dokter Hewan Drh. I.A Ary Purnamasari	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Seroja No.52, Tonja, Kec. Denpasar Utara, Kota Denpasar, Bali 80235, Indonesia	Jl. Seroja No.52	Tonja	Kec.	Denpasar	Kota Denpasar	-8.6295661	115.22804430000001	4.8	54		t	OPERATIONAL		0818-8341-1172	null	null							https://maps.google.com/?cid=9852268234111638640&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.809055+00	\N	2026-09-10 11:45:38.293297+00	2026-09-14 06:09:28.809055+00	f	\N
a07522a1-292f-41ff-a040-5d1c14e50297	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ--WGAV8_0i0RVr5Be56Sz8Q		Estimo Pet House (Shop & Clinic) Setiabudi	Veterinary Care	["Pet Boarding Service", "Pet Store", "Pet Care", "Veterinary Care", "Store", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Setia Budi No.50, Pemecutan Kaja, Kec. Denpasar Bar., Kota Denpasar, Bali 80000, Indonesia	Jl. Setia Budi No.50	Pemecutan Kaja	Kec.	Denpasar	Kota Denpasar	-8.649074599999999	115.2091114	4.7	575		t	OPERATIONAL		(0361) 425815	null	null							https://maps.google.com/?cid=14181714960983375446&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.810734+00	\N	2026-09-10 11:45:38.298389+00	2026-09-14 06:09:28.810734+00	f	\N
9137bd08-b906-4ab3-b325-bc27681ab5ff	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ9RC7jmxB0i0Rrl6GMLac-L8		Praktek Dokter Hewan Drh Tjokorda Istri Agung Cintya Dalem	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. Adelia No.4, Sumerta Kelod, Kec. Denpasar Tim., Kota Denpasar, Bali 80237, Indonesia	Gg. Adelia No.4	Sumerta Kelod	Kec.	Denpasar	Kota Denpasar	-8.6560784	115.244148	5	27		t	OPERATIONAL		0857-3961-0828	null	null							https://maps.google.com/?cid=13832978561780571822&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.822186+00	\N	2026-09-10 11:45:38.302085+00	2026-09-14 06:09:28.822186+00	f	\N
f7b04bcf-7ad5-41ab-8615-7b3bd580f5a4	9db7a179-c371-4b5f-82ff-70c756425086	ChIJzY-wRABB0i0RHmSS2i51uTQ		PetLove Center Bali	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Danau Toba No.7, Sanur, Denpasar Selatan, Kota Denpasar, Bali 80227, Indonesia	Jl. Danau Toba No.7	Sanur	Denpasar	Selatan	Kota Denpasar	-8.6832706	115.26059079999997	5	60		t	OPERATIONAL		0812-3900-9168	null	null							https://maps.google.com/?cid=3799196604759696414&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.824995+00	\N	2026-09-10 11:45:38.300822+00	2026-09-14 06:09:28.824995+00	f	\N
b2033f5a-e233-464a-8fc8-28263ef0d60f	9db7a179-c371-4b5f-82ff-70c756425086	ChIJiVM8ya5B0i0R878uYVwU29s		Estimo Pet House (Shop & Clinic) Tarakan	Store	["Pet Store", "Pet Care", "Store", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pulau Tarakan No.23, Dauh Puri Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80113, Indonesia	Jl. Pulau Tarakan No.23	Dauh Puri Klod	Kec.	Denpasar	Kota Denpasar	-8.676592	115.20840349999999	4.7	175		t	OPERATIONAL	https://www.instagram.com/estimopethouseclinic/	0852-5300-4363	null	null							https://maps.google.com/?cid=15842278501205852147&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.833844+00	2026-09-10 11:45:42.498789+00	2026-09-10 11:45:38.304107+00	2026-09-14 06:09:28.833844+00	f	\N
773d911b-6409-49b3-9698-5bd59f9c87d3	9db7a179-c371-4b5f-82ff-70c756425086	ChIJH9Njye850i0REhPpmHQkp7g		Central Vet Canggu	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Pertokoan Teratai Bali, Jl. Raya Tanah Lot No.710-711, Munggu, Kec. Mengwi, Kabupaten Badung, Bali 80351, Indonesia	Pertokoan Teratai Bali	Jl. Raya Tanah Lot No.710-711	Munggu		Kec. Mengwi	-8.6286275	115.1301887	4.8	134		t	OPERATIONAL	https://www.instagram.com/centralvetcanggu/	0813-2094-8550	null	[]							https://maps.google.com/?cid=13305643707289637650&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.836157+00	2026-09-14 06:09:30.914743+00	2026-09-14 06:09:28.836157+00	2026-09-14 06:09:30.914743+00	f	\N
68c1502a-d00a-4b8b-8795-988ee860c2b5	4f354790-f764-4c3f-b2df-31944a5590eb	ChIJ023q4PxH0i0R-VgPn5LdI_U		Vethoscope Animal Care	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Dewi Sri II, Kuta, Kec. Kuta, Kabupaten Badung, Bali 80361, Indonesia	Jl. Dewi Sri II	Kuta	Kec.	Kuta	Kabupaten Badung	-8.7052605	115.1794018	4.7	261		t	OPERATIONAL		0812-3285-0548	null	null							https://maps.google.com/?cid=17664205785280764153&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:46:06.142426+00	\N	2026-09-10 11:45:38.296336+00	2026-09-10 11:46:06.142426+00	f	\N
b65a6015-2cb6-4a4e-9649-66cae7f222a6	0094f278-e3ca-46e4-980f-a66ec72f987f	ChIJpdWAQI5A0i0RpQGpjHZ5I4k		Dokter Hewan Jiwa Kepakisan	Veterinary Care	["Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Jaya Giri XIII No.15, Dangin Puri Klod, Kec. Denpasar Tim., Kota Denpasar, Bali 80232, Indonesia	Jl. Jaya Giri XIII No.15	Dangin Puri Klod	Kec.	Denpasar	Kota Denpasar	-8.6630305	115.22598949999998	4.8	10		t	OPERATIONAL		0812-3995-114	null	null							https://maps.google.com/?cid=9881875557453988261&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-11 10:47:52.786751+00	\N	2026-09-10 11:45:38.325434+00	2026-09-11 10:47:52.786751+00	f	\N
f4ec2f66-7c76-45d6-9b10-95b178146ce2	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJtdJpFThH0i0Ri_n8knCS6MU		Central Vet	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Raya Kedampang Gg. Arjuna, Kerobokan, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Raya Kedampang Gg. Arjuna	Kerobokan	Kec.	Kuta	Kabupaten Badung	-8.6595056	115.1727532	4.5	654		t	OPERATIONAL		0811-3890-030	null	null							https://maps.google.com/?cid=14260809232268720523&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.384561+00	\N	2026-09-10 11:44:25.594365+00	2026-09-14 06:08:46.384561+00	f	\N
40ec0785-f8bd-4fef-b681-9b0db9e4d83e	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJ0ZOmGmlB0i0RBvX4u2kcEUY		Anom Vet Service	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. Sehati Jl. Bypass Ngurah Rai No.9A, Sesetan, Denpasar Selatan, Kota Denpasar, Bali 80223, Indonesia	Gg. Sehati Jl. Bypass Ngurah Rai No.9A	Sesetan	Denpasar	Selatan	Kota Denpasar	-8.716569699999999	115.21684289999999	4.2	312		t	OPERATIONAL	http://anomvet.com/	(0361) 723777	["anom_vetclinic@yahoo.com"]	null	https://www.facebook.com/anomveterinaryclinic/	https://www.instagram.com/anomvet			https://www.youtube.com/channel/UC-RGhP1xkmo4gIGkIesO4Eg		https://maps.google.com/?cid=5048847897709835526&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.395397+00	2026-09-10 11:44:35.075912+00	2026-09-10 11:44:25.601571+00	2026-09-14 06:08:46.395397+00	f	\N
0172d0e7-2e6f-4b26-8de7-5039719368a9	9db7a179-c371-4b5f-82ff-70c756425086	ChIJhzIlxJ1B0i0RWvS_QkADPCE		Amore Denpasar	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Gunung Sanghyang No.89, Kerobokan Kaja, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Gunung Sanghyang No.89	Kerobokan Kaja	Kec.	Kuta	Kabupaten Badung	-8.6470725	115.17588429999999	4.5	328		t	OPERATIONAL		0812-3774-8918	null	null							https://maps.google.com/?cid=2394792676386927706&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.79585+00	\N	2026-09-10 11:45:38.299578+00	2026-09-14 06:09:28.79585+00	f	\N
6c472471-f81e-4a87-8577-626fa7527d63	9db7a179-c371-4b5f-82ff-70c756425086	ChIJpzZRsGxB0i0RQV4yX2My-NA		Animal Clinic DR. Dharma	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Raya Sesetan Jl. Pesanggaran No.338, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80223, Indonesia	Jl. Raya Sesetan Jl. Pesanggaran No.338	Pedungan	Denpasar	Selatan	Kota Denpasar	-8.7108524	115.21949989999999	4.6	127		t	OPERATIONAL	http://www.dharmavetclinic.com/	(0361) 726856	null	null					https://www.youtube.com/embed/		https://maps.google.com/?cid=15057840756493540929&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.806481+00	2026-09-10 11:45:51.842841+00	2026-09-10 11:45:38.314233+00	2026-09-14 06:09:28.806481+00	f	\N
a46cf699-5c7a-416a-aa5f-3e5bd3573253	9db7a179-c371-4b5f-82ff-70c756425086	ChIJyWAVAGVB0i0RGCBknFsgOVw		Green Vet	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Sedap Malam Gg. Rampai I no.10, Kesiman Kelod, Sumerta Kelod, East Denpasar, Denpasar City, Bali 80237, Indonesia	Jl. Sedap Malam Gg. Rampai I no.10	Kesiman Kelod	Sumerta	Kelod	East Denpasar	-8.6582653	115.2500157	4.8	27		t	OPERATIONAL		0818-0531-7754	null	null							https://maps.google.com/?cid=6645378302999797784&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.819392+00	\N	2026-09-10 11:45:38.316169+00	2026-09-14 06:09:28.819392+00	f	\N
ed2b27d9-7619-477e-9a60-cdd2da2d513a	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ05AXBchA0i0RGupKssceHM0		Klinik Hewan Kalimutu	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Gn. Kalimutu XIX No.36, Pemecutan Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80113, Indonesia	Jl. Gn. Kalimutu XIX No.36	Pemecutan Klod	Kec.	Denpasar	Kota Denpasar	-8.671844	115.2001329	4.6	79		t	OPERATIONAL		0812-3984-465	null	null							https://maps.google.com/?cid=14779721920161704474&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.8297+00	\N	2026-09-10 11:45:38.321606+00	2026-09-14 06:09:28.8297+00	f	\N
e30fe0f6-5554-45ce-8384-19c35ddf58fc	9db7a179-c371-4b5f-82ff-70c756425086	ChIJSaYQqphB0i0ROg2UDvqzp5g		Vet4pets	Veterinary Care	["Veterinary Care", "Corporate Office", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Plawa No.22, Sumerta Kauh, Kec. Denpasar Tim., Kota Denpasar, Bali 80236, Indonesia	Jl. Plawa No.22	Sumerta Kauh	Kec.	Denpasar	Kota Denpasar	-8.6504976	115.22722919999998	5	14		t	OPERATIONAL		0821-4754-5919	null	null							https://maps.google.com/?cid=10999958501443505466&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.838624+00	\N	2026-09-10 11:45:38.311497+00	2026-09-14 06:09:28.838624+00	f	\N
46558496-535b-4e8e-9af1-78bc1ec80c6b	9db7a179-c371-4b5f-82ff-70c756425086	ChIJXb1RQwBH0i0RQaqVcH_x6dI		Dokter Hewan Panggilan ke Rumah - House Call Vet Home Visit Drh. Carene Naomi	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Perum Padang Lestari, Kerobokan Kaja, Kec. Kuta Utara, Kabupaten Badung, Bali 80117, Indonesia	Jl. Perum Padang Lestari	Kerobokan Kaja	Kec.	Kuta	Kabupaten Badung	-8.6598277	115.1787363	4.9	52		t	OPERATIONAL		0878-2326-8200	null	null							https://maps.google.com/?cid=15197943947190446657&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.841481+00	\N	2026-09-14 06:09:28.841481+00	2026-09-14 06:09:28.841481+00	f	\N
2b28f447-0f4a-452f-9e7b-643df4e0e4ac	9db7a179-c371-4b5f-82ff-70c756425086	ChIJf57WpflB0i0RiU56ZmwzqzY		PULU VET CARE	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "New Business", "Veterinarian in Denpasar, Bali"]	Jl. Imam Bonjol No.257, Pemecutan Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80113, Indonesia	Jl. Imam Bonjol No.257	Pemecutan Klod	Kec.	Denpasar	Kota Denpasar	-8.675912199999999	115.20167879999998	5	4		t	OPERATIONAL		0823-1405-4720	null	null							https://maps.google.com/?cid=3939298839734406793&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.849161+00	\N	2026-09-10 11:45:38.319857+00	2026-09-14 06:09:28.849161+00	f	\N
cc056134-fd86-42cb-b757-5d9ad0c0bd06	0094f278-e3ca-46e4-980f-a66ec72f987f	ChIJ72grgkNH0i0R68-6WxhIu0U		KAIA Vet	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Perumahan Puri Tegal Buah Jl. Graha Parta Lestari No.A9, Padangsambian Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80117, Indonesia	Perumahan Puri Tegal Buah Jl. Graha Parta Lestari No.A9	Padangsambian Klod	Kec.	Denpasar	Kota Denpasar	-8.665536399999999	115.18497939999999	5	14		t	OPERATIONAL		0813-3855-8030	null	null							https://maps.google.com/?cid=5024689078717304811&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-11 10:47:52.783297+00	\N	2026-09-10 11:45:38.32268+00	2026-09-11 10:47:52.783297+00	f	\N
1d64611e-6504-4206-af30-6287b81231fe	9db7a179-c371-4b5f-82ff-70c756425086	ChIJw1A_NQA_0i0R8wycilmI8_s		Vetology Pet Shop and Vet Care	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. WR Supratman No.888, Kesiman Kertalangu, Kec. Denpasar Tim., Kota Denpasar, Bali 80237, Indonesia	Jl. WR Supratman No.888	Kesiman Kertalangu	Kec.	Denpasar	Kota Denpasar	-8.6435882	115.2486966	5	78		t	OPERATIONAL	https://www.instagram.com/vetology.id/	0821-4274-3127	null	null							https://maps.google.com/?cid=18155004441019550963&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.798358+00	2026-09-10 11:45:40.355141+00	2026-09-10 11:45:38.281136+00	2026-09-14 06:09:28.798358+00	f	\N
a61d76a8-c082-4799-ac26-f419a8ceb501	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ3XPoGHVB0i0RViTsDDjoDQA		Nency Vet Care (Dokter hewan / Veterinarian)	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. 4A No.21, Pemecutan, Kec. Denpasar Bar., Kota Denpasar, Bali 80111, Indonesia	Gg. 4A No.21	Pemecutan	Kec.	Denpasar	Kota Denpasar	-8.6548257	115.19979269999999	4.8	16		t	OPERATIONAL	https://instagram.com/9.c_vetbali?utm_medium=copy_link	0819-3310-2007	null	null							https://maps.google.com/?cid=3914502129853526&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.800394+00	2026-09-10 11:45:44.442884+00	2026-09-10 11:45:38.318619+00	2026-09-14 06:09:28.800394+00	f	\N
21f562f3-5c6b-43e8-be5c-c4077bc20cdb	9db7a179-c371-4b5f-82ff-70c756425086	ChIJeWblt6hB0i0RJYrCx4a7ZzI		Pedungan Vet Care	Veterinary Care	["Pet Care", "Veterinary Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pulau Belitung No.3, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80222, Indonesia	Jl. Pulau Belitung No.3	Pedungan	Denpasar	Selatan	Kota Denpasar	-8.6910515	115.20616849999999	4.6	64		t	OPERATIONAL	https://www.facebook.com/pedungan.vetcare/	0813-3793-4685	null	null							https://maps.google.com/?cid=3632077812049021477&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.803271+00	2026-09-10 11:45:40.462401+00	2026-09-10 11:45:38.289346+00	2026-09-14 06:09:28.803271+00	f	\N
4c1cd26e-7f90-46da-9821-ab364bd17da3	9db7a179-c371-4b5f-82ff-70c756425086	ChIJR6lqoidB0i0RN7cy2TnKHLw		Klinik Hewan Drh. Gusti Ngurah Made Yudha Kumara	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pura Penataran Anyar, Br. Pitik, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80114, Indonesia	Jl. Pura Penataran Anyar	Br. Pitik	Pedungan		Denpasar Selatan	-8.692673	115.2032045	4.9	94		t	OPERATIONAL		0812-3929-816	null	null							https://maps.google.com/?cid=13554931328284276535&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.818011+00	\N	2026-09-10 11:45:38.330226+00	2026-09-14 06:09:28.818011+00	f	\N
84158bd4-6556-4f83-8e9d-feabd9657c04	19d713ab-d1b1-4367-9212-0c2f60a5c0eb	ChIJW1G_-le_sQ8RnAQnW7esefo		Drh Intan Pratiwi	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jln gunung andakasa, lingk tegal sari Gg. Matahari XIV No.5, Padangsambian, Kec. Denpasar Bar., Kota Denpasar, Bali 80117, Indonesia	Jln gunung andakasa	lingk tegal sari Gg. Matahari XIV No.5	Padangsambian		Kec. Denpasar Bar.	-8.648054799999999	115.1920409	4.5	8		t	OPERATIONAL		0822-6627-2391	null	null							https://maps.google.com/?cid=18048646885172249756&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-10 11:45:38.335911+00	\N	2026-09-10 11:45:38.335911+00	2026-09-10 11:45:38.335911+00	f	\N
153443ad-3e4f-47ac-a70c-3e13bfc981df	9db7a179-c371-4b5f-82ff-70c756425086	ChIJl7HlNn1B0i0R2tCDElY4ttE		Lemon Pet Care (Prakter Dokter Hewan, Pet Grooming, Penitipan Kucing)	Veterinary Care	["Veterinary Care", "Pet Boarding Service", "Pet Care", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. Tunjung Biru No.12, Kesiman, Kec. Denpasar Tim., Kota Denpasar, Bali 80237, Indonesia	Gg. Tunjung Biru No.12	Kesiman	Kec.	Denpasar	Kota Denpasar	-8.6691676	115.2497044	5	87		t	OPERATIONAL		0821-4676-2678	null	null							https://maps.google.com/?cid=15111327542017249498&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.823517+00	\N	2026-09-10 11:45:38.333823+00	2026-09-14 06:09:28.823517+00	f	\N
ecb9e1be-3b62-41fc-87fa-057c903df9e7	9db7a179-c371-4b5f-82ff-70c756425086	ChIJAY7CUl4_0i0RB3EKAfahGPE		Drh. I Made Jiestara	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Sutomo No.94, Pemecutan Kaja, Kec. Denpasar Utara, Kota Denpasar, Bali 80118, Indonesia	Jl. Sutomo No.94	Pemecutan Kaja	Kec.	Denpasar	Kota Denpasar	-8.648011499999999	115.2102858	5	28		t	OPERATIONAL		0851-0256-7909	null	null							https://maps.google.com/?cid=17372813640533176583&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.839985+00	\N	2026-09-10 11:45:38.331755+00	2026-09-14 06:09:28.839985+00	f	\N
fb800f0a-62f2-4959-a8cd-d4087f528a13	9db7a179-c371-4b5f-82ff-70c756425086	ChIJOYC5P9dA0i0RxKYN5Itj6AI		Dokter Hewan Inu Neko	Pet Care	["Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pulau Batanta No.11A, Dauh Puri Kauh, Kec. Denpasar Bar., Kota Denpasar, Bali 80113, Indonesia	Jl. Pulau Batanta No.11A	Dauh Puri Kauh	Kec.	Denpasar	Kota Denpasar	-8.682165699999999	115.2006954	4.1	179		t	OPERATIONAL		0851-0043-4996	null	null							https://maps.google.com/?cid=209526835150431940&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.842967+00	\N	2026-09-10 11:45:38.317533+00	2026-09-14 06:09:28.842967+00	f	\N
c3176a82-2b9b-461c-9386-1fe658dd6dfc	9db7a179-c371-4b5f-82ff-70c756425086	ChIJywvvlFlA0i0RzcMrPGv_qyA		Drh Agung Wirawan	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jalan Tukad Yeh Aya Gang IX c No.25, Renon, Denpasar Selatan, Kota Denpasar, Bali 80234, Indonesia	Jalan Tukad Yeh Aya Gang IX c No.25	Renon	Denpasar	Selatan	Kota Denpasar	-8.6800408	115.240392	4.3	55		t	OPERATIONAL	https://agungwira.com/	0812-3831-237	["info@dokterhewandenpasar.id"]	null							https://maps.google.com/?cid=2354256066267300813&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:09:28.84717+00	2026-09-10 11:45:43.037817+00	2026-09-10 11:45:38.328808+00	2026-09-14 06:09:28.84717+00	f	\N
c78297dc-7f01-40f0-bddd-8099def49727	0094f278-e3ca-46e4-980f-a66ec72f987f	ChIJ63DXJFxH0i0RPHzeGnDNrgY		Dokter Hewan Cashandra Dewi veterinary	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	block C perum malboro indah residence Jl. Gn. Talang VIC perum malboro indah residence block C, Padangsambian Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80112, Indonesia	block C perum malboro indah residence Jl. Gn. Talang VIC perum malboro indah residence block C	Padangsambian Klod	Kec.	Denpasar	Kota Denpasar	-8.6739497	115.18651679999998	4.7	14		t	OPERATIONAL		0819-9943-2121	null	null							https://maps.google.com/?cid=481548091546041404&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-11 10:47:52.788229+00	\N	2026-09-10 11:45:38.326809+00	2026-09-11 10:47:52.788229+00	f	\N
5ec5c6df-e7ba-40c5-b871-3cfc44a59378	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJgY4JhDpH0i0RZBZnJmnnPus		Hadiprata Vet	Veterinary Care	["Pharmacy", "Pet Store", "Veterinary Care", "Pet Boarding Service", "Pet Care", "Store", "Health", "Point Of Interest", "Service", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Persada, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Jl. Persada	Kerobokan Kelod	Kec.	Kuta	Kabupaten Badung	-8.6770294	115.1759501	4.9	604		t	OPERATIONAL		0822-8887-7886	null	null							https://maps.google.com/?cid=16951240486270998116&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:08:46.391049+00	\N	2026-09-10 11:44:25.595688+00	2026-09-14 06:08:46.391049+00	f	\N
d8d13b88-92b2-43c5-921f-757b86d49158	56d70ff1-409c-468b-80a8-b8bf6fede65a	ChIJ944OYz450i0Ra58O1by7fo8		Island Vet Bali - Canggu	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Gg. Kresna No.1A, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361, Indonesia	Gg. Kresna No.1A	Tibubeneng	Kec.	Kuta	Kabupaten Badung	-8.6500944	115.1497174	4.8	255		t	OPERATIONAL	http://www.islandvetbali.com/	0813-9119-1129	["reception@islandvetbali.com", "605a7baede844d278b89dc95ae0a9123@sentry-next.wixpress.com", "dd0a55ccb8124b9c9d938e3acf41f8aa@sentry.wixpress.com", "c183baa23371454f99f417f6616b724d@sentry.wixpress.com", "ed436f5053144538958ad06a5005e99a@sentry.wixpress.com", "460ff4620fa44cba8df530afde949785@sentry.wixpress.com", "1eeb89147c984dc6bc3ffafd9e6cd089@sentry.wixpress.com", "79baaa8e09c746d2b7401643b99792e0@sentry.wixpress.com", "8eb368c655b84e029ed79ad7a5c1718e@sentry.wixpress.com", "2062d0a4929b45348643784b5cb39c36@sentry.wixpress.com", "271e9fa3230b4eec94b02bf95780f5f2@sentry.wixpress.com"]	null		https://instagram.com/islandvetbali					https://maps.google.com/?cid=10339908214191988587&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	SUCCESS	2026-09-14 06:08:46.398225+00	2026-09-10 11:44:30.629252+00	2026-09-10 11:44:25.602522+00	2026-09-14 06:08:46.398225+00	f	\N
35a3d3ce-e2bb-47bd-9355-3ad3c6c36316	9db7a179-c371-4b5f-82ff-70c756425086	ChIJjdw-OepB0i0R5n-Qt2QDMAs		Anima Vet Care Bali	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Tukad Melangit No.54, Dauh Puri Klod, Kec. Denpasar Bar., Kota Denpasar, Bali 80225, Indonesia	Jl. Tukad Melangit No.54	Dauh Puri Klod	Kec.	Denpasar	Kota Denpasar	-8.6827948	115.2233854	5	110		t	OPERATIONAL		0823-4000-6177	null	null							https://maps.google.com/?cid=806148064410632166&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.791006+00	\N	2026-09-10 11:44:25.592907+00	2026-09-14 06:09:28.791006+00	f	\N
6dbe56c5-0198-452e-ab1c-aa4fc9a6c576	9db7a179-c371-4b5f-82ff-70c756425086	ChIJzW8dNAA50i0RXQfLR3FzUtE		CatNis Vet Care - Dokter Hewan	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Mangga Sari No.7, Padangsambian Kaja, Kec. Denpasar Bar., Kota Denpasar, Bali 80117, Indonesia	Jl. Mangga Sari No.7	Padangsambian Kaja	Kec.	Denpasar	Kota Denpasar	-8.639289	115.1873476	5	46		t	OPERATIONAL		0819-3629-6412	null	null							https://maps.google.com/?cid=15083245032390199133&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.804639+00	\N	2026-09-10 11:45:38.312893+00	2026-09-14 06:09:28.804639+00	f	\N
7c3c9f4c-1300-45d0-b800-ecb4040dce19	9db7a179-c371-4b5f-82ff-70c756425086	ChIJ96i3wGI_0i0RaTFhyWHIrQc		BORA PET CARE	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Trengguli No.93, Penatih, Kec. Denpasar Tim., Kota Denpasar, Bali 80238, Indonesia	Jl. Trengguli No.93	Penatih	Kec.	Denpasar	Kota Denpasar	-8.6257504	115.2409486	4.9	78		t	OPERATIONAL		0853-3376-6041	null	null							https://maps.google.com/?cid=553318651552412009&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.844359+00	\N	2026-09-10 11:45:38.307034+00	2026-09-14 06:09:28.844359+00	f	\N
5bdf8806-11d5-40f9-8f9c-c1af0d17d1de	9db7a179-c371-4b5f-82ff-70c756425086	ChIJTw0KMbA50i0REMWtWaB25lY		Kartini Veterinary (home visit only)	Veterinary Care	["Veterinary Care", "Pet Care", "Point Of Interest", "Establishment", "Veterinarian in Denpasar, Bali"]	Jl. Pertiwi Indah Residence No.9, Padangsambian Kaja, Kec. Denpasar Bar., Kota Denpasar, Bali 80117, Indonesia	Jl. Pertiwi Indah Residence No.9	Padangsambian Kaja	Kec.	Denpasar	Kota Denpasar	-8.6305108	115.1815649	5	1		t	OPERATIONAL		0857-3972-6020	null	null							https://maps.google.com/?cid=6261822762976658704&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA	null	null	NONE	2026-09-14 06:09:28.846131+00	\N	2026-09-11 10:47:19.81958+00	2026-09-14 06:09:28.846131+00	f	\N
\.


--
-- Data for Name: scrape_jobs; Type: TABLE DATA; Schema: public; Owner: momos_scraper_user
--

COPY public.scrape_jobs (id, status, query, location, category, max_results, enrich_contacts, total_scraped, total_enriched, error_count, error_message, metadata, started_at, completed_at, created_at, updated_at) FROM stdin;
ce170763-0a71-462f-bfc1-6d5e422dbd53	COMPLETED	Cafe in Denpasar	Google Maps	Keyword Scrape	20	t	20	3	0		null	2026-09-10 11:34:50.861247+00	2026-09-10 11:34:51.478057+00	2026-09-10 11:34:50.861248+00	2026-09-10 11:34:56.028312+00
42299b6d-82c5-4f54-9764-35ac0b6f7740	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	20	t	20	3	0		null	2026-09-10 11:44:25.193993+00	2026-09-10 11:44:25.606733+00	2026-09-10 11:44:25.193994+00	2026-09-10 11:44:35.077303+00
19d713ab-d1b1-4367-9212-0c2f60a5c0eb	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	60	t	40	3	0		null	2026-09-10 11:45:36.539641+00	2026-09-10 11:45:38.337734+00	2026-09-10 11:45:36.539642+00	2026-09-10 11:45:50.796281+00
4f354790-f764-4c3f-b2df-31944a5590eb	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	40	t	40	0	0		null	2026-09-10 11:46:04.55123+00	2026-09-10 11:46:06.148664+00	2026-09-10 11:46:04.551231+00	2026-09-10 11:46:06.148612+00
4d7ee307-ec7c-4f27-949e-5462ffda9f89	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	100	t	20	0	0		null	2026-09-11 10:47:19.322103+00	2026-09-11 10:47:19.834853+00	2026-09-11 10:47:19.322104+00	2026-09-11 10:47:19.834154+00
1725be61-0be4-4e28-8c5f-5bb744d4471f	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	40	t	40	0	0		null	2026-09-11 10:47:30.549888+00	2026-09-11 10:47:32.341013+00	2026-09-11 10:47:30.549889+00	2026-09-11 10:47:32.340964+00
b27e4b4a-fa74-4d74-b96e-975b9594690d	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	100	t	20	0	0		null	2026-09-11 10:47:36.759372+00	2026-09-11 10:47:37.075515+00	2026-09-11 10:47:36.759372+00	2026-09-11 10:47:37.075356+00
0094f278-e3ca-46e4-980f-a66ec72f987f	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	100	t	60	0	0		null	2026-09-11 10:47:50.028182+00	2026-09-11 10:47:52.793989+00	2026-09-11 10:47:50.028183+00	2026-09-11 10:47:52.793653+00
56d70ff1-409c-468b-80a8-b8bf6fede65a	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	20	t	0	0	0		null	2026-09-14 06:08:45.816945+00	2026-09-14 06:08:46.40064+00	2026-09-14 06:08:45.816945+00	2026-09-14 06:08:46.400004+00
9db7a179-c371-4b5f-82ff-70c756425086	COMPLETED	Veterinarian in Denpasar, Bali	Google Maps	Keyword Scrape	40	t	4	0	0		null	2026-09-14 06:09:27.05212+00	2026-09-14 06:09:28.853821+00	2026-09-14 06:09:27.05212+00	2026-09-14 06:09:28.853586+00
\.


--
-- Data for Name: scraper_keywords; Type: TABLE DATA; Schema: public; Owner: momos_scraper_user
--

COPY public.scraper_keywords (id, keyword, next_page_token, current_page, total_leads_scraped, last_scraped_at, status, is_active, created_at, updated_at) FROM stdin;
3d30e840-3278-43f0-860e-64effa66d55e	Cafe in Denpasar	AVoNoXQZ_vi58-CjnxKksp9BHuS7ivoqKY_1GbmeWjwwxWeanoZDVW2ah6S4HpH_76OOVI3lRLoXskwC8r2Z94XuiC1Orcphl-5qh5klj4BlRlXjSGvKlgMbfc4bkDdK-HgRbyq8WBKc8AJAf_H8kx9vUuyWocsF-JsSp6ti13JP9SlDAf_RTErrNjhJQSt_THIZu7cHrlzPE5jGo8BYy6F1CpjIXQp8tJobH3ykMeafS1Yk7ol8jQNbmByfg0qY0Bn8JuzBi_aRcuoA9mpbXe-s6mtwhH3QPrT8-NFsLDCCB9wS4mxIdt2i9xDXr6JVmnuHpvsBab8K63PWKwbnt03YKrihkfiawTblLZP_ep-8ak-y_QdqwOdePxhlBXvfIGyZqMZCNHOJDdHU4K7FRgARWgtmfnM5N03DpxiGQS-kpgtakTZv0Gqf44yJ-f999BAVw9DwqNiFEqHcYnB-gNgDi5_bGnW9cdgmFxsir7UKEnVvFOSXbsAs8JNqondPpK6qstbTAYUqP5lljKvM_ZXzcP_mPqyinTXhgRVFzMiOMPfjZOk9eJVclQ86faZuQy3uIhKhpAgoikQvL2ImK9hj1t95fQOfGzXJ2oZBAwN-mbT1puI-MSKIh3Mq4fG-AV07eeX7hr6s-h5sIa1VhS6kLvOX-YlnHnH2TKoSd4bsTpQSk3m7RzMjZDQ0dU8FqpfxuQkv3FCpRZHtJg9fONk64pfKuxhpbVvonEpjf6nEnMI33ImxfmErdN6ppD2qLvO4x46-vfz4l1vqZN98zWDcP3BW6cay8YWaklDRI4jIEBHpI3RZYhhIlBxvwB491oeEKLDE5etvFpQ	2	20	2026-09-10 11:34:51.479517+00	paginating	f	2026-09-10 11:34:42.974389+00	2026-09-10 11:34:51.479517+00
8f782e78-46ef-4ff0-b03d-0342f83d4790	Veterinarian in Badung, Bali		1	0	\N	ready	f	2026-09-10 11:41:07.080801+00	2026-09-10 11:43:22.522529+00
65acecb1-44de-4ac6-89fe-bf03bce989eb	Law Firm in\tDenpasar, Bali		1	0	\N	ready	f	2026-09-10 11:42:08.030794+00	2026-09-10 11:43:32.366233+00
4ca05312-706c-4b7d-8205-8a3251ddf35d	Law Firm in\tBadung, Bali		1	0	\N	ready	f	2026-09-10 11:43:46.49065+00	2026-09-10 11:43:46.49065+00
456071a8-5702-4295-b3d1-b3f51015f498	Veterinarian in Denpasar, Bali		1	244	2026-09-14 06:09:28.854485+00	completed	f	2026-09-10 11:40:54.072171+00	2026-09-14 06:09:28.854485+00
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: momos_scraper_user
--

COPY public.system_settings (key, value, updated_at) FROM stdin;
\.


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: business_leads business_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.business_leads
    ADD CONSTRAINT business_leads_pkey PRIMARY KEY (id);


--
-- Name: business_leads business_leads_place_id_key; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.business_leads
    ADD CONSTRAINT business_leads_place_id_key UNIQUE (place_id);


--
-- Name: scrape_jobs scrape_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.scrape_jobs
    ADD CONSTRAINT scrape_jobs_pkey PRIMARY KEY (id);


--
-- Name: scraper_keywords scraper_keywords_keyword_key; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.scraper_keywords
    ADD CONSTRAINT scraper_keywords_keyword_key UNIQUE (keyword);


--
-- Name: scraper_keywords scraper_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.scraper_keywords
    ADD CONSTRAINT scraper_keywords_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: idx_business_leads_category; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_category ON public.business_leads USING btree (category);


--
-- Name: idx_business_leads_city; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_city ON public.business_leads USING btree (city);


--
-- Name: idx_business_leads_contacted; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_contacted ON public.business_leads USING btree (contacted);


--
-- Name: idx_business_leads_created_at; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_created_at ON public.business_leads USING btree (created_at DESC);


--
-- Name: idx_business_leads_enrichment_status; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_enrichment_status ON public.business_leads USING btree (enrichment_status);


--
-- Name: idx_business_leads_job_id; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_job_id ON public.business_leads USING btree (job_id);


--
-- Name: idx_business_leads_lower_name_city; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_lower_name_city ON public.business_leads USING btree (lower((name)::text), lower((city)::text));


--
-- Name: idx_business_leads_lower_website; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_lower_website ON public.business_leads USING btree (lower(website));


--
-- Name: idx_business_leads_name; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_name ON public.business_leads USING btree (name);


--
-- Name: idx_business_leads_phone; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_phone ON public.business_leads USING btree (primary_phone);


--
-- Name: idx_business_leads_rating; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_business_leads_rating ON public.business_leads USING btree (rating DESC);


--
-- Name: idx_scrape_jobs_created_at; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_scrape_jobs_created_at ON public.scrape_jobs USING btree (created_at DESC);


--
-- Name: idx_scrape_jobs_status; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_scrape_jobs_status ON public.scrape_jobs USING btree (status);


--
-- Name: idx_scraper_keywords_active; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_scraper_keywords_active ON public.scraper_keywords USING btree (is_active);


--
-- Name: idx_scraper_keywords_status; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_scraper_keywords_status ON public.scraper_keywords USING btree (status);


--
-- Name: idx_scraper_keywords_updated_at; Type: INDEX; Schema: public; Owner: momos_scraper_user
--

CREATE INDEX idx_scraper_keywords_updated_at ON public.scraper_keywords USING btree (updated_at DESC);


--
-- Name: business_leads business_leads_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: momos_scraper_user
--

ALTER TABLE ONLY public.business_leads
    ADD CONSTRAINT business_leads_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.scrape_jobs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict FWKIxMhdCRGVaVvIWAjMqjEqFZ4Wd6dOzyunvLig7U7vzkbwRmxIt4bJL10Q0JE

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict pJBUlmh0kKrhNZoDfDh9qwzhgxL8rW4kf6suRx2dT9e7l21H5av6x3eLSLxaZyo

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict pJBUlmh0kKrhNZoDfDh9qwzhgxL8rW4kf6suRx2dT9e7l21H5av6x3eLSLxaZyo

--
-- PostgreSQL database cluster dump complete
--

