--
-- PostgreSQL database cluster dump
--

\restrict do1285EvtAZUPcNibtNXNJq0zT3ByawunEVoV8T4nfzOaAEwXowUcc8ava2dgH7

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE momos_user;
ALTER ROLE momos_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:+gQCoDk5ufAgk8w4mGH8HA==$UZI/YJOeIvARN0jg9NRxTXEONsZX26yIpLTReEy2Mwo=:XGatNzdI3ORuV2pVNnkzByqSZJ91huZbjSapHbYHmic=';

--
-- User Configurations
--








\unrestrict do1285EvtAZUPcNibtNXNJq0zT3ByawunEVoV8T4nfzOaAEwXowUcc8ava2dgH7

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict gngJbt28CVw4MdZsHqXVwonxkgqFyGDznYYHEFZgvxbL1gGhtj8ZjF7oGtqdLBT

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict gngJbt28CVw4MdZsHqXVwonxkgqFyGDznYYHEFZgvxbL1gGhtj8ZjF7oGtqdLBT

--
-- Database "momos_db" dump
--

--
-- PostgreSQL database dump
--

\restrict GAx7IvPppp89l8nqFenAX8hfdMVrJUgOhctlIl8Y4vvXnxeSzCRaqCk4oAdrl20

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: momos_db; Type: DATABASE; Schema: -; Owner: momos_user
--

CREATE DATABASE momos_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE momos_db OWNER TO momos_user;

\unrestrict GAx7IvPppp89l8nqFenAX8hfdMVrJUgOhctlIl8Y4vvXnxeSzCRaqCk4oAdrl20
\connect momos_db
\restrict GAx7IvPppp89l8nqFenAX8hfdMVrJUgOhctlIl8Y4vvXnxeSzCRaqCk4oAdrl20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: _locales; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public._locales AS ENUM (
    'en',
    'id'
);


ALTER TYPE public._locales OWNER TO momos_user;

--
-- Name: enum__portfolio_v_published_locale; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__portfolio_v_published_locale AS ENUM (
    'en',
    'id'
);


ALTER TYPE public.enum__portfolio_v_published_locale OWNER TO momos_user;

--
-- Name: enum__portfolio_v_version_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__portfolio_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__portfolio_v_version_status OWNER TO momos_user;

--
-- Name: enum__posts_v_published_locale; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__posts_v_published_locale AS ENUM (
    'en',
    'id'
);


ALTER TYPE public.enum__posts_v_published_locale OWNER TO momos_user;

--
-- Name: enum__posts_v_version_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__posts_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__posts_v_version_status OWNER TO momos_user;

--
-- Name: enum__services_v_published_locale; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__services_v_published_locale AS ENUM (
    'en',
    'id'
);


ALTER TYPE public.enum__services_v_published_locale OWNER TO momos_user;

--
-- Name: enum__services_v_version_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__services_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__services_v_version_status OWNER TO momos_user;

--
-- Name: enum__testimonials_v_published_locale; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__testimonials_v_published_locale AS ENUM (
    'en',
    'id'
);


ALTER TYPE public.enum__testimonials_v_published_locale OWNER TO momos_user;

--
-- Name: enum__testimonials_v_version_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum__testimonials_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__testimonials_v_version_status OWNER TO momos_user;

--
-- Name: enum_footer_nav_items_link_type; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_footer_nav_items_link_type AS ENUM (
    'reference',
    'custom'
);


ALTER TYPE public.enum_footer_nav_items_link_type OWNER TO momos_user;

--
-- Name: enum_forms_confirmation_type; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_forms_confirmation_type AS ENUM (
    'message',
    'redirect'
);


ALTER TYPE public.enum_forms_confirmation_type OWNER TO momos_user;

--
-- Name: enum_header_nav_items_link_type; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_header_nav_items_link_type AS ENUM (
    'reference',
    'custom'
);


ALTER TYPE public.enum_header_nav_items_link_type OWNER TO momos_user;

--
-- Name: enum_payload_folders_folder_type; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_payload_folders_folder_type AS ENUM (
    'media'
);


ALTER TYPE public.enum_payload_folders_folder_type OWNER TO momos_user;

--
-- Name: enum_payload_jobs_log_state; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_payload_jobs_log_state AS ENUM (
    'failed',
    'succeeded'
);


ALTER TYPE public.enum_payload_jobs_log_state OWNER TO momos_user;

--
-- Name: enum_payload_jobs_log_task_slug; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_payload_jobs_log_task_slug AS ENUM (
    'inline',
    'schedulePublish'
);


ALTER TYPE public.enum_payload_jobs_log_task_slug OWNER TO momos_user;

--
-- Name: enum_payload_jobs_task_slug; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_payload_jobs_task_slug AS ENUM (
    'inline',
    'schedulePublish'
);


ALTER TYPE public.enum_payload_jobs_task_slug OWNER TO momos_user;

--
-- Name: enum_portfolio_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_portfolio_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_portfolio_status OWNER TO momos_user;

--
-- Name: enum_posts_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_posts_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_posts_status OWNER TO momos_user;

--
-- Name: enum_redirects_to_type; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_redirects_to_type AS ENUM (
    'reference',
    'custom'
);


ALTER TYPE public.enum_redirects_to_type OWNER TO momos_user;

--
-- Name: enum_services_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_services_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_services_status OWNER TO momos_user;

--
-- Name: enum_testimonials_status; Type: TYPE; Schema: public; Owner: momos_user
--

CREATE TYPE public.enum_testimonials_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_testimonials_status OWNER TO momos_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _portfolio_v; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._portfolio_v (
    id integer NOT NULL,
    parent_id integer,
    version_year character varying,
    version_image_id integer,
    version_featured_on_home boolean DEFAULT false,
    version_order numeric DEFAULT 0,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__portfolio_v_version_status DEFAULT 'draft'::public.enum__portfolio_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    snapshot boolean,
    published_locale public.enum__portfolio_v_published_locale,
    latest boolean
);


ALTER TABLE public._portfolio_v OWNER TO momos_user;

--
-- Name: _portfolio_v_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._portfolio_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._portfolio_v_id_seq OWNER TO momos_user;

--
-- Name: _portfolio_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._portfolio_v_id_seq OWNED BY public._portfolio_v.id;


--
-- Name: _portfolio_v_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._portfolio_v_locales (
    version_title character varying,
    version_category character varying,
    version_description character varying,
    version_image_alt character varying,
    version_generate_slug boolean DEFAULT true,
    version_slug character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public._portfolio_v_locales OWNER TO momos_user;

--
-- Name: _portfolio_v_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._portfolio_v_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._portfolio_v_locales_id_seq OWNER TO momos_user;

--
-- Name: _portfolio_v_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._portfolio_v_locales_id_seq OWNED BY public._portfolio_v_locales.id;


--
-- Name: _posts_v; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._posts_v (
    id integer NOT NULL,
    parent_id integer,
    version_hero_image_id integer,
    version_published_at timestamp(3) with time zone,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__posts_v_version_status DEFAULT 'draft'::public.enum__posts_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    snapshot boolean,
    published_locale public.enum__posts_v_published_locale,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._posts_v OWNER TO momos_user;

--
-- Name: _posts_v_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._posts_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._posts_v_id_seq OWNER TO momos_user;

--
-- Name: _posts_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._posts_v_id_seq OWNED BY public._posts_v.id;


--
-- Name: _posts_v_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._posts_v_locales (
    version_title character varying,
    version_content jsonb,
    version_meta_title character varying,
    version_meta_image_id integer,
    version_meta_description character varying,
    version_generate_slug boolean DEFAULT true,
    version_slug character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public._posts_v_locales OWNER TO momos_user;

--
-- Name: _posts_v_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._posts_v_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._posts_v_locales_id_seq OWNER TO momos_user;

--
-- Name: _posts_v_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._posts_v_locales_id_seq OWNED BY public._posts_v_locales.id;


--
-- Name: _posts_v_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._posts_v_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer,
    categories_id integer,
    users_id integer
);


ALTER TABLE public._posts_v_rels OWNER TO momos_user;

--
-- Name: _posts_v_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._posts_v_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._posts_v_rels_id_seq OWNER TO momos_user;

--
-- Name: _posts_v_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._posts_v_rels_id_seq OWNED BY public._posts_v_rels.id;


--
-- Name: _posts_v_version_populated_authors; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._posts_v_version_populated_authors (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    _uuid character varying,
    name character varying
);


ALTER TABLE public._posts_v_version_populated_authors OWNER TO momos_user;

--
-- Name: _posts_v_version_populated_authors_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._posts_v_version_populated_authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._posts_v_version_populated_authors_id_seq OWNER TO momos_user;

--
-- Name: _posts_v_version_populated_authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._posts_v_version_populated_authors_id_seq OWNED BY public._posts_v_version_populated_authors.id;


--
-- Name: _services_v; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._services_v (
    id integer NOT NULL,
    parent_id integer,
    version_order numeric DEFAULT 0,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__services_v_version_status DEFAULT 'draft'::public.enum__services_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    snapshot boolean,
    published_locale public.enum__services_v_published_locale,
    latest boolean
);


ALTER TABLE public._services_v OWNER TO momos_user;

--
-- Name: _services_v_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._services_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._services_v_id_seq OWNER TO momos_user;

--
-- Name: _services_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._services_v_id_seq OWNED BY public._services_v.id;


--
-- Name: _services_v_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._services_v_locales (
    version_title character varying,
    version_summary character varying,
    version_body character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public._services_v_locales OWNER TO momos_user;

--
-- Name: _services_v_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._services_v_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._services_v_locales_id_seq OWNER TO momos_user;

--
-- Name: _services_v_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._services_v_locales_id_seq OWNED BY public._services_v_locales.id;


--
-- Name: _testimonials_v; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._testimonials_v (
    id integer NOT NULL,
    parent_id integer,
    version_name character varying,
    version_order numeric DEFAULT 0,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__testimonials_v_version_status DEFAULT 'draft'::public.enum__testimonials_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    snapshot boolean,
    published_locale public.enum__testimonials_v_published_locale,
    latest boolean
);


ALTER TABLE public._testimonials_v OWNER TO momos_user;

--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._testimonials_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._testimonials_v_id_seq OWNER TO momos_user;

--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._testimonials_v_id_seq OWNED BY public._testimonials_v.id;


--
-- Name: _testimonials_v_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public._testimonials_v_locales (
    version_quote character varying,
    version_role character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public._testimonials_v_locales OWNER TO momos_user;

--
-- Name: _testimonials_v_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public._testimonials_v_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._testimonials_v_locales_id_seq OWNER TO momos_user;

--
-- Name: _testimonials_v_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public._testimonials_v_locales_id_seq OWNED BY public._testimonials_v_locales.id;


--
-- Name: about; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.about (
    id integer NOT NULL,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone
);


ALTER TABLE public.about OWNER TO momos_user;

--
-- Name: about_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.about_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_id_seq OWNER TO momos_user;

--
-- Name: about_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.about_id_seq OWNED BY public.about.id;


--
-- Name: about_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.about_locales (
    hero_heading character varying NOT NULL,
    hero_description character varying NOT NULL,
    story_heading character varying NOT NULL,
    story_paragraph1 character varying NOT NULL,
    story_paragraph2 character varying NOT NULL,
    principles_section_heading character varying NOT NULL,
    principles_section_subtext character varying NOT NULL,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.about_locales OWNER TO momos_user;

--
-- Name: about_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.about_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_locales_id_seq OWNER TO momos_user;

--
-- Name: about_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.about_locales_id_seq OWNED BY public.about_locales.id;


--
-- Name: about_principles; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.about_principles (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _locale public._locales NOT NULL,
    id character varying NOT NULL,
    title character varying NOT NULL,
    body character varying NOT NULL
);


ALTER TABLE public.about_principles OWNER TO momos_user;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    parent_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categories OWNER TO momos_user;

--
-- Name: categories_breadcrumbs; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.categories_breadcrumbs (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _locale public._locales NOT NULL,
    id character varying NOT NULL,
    doc_id integer,
    url character varying,
    label character varying
);


ALTER TABLE public.categories_breadcrumbs OWNER TO momos_user;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO momos_user;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: categories_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.categories_locales (
    title character varying NOT NULL,
    generate_slug boolean DEFAULT true,
    slug character varying NOT NULL,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.categories_locales OWNER TO momos_user;

--
-- Name: categories_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.categories_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_locales_id_seq OWNER TO momos_user;

--
-- Name: categories_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.categories_locales_id_seq OWNED BY public.categories_locales.id;


--
-- Name: footer; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.footer (
    id integer NOT NULL,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone
);


ALTER TABLE public.footer OWNER TO momos_user;

--
-- Name: footer_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.footer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.footer_id_seq OWNER TO momos_user;

--
-- Name: footer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.footer_id_seq OWNED BY public.footer.id;


--
-- Name: footer_nav_items; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.footer_nav_items (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    link_type public.enum_footer_nav_items_link_type DEFAULT 'reference'::public.enum_footer_nav_items_link_type,
    link_new_tab boolean,
    link_url character varying
);


ALTER TABLE public.footer_nav_items OWNER TO momos_user;

--
-- Name: footer_nav_items_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.footer_nav_items_locales (
    link_label character varying NOT NULL,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.footer_nav_items_locales OWNER TO momos_user;

--
-- Name: footer_nav_items_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.footer_nav_items_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.footer_nav_items_locales_id_seq OWNER TO momos_user;

--
-- Name: footer_nav_items_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.footer_nav_items_locales_id_seq OWNED BY public.footer_nav_items_locales.id;


--
-- Name: footer_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.footer_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer
);


ALTER TABLE public.footer_rels OWNER TO momos_user;

--
-- Name: footer_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.footer_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.footer_rels_id_seq OWNER TO momos_user;

--
-- Name: footer_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.footer_rels_id_seq OWNED BY public.footer_rels.id;


--
-- Name: form_submissions; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.form_submissions (
    id integer NOT NULL,
    form_id integer NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.form_submissions OWNER TO momos_user;

--
-- Name: form_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.form_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.form_submissions_id_seq OWNER TO momos_user;

--
-- Name: form_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.form_submissions_id_seq OWNED BY public.form_submissions.id;


--
-- Name: form_submissions_submission_data; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.form_submissions_submission_data (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    field character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.form_submissions_submission_data OWNER TO momos_user;

--
-- Name: forms; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms (
    id integer NOT NULL,
    title character varying NOT NULL,
    confirmation_type public.enum_forms_confirmation_type DEFAULT 'message'::public.enum_forms_confirmation_type,
    redirect_url character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forms OWNER TO momos_user;

--
-- Name: forms_blocks_checkbox; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_checkbox (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    default_value boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_checkbox OWNER TO momos_user;

--
-- Name: forms_blocks_checkbox_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_checkbox_locales (
    label character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_checkbox_locales OWNER TO momos_user;

--
-- Name: forms_blocks_checkbox_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_checkbox_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_checkbox_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_checkbox_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_checkbox_locales_id_seq OWNED BY public.forms_blocks_checkbox_locales.id;


--
-- Name: forms_blocks_country; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_country (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_country OWNER TO momos_user;

--
-- Name: forms_blocks_country_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_country_locales (
    label character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_country_locales OWNER TO momos_user;

--
-- Name: forms_blocks_country_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_country_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_country_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_country_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_country_locales_id_seq OWNED BY public.forms_blocks_country_locales.id;


--
-- Name: forms_blocks_email; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_email (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_email OWNER TO momos_user;

--
-- Name: forms_blocks_email_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_email_locales (
    label character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_email_locales OWNER TO momos_user;

--
-- Name: forms_blocks_email_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_email_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_email_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_email_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_email_locales_id_seq OWNED BY public.forms_blocks_email_locales.id;


--
-- Name: forms_blocks_message; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_message (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    block_name character varying
);


ALTER TABLE public.forms_blocks_message OWNER TO momos_user;

--
-- Name: forms_blocks_message_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_message_locales (
    message jsonb,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_message_locales OWNER TO momos_user;

--
-- Name: forms_blocks_message_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_message_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_message_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_message_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_message_locales_id_seq OWNED BY public.forms_blocks_message_locales.id;


--
-- Name: forms_blocks_number; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_number (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    default_value numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_number OWNER TO momos_user;

--
-- Name: forms_blocks_number_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_number_locales (
    label character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_number_locales OWNER TO momos_user;

--
-- Name: forms_blocks_number_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_number_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_number_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_number_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_number_locales_id_seq OWNED BY public.forms_blocks_number_locales.id;


--
-- Name: forms_blocks_select; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_select (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    placeholder character varying,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_select OWNER TO momos_user;

--
-- Name: forms_blocks_select_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_select_locales (
    label character varying,
    default_value character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_select_locales OWNER TO momos_user;

--
-- Name: forms_blocks_select_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_select_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_select_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_select_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_select_locales_id_seq OWNED BY public.forms_blocks_select_locales.id;


--
-- Name: forms_blocks_select_options; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_select_options (
    _order integer NOT NULL,
    _parent_id character varying NOT NULL,
    id character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.forms_blocks_select_options OWNER TO momos_user;

--
-- Name: forms_blocks_select_options_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_select_options_locales (
    label character varying NOT NULL,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_select_options_locales OWNER TO momos_user;

--
-- Name: forms_blocks_select_options_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_select_options_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_select_options_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_select_options_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_select_options_locales_id_seq OWNED BY public.forms_blocks_select_options_locales.id;


--
-- Name: forms_blocks_state; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_state (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_state OWNER TO momos_user;

--
-- Name: forms_blocks_state_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_state_locales (
    label character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_state_locales OWNER TO momos_user;

--
-- Name: forms_blocks_state_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_state_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_state_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_state_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_state_locales_id_seq OWNED BY public.forms_blocks_state_locales.id;


--
-- Name: forms_blocks_text; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_text (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_text OWNER TO momos_user;

--
-- Name: forms_blocks_text_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_text_locales (
    label character varying,
    default_value character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_text_locales OWNER TO momos_user;

--
-- Name: forms_blocks_text_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_text_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_text_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_text_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_text_locales_id_seq OWNED BY public.forms_blocks_text_locales.id;


--
-- Name: forms_blocks_textarea; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_textarea (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    _path text NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    width numeric,
    required boolean,
    block_name character varying
);


ALTER TABLE public.forms_blocks_textarea OWNER TO momos_user;

--
-- Name: forms_blocks_textarea_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_blocks_textarea_locales (
    label character varying,
    default_value character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_blocks_textarea_locales OWNER TO momos_user;

--
-- Name: forms_blocks_textarea_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_blocks_textarea_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_blocks_textarea_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_blocks_textarea_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_blocks_textarea_locales_id_seq OWNED BY public.forms_blocks_textarea_locales.id;


--
-- Name: forms_emails; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_emails (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    email_to character varying,
    cc character varying,
    bcc character varying,
    reply_to character varying,
    email_from character varying
);


ALTER TABLE public.forms_emails OWNER TO momos_user;

--
-- Name: forms_emails_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_emails_locales (
    subject character varying DEFAULT 'You''ve received a new message.'::character varying NOT NULL,
    message jsonb,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.forms_emails_locales OWNER TO momos_user;

--
-- Name: forms_emails_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_emails_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_emails_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_emails_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_emails_locales_id_seq OWNED BY public.forms_emails_locales.id;


--
-- Name: forms_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_id_seq OWNER TO momos_user;

--
-- Name: forms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_id_seq OWNED BY public.forms.id;


--
-- Name: forms_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.forms_locales (
    submit_button_label character varying,
    confirmation_message jsonb,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.forms_locales OWNER TO momos_user;

--
-- Name: forms_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.forms_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forms_locales_id_seq OWNER TO momos_user;

--
-- Name: forms_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.forms_locales_id_seq OWNED BY public.forms_locales.id;


--
-- Name: header; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.header (
    id integer NOT NULL,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone
);


ALTER TABLE public.header OWNER TO momos_user;

--
-- Name: header_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.header_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.header_id_seq OWNER TO momos_user;

--
-- Name: header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.header_id_seq OWNED BY public.header.id;


--
-- Name: header_nav_items; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.header_nav_items (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    link_type public.enum_header_nav_items_link_type DEFAULT 'reference'::public.enum_header_nav_items_link_type,
    link_new_tab boolean,
    link_url character varying
);


ALTER TABLE public.header_nav_items OWNER TO momos_user;

--
-- Name: header_nav_items_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.header_nav_items_locales (
    link_label character varying NOT NULL,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id character varying NOT NULL
);


ALTER TABLE public.header_nav_items_locales OWNER TO momos_user;

--
-- Name: header_nav_items_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.header_nav_items_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.header_nav_items_locales_id_seq OWNER TO momos_user;

--
-- Name: header_nav_items_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.header_nav_items_locales_id_seq OWNED BY public.header_nav_items_locales.id;


--
-- Name: header_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.header_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer
);


ALTER TABLE public.header_rels OWNER TO momos_user;

--
-- Name: header_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.header_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.header_rels_id_seq OWNER TO momos_user;

--
-- Name: header_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.header_rels_id_seq OWNED BY public.header_rels.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.media (
    id integer NOT NULL,
    folder_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    sizes_thumbnail_url character varying,
    sizes_thumbnail_width numeric,
    sizes_thumbnail_height numeric,
    sizes_thumbnail_mime_type character varying,
    sizes_thumbnail_filesize numeric,
    sizes_thumbnail_filename character varying,
    sizes_square_url character varying,
    sizes_square_width numeric,
    sizes_square_height numeric,
    sizes_square_mime_type character varying,
    sizes_square_filesize numeric,
    sizes_square_filename character varying,
    sizes_small_url character varying,
    sizes_small_width numeric,
    sizes_small_height numeric,
    sizes_small_mime_type character varying,
    sizes_small_filesize numeric,
    sizes_small_filename character varying,
    sizes_medium_url character varying,
    sizes_medium_width numeric,
    sizes_medium_height numeric,
    sizes_medium_mime_type character varying,
    sizes_medium_filesize numeric,
    sizes_medium_filename character varying,
    sizes_large_url character varying,
    sizes_large_width numeric,
    sizes_large_height numeric,
    sizes_large_mime_type character varying,
    sizes_large_filesize numeric,
    sizes_large_filename character varying,
    sizes_xlarge_url character varying,
    sizes_xlarge_width numeric,
    sizes_xlarge_height numeric,
    sizes_xlarge_mime_type character varying,
    sizes_xlarge_filesize numeric,
    sizes_xlarge_filename character varying,
    sizes_og_url character varying,
    sizes_og_width numeric,
    sizes_og_height numeric,
    sizes_og_mime_type character varying,
    sizes_og_filesize numeric,
    sizes_og_filename character varying
);


ALTER TABLE public.media OWNER TO momos_user;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_id_seq OWNER TO momos_user;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: media_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.media_locales (
    alt character varying,
    caption jsonb,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.media_locales OWNER TO momos_user;

--
-- Name: media_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.media_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_locales_id_seq OWNER TO momos_user;

--
-- Name: media_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.media_locales_id_seq OWNED BY public.media_locales.id;


--
-- Name: payload_folders; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_folders (
    id integer NOT NULL,
    name character varying NOT NULL,
    folder_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_folders OWNER TO momos_user;

--
-- Name: payload_folders_folder_type; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_folders_folder_type (
    "order" integer NOT NULL,
    parent_id integer NOT NULL,
    value public.enum_payload_folders_folder_type,
    id integer NOT NULL
);


ALTER TABLE public.payload_folders_folder_type OWNER TO momos_user;

--
-- Name: payload_folders_folder_type_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_folders_folder_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_folders_folder_type_id_seq OWNER TO momos_user;

--
-- Name: payload_folders_folder_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_folders_folder_type_id_seq OWNED BY public.payload_folders_folder_type.id;


--
-- Name: payload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_folders_id_seq OWNER TO momos_user;

--
-- Name: payload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_folders_id_seq OWNED BY public.payload_folders.id;


--
-- Name: payload_jobs; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_jobs (
    id integer NOT NULL,
    input jsonb,
    completed_at timestamp(3) with time zone,
    total_tried numeric DEFAULT 0,
    has_error boolean DEFAULT false,
    error jsonb,
    task_slug public.enum_payload_jobs_task_slug,
    queue character varying DEFAULT 'default'::character varying,
    wait_until timestamp(3) with time zone,
    processing boolean DEFAULT false,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_jobs OWNER TO momos_user;

--
-- Name: payload_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_jobs_id_seq OWNER TO momos_user;

--
-- Name: payload_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_jobs_id_seq OWNED BY public.payload_jobs.id;


--
-- Name: payload_jobs_log; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_jobs_log (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    executed_at timestamp(3) with time zone NOT NULL,
    completed_at timestamp(3) with time zone NOT NULL,
    task_slug public.enum_payload_jobs_log_task_slug NOT NULL,
    task_i_d character varying NOT NULL,
    input jsonb,
    output jsonb,
    state public.enum_payload_jobs_log_state NOT NULL,
    error jsonb
);


ALTER TABLE public.payload_jobs_log OWNER TO momos_user;

--
-- Name: payload_kv; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_kv (
    id integer NOT NULL,
    key character varying NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.payload_kv OWNER TO momos_user;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_kv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_kv_id_seq OWNER TO momos_user;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_kv_id_seq OWNED BY public.payload_kv.id;


--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_locked_documents (
    id integer NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO momos_user;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_locked_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_id_seq OWNER TO momos_user;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_locked_documents_id_seq OWNED BY public.payload_locked_documents.id;


--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer,
    media_id integer,
    categories_id integer,
    portfolio_id integer,
    services_id integer,
    testimonials_id integer,
    users_id integer,
    redirects_id integer,
    forms_id integer,
    form_submissions_id integer,
    search_id integer,
    payload_mcp_api_keys_id integer,
    payload_folders_id integer
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO momos_user;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO momos_user;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_mcp_api_keys; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_mcp_api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    label character varying,
    description character varying,
    posts_find boolean DEFAULT false,
    posts_create boolean DEFAULT false,
    posts_update boolean DEFAULT false,
    posts_delete boolean DEFAULT false,
    media_find boolean DEFAULT false,
    media_create boolean DEFAULT false,
    media_update boolean DEFAULT false,
    media_delete boolean DEFAULT false,
    categories_find boolean DEFAULT false,
    categories_create boolean DEFAULT false,
    categories_update boolean DEFAULT false,
    categories_delete boolean DEFAULT false,
    portfolio_find boolean DEFAULT false,
    portfolio_create boolean DEFAULT false,
    portfolio_update boolean DEFAULT false,
    portfolio_delete boolean DEFAULT false,
    header_find boolean DEFAULT false,
    header_update boolean DEFAULT false,
    footer_find boolean DEFAULT false,
    footer_update boolean DEFAULT false,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    enable_a_p_i_key boolean,
    api_key character varying,
    api_key_index character varying,
    services_find boolean DEFAULT false,
    services_create boolean DEFAULT false,
    services_update boolean DEFAULT false,
    services_delete boolean DEFAULT false,
    testimonials_find boolean DEFAULT false,
    testimonials_create boolean DEFAULT false,
    testimonials_update boolean DEFAULT false,
    testimonials_delete boolean DEFAULT false,
    about_find boolean DEFAULT false,
    about_update boolean DEFAULT false
);


ALTER TABLE public.payload_mcp_api_keys OWNER TO momos_user;

--
-- Name: payload_mcp_api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_mcp_api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_mcp_api_keys_id_seq OWNER TO momos_user;

--
-- Name: payload_mcp_api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_mcp_api_keys_id_seq OWNED BY public.payload_mcp_api_keys.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_migrations (
    id integer NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO momos_user;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_migrations_id_seq OWNER TO momos_user;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_migrations_id_seq OWNED BY public.payload_migrations.id;


--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_preferences (
    id integer NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO momos_user;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_id_seq OWNER TO momos_user;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_preferences_id_seq OWNED BY public.payload_preferences.id;


--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer,
    payload_mcp_api_keys_id integer
);


ALTER TABLE public.payload_preferences_rels OWNER TO momos_user;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO momos_user;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: portfolio; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.portfolio (
    id integer NOT NULL,
    year character varying,
    image_id integer,
    featured_on_home boolean DEFAULT false,
    "order" numeric DEFAULT 0,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_portfolio_status DEFAULT 'draft'::public.enum_portfolio_status
);


ALTER TABLE public.portfolio OWNER TO momos_user;

--
-- Name: portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portfolio_id_seq OWNER TO momos_user;

--
-- Name: portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.portfolio_id_seq OWNED BY public.portfolio.id;


--
-- Name: portfolio_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.portfolio_locales (
    title character varying,
    category character varying,
    description character varying,
    image_alt character varying,
    generate_slug boolean DEFAULT true,
    slug character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.portfolio_locales OWNER TO momos_user;

--
-- Name: portfolio_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.portfolio_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portfolio_locales_id_seq OWNER TO momos_user;

--
-- Name: portfolio_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.portfolio_locales_id_seq OWNED BY public.portfolio_locales.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    hero_image_id integer,
    published_at timestamp(3) with time zone,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_posts_status DEFAULT 'draft'::public.enum_posts_status
);


ALTER TABLE public.posts OWNER TO momos_user;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO momos_user;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: posts_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.posts_locales (
    title character varying,
    content jsonb,
    meta_title character varying,
    meta_image_id integer,
    meta_description character varying,
    generate_slug boolean DEFAULT true,
    slug character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.posts_locales OWNER TO momos_user;

--
-- Name: posts_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.posts_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_locales_id_seq OWNER TO momos_user;

--
-- Name: posts_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.posts_locales_id_seq OWNED BY public.posts_locales.id;


--
-- Name: posts_populated_authors; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.posts_populated_authors (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    name character varying
);


ALTER TABLE public.posts_populated_authors OWNER TO momos_user;

--
-- Name: posts_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.posts_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer,
    categories_id integer,
    users_id integer
);


ALTER TABLE public.posts_rels OWNER TO momos_user;

--
-- Name: posts_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.posts_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_rels_id_seq OWNER TO momos_user;

--
-- Name: posts_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.posts_rels_id_seq OWNED BY public.posts_rels.id;


--
-- Name: redirects; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.redirects (
    id integer NOT NULL,
    "from" character varying NOT NULL,
    to_type public.enum_redirects_to_type DEFAULT 'reference'::public.enum_redirects_to_type,
    to_url character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.redirects OWNER TO momos_user;

--
-- Name: redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.redirects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.redirects_id_seq OWNER TO momos_user;

--
-- Name: redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.redirects_id_seq OWNED BY public.redirects.id;


--
-- Name: redirects_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.redirects_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer
);


ALTER TABLE public.redirects_rels OWNER TO momos_user;

--
-- Name: redirects_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.redirects_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.redirects_rels_id_seq OWNER TO momos_user;

--
-- Name: redirects_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.redirects_rels_id_seq OWNED BY public.redirects_rels.id;


--
-- Name: search; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.search (
    id integer NOT NULL,
    priority numeric,
    slug character varying,
    meta_title character varying,
    meta_description character varying,
    meta_image_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.search OWNER TO momos_user;

--
-- Name: search_categories; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.search_categories (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    relation_to character varying,
    category_i_d character varying,
    title character varying
);


ALTER TABLE public.search_categories OWNER TO momos_user;

--
-- Name: search_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.search_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_id_seq OWNER TO momos_user;

--
-- Name: search_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.search_id_seq OWNED BY public.search.id;


--
-- Name: search_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.search_locales (
    title character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.search_locales OWNER TO momos_user;

--
-- Name: search_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.search_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_locales_id_seq OWNER TO momos_user;

--
-- Name: search_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.search_locales_id_seq OWNED BY public.search_locales.id;


--
-- Name: search_rels; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.search_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    posts_id integer
);


ALTER TABLE public.search_rels OWNER TO momos_user;

--
-- Name: search_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.search_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_rels_id_seq OWNER TO momos_user;

--
-- Name: search_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.search_rels_id_seq OWNED BY public.search_rels.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.services (
    id integer NOT NULL,
    "order" numeric DEFAULT 0,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_services_status DEFAULT 'draft'::public.enum_services_status
);


ALTER TABLE public.services OWNER TO momos_user;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO momos_user;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: services_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.services_locales (
    title character varying,
    summary character varying,
    body character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.services_locales OWNER TO momos_user;

--
-- Name: services_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.services_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_locales_id_seq OWNER TO momos_user;

--
-- Name: services_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.services_locales_id_seq OWNED BY public.services_locales.id;


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.testimonials (
    id integer NOT NULL,
    name character varying,
    "order" numeric DEFAULT 0,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_testimonials_status DEFAULT 'draft'::public.enum_testimonials_status
);


ALTER TABLE public.testimonials OWNER TO momos_user;

--
-- Name: testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.testimonials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.testimonials_id_seq OWNER TO momos_user;

--
-- Name: testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.testimonials_id_seq OWNED BY public.testimonials.id;


--
-- Name: testimonials_locales; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.testimonials_locales (
    quote character varying,
    role character varying,
    id integer NOT NULL,
    _locale public._locales NOT NULL,
    _parent_id integer NOT NULL
);


ALTER TABLE public.testimonials_locales OWNER TO momos_user;

--
-- Name: testimonials_locales_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.testimonials_locales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.testimonials_locales_id_seq OWNER TO momos_user;

--
-- Name: testimonials_locales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.testimonials_locales_id_seq OWNED BY public.testimonials_locales.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone
);


ALTER TABLE public.users OWNER TO momos_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: momos_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO momos_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: momos_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_sessions; Type: TABLE; Schema: public; Owner: momos_user
--

CREATE TABLE public.users_sessions (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    created_at timestamp(3) with time zone,
    expires_at timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.users_sessions OWNER TO momos_user;

--
-- Name: _portfolio_v id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v ALTER COLUMN id SET DEFAULT nextval('public._portfolio_v_id_seq'::regclass);


--
-- Name: _portfolio_v_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v_locales ALTER COLUMN id SET DEFAULT nextval('public._portfolio_v_locales_id_seq'::regclass);


--
-- Name: _posts_v id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v ALTER COLUMN id SET DEFAULT nextval('public._posts_v_id_seq'::regclass);


--
-- Name: _posts_v_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_locales ALTER COLUMN id SET DEFAULT nextval('public._posts_v_locales_id_seq'::regclass);


--
-- Name: _posts_v_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels ALTER COLUMN id SET DEFAULT nextval('public._posts_v_rels_id_seq'::regclass);


--
-- Name: _posts_v_version_populated_authors id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_version_populated_authors ALTER COLUMN id SET DEFAULT nextval('public._posts_v_version_populated_authors_id_seq'::regclass);


--
-- Name: _services_v id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v ALTER COLUMN id SET DEFAULT nextval('public._services_v_id_seq'::regclass);


--
-- Name: _services_v_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v_locales ALTER COLUMN id SET DEFAULT nextval('public._services_v_locales_id_seq'::regclass);


--
-- Name: _testimonials_v id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v ALTER COLUMN id SET DEFAULT nextval('public._testimonials_v_id_seq'::regclass);


--
-- Name: _testimonials_v_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v_locales ALTER COLUMN id SET DEFAULT nextval('public._testimonials_v_locales_id_seq'::regclass);


--
-- Name: about id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about ALTER COLUMN id SET DEFAULT nextval('public.about_id_seq'::regclass);


--
-- Name: about_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about_locales ALTER COLUMN id SET DEFAULT nextval('public.about_locales_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: categories_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_locales ALTER COLUMN id SET DEFAULT nextval('public.categories_locales_id_seq'::regclass);


--
-- Name: footer id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer ALTER COLUMN id SET DEFAULT nextval('public.footer_id_seq'::regclass);


--
-- Name: footer_nav_items_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_nav_items_locales ALTER COLUMN id SET DEFAULT nextval('public.footer_nav_items_locales_id_seq'::regclass);


--
-- Name: footer_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_rels ALTER COLUMN id SET DEFAULT nextval('public.footer_rels_id_seq'::regclass);


--
-- Name: form_submissions id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.form_submissions ALTER COLUMN id SET DEFAULT nextval('public.form_submissions_id_seq'::regclass);


--
-- Name: forms id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms ALTER COLUMN id SET DEFAULT nextval('public.forms_id_seq'::regclass);


--
-- Name: forms_blocks_checkbox_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_checkbox_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_checkbox_locales_id_seq'::regclass);


--
-- Name: forms_blocks_country_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_country_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_country_locales_id_seq'::regclass);


--
-- Name: forms_blocks_email_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_email_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_email_locales_id_seq'::regclass);


--
-- Name: forms_blocks_message_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_message_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_message_locales_id_seq'::regclass);


--
-- Name: forms_blocks_number_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_number_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_number_locales_id_seq'::regclass);


--
-- Name: forms_blocks_select_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_select_locales_id_seq'::regclass);


--
-- Name: forms_blocks_select_options_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_options_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_select_options_locales_id_seq'::regclass);


--
-- Name: forms_blocks_state_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_state_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_state_locales_id_seq'::regclass);


--
-- Name: forms_blocks_text_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_text_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_text_locales_id_seq'::regclass);


--
-- Name: forms_blocks_textarea_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_textarea_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_blocks_textarea_locales_id_seq'::regclass);


--
-- Name: forms_emails_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_emails_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_emails_locales_id_seq'::regclass);


--
-- Name: forms_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_locales ALTER COLUMN id SET DEFAULT nextval('public.forms_locales_id_seq'::regclass);


--
-- Name: header id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header ALTER COLUMN id SET DEFAULT nextval('public.header_id_seq'::regclass);


--
-- Name: header_nav_items_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_nav_items_locales ALTER COLUMN id SET DEFAULT nextval('public.header_nav_items_locales_id_seq'::regclass);


--
-- Name: header_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_rels ALTER COLUMN id SET DEFAULT nextval('public.header_rels_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: media_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media_locales ALTER COLUMN id SET DEFAULT nextval('public.media_locales_id_seq'::regclass);


--
-- Name: payload_folders id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders ALTER COLUMN id SET DEFAULT nextval('public.payload_folders_id_seq'::regclass);


--
-- Name: payload_folders_folder_type id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders_folder_type ALTER COLUMN id SET DEFAULT nextval('public.payload_folders_folder_type_id_seq'::regclass);


--
-- Name: payload_jobs id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_jobs ALTER COLUMN id SET DEFAULT nextval('public.payload_jobs_id_seq'::regclass);


--
-- Name: payload_kv id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_kv ALTER COLUMN id SET DEFAULT nextval('public.payload_kv_id_seq'::regclass);


--
-- Name: payload_locked_documents id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_mcp_api_keys id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_mcp_api_keys ALTER COLUMN id SET DEFAULT nextval('public.payload_mcp_api_keys_id_seq'::regclass);


--
-- Name: payload_migrations id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_migrations ALTER COLUMN id SET DEFAULT nextval('public.payload_migrations_id_seq'::regclass);


--
-- Name: payload_preferences id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Name: portfolio id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio ALTER COLUMN id SET DEFAULT nextval('public.portfolio_id_seq'::regclass);


--
-- Name: portfolio_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio_locales ALTER COLUMN id SET DEFAULT nextval('public.portfolio_locales_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: posts_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_locales ALTER COLUMN id SET DEFAULT nextval('public.posts_locales_id_seq'::regclass);


--
-- Name: posts_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels ALTER COLUMN id SET DEFAULT nextval('public.posts_rels_id_seq'::regclass);


--
-- Name: redirects id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects ALTER COLUMN id SET DEFAULT nextval('public.redirects_id_seq'::regclass);


--
-- Name: redirects_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects_rels ALTER COLUMN id SET DEFAULT nextval('public.redirects_rels_id_seq'::regclass);


--
-- Name: search id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search ALTER COLUMN id SET DEFAULT nextval('public.search_id_seq'::regclass);


--
-- Name: search_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_locales ALTER COLUMN id SET DEFAULT nextval('public.search_locales_id_seq'::regclass);


--
-- Name: search_rels id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_rels ALTER COLUMN id SET DEFAULT nextval('public.search_rels_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: services_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.services_locales ALTER COLUMN id SET DEFAULT nextval('public.services_locales_id_seq'::regclass);


--
-- Name: testimonials id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.testimonials ALTER COLUMN id SET DEFAULT nextval('public.testimonials_id_seq'::regclass);


--
-- Name: testimonials_locales id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.testimonials_locales ALTER COLUMN id SET DEFAULT nextval('public.testimonials_locales_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _portfolio_v; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._portfolio_v (id, parent_id, version_year, version_image_id, version_featured_on_home, version_order, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest) FROM stdin;
80	8	2025	8	t	1	2026-09-12 01:09:48.783+00	2026-09-09 16:50:49.246+00	published	2026-09-12 01:09:48.796+00	2026-09-12 01:09:48.796+00	\N	\N	t
33	7	2025	7	f	0	2026-09-09 17:10:22.918+00	2026-09-09 16:43:46.822+00	published	2026-09-09 17:10:22.953+00	2026-09-09 17:10:22.953+00	\N	\N	f
32	7	2025	7	f	0	2026-09-09 17:10:22.537+00	2026-09-09 16:43:46.822+00	published	2026-09-09 17:10:22.558+00	2026-09-09 17:10:22.558+00	\N	\N	f
8	7	2025	7	f	0	2026-09-09 16:43:46.824+00	2026-09-09 16:43:46.822+00	published	2026-09-09 16:43:46.879+00	2026-09-09 16:43:46.879+00	\N	\N	f
37	9	2025	9	f	2	2026-09-09 17:10:24.624+00	2026-09-09 16:59:33.5+00	published	2026-09-09 17:10:24.631+00	2026-09-09 17:10:24.631+00	\N	\N	t
36	9	2025	9	f	2	2026-09-09 17:10:23.824+00	2026-09-09 16:59:33.5+00	published	2026-09-09 17:10:23.878+00	2026-09-09 17:10:23.878+00	\N	\N	f
10	9	2025	9	f	2	2026-09-09 16:59:33.5+00	2026-09-09 16:59:33.5+00	published	2026-09-09 16:59:33.512+00	2026-09-09 16:59:33.512+00	\N	\N	f
39	10	2025	10	f	3	2026-09-09 17:10:25.421+00	2026-09-09 16:59:33.72+00	published	2026-09-09 17:10:25.425+00	2026-09-09 17:10:25.425+00	\N	\N	t
38	10	2025	10	f	3	2026-09-09 17:10:25.08+00	2026-09-09 16:59:33.72+00	published	2026-09-09 17:10:25.092+00	2026-09-09 17:10:25.092+00	\N	\N	f
11	10	2025	10	f	3	2026-09-09 16:59:33.721+00	2026-09-09 16:59:33.72+00	published	2026-09-09 16:59:33.76+00	2026-09-09 16:59:33.76+00	\N	\N	f
41	11	2025	11	f	4	2026-09-09 17:10:25.918+00	2026-09-09 16:59:34.141+00	published	2026-09-09 17:10:25.922+00	2026-09-09 17:10:25.922+00	\N	\N	t
40	11	2025	11	f	4	2026-09-09 17:10:25.703+00	2026-09-09 16:59:34.141+00	published	2026-09-09 17:10:25.707+00	2026-09-09 17:10:25.707+00	\N	\N	f
12	11	2025	11	f	4	2026-09-09 16:59:34.141+00	2026-09-09 16:59:34.141+00	published	2026-09-09 16:59:34.146+00	2026-09-09 16:59:34.146+00	\N	\N	f
43	12	2025	12	f	5	2026-09-09 17:10:26.423+00	2026-09-09 16:59:34.292+00	published	2026-09-09 17:10:26.453+00	2026-09-09 17:10:26.453+00	\N	\N	t
42	12	2025	12	f	5	2026-09-09 17:10:26.158+00	2026-09-09 16:59:34.292+00	published	2026-09-09 17:10:26.165+00	2026-09-09 17:10:26.165+00	\N	\N	f
13	12	2025	12	f	5	2026-09-09 16:59:34.292+00	2026-09-09 16:59:34.292+00	published	2026-09-09 16:59:34.297+00	2026-09-09 16:59:34.297+00	\N	\N	f
45	13	2025	13	f	6	2026-09-09 17:10:27.443+00	2026-09-09 16:59:34.461+00	published	2026-09-09 17:10:27.447+00	2026-09-09 17:10:27.447+00	\N	\N	t
44	13	2025	13	f	6	2026-09-09 17:10:27.073+00	2026-09-09 16:59:34.461+00	published	2026-09-09 17:10:27.087+00	2026-09-09 17:10:27.087+00	\N	\N	f
14	13	2025	13	f	6	2026-09-09 16:59:34.462+00	2026-09-09 16:59:34.461+00	published	2026-09-09 16:59:34.472+00	2026-09-09 16:59:34.472+00	\N	\N	f
47	14	2025	15	f	7	2026-09-09 17:10:28.177+00	2026-09-09 16:59:49.585+00	published	2026-09-09 17:10:28.188+00	2026-09-09 17:10:28.188+00	\N	\N	t
46	14	2025	15	f	7	2026-09-09 17:10:27.798+00	2026-09-09 16:59:49.585+00	published	2026-09-09 17:10:27.813+00	2026-09-09 17:10:27.813+00	\N	\N	f
15	14	2025	15	f	7	2026-09-09 16:59:49.585+00	2026-09-09 16:59:49.585+00	published	2026-09-09 16:59:49.592+00	2026-09-09 16:59:49.592+00	\N	\N	f
49	15	2025	16	f	8	2026-09-09 17:10:28.589+00	2026-09-09 17:00:13.47+00	published	2026-09-09 17:10:28.593+00	2026-09-09 17:10:28.593+00	\N	\N	t
48	15	2025	16	f	8	2026-09-09 17:10:28.38+00	2026-09-09 17:00:13.47+00	published	2026-09-09 17:10:28.392+00	2026-09-09 17:10:28.392+00	\N	\N	f
16	15	2025	16	f	8	2026-09-09 17:00:13.471+00	2026-09-09 17:00:13.47+00	published	2026-09-09 17:00:13.492+00	2026-09-09 17:00:13.492+00	\N	\N	f
51	16	2025	17	f	9	2026-09-09 17:10:28.952+00	2026-09-09 17:00:35.817+00	published	2026-09-09 17:10:28.956+00	2026-09-09 17:10:28.956+00	\N	\N	t
50	16	2025	17	f	9	2026-09-09 17:10:28.757+00	2026-09-09 17:00:35.817+00	published	2026-09-09 17:10:28.761+00	2026-09-09 17:10:28.761+00	\N	\N	f
17	16	2025	17	f	9	2026-09-09 17:00:35.818+00	2026-09-09 17:00:35.817+00	published	2026-09-09 17:00:35.834+00	2026-09-09 17:00:35.834+00	\N	\N	f
53	17	2025	18	f	10	2026-09-09 17:10:29.361+00	2026-09-09 17:00:54.888+00	published	2026-09-09 17:10:29.368+00	2026-09-09 17:10:29.368+00	\N	\N	t
52	17	2025	18	f	10	2026-09-09 17:10:29.116+00	2026-09-09 17:00:54.888+00	published	2026-09-09 17:10:29.121+00	2026-09-09 17:10:29.121+00	\N	\N	f
18	17	2025	18	f	10	2026-09-09 17:00:54.888+00	2026-09-09 17:00:54.888+00	published	2026-09-09 17:00:54.936+00	2026-09-09 17:00:54.936+00	\N	\N	f
55	18	2025	19	f	11	2026-09-09 17:10:29.862+00	2026-09-09 17:01:15.964+00	published	2026-09-09 17:10:29.87+00	2026-09-09 17:10:29.87+00	\N	\N	t
54	18	2025	19	f	11	2026-09-09 17:10:29.584+00	2026-09-09 17:01:15.964+00	published	2026-09-09 17:10:29.59+00	2026-09-09 17:10:29.59+00	\N	\N	f
19	18	2025	19	f	11	2026-09-09 17:01:15.965+00	2026-09-09 17:01:15.964+00	published	2026-09-09 17:01:15.989+00	2026-09-09 17:01:15.989+00	\N	\N	f
57	19	2025	20	f	12	2026-09-09 17:10:31.082+00	2026-09-09 17:01:32.549+00	published	2026-09-09 17:10:31.087+00	2026-09-09 17:10:31.087+00	\N	\N	t
56	19	2025	20	f	12	2026-09-09 17:10:30.116+00	2026-09-09 17:01:32.549+00	published	2026-09-09 17:10:30.13+00	2026-09-09 17:10:30.13+00	\N	\N	f
20	19	2025	20	f	12	2026-09-09 17:01:32.552+00	2026-09-09 17:01:32.549+00	published	2026-09-09 17:01:32.582+00	2026-09-09 17:01:32.582+00	\N	\N	f
59	20	2025	21	f	13	2026-09-09 17:10:31.676+00	2026-09-09 17:01:54.447+00	published	2026-09-09 17:10:31.691+00	2026-09-09 17:10:31.691+00	\N	\N	t
58	20	2025	21	f	13	2026-09-09 17:10:31.393+00	2026-09-09 17:01:54.447+00	published	2026-09-09 17:10:31.4+00	2026-09-09 17:10:31.4+00	\N	\N	f
21	20	2025	21	f	13	2026-09-09 17:01:54.447+00	2026-09-09 17:01:54.447+00	published	2026-09-09 17:01:54.453+00	2026-09-09 17:01:54.453+00	\N	\N	f
61	21	2025	22	f	14	2026-09-09 17:10:32.107+00	2026-09-09 17:02:10.33+00	published	2026-09-09 17:10:32.123+00	2026-09-09 17:10:32.123+00	\N	\N	t
60	21	2025	22	f	14	2026-09-09 17:10:31.88+00	2026-09-09 17:02:10.33+00	published	2026-09-09 17:10:31.885+00	2026-09-09 17:10:31.885+00	\N	\N	f
22	21	2025	22	f	14	2026-09-09 17:02:10.33+00	2026-09-09 17:02:10.33+00	published	2026-09-09 17:02:10.355+00	2026-09-09 17:02:10.355+00	\N	\N	f
63	22	2025	23	f	15	2026-09-09 17:10:32.635+00	2026-09-09 17:02:27.305+00	published	2026-09-09 17:10:32.663+00	2026-09-09 17:10:32.663+00	\N	\N	t
62	22	2025	23	f	15	2026-09-09 17:10:32.357+00	2026-09-09 17:02:27.305+00	published	2026-09-09 17:10:32.364+00	2026-09-09 17:10:32.364+00	\N	\N	f
23	22	2025	23	f	15	2026-09-09 17:02:27.305+00	2026-09-09 17:02:27.305+00	published	2026-09-09 17:02:27.332+00	2026-09-09 17:02:27.332+00	\N	\N	f
65	23	2025	24	f	16	2026-09-09 17:10:33.247+00	2026-09-09 17:02:45.659+00	published	2026-09-09 17:10:33.272+00	2026-09-09 17:10:33.272+00	\N	\N	t
64	23	2025	24	f	16	2026-09-09 17:10:32.941+00	2026-09-09 17:02:45.659+00	published	2026-09-09 17:10:32.946+00	2026-09-09 17:10:32.946+00	\N	\N	f
24	23	2025	24	f	16	2026-09-09 17:02:45.659+00	2026-09-09 17:02:45.659+00	published	2026-09-09 17:02:45.677+00	2026-09-09 17:02:45.677+00	\N	\N	f
67	24	2025	25	f	17	2026-09-09 17:10:34.071+00	2026-09-09 17:03:02.818+00	published	2026-09-09 17:10:34.082+00	2026-09-09 17:10:34.082+00	\N	\N	t
66	24	2025	25	f	17	2026-09-09 17:10:33.846+00	2026-09-09 17:03:02.818+00	published	2026-09-09 17:10:33.856+00	2026-09-09 17:10:33.856+00	\N	\N	f
25	24	2025	25	f	17	2026-09-09 17:03:02.818+00	2026-09-09 17:03:02.818+00	published	2026-09-09 17:03:02.827+00	2026-09-09 17:03:02.827+00	\N	\N	f
69	25	2025	26	f	18	2026-09-09 17:10:34.57+00	2026-09-09 17:03:18.625+00	published	2026-09-09 17:10:34.681+00	2026-09-09 17:10:34.681+00	\N	\N	t
68	25	2025	26	f	18	2026-09-09 17:10:34.247+00	2026-09-09 17:03:18.625+00	published	2026-09-09 17:10:34.264+00	2026-09-09 17:10:34.264+00	\N	\N	f
26	25	2025	26	f	18	2026-09-09 17:03:18.625+00	2026-09-09 17:03:18.625+00	published	2026-09-09 17:03:18.689+00	2026-09-09 17:03:18.689+00	\N	\N	f
71	26	2025	27	f	19	2026-09-09 17:10:35.623+00	2026-09-09 17:03:38.053+00	published	2026-09-09 17:10:35.63+00	2026-09-09 17:10:35.63+00	\N	\N	t
70	26	2025	27	f	19	2026-09-09 17:10:35.288+00	2026-09-09 17:03:38.053+00	published	2026-09-09 17:10:35.302+00	2026-09-09 17:10:35.302+00	\N	\N	f
27	26	2025	27	f	19	2026-09-09 17:03:38.054+00	2026-09-09 17:03:38.053+00	published	2026-09-09 17:03:38.08+00	2026-09-09 17:03:38.08+00	\N	\N	f
73	27	2025	28	f	20	2026-09-09 17:10:36.124+00	2026-09-09 17:03:53.869+00	published	2026-09-09 17:10:36.132+00	2026-09-09 17:10:36.132+00	\N	\N	t
72	27	2025	28	f	20	2026-09-09 17:10:35.883+00	2026-09-09 17:03:53.869+00	published	2026-09-09 17:10:35.889+00	2026-09-09 17:10:35.889+00	\N	\N	f
28	27	2025	28	f	20	2026-09-09 17:03:53.869+00	2026-09-09 17:03:53.869+00	published	2026-09-09 17:03:53.876+00	2026-09-09 17:03:53.876+00	\N	\N	f
75	28	2025	29	f	21	2026-09-09 17:10:36.61+00	2026-09-09 17:04:09.718+00	published	2026-09-09 17:10:36.614+00	2026-09-09 17:10:36.614+00	\N	\N	t
30	29	2025	30	f	22	2026-09-09 17:04:25.309+00	2026-09-09 17:04:25.308+00	published	2026-09-09 17:04:25.315+00	2026-09-09 17:04:25.315+00	\N	\N	f
31	30	2025	31	f	23	2026-09-09 17:04:43.687+00	2026-09-09 17:04:43.686+00	published	2026-09-09 17:04:43.694+00	2026-09-09 17:04:43.694+00	\N	\N	f
74	28	2025	29	f	21	2026-09-09 17:10:36.396+00	2026-09-09 17:04:09.718+00	published	2026-09-09 17:10:36.401+00	2026-09-09 17:10:36.401+00	\N	\N	f
29	28	2025	29	f	21	2026-09-09 17:04:09.718+00	2026-09-09 17:04:09.718+00	published	2026-09-09 17:04:09.725+00	2026-09-09 17:04:09.725+00	\N	\N	f
35	8	2025	8	f	1	2026-09-09 17:10:23.57+00	2026-09-09 16:50:49.246+00	published	2026-09-09 17:10:23.577+00	2026-09-09 17:10:23.577+00	\N	\N	f
77	29	2025	30	f	22	2026-09-09 17:10:37.142+00	2026-09-09 17:04:25.308+00	published	2026-09-09 17:10:37.153+00	2026-09-09 17:10:37.153+00	\N	\N	t
76	29	2025	30	f	22	2026-09-09 17:10:36.881+00	2026-09-09 17:04:25.308+00	published	2026-09-09 17:10:36.89+00	2026-09-09 17:10:36.89+00	\N	\N	f
34	8	2025	8	f	1	2026-09-09 17:10:23.302+00	2026-09-09 16:50:49.246+00	published	2026-09-09 17:10:23.312+00	2026-09-09 17:10:23.312+00	\N	\N	f
79	30	2025	31	f	23	2026-09-09 17:10:37.71+00	2026-09-09 17:04:43.686+00	published	2026-09-09 17:10:37.714+00	2026-09-09 17:10:37.714+00	\N	\N	t
78	30	2025	31	f	23	2026-09-09 17:10:37.439+00	2026-09-09 17:04:43.686+00	published	2026-09-09 17:10:37.443+00	2026-09-09 17:10:37.443+00	\N	\N	f
9	8	2025	8	f	1	2026-09-09 16:50:49.307+00	2026-09-09 16:50:49.246+00	published	2026-09-09 16:50:49.748+00	2026-09-09 16:50:49.748+00	\N	\N	f
81	7	2025	7	f	0	2026-09-14 08:46:25.909+00	2026-09-09 16:43:46.822+00	published	2026-09-14 08:46:25.924+00	2026-09-14 08:46:25.924+00	\N	\N	t
\.


--
-- Data for Name: _portfolio_v_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._portfolio_v_locales (version_title, version_category, version_description, version_image_alt, version_generate_slug, version_slug, id, _locale, _parent_id) FROM stdin;
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	8	en	8
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	9	en	9
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	10	en	10
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	11	en	11
Distruptive	—	—	Distruptive website screenshot	f	distruptive	12	en	12
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	13	en	13
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	14	en	14
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	15	en	15
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	16	en	16
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	17	en	17
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	18	en	18
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	19	en	19
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	20	en	20
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	21	en	21
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	22	en	22
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	23	en	23
Optica Capuchinos	—	—	Optica Capuchinos website screenshot	f	optica-capuchinos	24	en	24
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	25	en	25
Stay Store	—	—	Stay Store website screenshot	f	stay-store	26	en	26
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	27	en	27
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	28	en	28
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	29	en	29
Wearstatuquo	—	—	Wearstatuquo website screenshot	f	wearstatuquo	30	en	30
ZenResort	—	—	ZenResort website screenshot	f	zenresort	31	en	31
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	32	en	32
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	33	en	33
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	34	id	33
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	35	en	34
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	36	en	35
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	37	id	35
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	38	en	36
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	39	en	37
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	40	id	37
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	41	en	38
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	42	en	39
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	43	id	39
Distruptive	—	—	Distruptive website screenshot	f	distruptive	44	en	40
Distruptive	—	—	Distruptive website screenshot	f	distruptive	45	en	41
Distruptive	—	—	Distruptive website screenshot	f	distruptive	46	id	41
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	47	en	42
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	48	en	43
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	49	id	43
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	50	en	44
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	51	en	45
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	52	id	45
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	53	en	46
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	54	en	47
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	55	id	47
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	56	en	48
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	57	en	49
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	58	id	49
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	59	en	50
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	60	en	51
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	61	id	51
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	62	en	52
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	63	en	53
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	64	id	53
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	65	en	54
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	66	en	55
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	67	id	55
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	68	en	56
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	69	en	57
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	70	id	57
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	71	en	58
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	72	en	59
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	73	id	59
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	74	en	60
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	75	en	61
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	76	id	61
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	77	en	62
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	78	en	63
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	79	id	63
OPTICA CAPUCHINOS	—	—	OPTICA CAPUCHINOS website screenshot	f	optica-capuchinos	80	en	64
OPTICA CAPUCHINOS	—	—	OPTICA CAPUCHINOS website screenshot	f	optica-capuchinos	81	en	65
OPTICA CAPUCHINOS	—	—	OPTICA CAPUCHINOS website screenshot	f	optica-capuchinos	82	id	65
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	83	en	66
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	84	en	67
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	85	id	67
Stay Store	—	—	Stay Store website screenshot	f	stay-store	86	en	68
Stay Store	—	—	Stay Store website screenshot	f	stay-store	87	en	69
Stay Store	—	—	Stay Store website screenshot	f	stay-store	88	id	69
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	89	en	70
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	90	en	71
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	91	id	71
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	92	en	72
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	93	en	73
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	94	id	73
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	95	en	74
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	96	en	75
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	97	id	75
wearstatuquo	—	—	wearstatuquo website screenshot	f	wearstatuquo	98	en	76
wearstatuquo	—	—	wearstatuquo website screenshot	f	wearstatuquo	99	en	77
wearstatuquo	—	—	wearstatuquo website screenshot	f	wearstatuquo	100	id	77
ZenResort	—	—	ZenResort website screenshot	f	zenresort	101	en	78
ZenResort	—	—	ZenResort website screenshot	f	zenresort	102	en	79
ZenResort	—	—	ZenResort website screenshot	f	zenresort	103	id	79
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	104	en	80
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	105	id	80
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	106	en	81
Alas Harum Silverr	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	107	id	81
\.


--
-- Data for Name: _posts_v; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._posts_v (id, parent_id, version_hero_image_id, version_published_at, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _posts_v_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._posts_v_locales (version_title, version_content, version_meta_title, version_meta_image_id, version_meta_description, version_generate_slug, version_slug, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: _posts_v_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._posts_v_rels (id, "order", parent_id, path, posts_id, categories_id, users_id) FROM stdin;
\.


--
-- Data for Name: _posts_v_version_populated_authors; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._posts_v_version_populated_authors (_order, _parent_id, id, _uuid, name) FROM stdin;
\.


--
-- Data for Name: _services_v; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._services_v (id, parent_id, version_order, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest) FROM stdin;
6	5	3	2026-09-01 02:26:55.371+00	2026-09-01 02:26:43.808+00	published	2026-09-01 02:26:55.382+00	2026-09-01 02:26:55.382+00	\N	\N	t
5	5	3	2026-09-01 02:26:43.808+00	2026-09-01 02:26:43.808+00	published	2026-09-01 02:26:43.819+00	2026-09-01 02:26:43.819+00	\N	\N	f
7	4	2	2026-09-01 02:26:55.991+00	2026-09-01 02:26:33.581+00	published	2026-09-01 02:26:56.021+00	2026-09-01 02:26:56.021+00	\N	\N	t
4	4	2	2026-09-01 02:26:33.581+00	2026-09-01 02:26:33.581+00	published	2026-09-01 02:26:33.59+00	2026-09-01 02:26:33.59+00	\N	\N	f
8	3	1	2026-09-01 02:26:56.467+00	2026-09-01 02:26:33.243+00	published	2026-09-01 02:26:56.533+00	2026-09-01 02:26:56.533+00	\N	\N	t
3	3	1	2026-09-01 02:26:33.243+00	2026-09-01 02:26:33.243+00	published	2026-09-01 02:26:33.257+00	2026-09-01 02:26:33.257+00	\N	\N	f
10	2	4	2026-09-01 02:26:56.84+00	2026-09-01 02:26:32.264+00	published	2026-09-01 02:26:56.856+00	2026-09-01 02:26:56.856+00	\N	\N	t
2	2	4	2026-09-01 02:26:32.264+00	2026-09-01 02:26:32.264+00	published	2026-09-01 02:26:32.272+00	2026-09-01 02:26:32.272+00	\N	\N	f
12	1	0	2026-09-14 08:42:39.382+00	2026-09-01 02:26:31.578+00	published	2026-09-14 08:42:39.397+00	2026-09-14 08:42:39.397+00	\N	\N	t
1	1	0	2026-09-01 02:26:31.578+00	2026-09-01 02:26:31.578+00	published	2026-09-01 02:26:31.589+00	2026-09-01 02:26:31.589+00	\N	\N	f
11	1	0	2026-09-01 02:39:49.921+00	2026-09-01 02:26:31.578+00	published	2026-09-01 02:39:49.943+00	2026-09-01 02:39:49.943+00	\N	\N	f
9	1	0	2026-09-01 02:26:56.541+00	2026-09-01 02:26:31.578+00	published	2026-09-01 02:26:56.585+00	2026-09-01 02:26:56.585+00	\N	\N	f
\.


--
-- Data for Name: _services_v_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._services_v_locales (version_title, version_summary, version_body, id, _locale, _parent_id) FROM stdin;
Business Technology Consultant & Builder	Strategy and systems that turn business goals into working products.	Map how the business operates, then design the stack, workflows, and tools — from discovery through build and handoff.	1	en	1
AI Development	Practical AI features and workflows that serve the brand, not the hype.	Assistants, automation, and product features grounded in real use cases, with a human-readable interface.	2	en	2
Brand Create	Visualize the business from zero to one — identity with intent.	Name, voice, visual system, and narrative. A brand that can grow with the product, not a logo sitting on top of it.	3	en	3
Design Website	See the website clearly before build — structure, flow, and craft.	Information architecture, wireframes, and high-fidelity design so the experience can be approved before production code.	4	en	4
Development Website	Precise front-end and platform builds, engineered for clarity.	Modern, performant sites and web apps — typed, accessible, maintainable — aligned to the design system.	5	en	5
Development Website	Precise front-end and platform builds, engineered for clarity.	Modern, performant sites and web apps — typed, accessible, maintainable — aligned to the design system.	6	en	6
Development Website	Build front-end dan platform yang presisi, dirancang untuk kejelasan.	Website dan web app modern yang performan — typed, accessible, maintainable — selaras dengan design system.	7	id	6
Design Website	See the website clearly before build — structure, flow, and craft.	Information architecture, wireframes, and high-fidelity design so the experience can be approved before production code.	8	en	7
Design Website	Lihat website dengan jelas sebelum build — struktur, alur, dan craft.	Arsitektur informasi, wireframe, dan desain high-fidelity agar pengalaman bisa disetujui sebelum kode produksi.	9	id	7
Brand Create	Visualize the business from zero to one — identity with intent.	Name, voice, visual system, and narrative. A brand that can grow with the product, not a logo sitting on top of it.	10	en	8
Brand Create	Visualisasikan bisnis dari nol ke satu — identitas dengan intent.	Nama, suara, sistem visual, dan narasi. Brand yang bisa tumbuh bersama produk, bukan logo yang hanya menempel di atasnya.	11	id	8
Business Technology Consultant & Builder	Strategy and systems that turn business goals into working products.	Map how the business operates, then design the stack, workflows, and tools — from discovery through build and handoff.	12	en	9
Konsultan & Builder Teknologi Bisnis	Strategi dan sistem yang mengubah tujuan bisnis menjadi produk yang berfungsi.	Petakan cara bisnis beroperasi, lalu rancang stack, alur kerja, dan tools — dari discovery hingga build dan handoff.	13	id	9
AI Development	Practical AI features and workflows that serve the brand, not the hype.	Assistants, automation, and product features grounded in real use cases, with a human-readable interface.	14	en	10
AI Development	Fitur dan alur AI praktis yang melayani brand, bukan hype.	Asisten, otomasi, dan fitur produk yang berlandaskan use case nyata, dengan antarmuka yang mudah dibaca manusia.	15	id	10
Business Technology Consultant & Builder	Strategy and systems that turn business goals into working products.	Map how the business operates, then design the stack, workflows, and tools — from discovery through build and handoff.	16	en	11
Konsultan & Builder Teknologi Bisnis	Strategi dan sistem yang mengubah tujuan bisnis menjadi produk yang berfungsi.	Petakan cara bisnis beroperasi, lalu rancang stack, alur kerja, dan tools — dari discovery hingga build dan handoff.	17	id	11
Business Technology Consultant & Builder	Strategy and systems that turn business goals into working products.	Map how the business operates, then design the stack, workflows, and tools — from discovery through build and handoff.	18	en	12
Konsultan & Builder Teknologi Bisnis	Strategi dan sistem yang mengubah tujuan bisnis menjadi produk yang berfungsi.	Petakan cara bisnis beroperasi, lalu rancang stack, alur kerja, dan tools — dari discovery hingga build dan handoff.	19	id	12
\.


--
-- Data for Name: _testimonials_v; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._testimonials_v (id, parent_id, version_name, version_order, version_updated_at, version_created_at, version__status, created_at, updated_at, snapshot, published_locale, latest) FROM stdin;
4	2	Nata	2	2026-09-01 02:49:46.145+00	2026-09-01 02:49:39.727+00	published	2026-09-01 02:49:46.178+00	2026-09-01 02:49:46.178+00	\N	\N	t
2	2	Nata	2	2026-09-01 02:49:39.727+00	2026-09-01 02:49:39.727+00	published	2026-09-01 02:49:39.731+00	2026-09-01 02:49:39.731+00	\N	\N	f
8	1	Mantra	0	2026-09-01 03:01:43.282+00	2026-09-01 02:49:38.586+00	published	2026-09-01 03:01:43.303+00	2026-09-01 03:01:43.303+00	\N	\N	t
1	1	Mantra	0	2026-09-01 02:49:38.586+00	2026-09-01 02:49:38.586+00	published	2026-09-01 02:49:38.631+00	2026-09-01 02:49:38.631+00	\N	\N	f
7	1	Mantra	0	2026-09-01 03:00:57.033+00	2026-09-01 02:49:38.586+00	published	2026-09-01 03:00:57.059+00	2026-09-01 03:00:57.059+00	\N	\N	f
5	1	Mantra	0	2026-09-01 02:49:46.586+00	2026-09-01 02:49:38.586+00	published	2026-09-01 02:49:46.601+00	2026-09-01 02:49:46.601+00	\N	\N	f
10	3	Nobee Mengemudi	1	2026-09-01 03:02:34.983+00	2026-09-01 02:49:41.432+00	published	2026-09-01 03:02:35.005+00	2026-09-01 03:02:35.005+00	\N	\N	t
3	3	Nobee Mengemudi	1	2026-09-01 02:49:41.432+00	2026-09-01 02:49:41.432+00	published	2026-09-01 02:49:41.448+00	2026-09-01 02:49:41.448+00	\N	\N	f
9	3	Nobee Mengemudi	1	2026-09-01 03:02:29.921+00	2026-09-01 02:49:41.432+00	published	2026-09-01 03:02:29.927+00	2026-09-01 03:02:29.927+00	\N	\N	f
6	3	Nobee Mengemudi	1	2026-09-01 02:49:46.608+00	2026-09-01 02:49:41.432+00	published	2026-09-01 02:49:46.626+00	2026-09-01 02:49:46.626+00	\N	\N	f
\.


--
-- Data for Name: _testimonials_v_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public._testimonials_v_locales (version_quote, version_role, id, _locale, _parent_id) FROM stdin;
MŌMOS delivered exactly what we needed — thoughtful service from first brief to final handoff. Every step felt considered, responsive, and built around our goals.	Founder, Mantra	1	en	1
Communication with MŌMOS was clear from day one. They listened, kept us in the loop, and made sure every decision was easy to understand before we moved forward.	Founder, Nata	2	en	2
The branding solution MŌMOS built for us fits the Bali market perfectly. Our identity finally speaks to local customers — and we have seen that translate directly into stronger sales.	Manager at Nobee Mengemudi	3	en	3
Communication with MŌMOS was clear from day one. They listened, kept us in the loop, and made sure every decision was easy to understand before we moved forward.	Founder, Nata	4	en	4
Komunikasi dengan MŌMOS jelas sejak hari pertama. Mereka mendengarkan, menjaga kami selalu update, dan memastikan setiap keputusan mudah dipahami sebelum kami lanjut.	Founder, Nata	5	id	4
MŌMOS delivered exactly what we needed — thoughtful service from first brief to final handoff. Every step felt considered, responsive, and built around our goals.	Founder, Mantra	6	en	5
MŌMOS memberikan persis yang kami butuhkan — layanan yang matang dari brief pertama hingga serah terima. Setiap langkah terasa penuh pertimbangan, responsif, dan selaras dengan tujuan kami.	Founder, Mantra	7	id	5
The branding solution MŌMOS built for us fits the Bali market perfectly. Our identity finally speaks to local customers — and we have seen that translate directly into stronger sales.	Manager at Nobee Mengemudi	8	en	6
Solusi branding dari MŌMOS sangat selaras dengan pasar Bali. Identitas kami akhirnya berbicara ke pelanggan lokal — dan kami merasakan dampaknya langsung pada penjualan.	Manager at Nobee Mengemudi	9	id	6
MŌMOS delivered exactly what we needed. thoughtful service from first brief to final handoff. Every step felt considered, responsive, and built around our goals.	Founder, Mantra	10	en	7
MŌMOS memberikan persis yang kami butuhkan — layanan yang matang dari brief pertama hingga serah terima. Setiap langkah terasa penuh pertimbangan, responsif, dan selaras dengan tujuan kami.	Founder, Mantra	11	id	7
MŌMOS delivered exactly what we needed. thoughtful service from first brief to final handoff. Every step felt considered, responsive, and built around our goals.	Founder, Mantra	12	en	8
MŌMOS deliver service sesuai yg kami butuhkan. dari brief pertama hingga serah terima. Setiap proses pertimbangan, responsif, dan selaras dengan tujuan kami.	Founder, Mantra	13	id	8
The branding solution MŌMOS built for us fits the Bali market perfectly. Our identity finally speaks to local customers — and we have seen that translate directly into stronger sales.	Manager at Nobee Mengemudi	14	en	9
Solusi branding dari MŌMOS sangat cocok dengan pasar kami di Bali. Identitas kami akhirnya berbicara ke murid lokal. dan kami merasakan dampaknya langsung pada sales.	Manager at Nobee Mengemudi	15	id	9
The branding solution MŌMOS built for us fits the Bali market perfectly. Our identity finally speaks to local customers. and we have seen that translate directly into stronger sales.	Manager at Nobee Mengemudi	16	en	10
Solusi branding dari MŌMOS sangat cocok dengan pasar kami di Bali. Identitas kami akhirnya berbicara ke murid lokal. dan kami merasakan dampaknya langsung pada sales.	Manager at Nobee Mengemudi	17	id	10
\.


--
-- Data for Name: about; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.about (id, updated_at, created_at) FROM stdin;
1	2026-09-01 02:26:20.879+00	2026-09-01 02:26:20.879+00
\.


--
-- Data for Name: about_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.about_locales (hero_heading, hero_description, story_heading, story_paragraph1, story_paragraph2, principles_section_heading, principles_section_subtext, id, _locale, _parent_id) FROM stdin;
Digital craft, elevated	MŌMOS is an agency for founders and operators who need a clear brand, a website they can see before it ships, and technology that matches how the business actually works.	Who we are	We started MŌMOS to close the gap between strategy decks and shipped work. Brand, web, and AI sit in one studio so the story, the interface, and the build stay aligned.	Whether you are going from zero to one or tightening an existing product, we work as one team from first sketch through launch — no theater, no leftover slides.	How we work	A few principles that keep every engagement sharp.	4	en	1
Kerajinan digital, ditingkatkan.	MŌMOS adalah agensi untuk founder dan operator yang membutuhkan brand yang jelas, website yang bisa dilihat sebelum diluncurkan, dan teknologi yang selaras dengan cara bisnis benar-benar beroperasi.	Siapa kami	Kami mendirikan MŌMOS untuk menutup jarak antara deck strategi dan pekerjaan yang benar-benar dirilis. Brand, web, dan AI berada dalam satu studio sehingga cerita, antarmuka, dan build tetap selaras.	Baik Anda memulai dari nol atau memperbaiki produk yang sudah ada, kami bekerja sebagai satu tim dari sketsa pertama hingga peluncuran — tanpa teater, tanpa slide yang tertinggal.	Cara kami bekerja	Beberapa prinsip yang menjaga setiap proyek tetap tajam.	5	id	1
\.


--
-- Data for Name: about_principles; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.about_principles (_order, _parent_id, _locale, id, title, body) FROM stdin;
1	1	en	6a9637cc256c990001f5cd91	Clarity first	If it is not clear, it is not done. We cut noise until the idea can stand alone.
2	1	en	6a9637cc256c990001f5cd92	See before build	Brand and product should be visible early, so decisions are made with eyes open.
3	1	en	6a9637cc256c990001f5cd93	Ship with craft	Strategy without execution is slides. We stay through design and development.
1	1	id	6a9637d3256c990001f5cd94	Kejelasan dulu	Jika belum jelas, belum selesai. Kami memangkas noise sampai ide bisa berdiri sendiri.
2	1	id	6a9637d3256c990001f5cd95	Lihat sebelum bangun	Brand dan produk harus terlihat sejak awal, agar keputusan diambil dengan mata terbuka.
3	1	id	6a9637d3256c990001f5cd96	Rilis dengan craft	Strategi tanpa eksekusi hanyalah slide. Kami tetap hadir dari desain hingga development.
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.categories (id, parent_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: categories_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.categories_breadcrumbs (_order, _parent_id, _locale, id, doc_id, url, label) FROM stdin;
\.


--
-- Data for Name: categories_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.categories_locales (title, generate_slug, slug, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: footer; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.footer (id, updated_at, created_at) FROM stdin;
1	2026-08-28 09:57:55.883+00	2026-08-28 09:57:55.883+00
\.


--
-- Data for Name: footer_nav_items; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.footer_nav_items (_order, _parent_id, id, link_type, link_new_tab, link_url) FROM stdin;
1	1	6a915ba32fa744000110f9b5	custom	\N	/about
2	1	6a915ba32fa744000110f9b6	custom	\N	/services
3	1	6a915ba32fa744000110f9b7	custom	\N	/portfolio
4	1	6a915ba32fa744000110f9b8	custom	\N	/posts
\.


--
-- Data for Name: footer_nav_items_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.footer_nav_items_locales (link_label, id, _locale, _parent_id) FROM stdin;
about	1	en	6a915ba32fa744000110f9b5
services	2	en	6a915ba32fa744000110f9b6
portfolio	3	en	6a915ba32fa744000110f9b7
blog	4	en	6a915ba32fa744000110f9b8
\.


--
-- Data for Name: footer_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.footer_rels (id, "order", parent_id, path, posts_id) FROM stdin;
\.


--
-- Data for Name: form_submissions; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.form_submissions (id, form_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: form_submissions_submission_data; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.form_submissions_submission_data (_order, _parent_id, id, field, value) FROM stdin;
\.


--
-- Data for Name: forms; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms (id, title, confirmation_type, redirect_url, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: forms_blocks_checkbox; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_checkbox (_order, _parent_id, _path, id, name, width, required, default_value, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_checkbox_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_checkbox_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_country; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_country (_order, _parent_id, _path, id, name, width, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_country_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_country_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_email; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_email (_order, _parent_id, _path, id, name, width, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_email_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_email_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_message; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_message (_order, _parent_id, _path, id, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_message_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_message_locales (message, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_number; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_number (_order, _parent_id, _path, id, name, width, default_value, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_number_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_number_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_select; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_select (_order, _parent_id, _path, id, name, width, placeholder, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_select_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_select_locales (label, default_value, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_select_options; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_select_options (_order, _parent_id, id, value) FROM stdin;
\.


--
-- Data for Name: forms_blocks_select_options_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_select_options_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_state; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_state (_order, _parent_id, _path, id, name, width, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_state_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_state_locales (label, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_text; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_text (_order, _parent_id, _path, id, name, width, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_text_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_text_locales (label, default_value, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_blocks_textarea; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_textarea (_order, _parent_id, _path, id, name, width, required, block_name) FROM stdin;
\.


--
-- Data for Name: forms_blocks_textarea_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_blocks_textarea_locales (label, default_value, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_emails; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_emails (_order, _parent_id, id, email_to, cc, bcc, reply_to, email_from) FROM stdin;
\.


--
-- Data for Name: forms_emails_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_emails_locales (subject, message, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: forms_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.forms_locales (submit_button_label, confirmation_message, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: header; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.header (id, updated_at, created_at) FROM stdin;
1	2026-08-28 09:57:56.29+00	2026-08-28 09:57:56.29+00
\.


--
-- Data for Name: header_nav_items; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.header_nav_items (_order, _parent_id, id, link_type, link_new_tab, link_url) FROM stdin;
1	1	6a915ba42fa744000110f9b9	custom	\N	/about
2	1	6a915ba42fa744000110f9ba	custom	\N	/services
3	1	6a915ba42fa744000110f9bb	custom	\N	/portfolio
4	1	6a915ba42fa744000110f9bc	custom	\N	/posts
\.


--
-- Data for Name: header_nav_items_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.header_nav_items_locales (link_label, id, _locale, _parent_id) FROM stdin;
about	1	en	6a915ba42fa744000110f9b9
services	2	en	6a915ba42fa744000110f9ba
portfolio	3	en	6a915ba42fa744000110f9bb
blog	4	en	6a915ba42fa744000110f9bc
\.


--
-- Data for Name: header_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.header_rels (id, "order", parent_id, path, posts_id) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.media (id, folder_id, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumbnail_url, sizes_thumbnail_width, sizes_thumbnail_height, sizes_thumbnail_mime_type, sizes_thumbnail_filesize, sizes_thumbnail_filename, sizes_square_url, sizes_square_width, sizes_square_height, sizes_square_mime_type, sizes_square_filesize, sizes_square_filename, sizes_small_url, sizes_small_width, sizes_small_height, sizes_small_mime_type, sizes_small_filesize, sizes_small_filename, sizes_medium_url, sizes_medium_width, sizes_medium_height, sizes_medium_mime_type, sizes_medium_filesize, sizes_medium_filename, sizes_large_url, sizes_large_width, sizes_large_height, sizes_large_mime_type, sizes_large_filesize, sizes_large_filename, sizes_xlarge_url, sizes_xlarge_width, sizes_xlarge_height, sizes_xlarge_mime_type, sizes_xlarge_filesize, sizes_xlarge_filename, sizes_og_url, sizes_og_width, sizes_og_height, sizes_og_mime_type, sizes_og_filesize, sizes_og_filename) FROM stdin;
7	\N	2026-09-09 16:43:15.504+00	2026-09-09 16:43:15.504+00	/api/media/file/alas-harum-silver.webp	\N	alas-harum-silver.webp	image/webp	339568	4096	3072	50	50	/api/media/file/alas-harum-silver-300x225.webp	300	225	image/webp	13764	alas-harum-silver-300x225.webp	/api/media/file/alas-harum-silver-500x500.webp	500	500	image/webp	34128	alas-harum-silver-500x500.webp	/api/media/file/alas-harum-silver-600x450.webp	600	450	image/webp	35796	alas-harum-silver-600x450.webp	/api/media/file/alas-harum-silver-900x675.webp	900	675	image/webp	60378	alas-harum-silver-900x675.webp	/api/media/file/alas-harum-silver-1400x1050.webp	1400	1050	image/webp	98678	alas-harum-silver-1400x1050.webp	/api/media/file/alas-harum-silver-1920x1440.webp	1920	1440	image/webp	145082	alas-harum-silver-1920x1440.webp	/api/media/file/alas-harum-silver-1200x630.webp	1200	630	image/webp	67220	alas-harum-silver-1200x630.webp
8	\N	2026-09-09 16:49:33.197+00	2026-09-09 16:49:33.197+00	/api/media/file/bali-paragliding.webp	\N	bali-paragliding.webp	image/webp	142210	4096	3072	50	50	/api/media/file/bali-paragliding-300x225.webp	300	225	image/webp	6310	bali-paragliding-300x225.webp	/api/media/file/bali-paragliding-500x500.webp	500	500	image/webp	14440	bali-paragliding-500x500.webp	/api/media/file/bali-paragliding-600x450.webp	600	450	image/webp	14378	bali-paragliding-600x450.webp	/api/media/file/bali-paragliding-900x675.webp	900	675	image/webp	23364	bali-paragliding-900x675.webp	/api/media/file/bali-paragliding-1400x1050.webp	1400	1050	image/webp	39142	bali-paragliding-1400x1050.webp	/api/media/file/bali-paragliding-1920x1440.webp	1920	1440	image/webp	55198	bali-paragliding-1920x1440.webp	/api/media/file/bali-paragliding-1200x630.webp	1200	630	image/webp	26200	bali-paragliding-1200x630.webp
9	\N	2026-09-09 16:50:45.302+00	2026-09-09 16:50:45.299+00	/api/media/file/berawa-vet-care.webp	\N	berawa-vet-care.webp	image/webp	103076	4096	3072	50	50	/api/media/file/berawa-vet-care-300x225.webp	300	225	image/webp	5326	berawa-vet-care-300x225.webp	/api/media/file/berawa-vet-care-500x500.webp	500	500	image/webp	11966	berawa-vet-care-500x500.webp	/api/media/file/berawa-vet-care-600x450.webp	600	450	image/webp	11338	berawa-vet-care-600x450.webp	/api/media/file/berawa-vet-care-900x675.webp	900	675	image/webp	17992	berawa-vet-care-900x675.webp	/api/media/file/berawa-vet-care-1400x1050.webp	1400	1050	image/webp	29692	berawa-vet-care-1400x1050.webp	/api/media/file/berawa-vet-care-1920x1440.webp	1920	1440	image/webp	41532	berawa-vet-care-1920x1440.webp	/api/media/file/berawa-vet-care-1200x630.webp	1200	630	image/webp	20940	berawa-vet-care-1200x630.webp
10	\N	2026-09-09 16:50:45.419+00	2026-09-09 16:50:45.419+00	/api/media/file/berkat-abadi.webp	\N	berkat-abadi.webp	image/webp	102170	4096	3072	50	50	/api/media/file/berkat-abadi-300x225.webp	300	225	image/webp	4288	berkat-abadi-300x225.webp	/api/media/file/berkat-abadi-500x500.webp	500	500	image/webp	9360	berkat-abadi-500x500.webp	/api/media/file/berkat-abadi-600x450.webp	600	450	image/webp	9746	berkat-abadi-600x450.webp	/api/media/file/berkat-abadi-900x675.webp	900	675	image/webp	15424	berkat-abadi-900x675.webp	/api/media/file/berkat-abadi-1400x1050.webp	1400	1050	image/webp	26456	berkat-abadi-1400x1050.webp	/api/media/file/berkat-abadi-1920x1440.webp	1920	1440	image/webp	39664	berkat-abadi-1920x1440.webp	/api/media/file/berkat-abadi-1200x630.webp	1200	630	image/webp	19562	berkat-abadi-1200x630.webp
11	\N	2026-09-09 16:50:45.481+00	2026-09-09 16:50:45.481+00	/api/media/file/distruptive.webp	\N	distruptive.webp	image/webp	145760	4096	3072	50	50	/api/media/file/distruptive-300x225.webp	300	225	image/webp	7860	distruptive-300x225.webp	/api/media/file/distruptive-500x500.webp	500	500	image/webp	14488	distruptive-500x500.webp	/api/media/file/distruptive-600x450.webp	600	450	image/webp	16134	distruptive-600x450.webp	/api/media/file/distruptive-900x675.webp	900	675	image/webp	25248	distruptive-900x675.webp	/api/media/file/distruptive-1400x1050.webp	1400	1050	image/webp	41902	distruptive-1400x1050.webp	/api/media/file/distruptive-1920x1440.webp	1920	1440	image/webp	60642	distruptive-1920x1440.webp	/api/media/file/distruptive-1200x630.webp	1200	630	image/webp	27086	distruptive-1200x630.webp
12	\N	2026-09-09 16:50:50.044+00	2026-09-09 16:50:50.043+00	/api/media/file/immasa-studio.webp	\N	immasa-studio.webp	image/webp	118762	4096	3072	50	50	/api/media/file/immasa-studio-300x225.webp	300	225	image/webp	5896	immasa-studio-300x225.webp	/api/media/file/immasa-studio-500x500.webp	500	500	image/webp	11106	immasa-studio-500x500.webp	/api/media/file/immasa-studio-600x450.webp	600	450	image/webp	12442	immasa-studio-600x450.webp	/api/media/file/immasa-studio-900x675.webp	900	675	image/webp	19610	immasa-studio-900x675.webp	/api/media/file/immasa-studio-1400x1050.webp	1400	1050	image/webp	33310	immasa-studio-1400x1050.webp	/api/media/file/immasa-studio-1920x1440.webp	1920	1440	image/webp	47156	immasa-studio-1920x1440.webp	/api/media/file/immasa-studio-1200x630.webp	1200	630	image/webp	18524	immasa-studio-1200x630.webp
13	\N	2026-09-09 16:50:52.846+00	2026-09-09 16:50:52.846+00	/api/media/file/kedai-bang-bewok.webp	\N	kedai-bang-bewok.webp	image/webp	166302	4096	3072	50	50	/api/media/file/kedai-bang-bewok-300x225.webp	300	225	image/webp	8764	kedai-bang-bewok-300x225.webp	/api/media/file/kedai-bang-bewok-500x500.webp	500	500	image/webp	17216	kedai-bang-bewok-500x500.webp	/api/media/file/kedai-bang-bewok-600x450.webp	600	450	image/webp	18358	kedai-bang-bewok-600x450.webp	/api/media/file/kedai-bang-bewok-900x675.webp	900	675	image/webp	29142	kedai-bang-bewok-900x675.webp	/api/media/file/kedai-bang-bewok-1400x1050.webp	1400	1050	image/webp	47746	kedai-bang-bewok-1400x1050.webp	/api/media/file/kedai-bang-bewok-1920x1440.webp	1920	1440	image/webp	67430	kedai-bang-bewok-1920x1440.webp	/api/media/file/kedai-bang-bewok-1200x630.webp	1200	630	image/webp	32264	kedai-bang-bewok-1200x630.webp
15	\N	2026-09-09 16:59:49.228+00	2026-09-09 16:59:49.227+00	/api/media/file/kopi-veteran.webp	\N	kopi-veteran.webp	image/webp	148880	4096	3072	50	50	/api/media/file/kopi-veteran-300x225.webp	300	225	image/webp	6516	kopi-veteran-300x225.webp	/api/media/file/kopi-veteran-500x500.webp	500	500	image/webp	15772	kopi-veteran-500x500.webp	/api/media/file/kopi-veteran-600x450.webp	600	450	image/webp	15048	kopi-veteran-600x450.webp	/api/media/file/kopi-veteran-900x675.webp	900	675	image/webp	24336	kopi-veteran-900x675.webp	/api/media/file/kopi-veteran-1400x1050.webp	1400	1050	image/webp	41788	kopi-veteran-1400x1050.webp	/api/media/file/kopi-veteran-1920x1440.webp	1920	1440	image/webp	62336	kopi-veteran-1920x1440.webp	/api/media/file/kopi-veteran-1200x630.webp	1200	630	image/webp	31346	kopi-veteran-1200x630.webp
16	\N	2026-09-09 17:00:11.8+00	2026-09-09 17:00:11.8+00	/api/media/file/krisna-silver-class.webp	\N	krisna-silver-class.webp	image/webp	163436	4096	3072	50	50	/api/media/file/krisna-silver-class-300x225.webp	300	225	image/webp	8310	krisna-silver-class-300x225.webp	/api/media/file/krisna-silver-class-500x500.webp	500	500	image/webp	17840	krisna-silver-class-500x500.webp	/api/media/file/krisna-silver-class-600x450.webp	600	450	image/webp	18464	krisna-silver-class-600x450.webp	/api/media/file/krisna-silver-class-900x675.webp	900	675	image/webp	29114	krisna-silver-class-900x675.webp	/api/media/file/krisna-silver-class-1400x1050.webp	1400	1050	image/webp	48550	krisna-silver-class-1400x1050.webp	/api/media/file/krisna-silver-class-1920x1440.webp	1920	1440	image/webp	69964	krisna-silver-class-1920x1440.webp	/api/media/file/krisna-silver-class-1200x630.webp	1200	630	image/webp	31182	krisna-silver-class-1200x630.webp
17	\N	2026-09-09 17:00:35.092+00	2026-09-09 17:00:35.092+00	/api/media/file/lovina-hill-paradise.webp	\N	lovina-hill-paradise.webp	image/webp	291012	4096	3072	50	50	/api/media/file/lovina-hill-paradise-300x225.webp	300	225	image/webp	13728	lovina-hill-paradise-300x225.webp	/api/media/file/lovina-hill-paradise-500x500.webp	500	500	image/webp	29732	lovina-hill-paradise-500x500.webp	/api/media/file/lovina-hill-paradise-600x450.webp	600	450	image/webp	35668	lovina-hill-paradise-600x450.webp	/api/media/file/lovina-hill-paradise-900x675.webp	900	675	image/webp	56550	lovina-hill-paradise-900x675.webp	/api/media/file/lovina-hill-paradise-1400x1050.webp	1400	1050	image/webp	89014	lovina-hill-paradise-1400x1050.webp	/api/media/file/lovina-hill-paradise-1920x1440.webp	1920	1440	image/webp	123870	lovina-hill-paradise-1920x1440.webp	/api/media/file/lovina-hill-paradise-1200x630.webp	1200	630	image/webp	54642	lovina-hill-paradise-1200x630.webp
18	\N	2026-09-09 17:00:54.149+00	2026-09-09 17:00:54.148+00	/api/media/file/mantra-legal-counsel.webp	\N	mantra-legal-counsel.webp	image/webp	105576	4096	3072	50	50	/api/media/file/mantra-legal-counsel-300x225.webp	300	225	image/webp	4446	mantra-legal-counsel-300x225.webp	/api/media/file/mantra-legal-counsel-500x500.webp	500	500	image/webp	10062	mantra-legal-counsel-500x500.webp	/api/media/file/mantra-legal-counsel-600x450.webp	600	450	image/webp	10438	mantra-legal-counsel-600x450.webp	/api/media/file/mantra-legal-counsel-900x675.webp	900	675	image/webp	16638	mantra-legal-counsel-900x675.webp	/api/media/file/mantra-legal-counsel-1400x1050.webp	1400	1050	image/webp	27712	mantra-legal-counsel-1400x1050.webp	/api/media/file/mantra-legal-counsel-1920x1440.webp	1920	1440	image/webp	40394	mantra-legal-counsel-1920x1440.webp	/api/media/file/mantra-legal-counsel-1200x630.webp	1200	630	image/webp	18496	mantra-legal-counsel-1200x630.webp
19	\N	2026-09-09 17:01:15.199+00	2026-09-09 17:01:15.198+00	/api/media/file/mekar-sari.webp	\N	mekar-sari.webp	image/webp	191072	4096	3072	50	50	/api/media/file/mekar-sari-300x225.webp	300	225	image/webp	9532	mekar-sari-300x225.webp	/api/media/file/mekar-sari-500x500.webp	500	500	image/webp	21514	mekar-sari-500x500.webp	/api/media/file/mekar-sari-600x450.webp	600	450	image/webp	21936	mekar-sari-600x450.webp	/api/media/file/mekar-sari-900x675.webp	900	675	image/webp	34854	mekar-sari-900x675.webp	/api/media/file/mekar-sari-1400x1050.webp	1400	1050	image/webp	58542	mekar-sari-1400x1050.webp	/api/media/file/mekar-sari-1920x1440.webp	1920	1440	image/webp	82322	mekar-sari-1920x1440.webp	/api/media/file/mekar-sari-1200x630.webp	1200	630	image/webp	39348	mekar-sari-1200x630.webp
20	\N	2026-09-09 17:01:32.067+00	2026-09-09 17:01:32.067+00	/api/media/file/motion-health-fitness.webp	\N	motion-health-fitness.webp	image/webp	227548	4096	3072	50	50	/api/media/file/motion-health-fitness-300x225.webp	300	225	image/webp	9462	motion-health-fitness-300x225.webp	/api/media/file/motion-health-fitness-500x500.webp	500	500	image/webp	20124	motion-health-fitness-500x500.webp	/api/media/file/motion-health-fitness-600x450.webp	600	450	image/webp	23132	motion-health-fitness-600x450.webp	/api/media/file/motion-health-fitness-900x675.webp	900	675	image/webp	36972	motion-health-fitness-900x675.webp	/api/media/file/motion-health-fitness-1400x1050.webp	1400	1050	image/webp	65414	motion-health-fitness-1400x1050.webp	/api/media/file/motion-health-fitness-1920x1440.webp	1920	1440	image/webp	93404	motion-health-fitness-1920x1440.webp	/api/media/file/motion-health-fitness-1200x630.webp	1200	630	image/webp	33288	motion-health-fitness-1200x630.webp
21	\N	2026-09-09 17:01:54.139+00	2026-09-09 17:01:54.138+00	/api/media/file/nata-ubud.webp	\N	nata-ubud.webp	image/webp	326258	4096	3072	50	50	/api/media/file/nata-ubud-300x225.webp	300	225	image/webp	16370	nata-ubud-300x225.webp	/api/media/file/nata-ubud-500x500.webp	500	500	image/webp	34050	nata-ubud-500x500.webp	/api/media/file/nata-ubud-600x450.webp	600	450	image/webp	40156	nata-ubud-600x450.webp	/api/media/file/nata-ubud-900x675.webp	900	675	image/webp	61208	nata-ubud-900x675.webp	/api/media/file/nata-ubud-1400x1050.webp	1400	1050	image/webp	98108	nata-ubud-1400x1050.webp	/api/media/file/nata-ubud-1920x1440.webp	1920	1440	image/webp	137588	nata-ubud-1920x1440.webp	/api/media/file/nata-ubud-1200x630.webp	1200	630	image/webp	66320	nata-ubud-1200x630.webp
22	\N	2026-09-09 17:02:10.067+00	2026-09-09 17:02:10.067+00	/api/media/file/nobee-mengemudi.webp	\N	nobee-mengemudi.webp	image/webp	141836	4096	3072	50	50	/api/media/file/nobee-mengemudi-300x225.webp	300	225	image/webp	7640	nobee-mengemudi-300x225.webp	/api/media/file/nobee-mengemudi-500x500.webp	500	500	image/webp	16530	nobee-mengemudi-500x500.webp	/api/media/file/nobee-mengemudi-600x450.webp	600	450	image/webp	16994	nobee-mengemudi-600x450.webp	/api/media/file/nobee-mengemudi-900x675.webp	900	675	image/webp	26632	nobee-mengemudi-900x675.webp	/api/media/file/nobee-mengemudi-1400x1050.webp	1400	1050	image/webp	44320	nobee-mengemudi-1400x1050.webp	/api/media/file/nobee-mengemudi-1920x1440.webp	1920	1440	image/webp	61148	nobee-mengemudi-1920x1440.webp	/api/media/file/nobee-mengemudi-1200x630.webp	1200	630	image/webp	31644	nobee-mengemudi-1200x630.webp
23	\N	2026-09-09 17:02:26.925+00	2026-09-09 17:02:26.925+00	/api/media/file/nyaman-hospitality.webp	\N	nyaman-hospitality.webp	image/webp	162922	4096	3072	50	50	/api/media/file/nyaman-hospitality-300x225.webp	300	225	image/webp	7582	nyaman-hospitality-300x225.webp	/api/media/file/nyaman-hospitality-500x500.webp	500	500	image/webp	14868	nyaman-hospitality-500x500.webp	/api/media/file/nyaman-hospitality-600x450.webp	600	450	image/webp	16802	nyaman-hospitality-600x450.webp	/api/media/file/nyaman-hospitality-900x675.webp	900	675	image/webp	26678	nyaman-hospitality-900x675.webp	/api/media/file/nyaman-hospitality-1400x1050.webp	1400	1050	image/webp	45532	nyaman-hospitality-1400x1050.webp	/api/media/file/nyaman-hospitality-1920x1440.webp	1920	1440	image/webp	66540	nyaman-hospitality-1920x1440.webp	/api/media/file/nyaman-hospitality-1200x630.webp	1200	630	image/webp	29682	nyaman-hospitality-1200x630.webp
24	\N	2026-09-09 17:02:45.25+00	2026-09-09 17:02:45.249+00	/api/media/file/optica-capuchinos.webp	\N	optica-capuchinos.webp	image/webp	119428	4096	3072	50	50	/api/media/file/optica-capuchinos-300x225.webp	300	225	image/webp	5760	optica-capuchinos-300x225.webp	/api/media/file/optica-capuchinos-500x500.webp	500	500	image/webp	11908	optica-capuchinos-500x500.webp	/api/media/file/optica-capuchinos-600x450.webp	600	450	image/webp	12346	optica-capuchinos-600x450.webp	/api/media/file/optica-capuchinos-900x675.webp	900	675	image/webp	19578	optica-capuchinos-900x675.webp	/api/media/file/optica-capuchinos-1400x1050.webp	1400	1050	image/webp	32988	optica-capuchinos-1400x1050.webp	/api/media/file/optica-capuchinos-1920x1440.webp	1920	1440	image/webp	48410	optica-capuchinos-1920x1440.webp	/api/media/file/optica-capuchinos-1200x630.webp	1200	630	image/webp	21580	optica-capuchinos-1200x630.webp
25	\N	2026-09-09 17:03:02.29+00	2026-09-09 17:03:02.29+00	/api/media/file/pacific-ridge.webp	\N	pacific-ridge.webp	image/webp	118872	4096	3072	50	50	/api/media/file/pacific-ridge-300x225.webp	300	225	image/webp	5762	pacific-ridge-300x225.webp	/api/media/file/pacific-ridge-500x500.webp	500	500	image/webp	13062	pacific-ridge-500x500.webp	/api/media/file/pacific-ridge-600x450.webp	600	450	image/webp	13054	pacific-ridge-600x450.webp	/api/media/file/pacific-ridge-900x675.webp	900	675	image/webp	21270	pacific-ridge-900x675.webp	/api/media/file/pacific-ridge-1400x1050.webp	1400	1050	image/webp	35838	pacific-ridge-1400x1050.webp	/api/media/file/pacific-ridge-1920x1440.webp	1920	1440	image/webp	51612	pacific-ridge-1920x1440.webp	/api/media/file/pacific-ridge-1200x630.webp	1200	630	image/webp	24972	pacific-ridge-1200x630.webp
26	\N	2026-09-09 17:03:17.862+00	2026-09-09 17:03:17.862+00	/api/media/file/stay-store.webp	\N	stay-store.webp	image/webp	133400	4096	3072	50	50	/api/media/file/stay-store-300x225.webp	300	225	image/webp	7686	stay-store-300x225.webp	/api/media/file/stay-store-500x500.webp	500	500	image/webp	14670	stay-store-500x500.webp	/api/media/file/stay-store-600x450.webp	600	450	image/webp	15774	stay-store-600x450.webp	/api/media/file/stay-store-900x675.webp	900	675	image/webp	24794	stay-store-900x675.webp	/api/media/file/stay-store-1400x1050.webp	1400	1050	image/webp	40258	stay-store-1400x1050.webp	/api/media/file/stay-store-1920x1440.webp	1920	1440	image/webp	57060	stay-store-1920x1440.webp	/api/media/file/stay-store-1200x630.webp	1200	630	image/webp	24436	stay-store-1200x630.webp
27	\N	2026-09-09 17:03:36.903+00	2026-09-09 17:03:36.903+00	/api/media/file/tasty-turkish.webp	\N	tasty-turkish.webp	image/webp	177796	4096	3072	50	50	/api/media/file/tasty-turkish-300x225.webp	300	225	image/webp	9192	tasty-turkish-300x225.webp	/api/media/file/tasty-turkish-500x500.webp	500	500	image/webp	18048	tasty-turkish-500x500.webp	/api/media/file/tasty-turkish-600x450.webp	600	450	image/webp	19764	tasty-turkish-600x450.webp	/api/media/file/tasty-turkish-900x675.webp	900	675	image/webp	31058	tasty-turkish-900x675.webp	/api/media/file/tasty-turkish-1400x1050.webp	1400	1050	image/webp	52154	tasty-turkish-1400x1050.webp	/api/media/file/tasty-turkish-1920x1440.webp	1920	1440	image/webp	73922	tasty-turkish-1920x1440.webp	/api/media/file/tasty-turkish-1200x630.webp	1200	630	image/webp	35128	tasty-turkish-1200x630.webp
28	\N	2026-09-09 17:03:53.506+00	2026-09-09 17:03:53.506+00	/api/media/file/the-artisan-board.webp	\N	the-artisan-board.webp	image/webp	120308	4096	3072	50	50	/api/media/file/the-artisan-board-300x225.webp	300	225	image/webp	5120	the-artisan-board-300x225.webp	/api/media/file/the-artisan-board-500x500.webp	500	500	image/webp	12216	the-artisan-board-500x500.webp	/api/media/file/the-artisan-board-600x450.webp	600	450	image/webp	12016	the-artisan-board-600x450.webp	/api/media/file/the-artisan-board-900x675.webp	900	675	image/webp	19310	the-artisan-board-900x675.webp	/api/media/file/the-artisan-board-1400x1050.webp	1400	1050	image/webp	33936	the-artisan-board-1400x1050.webp	/api/media/file/the-artisan-board-1920x1440.webp	1920	1440	image/webp	49680	the-artisan-board-1920x1440.webp	/api/media/file/the-artisan-board-1200x630.webp	1200	630	image/webp	23338	the-artisan-board-1200x630.webp
29	\N	2026-09-09 17:04:09.427+00	2026-09-09 17:04:09.427+00	/api/media/file/the-boho-art-room.webp	\N	the-boho-art-room.webp	image/webp	115360	4096	3072	50	50	/api/media/file/the-boho-art-room-300x225.webp	300	225	image/webp	5714	the-boho-art-room-300x225.webp	/api/media/file/the-boho-art-room-500x500.webp	500	500	image/webp	10760	the-boho-art-room-500x500.webp	/api/media/file/the-boho-art-room-600x450.webp	600	450	image/webp	12378	the-boho-art-room-600x450.webp	/api/media/file/the-boho-art-room-900x675.webp	900	675	image/webp	19704	the-boho-art-room-900x675.webp	/api/media/file/the-boho-art-room-1400x1050.webp	1400	1050	image/webp	32516	the-boho-art-room-1400x1050.webp	/api/media/file/the-boho-art-room-1920x1440.webp	1920	1440	image/webp	46522	the-boho-art-room-1920x1440.webp	/api/media/file/the-boho-art-room-1200x630.webp	1200	630	image/webp	21144	the-boho-art-room-1200x630.webp
30	\N	2026-09-09 17:04:24.677+00	2026-09-09 17:04:24.677+00	/api/media/file/wearstatuquo.webp	\N	wearstatuquo.webp	image/webp	85630	4096	3072	50	50	/api/media/file/wearstatuquo-300x225.webp	300	225	image/webp	4194	wearstatuquo-300x225.webp	/api/media/file/wearstatuquo-500x500.webp	500	500	image/webp	7804	wearstatuquo-500x500.webp	/api/media/file/wearstatuquo-600x450.webp	600	450	image/webp	9222	wearstatuquo-600x450.webp	/api/media/file/wearstatuquo-900x675.webp	900	675	image/webp	14200	wearstatuquo-900x675.webp	/api/media/file/wearstatuquo-1400x1050.webp	1400	1050	image/webp	23774	wearstatuquo-1400x1050.webp	/api/media/file/wearstatuquo-1920x1440.webp	1920	1440	image/webp	34988	wearstatuquo-1920x1440.webp	/api/media/file/wearstatuquo-1200x630.webp	1200	630	image/webp	15750	wearstatuquo-1200x630.webp
31	\N	2026-09-09 17:04:42.747+00	2026-09-09 17:04:42.746+00	/api/media/file/zenresort.webp	\N	zenresort.webp	image/webp	154684	4096	3072	50	50	/api/media/file/zenresort-300x225.webp	300	225	image/webp	9612	zenresort-300x225.webp	/api/media/file/zenresort-500x500.webp	500	500	image/webp	19834	zenresort-500x500.webp	/api/media/file/zenresort-600x450.webp	600	450	image/webp	20414	zenresort-600x450.webp	/api/media/file/zenresort-900x675.webp	900	675	image/webp	32044	zenresort-900x675.webp	/api/media/file/zenresort-1400x1050.webp	1400	1050	image/webp	53214	zenresort-1400x1050.webp	/api/media/file/zenresort-1920x1440.webp	1920	1440	image/webp	75948	zenresort-1920x1440.webp	/api/media/file/zenresort-1200x630.webp	1200	630	image/webp	33046	zenresort-1200x630.webp
\.


--
-- Data for Name: media_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.media_locales (alt, caption, id, _locale, _parent_id) FROM stdin;
Alas Harum Silver website screenshot	\N	7	en	7
Bali Paragliding website screenshot	\N	8	en	8
Berawa Vet Care website screenshot	\N	9	en	9
Berkat Abadi website screenshot	\N	10	en	10
Distruptive website screenshot	\N	11	en	11
Immasa Studio website screenshot	\N	12	en	12
Kedai Bang Bewok website screenshot	\N	13	en	13
Kopi Veteran website screenshot	\N	14	en	15
Krisna Silver Class website screenshot	\N	15	en	16
Lovina Hill Paradise website screenshot	\N	16	en	17
Mantra Legal Counsel website screenshot	\N	17	en	18
Mekar Sari website screenshot	\N	18	en	19
Motion Health & Fitness website screenshot	\N	19	en	20
Nata Ubud website screenshot	\N	20	en	21
Nobee Mengemudi website screenshot	\N	21	en	22
Nyaman Hospitality website screenshot	\N	22	en	23
Optica Capuchinos website screenshot	\N	23	en	24
Pacific Ridge website screenshot	\N	24	en	25
Stay Store website screenshot	\N	25	en	26
Tasty Turkish website screenshot	\N	26	en	27
The Artisan Board website screenshot	\N	27	en	28
The Boho Art Room website screenshot	\N	28	en	29
Wearstatuquo website screenshot	\N	29	en	30
ZenResort website screenshot	\N	30	en	31
\.


--
-- Data for Name: payload_folders; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_folders (id, name, folder_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_folders_folder_type; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_folders_folder_type ("order", parent_id, value, id) FROM stdin;
\.


--
-- Data for Name: payload_jobs; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_jobs (id, input, completed_at, total_tried, has_error, error, task_slug, queue, wait_until, processing, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_jobs_log; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_jobs_log (_order, _parent_id, id, executed_at, completed_at, task_slug, task_i_d, input, output, state, error) FROM stdin;
\.


--
-- Data for Name: payload_kv; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_kv (id, key, data) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
12	about	2026-09-14 08:48:58.303+00	2026-09-14 08:48:58.302+00
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, posts_id, media_id, categories_id, portfolio_id, services_id, testimonials_id, users_id, redirects_id, forms_id, form_submissions_id, search_id, payload_mcp_api_keys_id, payload_folders_id) FROM stdin;
22	\N	12	user	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: payload_mcp_api_keys; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_mcp_api_keys (id, user_id, label, description, posts_find, posts_create, posts_update, posts_delete, media_find, media_create, media_update, media_delete, categories_find, categories_create, categories_update, categories_delete, portfolio_find, portfolio_create, portfolio_update, portfolio_delete, header_find, header_update, footer_find, footer_update, updated_at, created_at, enable_a_p_i_key, api_key, api_key_index, services_find, services_create, services_update, services_delete, testimonials_find, testimonials_create, testimonials_update, testimonials_delete, about_find, about_update) FROM stdin;
1	1	MCP Master	Master Robot	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	2026-08-31 13:11:06.172+00	2026-08-28 01:38:51.508+00	t	3bc82f2ad0065e1afcbbe99a1f0db4a7f7158e4aff2429ed0813d308f762f46d8a0158eb8fa3a37c8008493096bc96f24870d3ce	317c5dda2a0de86e92a699127f3f1231fa2e08134e55e32ca7dec4f78ae1d62f	t	t	t	t	t	t	t	t	t	t
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
1	20260825_113937_init	1	2026-08-25 11:53:24.963+00	2026-08-25 11:53:24.961+00
2	20260831_113015	2	2026-08-31 13:10:39.251+00	2026-08-31 13:10:39.249+00
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
1	collection-payload-mcp-api-keys	{"limit": 10}	2026-08-28 03:23:57.731+00	2026-08-25 18:48:21.115+00
2	collection-posts	{"limit": 10}	2026-08-28 09:56:38.585+00	2026-08-28 03:23:58.846+00
5	collection-testimonials	{}	2026-08-28 09:58:21.242+00	2026-08-28 09:58:21.242+00
6	collection-portfolio	{"sort": "order", "limit": 10}	2026-08-28 10:01:46.117+00	2026-08-28 09:58:25.318+00
7	collection-form-submissions	{}	2026-08-28 10:25:17.722+00	2026-08-28 10:25:17.72+00
8	collection-forms	{}	2026-08-28 10:25:18.343+00	2026-08-28 10:25:18.343+00
9	collection-redirects	{}	2026-08-28 10:25:19.102+00	2026-08-28 10:25:19.102+00
10	collection-users	{}	2026-08-28 10:25:19.652+00	2026-08-28 10:25:19.652+00
11	dashboard-layout	{"layouts": null}	2026-08-28 10:25:47.829+00	2026-08-28 10:25:47.835+00
12	collection-media	{}	2026-09-01 02:21:13.02+00	2026-09-01 02:21:13.018+00
13	collection-categories	{}	2026-09-01 02:21:14.533+00	2026-09-01 02:21:14.533+00
14	global-about	{"fields": {"principles": {"collapsed": []}}}	2026-09-01 02:27:08.71+00	2026-09-01 02:27:05.36+00
4	collection-services	{"sort": "order", "limit": 10}	2026-09-01 02:27:49.749+00	2026-08-28 09:58:19.704+00
15	browse-by-folder	{}	2026-09-01 02:29:33.103+00	2026-09-01 02:29:33.103+00
16	locale	"id"	2026-09-01 03:02:44.204+00	2026-09-01 03:00:43.355+00
3	nav	{"open": true, "groups": {"MCP": {"open": true}}}	2026-09-01 03:05:56.306+00	2026-08-28 09:57:25.644+00
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id, payload_mcp_api_keys_id) FROM stdin;
2	\N	1	user	1	\N
4	\N	2	user	1	\N
8	\N	5	user	1	\N
10	\N	6	user	1	\N
11	\N	7	user	1	\N
12	\N	8	user	1	\N
13	\N	9	user	1	\N
14	\N	10	user	1	\N
15	\N	11	user	1	\N
20	\N	12	user	1	\N
21	\N	13	user	1	\N
24	\N	14	user	1	\N
25	\N	4	user	1	\N
26	\N	15	user	1	\N
31	\N	16	user	1	\N
33	\N	3	user	1	\N
\.


--
-- Data for Name: portfolio; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.portfolio (id, year, image_id, featured_on_home, "order", updated_at, created_at, _status) FROM stdin;
8	2025	8	t	1	2026-09-12 01:09:48.783+00	2026-09-09 16:50:49.246+00	published
7	2025	7	f	0	2026-09-14 08:46:25.909+00	2026-09-09 16:43:46.822+00	published
9	2025	9	f	2	2026-09-09 17:10:24.624+00	2026-09-09 16:59:33.5+00	published
10	2025	10	f	3	2026-09-09 17:10:25.421+00	2026-09-09 16:59:33.72+00	published
11	2025	11	f	4	2026-09-09 17:10:25.918+00	2026-09-09 16:59:34.141+00	published
12	2025	12	f	5	2026-09-09 17:10:26.423+00	2026-09-09 16:59:34.292+00	published
13	2025	13	f	6	2026-09-09 17:10:27.443+00	2026-09-09 16:59:34.461+00	published
14	2025	15	f	7	2026-09-09 17:10:28.177+00	2026-09-09 16:59:49.585+00	published
15	2025	16	f	8	2026-09-09 17:10:28.589+00	2026-09-09 17:00:13.47+00	published
16	2025	17	f	9	2026-09-09 17:10:28.952+00	2026-09-09 17:00:35.817+00	published
17	2025	18	f	10	2026-09-09 17:10:29.361+00	2026-09-09 17:00:54.888+00	published
18	2025	19	f	11	2026-09-09 17:10:29.862+00	2026-09-09 17:01:15.964+00	published
19	2025	20	f	12	2026-09-09 17:10:31.082+00	2026-09-09 17:01:32.549+00	published
20	2025	21	f	13	2026-09-09 17:10:31.676+00	2026-09-09 17:01:54.447+00	published
21	2025	22	f	14	2026-09-09 17:10:32.107+00	2026-09-09 17:02:10.33+00	published
22	2025	23	f	15	2026-09-09 17:10:32.635+00	2026-09-09 17:02:27.305+00	published
23	2025	24	f	16	2026-09-09 17:10:33.247+00	2026-09-09 17:02:45.659+00	published
24	2025	25	f	17	2026-09-09 17:10:34.071+00	2026-09-09 17:03:02.818+00	published
25	2025	26	f	18	2026-09-09 17:10:34.57+00	2026-09-09 17:03:18.625+00	published
26	2025	27	f	19	2026-09-09 17:10:35.623+00	2026-09-09 17:03:38.053+00	published
27	2025	28	f	20	2026-09-09 17:10:36.124+00	2026-09-09 17:03:53.869+00	published
28	2025	29	f	21	2026-09-09 17:10:36.61+00	2026-09-09 17:04:09.718+00	published
29	2025	30	f	22	2026-09-09 17:10:37.142+00	2026-09-09 17:04:25.308+00	published
30	2025	31	f	23	2026-09-09 17:10:37.71+00	2026-09-09 17:04:43.686+00	published
\.


--
-- Data for Name: portfolio_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.portfolio_locales (title, category, description, image_alt, generate_slug, slug, id, _locale, _parent_id) FROM stdin;
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	104	en	8
Bali Paragliding	—	—	Bali Paragliding website screenshot	f	bali-paragliding	105	id	8
Alas Harum Silver	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	106	en	7
Alas Harum Silverr	—	—	Alas Harum Silver website screenshot	f	alas-harum-silver	107	id	7
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	39	en	9
Berawa Vet Care	—	—	Berawa Vet Care website screenshot	f	berawa-vet-care	40	id	9
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	42	en	10
Berkat Abadi	—	—	Berkat Abadi website screenshot	f	berkat-abadi	43	id	10
Distruptive	—	—	Distruptive website screenshot	f	distruptive	45	en	11
Distruptive	—	—	Distruptive website screenshot	f	distruptive	46	id	11
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	48	en	12
Immasa Studio	—	—	Immasa Studio website screenshot	f	immasa-studio	49	id	12
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	51	en	13
Kedai Bang Bewok	—	—	Kedai Bang Bewok website screenshot	f	kedai-bang-bewok	52	id	13
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	54	en	14
Kopi Veteran	—	—	Kopi Veteran website screenshot	f	kopi-veteran	55	id	14
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	57	en	15
Krisna Silver Class	—	—	Krisna Silver Class website screenshot	f	krisna-silver-class	58	id	15
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	60	en	16
Lovina Hill Paradise	—	—	Lovina Hill Paradise website screenshot	f	lovina-hill-paradise	61	id	16
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	63	en	17
Mantra Legal Counsel	—	—	Mantra Legal Counsel website screenshot	f	mantra-legal-counsel	64	id	17
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	66	en	18
Mekar Sari	—	—	Mekar Sari website screenshot	f	mekar-sari	67	id	18
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	69	en	19
Motion Health & Fitness	—	—	Motion Health & Fitness website screenshot	f	motion-health-fitness	70	id	19
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	72	en	20
Nata Ubud	—	—	Nata Ubud website screenshot	f	nata-ubud	73	id	20
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	75	en	21
Nobee Mengemudi	—	—	Nobee Mengemudi website screenshot	f	nobee-mengemudi	76	id	21
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	78	en	22
Nyaman Hospitality	—	—	Nyaman Hospitality website screenshot	f	nyaman-hospitality	79	id	22
OPTICA CAPUCHINOS	—	—	OPTICA CAPUCHINOS website screenshot	f	optica-capuchinos	81	en	23
OPTICA CAPUCHINOS	—	—	OPTICA CAPUCHINOS website screenshot	f	optica-capuchinos	82	id	23
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	84	en	24
Pacific Ridge	—	—	Pacific Ridge website screenshot	f	pacific-ridge	85	id	24
Stay Store	—	—	Stay Store website screenshot	f	stay-store	87	en	25
Stay Store	—	—	Stay Store website screenshot	f	stay-store	88	id	25
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	90	en	26
Tasty Turkish	—	—	Tasty Turkish website screenshot	f	tasty-turkish	91	id	26
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	93	en	27
The Artisan Board	—	—	The Artisan Board website screenshot	f	the-artisan-board	94	id	27
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	96	en	28
The Boho Art Room	—	—	The Boho Art Room website screenshot	f	the-boho-art-room	97	id	28
wearstatuquo	—	—	wearstatuquo website screenshot	f	wearstatuquo	99	en	29
wearstatuquo	—	—	wearstatuquo website screenshot	f	wearstatuquo	100	id	29
ZenResort	—	—	ZenResort website screenshot	f	zenresort	102	en	30
ZenResort	—	—	ZenResort website screenshot	f	zenresort	103	id	30
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.posts (id, hero_image_id, published_at, updated_at, created_at, _status) FROM stdin;
\.


--
-- Data for Name: posts_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.posts_locales (title, content, meta_title, meta_image_id, meta_description, generate_slug, slug, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: posts_populated_authors; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.posts_populated_authors (_order, _parent_id, id, name) FROM stdin;
\.


--
-- Data for Name: posts_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.posts_rels (id, "order", parent_id, path, posts_id, categories_id, users_id) FROM stdin;
\.


--
-- Data for Name: redirects; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.redirects (id, "from", to_type, to_url, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: redirects_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.redirects_rels (id, "order", parent_id, path, posts_id) FROM stdin;
\.


--
-- Data for Name: search; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.search (id, priority, slug, meta_title, meta_description, meta_image_id, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: search_categories; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.search_categories (_order, _parent_id, id, relation_to, category_i_d, title) FROM stdin;
\.


--
-- Data for Name: search_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.search_locales (title, id, _locale, _parent_id) FROM stdin;
\.


--
-- Data for Name: search_rels; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.search_rels (id, "order", parent_id, path, posts_id) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.services (id, "order", updated_at, created_at, _status) FROM stdin;
5	3	2026-09-01 02:26:55.371+00	2026-09-01 02:26:43.808+00	published
4	2	2026-09-01 02:26:55.991+00	2026-09-01 02:26:33.581+00	published
3	1	2026-09-01 02:26:56.467+00	2026-09-01 02:26:33.243+00	published
2	4	2026-09-01 02:26:56.84+00	2026-09-01 02:26:32.264+00	published
1	0	2026-09-14 08:42:39.382+00	2026-09-01 02:26:31.578+00	published
\.


--
-- Data for Name: services_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.services_locales (title, summary, body, id, _locale, _parent_id) FROM stdin;
Development Website	Precise front-end and platform builds, engineered for clarity.	Modern, performant sites and web apps — typed, accessible, maintainable — aligned to the design system.	6	en	5
Development Website	Build front-end dan platform yang presisi, dirancang untuk kejelasan.	Website dan web app modern yang performan — typed, accessible, maintainable — selaras dengan design system.	7	id	5
Design Website	See the website clearly before build — structure, flow, and craft.	Information architecture, wireframes, and high-fidelity design so the experience can be approved before production code.	8	en	4
Design Website	Lihat website dengan jelas sebelum build — struktur, alur, dan craft.	Arsitektur informasi, wireframe, dan desain high-fidelity agar pengalaman bisa disetujui sebelum kode produksi.	9	id	4
Brand Create	Visualize the business from zero to one — identity with intent.	Name, voice, visual system, and narrative. A brand that can grow with the product, not a logo sitting on top of it.	10	en	3
Brand Create	Visualisasikan bisnis dari nol ke satu — identitas dengan intent.	Nama, suara, sistem visual, dan narasi. Brand yang bisa tumbuh bersama produk, bukan logo yang hanya menempel di atasnya.	11	id	3
AI Development	Practical AI features and workflows that serve the brand, not the hype.	Assistants, automation, and product features grounded in real use cases, with a human-readable interface.	14	en	2
AI Development	Fitur dan alur AI praktis yang melayani brand, bukan hype.	Asisten, otomasi, dan fitur produk yang berlandaskan use case nyata, dengan antarmuka yang mudah dibaca manusia.	15	id	2
Business Technology Consultant & Builder	Strategy and systems that turn business goals into working products.	Map how the business operates, then design the stack, workflows, and tools — from discovery through build and handoff.	18	en	1
Konsultan & Builder Teknologi Bisnis	Strategi dan sistem yang mengubah tujuan bisnis menjadi produk yang berfungsi.	Petakan cara bisnis beroperasi, lalu rancang stack, alur kerja, dan tools — dari discovery hingga build dan handoff.	19	id	1
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.testimonials (id, name, "order", updated_at, created_at, _status) FROM stdin;
2	Nata	2	2026-09-01 02:49:46.145+00	2026-09-01 02:49:39.727+00	published
1	Mantra	0	2026-09-01 03:01:43.282+00	2026-09-01 02:49:38.586+00	published
3	Nobee Mengemudi	1	2026-09-01 03:02:34.983+00	2026-09-01 02:49:41.432+00	published
\.


--
-- Data for Name: testimonials_locales; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.testimonials_locales (quote, role, id, _locale, _parent_id) FROM stdin;
Communication with MŌMOS was clear from day one. They listened, kept us in the loop, and made sure every decision was easy to understand before we moved forward.	Founder, Nata	4	en	2
Komunikasi dengan MŌMOS jelas sejak hari pertama. Mereka mendengarkan, menjaga kami selalu update, dan memastikan setiap keputusan mudah dipahami sebelum kami lanjut.	Founder, Nata	5	id	2
MŌMOS delivered exactly what we needed. thoughtful service from first brief to final handoff. Every step felt considered, responsive, and built around our goals.	Founder, Mantra	12	en	1
MŌMOS deliver service sesuai yg kami butuhkan. dari brief pertama hingga serah terima. Setiap proses pertimbangan, responsif, dan selaras dengan tujuan kami.	Founder, Mantra	13	id	1
The branding solution MŌMOS built for us fits the Bali market perfectly. Our identity finally speaks to local customers. and we have seen that translate directly into stronger sales.	Manager at Nobee Mengemudi	16	en	3
Solusi branding dari MŌMOS sangat cocok dengan pasar kami di Bali. Identitas kami akhirnya berbicara ke murid lokal. dan kami merasakan dampaknya langsung pada sales.	Manager at Nobee Mengemudi	17	id	3
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.users (id, name, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until) FROM stdin;
1	Pending Brew	2026-08-25 18:48:15.703+00	2026-08-25 18:48:15.7+00	brewpending@gmail.com	\N	\N	df1cb2bde6b35f6ad94ea9b54c77dd438b1df4df0288d4cb3c03f4ef085faf4d	13f337a1d02d82d29ceba1259c32193d559066a2e60c9ee16a3d861d6ae1b4406c075479eaf5182f165a374713f6be6e5c28a752f14bf17537dbc714e07a35cd82bf1bc73ee7b70cbc6b10fc89125f1c59487f070fabfde1aaec04118d00b63e2f15d850074681c1e7e8358dc1d7a916fe9ab4ae80fe50a350ebc023a62468f2d30dab7895f8625049cde53fcd56839e809224e85ebe045e816902bdc4c491884c60cea08716543f11c00a1de30d9d2a189b2094528cb18677ad16336a64854cbe170964c53e0785ebfc1f6a777ef8b434b4e31f237130b318f3b42e9412cb9b966e87434402560de77e43db2185958d6ce44abcfff6b0ed472cea7ac53af8c55f36b6cc3ee1c2d4932f8b4e0abb5b197473300ecb12a6ebd1843a154e1cd49039f95dee1226593f08030991af762b1a0a15361121807ab812ac71603fc54b1fe52a203c4f0cfc1ba685748f207588e3d8de8e7680aa046bf300baeb71cab2f0606b96c50d501539c5999cc5abf2ad5ef26928cee74e430366c2f31e651e7b39142e38707b37f3d5bddfd970e861654707905ac91e7448a8e5309431d35241a724e541eb5363cd7d92cf25b68a3350ee9778ff79fa3b7db4cdbd7d5183e54185d8959c89dbc25c42b208c68831df6537e3d1910c875e6674ea50c31e36d9a79c550b7c65738a85ff5bac3adacb42af74ec8f69aa6870e3dcfc43ca6e0a52d976	0	\N
\.


--
-- Data for Name: users_sessions; Type: TABLE DATA; Schema: public; Owner: momos_user
--

COPY public.users_sessions (_order, _parent_id, id, created_at, expires_at) FROM stdin;
1	1	99cbc51a-779f-46f9-ab89-25248432f1da	2026-09-14 07:49:30.061+00	2026-09-14 09:49:30.061+00
\.


--
-- Name: _portfolio_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._portfolio_v_id_seq', 81, true);


--
-- Name: _portfolio_v_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._portfolio_v_locales_id_seq', 107, true);


--
-- Name: _posts_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._posts_v_id_seq', 1, false);


--
-- Name: _posts_v_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._posts_v_locales_id_seq', 1, false);


--
-- Name: _posts_v_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._posts_v_rels_id_seq', 1, false);


--
-- Name: _posts_v_version_populated_authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._posts_v_version_populated_authors_id_seq', 1, false);


--
-- Name: _services_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._services_v_id_seq', 12, true);


--
-- Name: _services_v_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._services_v_locales_id_seq', 19, true);


--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._testimonials_v_id_seq', 10, true);


--
-- Name: _testimonials_v_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public._testimonials_v_locales_id_seq', 17, true);


--
-- Name: about_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.about_id_seq', 1, true);


--
-- Name: about_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.about_locales_id_seq', 5, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: categories_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.categories_locales_id_seq', 1, false);


--
-- Name: footer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.footer_id_seq', 1, true);


--
-- Name: footer_nav_items_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.footer_nav_items_locales_id_seq', 4, true);


--
-- Name: footer_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.footer_rels_id_seq', 1, false);


--
-- Name: form_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.form_submissions_id_seq', 1, false);


--
-- Name: forms_blocks_checkbox_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_checkbox_locales_id_seq', 1, false);


--
-- Name: forms_blocks_country_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_country_locales_id_seq', 1, false);


--
-- Name: forms_blocks_email_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_email_locales_id_seq', 1, false);


--
-- Name: forms_blocks_message_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_message_locales_id_seq', 1, false);


--
-- Name: forms_blocks_number_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_number_locales_id_seq', 1, false);


--
-- Name: forms_blocks_select_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_select_locales_id_seq', 1, false);


--
-- Name: forms_blocks_select_options_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_select_options_locales_id_seq', 1, false);


--
-- Name: forms_blocks_state_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_state_locales_id_seq', 1, false);


--
-- Name: forms_blocks_text_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_text_locales_id_seq', 1, false);


--
-- Name: forms_blocks_textarea_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_blocks_textarea_locales_id_seq', 1, false);


--
-- Name: forms_emails_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_emails_locales_id_seq', 1, false);


--
-- Name: forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_id_seq', 1, false);


--
-- Name: forms_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.forms_locales_id_seq', 1, false);


--
-- Name: header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.header_id_seq', 1, true);


--
-- Name: header_nav_items_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.header_nav_items_locales_id_seq', 4, true);


--
-- Name: header_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.header_rels_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.media_id_seq', 31, true);


--
-- Name: media_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.media_locales_id_seq', 30, true);


--
-- Name: payload_folders_folder_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_folders_folder_type_id_seq', 1, false);


--
-- Name: payload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_folders_id_seq', 1, false);


--
-- Name: payload_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_jobs_id_seq', 1, false);


--
-- Name: payload_kv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_kv_id_seq', 1, false);


--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_locked_documents_id_seq', 12, true);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 22, true);


--
-- Name: payload_mcp_api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_mcp_api_keys_id_seq', 1, true);


--
-- Name: payload_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_migrations_id_seq', 2, true);


--
-- Name: payload_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_preferences_id_seq', 16, true);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 33, true);


--
-- Name: portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.portfolio_id_seq', 30, true);


--
-- Name: portfolio_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.portfolio_locales_id_seq', 107, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: posts_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.posts_locales_id_seq', 1, false);


--
-- Name: posts_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.posts_rels_id_seq', 1, false);


--
-- Name: redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.redirects_id_seq', 1, false);


--
-- Name: redirects_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.redirects_rels_id_seq', 1, false);


--
-- Name: search_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.search_id_seq', 1, false);


--
-- Name: search_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.search_locales_id_seq', 1, false);


--
-- Name: search_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.search_rels_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.services_id_seq', 5, true);


--
-- Name: services_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.services_locales_id_seq', 19, true);


--
-- Name: testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.testimonials_id_seq', 3, true);


--
-- Name: testimonials_locales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.testimonials_locales_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: momos_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: _portfolio_v_locales _portfolio_v_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v_locales
    ADD CONSTRAINT _portfolio_v_locales_pkey PRIMARY KEY (id);


--
-- Name: _portfolio_v _portfolio_v_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v
    ADD CONSTRAINT _portfolio_v_pkey PRIMARY KEY (id);


--
-- Name: _posts_v_locales _posts_v_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_locales
    ADD CONSTRAINT _posts_v_locales_pkey PRIMARY KEY (id);


--
-- Name: _posts_v _posts_v_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_pkey PRIMARY KEY (id);


--
-- Name: _posts_v_rels _posts_v_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels
    ADD CONSTRAINT _posts_v_rels_pkey PRIMARY KEY (id);


--
-- Name: _posts_v_version_populated_authors _posts_v_version_populated_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_version_populated_authors
    ADD CONSTRAINT _posts_v_version_populated_authors_pkey PRIMARY KEY (id);


--
-- Name: _services_v_locales _services_v_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v_locales
    ADD CONSTRAINT _services_v_locales_pkey PRIMARY KEY (id);


--
-- Name: _services_v _services_v_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v
    ADD CONSTRAINT _services_v_pkey PRIMARY KEY (id);


--
-- Name: _testimonials_v_locales _testimonials_v_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v_locales
    ADD CONSTRAINT _testimonials_v_locales_pkey PRIMARY KEY (id);


--
-- Name: _testimonials_v _testimonials_v_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v
    ADD CONSTRAINT _testimonials_v_pkey PRIMARY KEY (id);


--
-- Name: about_locales about_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about_locales
    ADD CONSTRAINT about_locales_pkey PRIMARY KEY (id);


--
-- Name: about about_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about
    ADD CONSTRAINT about_pkey PRIMARY KEY (id);


--
-- Name: about_principles about_principles_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about_principles
    ADD CONSTRAINT about_principles_pkey PRIMARY KEY (id);


--
-- Name: categories_breadcrumbs categories_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_breadcrumbs
    ADD CONSTRAINT categories_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: categories_locales categories_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_locales
    ADD CONSTRAINT categories_locales_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: footer_nav_items_locales footer_nav_items_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_nav_items_locales
    ADD CONSTRAINT footer_nav_items_locales_pkey PRIMARY KEY (id);


--
-- Name: footer_nav_items footer_nav_items_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_nav_items
    ADD CONSTRAINT footer_nav_items_pkey PRIMARY KEY (id);


--
-- Name: footer footer_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer
    ADD CONSTRAINT footer_pkey PRIMARY KEY (id);


--
-- Name: footer_rels footer_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_rels
    ADD CONSTRAINT footer_rels_pkey PRIMARY KEY (id);


--
-- Name: form_submissions form_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_pkey PRIMARY KEY (id);


--
-- Name: form_submissions_submission_data form_submissions_submission_data_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.form_submissions_submission_data
    ADD CONSTRAINT form_submissions_submission_data_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_checkbox_locales forms_blocks_checkbox_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_checkbox_locales
    ADD CONSTRAINT forms_blocks_checkbox_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_checkbox forms_blocks_checkbox_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_checkbox
    ADD CONSTRAINT forms_blocks_checkbox_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_country_locales forms_blocks_country_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_country_locales
    ADD CONSTRAINT forms_blocks_country_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_country forms_blocks_country_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_country
    ADD CONSTRAINT forms_blocks_country_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_email_locales forms_blocks_email_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_email_locales
    ADD CONSTRAINT forms_blocks_email_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_email forms_blocks_email_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_email
    ADD CONSTRAINT forms_blocks_email_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_message_locales forms_blocks_message_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_message_locales
    ADD CONSTRAINT forms_blocks_message_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_message forms_blocks_message_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_message
    ADD CONSTRAINT forms_blocks_message_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_number_locales forms_blocks_number_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_number_locales
    ADD CONSTRAINT forms_blocks_number_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_number forms_blocks_number_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_number
    ADD CONSTRAINT forms_blocks_number_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_select_locales forms_blocks_select_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_locales
    ADD CONSTRAINT forms_blocks_select_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_select_options_locales forms_blocks_select_options_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_options_locales
    ADD CONSTRAINT forms_blocks_select_options_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_select_options forms_blocks_select_options_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_options
    ADD CONSTRAINT forms_blocks_select_options_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_select forms_blocks_select_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select
    ADD CONSTRAINT forms_blocks_select_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_state_locales forms_blocks_state_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_state_locales
    ADD CONSTRAINT forms_blocks_state_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_state forms_blocks_state_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_state
    ADD CONSTRAINT forms_blocks_state_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_text_locales forms_blocks_text_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_text_locales
    ADD CONSTRAINT forms_blocks_text_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_text forms_blocks_text_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_text
    ADD CONSTRAINT forms_blocks_text_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_textarea_locales forms_blocks_textarea_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_textarea_locales
    ADD CONSTRAINT forms_blocks_textarea_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_blocks_textarea forms_blocks_textarea_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_textarea
    ADD CONSTRAINT forms_blocks_textarea_pkey PRIMARY KEY (id);


--
-- Name: forms_emails_locales forms_emails_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_emails_locales
    ADD CONSTRAINT forms_emails_locales_pkey PRIMARY KEY (id);


--
-- Name: forms_emails forms_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_emails
    ADD CONSTRAINT forms_emails_pkey PRIMARY KEY (id);


--
-- Name: forms_locales forms_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_locales
    ADD CONSTRAINT forms_locales_pkey PRIMARY KEY (id);


--
-- Name: forms forms_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_pkey PRIMARY KEY (id);


--
-- Name: header_nav_items_locales header_nav_items_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_nav_items_locales
    ADD CONSTRAINT header_nav_items_locales_pkey PRIMARY KEY (id);


--
-- Name: header_nav_items header_nav_items_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_nav_items
    ADD CONSTRAINT header_nav_items_pkey PRIMARY KEY (id);


--
-- Name: header header_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header
    ADD CONSTRAINT header_pkey PRIMARY KEY (id);


--
-- Name: header_rels header_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_rels
    ADD CONSTRAINT header_rels_pkey PRIMARY KEY (id);


--
-- Name: media_locales media_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media_locales
    ADD CONSTRAINT media_locales_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: payload_folders_folder_type payload_folders_folder_type_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders_folder_type
    ADD CONSTRAINT payload_folders_folder_type_pkey PRIMARY KEY (id);


--
-- Name: payload_folders payload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders
    ADD CONSTRAINT payload_folders_pkey PRIMARY KEY (id);


--
-- Name: payload_jobs_log payload_jobs_log_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_jobs_log
    ADD CONSTRAINT payload_jobs_log_pkey PRIMARY KEY (id);


--
-- Name: payload_jobs payload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_jobs
    ADD CONSTRAINT payload_jobs_pkey PRIMARY KEY (id);


--
-- Name: payload_kv payload_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_kv
    ADD CONSTRAINT payload_kv_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_mcp_api_keys payload_mcp_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_mcp_api_keys
    ADD CONSTRAINT payload_mcp_api_keys_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: portfolio_locales portfolio_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio_locales
    ADD CONSTRAINT portfolio_locales_pkey PRIMARY KEY (id);


--
-- Name: portfolio portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_pkey PRIMARY KEY (id);


--
-- Name: posts_locales posts_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_locales
    ADD CONSTRAINT posts_locales_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts_populated_authors posts_populated_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_populated_authors
    ADD CONSTRAINT posts_populated_authors_pkey PRIMARY KEY (id);


--
-- Name: posts_rels posts_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels
    ADD CONSTRAINT posts_rels_pkey PRIMARY KEY (id);


--
-- Name: redirects redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects
    ADD CONSTRAINT redirects_pkey PRIMARY KEY (id);


--
-- Name: redirects_rels redirects_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects_rels
    ADD CONSTRAINT redirects_rels_pkey PRIMARY KEY (id);


--
-- Name: search_categories search_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_categories
    ADD CONSTRAINT search_categories_pkey PRIMARY KEY (id);


--
-- Name: search_locales search_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_locales
    ADD CONSTRAINT search_locales_pkey PRIMARY KEY (id);


--
-- Name: search search_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search
    ADD CONSTRAINT search_pkey PRIMARY KEY (id);


--
-- Name: search_rels search_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_rels
    ADD CONSTRAINT search_rels_pkey PRIMARY KEY (id);


--
-- Name: services_locales services_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.services_locales
    ADD CONSTRAINT services_locales_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: testimonials_locales testimonials_locales_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.testimonials_locales
    ADD CONSTRAINT testimonials_locales_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_sessions users_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_pkey PRIMARY KEY (id);


--
-- Name: _portfolio_v_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_created_at_idx ON public._portfolio_v USING btree (created_at);


--
-- Name: _portfolio_v_latest_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_latest_idx ON public._portfolio_v USING btree (latest);


--
-- Name: _portfolio_v_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX _portfolio_v_locales_locale_parent_id_unique ON public._portfolio_v_locales USING btree (_locale, _parent_id);


--
-- Name: _portfolio_v_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_parent_idx ON public._portfolio_v USING btree (parent_id);


--
-- Name: _portfolio_v_published_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_published_locale_idx ON public._portfolio_v USING btree (published_locale);


--
-- Name: _portfolio_v_snapshot_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_snapshot_idx ON public._portfolio_v USING btree (snapshot);


--
-- Name: _portfolio_v_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_updated_at_idx ON public._portfolio_v USING btree (updated_at);


--
-- Name: _portfolio_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_version_version__status_idx ON public._portfolio_v USING btree (version__status);


--
-- Name: _portfolio_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_version_version_created_at_idx ON public._portfolio_v USING btree (version_created_at);


--
-- Name: _portfolio_v_version_version_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_version_version_image_idx ON public._portfolio_v USING btree (version_image_id);


--
-- Name: _portfolio_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_version_version_slug_idx ON public._portfolio_v_locales USING btree (version_slug, _locale);


--
-- Name: _portfolio_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _portfolio_v_version_version_updated_at_idx ON public._portfolio_v USING btree (version_updated_at);


--
-- Name: _posts_v_autosave_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_autosave_idx ON public._posts_v USING btree (autosave);


--
-- Name: _posts_v_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_created_at_idx ON public._posts_v USING btree (created_at);


--
-- Name: _posts_v_latest_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_latest_idx ON public._posts_v USING btree (latest);


--
-- Name: _posts_v_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX _posts_v_locales_locale_parent_id_unique ON public._posts_v_locales USING btree (_locale, _parent_id);


--
-- Name: _posts_v_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_parent_idx ON public._posts_v USING btree (parent_id);


--
-- Name: _posts_v_published_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_published_locale_idx ON public._posts_v USING btree (published_locale);


--
-- Name: _posts_v_rels_categories_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_categories_id_idx ON public._posts_v_rels USING btree (categories_id);


--
-- Name: _posts_v_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_order_idx ON public._posts_v_rels USING btree ("order");


--
-- Name: _posts_v_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_parent_idx ON public._posts_v_rels USING btree (parent_id);


--
-- Name: _posts_v_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_path_idx ON public._posts_v_rels USING btree (path);


--
-- Name: _posts_v_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_posts_id_idx ON public._posts_v_rels USING btree (posts_id);


--
-- Name: _posts_v_rels_users_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_rels_users_id_idx ON public._posts_v_rels USING btree (users_id);


--
-- Name: _posts_v_snapshot_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_snapshot_idx ON public._posts_v USING btree (snapshot);


--
-- Name: _posts_v_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_updated_at_idx ON public._posts_v USING btree (updated_at);


--
-- Name: _posts_v_version_meta_version_meta_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_meta_version_meta_image_idx ON public._posts_v_locales USING btree (version_meta_image_id, _locale);


--
-- Name: _posts_v_version_populated_authors_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_populated_authors_order_idx ON public._posts_v_version_populated_authors USING btree (_order);


--
-- Name: _posts_v_version_populated_authors_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_populated_authors_parent_id_idx ON public._posts_v_version_populated_authors USING btree (_parent_id);


--
-- Name: _posts_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_version__status_idx ON public._posts_v USING btree (version__status);


--
-- Name: _posts_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_version_created_at_idx ON public._posts_v USING btree (version_created_at);


--
-- Name: _posts_v_version_version_hero_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_version_hero_image_idx ON public._posts_v USING btree (version_hero_image_id);


--
-- Name: _posts_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_version_slug_idx ON public._posts_v_locales USING btree (version_slug, _locale);


--
-- Name: _posts_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _posts_v_version_version_updated_at_idx ON public._posts_v USING btree (version_updated_at);


--
-- Name: _services_v_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_created_at_idx ON public._services_v USING btree (created_at);


--
-- Name: _services_v_latest_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_latest_idx ON public._services_v USING btree (latest);


--
-- Name: _services_v_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX _services_v_locales_locale_parent_id_unique ON public._services_v_locales USING btree (_locale, _parent_id);


--
-- Name: _services_v_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_parent_idx ON public._services_v USING btree (parent_id);


--
-- Name: _services_v_published_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_published_locale_idx ON public._services_v USING btree (published_locale);


--
-- Name: _services_v_snapshot_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_snapshot_idx ON public._services_v USING btree (snapshot);


--
-- Name: _services_v_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_updated_at_idx ON public._services_v USING btree (updated_at);


--
-- Name: _services_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_version_version__status_idx ON public._services_v USING btree (version__status);


--
-- Name: _services_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_version_version_created_at_idx ON public._services_v USING btree (version_created_at);


--
-- Name: _services_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _services_v_version_version_updated_at_idx ON public._services_v USING btree (version_updated_at);


--
-- Name: _testimonials_v_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_created_at_idx ON public._testimonials_v USING btree (created_at);


--
-- Name: _testimonials_v_latest_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_latest_idx ON public._testimonials_v USING btree (latest);


--
-- Name: _testimonials_v_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX _testimonials_v_locales_locale_parent_id_unique ON public._testimonials_v_locales USING btree (_locale, _parent_id);


--
-- Name: _testimonials_v_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_parent_idx ON public._testimonials_v USING btree (parent_id);


--
-- Name: _testimonials_v_published_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_published_locale_idx ON public._testimonials_v USING btree (published_locale);


--
-- Name: _testimonials_v_snapshot_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_snapshot_idx ON public._testimonials_v USING btree (snapshot);


--
-- Name: _testimonials_v_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_updated_at_idx ON public._testimonials_v USING btree (updated_at);


--
-- Name: _testimonials_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_version_version__status_idx ON public._testimonials_v USING btree (version__status);


--
-- Name: _testimonials_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_version_version_created_at_idx ON public._testimonials_v USING btree (version_created_at);


--
-- Name: _testimonials_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX _testimonials_v_version_version_updated_at_idx ON public._testimonials_v USING btree (version_updated_at);


--
-- Name: about_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX about_locales_locale_parent_id_unique ON public.about_locales USING btree (_locale, _parent_id);


--
-- Name: about_principles_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX about_principles_locale_idx ON public.about_principles USING btree (_locale);


--
-- Name: about_principles_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX about_principles_order_idx ON public.about_principles USING btree (_order);


--
-- Name: about_principles_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX about_principles_parent_id_idx ON public.about_principles USING btree (_parent_id);


--
-- Name: categories_breadcrumbs_doc_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_breadcrumbs_doc_idx ON public.categories_breadcrumbs USING btree (doc_id);


--
-- Name: categories_breadcrumbs_locale_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_breadcrumbs_locale_idx ON public.categories_breadcrumbs USING btree (_locale);


--
-- Name: categories_breadcrumbs_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_breadcrumbs_order_idx ON public.categories_breadcrumbs USING btree (_order);


--
-- Name: categories_breadcrumbs_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_breadcrumbs_parent_id_idx ON public.categories_breadcrumbs USING btree (_parent_id);


--
-- Name: categories_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_created_at_idx ON public.categories USING btree (created_at);


--
-- Name: categories_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX categories_locales_locale_parent_id_unique ON public.categories_locales USING btree (_locale, _parent_id);


--
-- Name: categories_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_parent_idx ON public.categories USING btree (parent_id);


--
-- Name: categories_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX categories_slug_idx ON public.categories_locales USING btree (slug, _locale);


--
-- Name: categories_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX categories_updated_at_idx ON public.categories USING btree (updated_at);


--
-- Name: footer_nav_items_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX footer_nav_items_locales_locale_parent_id_unique ON public.footer_nav_items_locales USING btree (_locale, _parent_id);


--
-- Name: footer_nav_items_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_nav_items_order_idx ON public.footer_nav_items USING btree (_order);


--
-- Name: footer_nav_items_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_nav_items_parent_id_idx ON public.footer_nav_items USING btree (_parent_id);


--
-- Name: footer_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_rels_order_idx ON public.footer_rels USING btree ("order");


--
-- Name: footer_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_rels_parent_idx ON public.footer_rels USING btree (parent_id);


--
-- Name: footer_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_rels_path_idx ON public.footer_rels USING btree (path);


--
-- Name: footer_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX footer_rels_posts_id_idx ON public.footer_rels USING btree (posts_id);


--
-- Name: form_submissions_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX form_submissions_created_at_idx ON public.form_submissions USING btree (created_at);


--
-- Name: form_submissions_form_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX form_submissions_form_idx ON public.form_submissions USING btree (form_id);


--
-- Name: form_submissions_submission_data_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX form_submissions_submission_data_order_idx ON public.form_submissions_submission_data USING btree (_order);


--
-- Name: form_submissions_submission_data_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX form_submissions_submission_data_parent_id_idx ON public.form_submissions_submission_data USING btree (_parent_id);


--
-- Name: form_submissions_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX form_submissions_updated_at_idx ON public.form_submissions USING btree (updated_at);


--
-- Name: forms_blocks_checkbox_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_checkbox_locales_locale_parent_id_unique ON public.forms_blocks_checkbox_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_checkbox_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_checkbox_order_idx ON public.forms_blocks_checkbox USING btree (_order);


--
-- Name: forms_blocks_checkbox_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_checkbox_parent_id_idx ON public.forms_blocks_checkbox USING btree (_parent_id);


--
-- Name: forms_blocks_checkbox_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_checkbox_path_idx ON public.forms_blocks_checkbox USING btree (_path);


--
-- Name: forms_blocks_country_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_country_locales_locale_parent_id_unique ON public.forms_blocks_country_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_country_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_country_order_idx ON public.forms_blocks_country USING btree (_order);


--
-- Name: forms_blocks_country_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_country_parent_id_idx ON public.forms_blocks_country USING btree (_parent_id);


--
-- Name: forms_blocks_country_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_country_path_idx ON public.forms_blocks_country USING btree (_path);


--
-- Name: forms_blocks_email_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_email_locales_locale_parent_id_unique ON public.forms_blocks_email_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_email_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_email_order_idx ON public.forms_blocks_email USING btree (_order);


--
-- Name: forms_blocks_email_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_email_parent_id_idx ON public.forms_blocks_email USING btree (_parent_id);


--
-- Name: forms_blocks_email_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_email_path_idx ON public.forms_blocks_email USING btree (_path);


--
-- Name: forms_blocks_message_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_message_locales_locale_parent_id_unique ON public.forms_blocks_message_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_message_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_message_order_idx ON public.forms_blocks_message USING btree (_order);


--
-- Name: forms_blocks_message_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_message_parent_id_idx ON public.forms_blocks_message USING btree (_parent_id);


--
-- Name: forms_blocks_message_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_message_path_idx ON public.forms_blocks_message USING btree (_path);


--
-- Name: forms_blocks_number_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_number_locales_locale_parent_id_unique ON public.forms_blocks_number_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_number_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_number_order_idx ON public.forms_blocks_number USING btree (_order);


--
-- Name: forms_blocks_number_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_number_parent_id_idx ON public.forms_blocks_number USING btree (_parent_id);


--
-- Name: forms_blocks_number_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_number_path_idx ON public.forms_blocks_number USING btree (_path);


--
-- Name: forms_blocks_select_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_select_locales_locale_parent_id_unique ON public.forms_blocks_select_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_select_options_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_select_options_locales_locale_parent_id_unique ON public.forms_blocks_select_options_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_select_options_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_select_options_order_idx ON public.forms_blocks_select_options USING btree (_order);


--
-- Name: forms_blocks_select_options_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_select_options_parent_id_idx ON public.forms_blocks_select_options USING btree (_parent_id);


--
-- Name: forms_blocks_select_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_select_order_idx ON public.forms_blocks_select USING btree (_order);


--
-- Name: forms_blocks_select_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_select_parent_id_idx ON public.forms_blocks_select USING btree (_parent_id);


--
-- Name: forms_blocks_select_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_select_path_idx ON public.forms_blocks_select USING btree (_path);


--
-- Name: forms_blocks_state_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_state_locales_locale_parent_id_unique ON public.forms_blocks_state_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_state_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_state_order_idx ON public.forms_blocks_state USING btree (_order);


--
-- Name: forms_blocks_state_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_state_parent_id_idx ON public.forms_blocks_state USING btree (_parent_id);


--
-- Name: forms_blocks_state_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_state_path_idx ON public.forms_blocks_state USING btree (_path);


--
-- Name: forms_blocks_text_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_text_locales_locale_parent_id_unique ON public.forms_blocks_text_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_text_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_text_order_idx ON public.forms_blocks_text USING btree (_order);


--
-- Name: forms_blocks_text_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_text_parent_id_idx ON public.forms_blocks_text USING btree (_parent_id);


--
-- Name: forms_blocks_text_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_text_path_idx ON public.forms_blocks_text USING btree (_path);


--
-- Name: forms_blocks_textarea_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_blocks_textarea_locales_locale_parent_id_unique ON public.forms_blocks_textarea_locales USING btree (_locale, _parent_id);


--
-- Name: forms_blocks_textarea_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_textarea_order_idx ON public.forms_blocks_textarea USING btree (_order);


--
-- Name: forms_blocks_textarea_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_textarea_parent_id_idx ON public.forms_blocks_textarea USING btree (_parent_id);


--
-- Name: forms_blocks_textarea_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_blocks_textarea_path_idx ON public.forms_blocks_textarea USING btree (_path);


--
-- Name: forms_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_created_at_idx ON public.forms USING btree (created_at);


--
-- Name: forms_emails_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_emails_locales_locale_parent_id_unique ON public.forms_emails_locales USING btree (_locale, _parent_id);


--
-- Name: forms_emails_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_emails_order_idx ON public.forms_emails USING btree (_order);


--
-- Name: forms_emails_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_emails_parent_id_idx ON public.forms_emails USING btree (_parent_id);


--
-- Name: forms_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX forms_locales_locale_parent_id_unique ON public.forms_locales USING btree (_locale, _parent_id);


--
-- Name: forms_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX forms_updated_at_idx ON public.forms USING btree (updated_at);


--
-- Name: header_nav_items_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX header_nav_items_locales_locale_parent_id_unique ON public.header_nav_items_locales USING btree (_locale, _parent_id);


--
-- Name: header_nav_items_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_nav_items_order_idx ON public.header_nav_items USING btree (_order);


--
-- Name: header_nav_items_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_nav_items_parent_id_idx ON public.header_nav_items USING btree (_parent_id);


--
-- Name: header_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_rels_order_idx ON public.header_rels USING btree ("order");


--
-- Name: header_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_rels_parent_idx ON public.header_rels USING btree (parent_id);


--
-- Name: header_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_rels_path_idx ON public.header_rels USING btree (path);


--
-- Name: header_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX header_rels_posts_id_idx ON public.header_rels USING btree (posts_id);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_folder_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_folder_idx ON public.media USING btree (folder_id);


--
-- Name: media_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX media_locales_locale_parent_id_unique ON public.media_locales USING btree (_locale, _parent_id);


--
-- Name: media_sizes_large_sizes_large_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_large_sizes_large_filename_idx ON public.media USING btree (sizes_large_filename);


--
-- Name: media_sizes_medium_sizes_medium_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_medium_sizes_medium_filename_idx ON public.media USING btree (sizes_medium_filename);


--
-- Name: media_sizes_og_sizes_og_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_og_sizes_og_filename_idx ON public.media USING btree (sizes_og_filename);


--
-- Name: media_sizes_small_sizes_small_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_small_sizes_small_filename_idx ON public.media USING btree (sizes_small_filename);


--
-- Name: media_sizes_square_sizes_square_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_square_sizes_square_filename_idx ON public.media USING btree (sizes_square_filename);


--
-- Name: media_sizes_thumbnail_sizes_thumbnail_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_thumbnail_sizes_thumbnail_filename_idx ON public.media USING btree (sizes_thumbnail_filename);


--
-- Name: media_sizes_xlarge_sizes_xlarge_filename_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_sizes_xlarge_sizes_xlarge_filename_idx ON public.media USING btree (sizes_xlarge_filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: payload_folders_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_created_at_idx ON public.payload_folders USING btree (created_at);


--
-- Name: payload_folders_folder_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_folder_idx ON public.payload_folders USING btree (folder_id);


--
-- Name: payload_folders_folder_type_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_folder_type_order_idx ON public.payload_folders_folder_type USING btree ("order");


--
-- Name: payload_folders_folder_type_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_folder_type_parent_idx ON public.payload_folders_folder_type USING btree (parent_id);


--
-- Name: payload_folders_name_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_name_idx ON public.payload_folders USING btree (name);


--
-- Name: payload_folders_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_folders_updated_at_idx ON public.payload_folders USING btree (updated_at);


--
-- Name: payload_jobs_completed_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_completed_at_idx ON public.payload_jobs USING btree (completed_at);


--
-- Name: payload_jobs_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_created_at_idx ON public.payload_jobs USING btree (created_at);


--
-- Name: payload_jobs_has_error_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_has_error_idx ON public.payload_jobs USING btree (has_error);


--
-- Name: payload_jobs_log_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_log_order_idx ON public.payload_jobs_log USING btree (_order);


--
-- Name: payload_jobs_log_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_log_parent_id_idx ON public.payload_jobs_log USING btree (_parent_id);


--
-- Name: payload_jobs_processing_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_processing_idx ON public.payload_jobs USING btree (processing);


--
-- Name: payload_jobs_queue_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_queue_idx ON public.payload_jobs USING btree (queue);


--
-- Name: payload_jobs_task_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_task_slug_idx ON public.payload_jobs USING btree (task_slug);


--
-- Name: payload_jobs_total_tried_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_total_tried_idx ON public.payload_jobs USING btree (total_tried);


--
-- Name: payload_jobs_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_updated_at_idx ON public.payload_jobs USING btree (updated_at);


--
-- Name: payload_jobs_wait_until_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_jobs_wait_until_idx ON public.payload_jobs USING btree (wait_until);


--
-- Name: payload_kv_key_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX payload_kv_key_idx ON public.payload_kv USING btree (key);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_categories_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_categories_id_idx ON public.payload_locked_documents_rels USING btree (categories_id);


--
-- Name: payload_locked_documents_rels_form_submissions_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_form_submissions_id_idx ON public.payload_locked_documents_rels USING btree (form_submissions_id);


--
-- Name: payload_locked_documents_rels_forms_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_forms_id_idx ON public.payload_locked_documents_rels USING btree (forms_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_payload_folders_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_payload_folders_id_idx ON public.payload_locked_documents_rels USING btree (payload_folders_id);


--
-- Name: payload_locked_documents_rels_payload_mcp_api_keys_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_payload_mcp_api_keys_id_idx ON public.payload_locked_documents_rels USING btree (payload_mcp_api_keys_id);


--
-- Name: payload_locked_documents_rels_portfolio_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_portfolio_id_idx ON public.payload_locked_documents_rels USING btree (portfolio_id);


--
-- Name: payload_locked_documents_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_posts_id_idx ON public.payload_locked_documents_rels USING btree (posts_id);


--
-- Name: payload_locked_documents_rels_redirects_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_redirects_id_idx ON public.payload_locked_documents_rels USING btree (redirects_id);


--
-- Name: payload_locked_documents_rels_search_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_search_id_idx ON public.payload_locked_documents_rels USING btree (search_id);


--
-- Name: payload_locked_documents_rels_services_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_services_id_idx ON public.payload_locked_documents_rels USING btree (services_id);


--
-- Name: payload_locked_documents_rels_testimonials_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_testimonials_id_idx ON public.payload_locked_documents_rels USING btree (testimonials_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_mcp_api_keys_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_mcp_api_keys_created_at_idx ON public.payload_mcp_api_keys USING btree (created_at);


--
-- Name: payload_mcp_api_keys_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_mcp_api_keys_updated_at_idx ON public.payload_mcp_api_keys USING btree (updated_at);


--
-- Name: payload_mcp_api_keys_user_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_mcp_api_keys_user_idx ON public.payload_mcp_api_keys USING btree (user_id);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_payload_mcp_api_keys_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_rels_payload_mcp_api_keys_id_idx ON public.payload_preferences_rels USING btree (payload_mcp_api_keys_id);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: portfolio__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX portfolio__status_idx ON public.portfolio USING btree (_status);


--
-- Name: portfolio_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX portfolio_created_at_idx ON public.portfolio USING btree (created_at);


--
-- Name: portfolio_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX portfolio_image_idx ON public.portfolio USING btree (image_id);


--
-- Name: portfolio_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX portfolio_locales_locale_parent_id_unique ON public.portfolio_locales USING btree (_locale, _parent_id);


--
-- Name: portfolio_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX portfolio_slug_idx ON public.portfolio_locales USING btree (slug, _locale);


--
-- Name: portfolio_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX portfolio_updated_at_idx ON public.portfolio USING btree (updated_at);


--
-- Name: posts__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts__status_idx ON public.posts USING btree (_status);


--
-- Name: posts_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_created_at_idx ON public.posts USING btree (created_at);


--
-- Name: posts_hero_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_hero_image_idx ON public.posts USING btree (hero_image_id);


--
-- Name: posts_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX posts_locales_locale_parent_id_unique ON public.posts_locales USING btree (_locale, _parent_id);


--
-- Name: posts_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_meta_meta_image_idx ON public.posts_locales USING btree (meta_image_id, _locale);


--
-- Name: posts_populated_authors_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_populated_authors_order_idx ON public.posts_populated_authors USING btree (_order);


--
-- Name: posts_populated_authors_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_populated_authors_parent_id_idx ON public.posts_populated_authors USING btree (_parent_id);


--
-- Name: posts_rels_categories_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_categories_id_idx ON public.posts_rels USING btree (categories_id);


--
-- Name: posts_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_order_idx ON public.posts_rels USING btree ("order");


--
-- Name: posts_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_parent_idx ON public.posts_rels USING btree (parent_id);


--
-- Name: posts_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_path_idx ON public.posts_rels USING btree (path);


--
-- Name: posts_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_posts_id_idx ON public.posts_rels USING btree (posts_id);


--
-- Name: posts_rels_users_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_rels_users_id_idx ON public.posts_rels USING btree (users_id);


--
-- Name: posts_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX posts_slug_idx ON public.posts_locales USING btree (slug, _locale);


--
-- Name: posts_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX posts_updated_at_idx ON public.posts USING btree (updated_at);


--
-- Name: redirects_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_created_at_idx ON public.redirects USING btree (created_at);


--
-- Name: redirects_from_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX redirects_from_idx ON public.redirects USING btree ("from");


--
-- Name: redirects_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_rels_order_idx ON public.redirects_rels USING btree ("order");


--
-- Name: redirects_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_rels_parent_idx ON public.redirects_rels USING btree (parent_id);


--
-- Name: redirects_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_rels_path_idx ON public.redirects_rels USING btree (path);


--
-- Name: redirects_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_rels_posts_id_idx ON public.redirects_rels USING btree (posts_id);


--
-- Name: redirects_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX redirects_updated_at_idx ON public.redirects USING btree (updated_at);


--
-- Name: search_categories_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_categories_order_idx ON public.search_categories USING btree (_order);


--
-- Name: search_categories_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_categories_parent_id_idx ON public.search_categories USING btree (_parent_id);


--
-- Name: search_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_created_at_idx ON public.search USING btree (created_at);


--
-- Name: search_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX search_locales_locale_parent_id_unique ON public.search_locales USING btree (_locale, _parent_id);


--
-- Name: search_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_meta_meta_image_idx ON public.search USING btree (meta_image_id);


--
-- Name: search_rels_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_rels_order_idx ON public.search_rels USING btree ("order");


--
-- Name: search_rels_parent_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_rels_parent_idx ON public.search_rels USING btree (parent_id);


--
-- Name: search_rels_path_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_rels_path_idx ON public.search_rels USING btree (path);


--
-- Name: search_rels_posts_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_rels_posts_id_idx ON public.search_rels USING btree (posts_id);


--
-- Name: search_slug_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_slug_idx ON public.search USING btree (slug);


--
-- Name: search_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX search_updated_at_idx ON public.search USING btree (updated_at);


--
-- Name: services__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX services__status_idx ON public.services USING btree (_status);


--
-- Name: services_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX services_created_at_idx ON public.services USING btree (created_at);


--
-- Name: services_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX services_locales_locale_parent_id_unique ON public.services_locales USING btree (_locale, _parent_id);


--
-- Name: services_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX services_updated_at_idx ON public.services USING btree (updated_at);


--
-- Name: testimonials__status_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX testimonials__status_idx ON public.testimonials USING btree (_status);


--
-- Name: testimonials_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX testimonials_created_at_idx ON public.testimonials USING btree (created_at);


--
-- Name: testimonials_locales_locale_parent_id_unique; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX testimonials_locales_locale_parent_id_unique ON public.testimonials_locales USING btree (_locale, _parent_id);


--
-- Name: testimonials_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX testimonials_updated_at_idx ON public.testimonials USING btree (updated_at);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_sessions_order_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX users_sessions_order_idx ON public.users_sessions USING btree (_order);


--
-- Name: users_sessions_parent_id_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX users_sessions_parent_id_idx ON public.users_sessions USING btree (_parent_id);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: momos_user
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: _portfolio_v_locales _portfolio_v_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v_locales
    ADD CONSTRAINT _portfolio_v_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._portfolio_v(id) ON DELETE CASCADE;


--
-- Name: _portfolio_v _portfolio_v_parent_id_portfolio_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v
    ADD CONSTRAINT _portfolio_v_parent_id_portfolio_id_fk FOREIGN KEY (parent_id) REFERENCES public.portfolio(id) ON DELETE SET NULL;


--
-- Name: _portfolio_v _portfolio_v_version_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._portfolio_v
    ADD CONSTRAINT _portfolio_v_version_image_id_media_id_fk FOREIGN KEY (version_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _posts_v_locales _posts_v_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_locales
    ADD CONSTRAINT _posts_v_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._posts_v(id) ON DELETE CASCADE;


--
-- Name: _posts_v_locales _posts_v_locales_version_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_locales
    ADD CONSTRAINT _posts_v_locales_version_meta_image_id_media_id_fk FOREIGN KEY (version_meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _posts_v _posts_v_parent_id_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_parent_id_posts_id_fk FOREIGN KEY (parent_id) REFERENCES public.posts(id) ON DELETE SET NULL;


--
-- Name: _posts_v_rels _posts_v_rels_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels
    ADD CONSTRAINT _posts_v_rels_categories_fk FOREIGN KEY (categories_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: _posts_v_rels _posts_v_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels
    ADD CONSTRAINT _posts_v_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public._posts_v(id) ON DELETE CASCADE;


--
-- Name: _posts_v_rels _posts_v_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels
    ADD CONSTRAINT _posts_v_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: _posts_v_rels _posts_v_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_rels
    ADD CONSTRAINT _posts_v_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: _posts_v _posts_v_version_hero_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v
    ADD CONSTRAINT _posts_v_version_hero_image_id_media_id_fk FOREIGN KEY (version_hero_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _posts_v_version_populated_authors _posts_v_version_populated_authors_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._posts_v_version_populated_authors
    ADD CONSTRAINT _posts_v_version_populated_authors_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._posts_v(id) ON DELETE CASCADE;


--
-- Name: _services_v_locales _services_v_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v_locales
    ADD CONSTRAINT _services_v_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._services_v(id) ON DELETE CASCADE;


--
-- Name: _services_v _services_v_parent_id_services_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._services_v
    ADD CONSTRAINT _services_v_parent_id_services_id_fk FOREIGN KEY (parent_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: _testimonials_v_locales _testimonials_v_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v_locales
    ADD CONSTRAINT _testimonials_v_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._testimonials_v(id) ON DELETE CASCADE;


--
-- Name: _testimonials_v _testimonials_v_parent_id_testimonials_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public._testimonials_v
    ADD CONSTRAINT _testimonials_v_parent_id_testimonials_id_fk FOREIGN KEY (parent_id) REFERENCES public.testimonials(id) ON DELETE SET NULL;


--
-- Name: about_locales about_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about_locales
    ADD CONSTRAINT about_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.about(id) ON DELETE CASCADE;


--
-- Name: about_principles about_principles_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.about_principles
    ADD CONSTRAINT about_principles_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.about(id) ON DELETE CASCADE;


--
-- Name: categories_breadcrumbs categories_breadcrumbs_doc_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_breadcrumbs
    ADD CONSTRAINT categories_breadcrumbs_doc_id_categories_id_fk FOREIGN KEY (doc_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: categories_breadcrumbs categories_breadcrumbs_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_breadcrumbs
    ADD CONSTRAINT categories_breadcrumbs_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories_locales categories_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories_locales
    ADD CONSTRAINT categories_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: categories categories_parent_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_categories_id_fk FOREIGN KEY (parent_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: footer_nav_items_locales footer_nav_items_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_nav_items_locales
    ADD CONSTRAINT footer_nav_items_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.footer_nav_items(id) ON DELETE CASCADE;


--
-- Name: footer_nav_items footer_nav_items_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_nav_items
    ADD CONSTRAINT footer_nav_items_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.footer(id) ON DELETE CASCADE;


--
-- Name: footer_rels footer_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_rels
    ADD CONSTRAINT footer_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.footer(id) ON DELETE CASCADE;


--
-- Name: footer_rels footer_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.footer_rels
    ADD CONSTRAINT footer_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_form_id_forms_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_form_id_forms_id_fk FOREIGN KEY (form_id) REFERENCES public.forms(id) ON DELETE SET NULL;


--
-- Name: form_submissions_submission_data form_submissions_submission_data_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.form_submissions_submission_data
    ADD CONSTRAINT form_submissions_submission_data_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.form_submissions(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_checkbox_locales forms_blocks_checkbox_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_checkbox_locales
    ADD CONSTRAINT forms_blocks_checkbox_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_checkbox(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_checkbox forms_blocks_checkbox_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_checkbox
    ADD CONSTRAINT forms_blocks_checkbox_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_country_locales forms_blocks_country_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_country_locales
    ADD CONSTRAINT forms_blocks_country_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_country(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_country forms_blocks_country_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_country
    ADD CONSTRAINT forms_blocks_country_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_email_locales forms_blocks_email_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_email_locales
    ADD CONSTRAINT forms_blocks_email_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_email(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_email forms_blocks_email_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_email
    ADD CONSTRAINT forms_blocks_email_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_message_locales forms_blocks_message_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_message_locales
    ADD CONSTRAINT forms_blocks_message_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_message(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_message forms_blocks_message_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_message
    ADD CONSTRAINT forms_blocks_message_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_number_locales forms_blocks_number_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_number_locales
    ADD CONSTRAINT forms_blocks_number_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_number(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_number forms_blocks_number_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_number
    ADD CONSTRAINT forms_blocks_number_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_select_locales forms_blocks_select_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_locales
    ADD CONSTRAINT forms_blocks_select_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_select(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_select_options_locales forms_blocks_select_options_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_options_locales
    ADD CONSTRAINT forms_blocks_select_options_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_select_options(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_select_options forms_blocks_select_options_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select_options
    ADD CONSTRAINT forms_blocks_select_options_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_select(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_select forms_blocks_select_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_select
    ADD CONSTRAINT forms_blocks_select_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_state_locales forms_blocks_state_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_state_locales
    ADD CONSTRAINT forms_blocks_state_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_state(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_state forms_blocks_state_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_state
    ADD CONSTRAINT forms_blocks_state_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_text_locales forms_blocks_text_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_text_locales
    ADD CONSTRAINT forms_blocks_text_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_text(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_text forms_blocks_text_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_text
    ADD CONSTRAINT forms_blocks_text_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_textarea_locales forms_blocks_textarea_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_textarea_locales
    ADD CONSTRAINT forms_blocks_textarea_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_blocks_textarea(id) ON DELETE CASCADE;


--
-- Name: forms_blocks_textarea forms_blocks_textarea_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_blocks_textarea
    ADD CONSTRAINT forms_blocks_textarea_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_emails_locales forms_emails_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_emails_locales
    ADD CONSTRAINT forms_emails_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms_emails(id) ON DELETE CASCADE;


--
-- Name: forms_emails forms_emails_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_emails
    ADD CONSTRAINT forms_emails_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: forms_locales forms_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.forms_locales
    ADD CONSTRAINT forms_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: header_nav_items_locales header_nav_items_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_nav_items_locales
    ADD CONSTRAINT header_nav_items_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.header_nav_items(id) ON DELETE CASCADE;


--
-- Name: header_nav_items header_nav_items_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_nav_items
    ADD CONSTRAINT header_nav_items_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.header(id) ON DELETE CASCADE;


--
-- Name: header_rels header_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_rels
    ADD CONSTRAINT header_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.header(id) ON DELETE CASCADE;


--
-- Name: header_rels header_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.header_rels
    ADD CONSTRAINT header_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: media media_folder_id_payload_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_folder_id_payload_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.payload_folders(id) ON DELETE SET NULL;


--
-- Name: media_locales media_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.media_locales
    ADD CONSTRAINT media_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_folders payload_folders_folder_id_payload_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders
    ADD CONSTRAINT payload_folders_folder_id_payload_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.payload_folders(id) ON DELETE SET NULL;


--
-- Name: payload_folders_folder_type payload_folders_folder_type_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_folders_folder_type
    ADD CONSTRAINT payload_folders_folder_type_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_folders(id) ON DELETE CASCADE;


--
-- Name: payload_jobs_log payload_jobs_log_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_jobs_log
    ADD CONSTRAINT payload_jobs_log_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.payload_jobs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_categories_fk FOREIGN KEY (categories_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_form_submissions_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_form_submissions_fk FOREIGN KEY (form_submissions_id) REFERENCES public.form_submissions(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_forms_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_forms_fk FOREIGN KEY (forms_id) REFERENCES public.forms(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_payload_folders_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_payload_folders_fk FOREIGN KEY (payload_folders_id) REFERENCES public.payload_folders(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_payload_mcp_api_keys_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_payload_mcp_api_keys_fk FOREIGN KEY (payload_mcp_api_keys_id) REFERENCES public.payload_mcp_api_keys(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_portfolio_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_portfolio_fk FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_redirects_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_redirects_fk FOREIGN KEY (redirects_id) REFERENCES public.redirects(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_search_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_search_fk FOREIGN KEY (search_id) REFERENCES public.search(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_services_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_services_fk FOREIGN KEY (services_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_testimonials_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_testimonials_fk FOREIGN KEY (testimonials_id) REFERENCES public.testimonials(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_mcp_api_keys payload_mcp_api_keys_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_mcp_api_keys
    ADD CONSTRAINT payload_mcp_api_keys_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_payload_mcp_api_keys_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_payload_mcp_api_keys_fk FOREIGN KEY (payload_mcp_api_keys_id) REFERENCES public.payload_mcp_api_keys(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: portfolio portfolio_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: portfolio_locales portfolio_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.portfolio_locales
    ADD CONSTRAINT portfolio_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.portfolio(id) ON DELETE CASCADE;


--
-- Name: posts posts_hero_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_hero_image_id_media_id_fk FOREIGN KEY (hero_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: posts_locales posts_locales_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_locales
    ADD CONSTRAINT posts_locales_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: posts_locales posts_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_locales
    ADD CONSTRAINT posts_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts_populated_authors posts_populated_authors_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_populated_authors
    ADD CONSTRAINT posts_populated_authors_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts_rels posts_rels_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels
    ADD CONSTRAINT posts_rels_categories_fk FOREIGN KEY (categories_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: posts_rels posts_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels
    ADD CONSTRAINT posts_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts_rels posts_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels
    ADD CONSTRAINT posts_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts_rels posts_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.posts_rels
    ADD CONSTRAINT posts_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: redirects_rels redirects_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects_rels
    ADD CONSTRAINT redirects_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.redirects(id) ON DELETE CASCADE;


--
-- Name: redirects_rels redirects_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.redirects_rels
    ADD CONSTRAINT redirects_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: search_categories search_categories_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_categories
    ADD CONSTRAINT search_categories_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.search(id) ON DELETE CASCADE;


--
-- Name: search_locales search_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_locales
    ADD CONSTRAINT search_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.search(id) ON DELETE CASCADE;


--
-- Name: search search_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search
    ADD CONSTRAINT search_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: search_rels search_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_rels
    ADD CONSTRAINT search_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.search(id) ON DELETE CASCADE;


--
-- Name: search_rels search_rels_posts_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.search_rels
    ADD CONSTRAINT search_rels_posts_fk FOREIGN KEY (posts_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: services_locales services_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.services_locales
    ADD CONSTRAINT services_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: testimonials_locales testimonials_locales_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.testimonials_locales
    ADD CONSTRAINT testimonials_locales_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.testimonials(id) ON DELETE CASCADE;


--
-- Name: users_sessions users_sessions_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: momos_user
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GAx7IvPppp89l8nqFenAX8hfdMVrJUgOhctlIl8Y4vvXnxeSzCRaqCk4oAdrl20

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict ATnUspBYi4xQJ32DI4NCNtUD1pJdl31agGssCqMi2n1WaQhdId3Hfrtc1JpzarG

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ATnUspBYi4xQJ32DI4NCNtUD1pJdl31agGssCqMi2n1WaQhdId3Hfrtc1JpzarG

--
-- PostgreSQL database cluster dump complete
--

