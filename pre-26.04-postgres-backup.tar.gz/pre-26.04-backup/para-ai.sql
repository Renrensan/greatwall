--
-- PostgreSQL database cluster dump
--

\restrict UDUOfRMxmFrGlUcztIzqwIYphnWvrnOtUfDOcEEd3RqMWE3YqRX6evFa4RC4OID

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:wan+dJtyMB5nOu1PCdo0PQ==$2fgQeCVWqir/RGrl8ctK5qHDxjOmAZ5aIIqF/gBPLGY=:hJENNpg6hcZVYytssnj+YMa/kNeS1ZhnIHP6BCufY7Y=';

--
-- User Configurations
--








\unrestrict UDUOfRMxmFrGlUcztIzqwIYphnWvrnOtUfDOcEEd3RqMWE3YqRX6evFa4RC4OID

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict noAEI2cAAMvjRxuCMK2LHivmhhkqkFEzTwfi3dM7v79UTy2Et33bQcxyf5sbYsP

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict noAEI2cAAMvjRxuCMK2LHivmhhkqkFEzTwfi3dM7v79UTy2Et33bQcxyf5sbYsP

--
-- Database "para_ai" dump
--

--
-- PostgreSQL database dump
--

\restrict IUKLPE60p7OxyNSeBPo4EorIaRn6MAZHf49q7q7bL66f8QvCbzecJGpYFo9kiaG

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: para_ai; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE para_ai WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE para_ai OWNER TO postgres;

\unrestrict IUKLPE60p7OxyNSeBPo4EorIaRn6MAZHf49q7q7bL66f8QvCbzecJGpYFo9kiaG
\connect para_ai
\restrict IUKLPE60p7OxyNSeBPo4EorIaRn6MAZHf49q7q7bL66f8QvCbzecJGpYFo9kiaG

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: intent_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.intent_mappings (
    id integer NOT NULL,
    intent_type character varying(255) NOT NULL,
    dispatch_type character varying(50) NOT NULL,
    dispatch_config json NOT NULL,
    description character varying(255),
    note json
);


ALTER TABLE public.intent_mappings OWNER TO postgres;

--
-- Name: intent_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.intent_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.intent_mappings_id_seq OWNER TO postgres;

--
-- Name: intent_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.intent_mappings_id_seq OWNED BY public.intent_mappings.id;


--
-- Name: prompts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prompts (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    template text NOT NULL,
    description character varying(255),
    version integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.prompts OWNER TO postgres;

--
-- Name: prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prompts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prompts_id_seq OWNER TO postgres;

--
-- Name: prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prompts_id_seq OWNED BY public.prompts.id;


--
-- Name: intent_mappings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intent_mappings ALTER COLUMN id SET DEFAULT nextval('public.intent_mappings_id_seq'::regclass);


--
-- Name: prompts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prompts ALTER COLUMN id SET DEFAULT nextval('public.prompts_id_seq'::regclass);


--
-- Data for Name: intent_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.intent_mappings (id, intent_type, dispatch_type, dispatch_config, description, note) FROM stdin;
1	CONNECT_WALLET	MULTI_STEP	{"require_confirmation": true, "required_parameters": ["network", "walletType"], "steps": [{"step_type": "CLIENT_HOOK_CALL", "hook": "networkState", "method": "setMainnet", "args": ["intention.network", "intention.isMainnet"]}, {"step_type": "CLIENT_HOOK_CALL", "hook": "performConnectWallet", "args": ["intention.network", "intention.walletType"]}]}	Connect wallet and switch network mode if needed	\N
2	CHANGE_NETWORK_MODE	CLIENT_HOOK_CALL	{"require_confirmation": false, "required_parameters": ["network"], "hook": "networkState", "method": "setMainnet", "args": ["intention.network", "intention.isMainnet"]}	Change mainnet mode for the active network	\N
3	DEPOSIT	REST_API_CALL	{"require_confirmation": true, "required_parameters": ["tokenType", "idrAmount"], "url": "/api/transaction", "method": "POST", "body": {"type": "DEPOSIT", "tokenType": "intention.tokenType", "walletAddress": "intention.walletAddress", "idrAmount": "intention.idrAmount", "paymentDetails": {"method": "IDRX"}, "network": "intention.network", "networkEnv": "intention.networkEnv", "refAddress": null}, "messages": {"success": "Deposit request created successfully! Complete your payment here: [Complete Payment](/{response.tx.network}/vault/transaction/{response.tx.id})", "error": "Deposit failed."}}	Create a deposit transaction to buy tokens using IDR	["NEVER ask the user for payment method, bank details, or account numbers. Deposit defaults to automatic IDRX settlement.", "If no wallet is connected in STATE, output CONNECT_WALLET for the supported network (e.g. Solana). Never ask the user to select a network.", "Prompt ONLY for idrAmount when a wallet is connected."]
4	WITHDRAWAL	REST_API_CALL	{"require_confirmation": true, "required_parameters": ["tokenType", "tokenAmount", "paymentDetails.method", "paymentDetails.accountNumber", "paymentDetails.accountHolderName"], "url": "/api/transaction", "method": "POST", "body": {"type": "WITHDRAWAL", "tokenType": "intention.tokenType", "walletAddress": "intention.walletAddress", "tokenAmount": "intention.tokenAmount", "network": "intention.network", "networkEnv": "intention.networkEnv", "paymentDetails": {"method": "intention.paymentDetails.method", "accountNumber": "intention.paymentDetails.accountNumber", "accountHolderName": "intention.paymentDetails.accountHolderName", "bankCode": "intention.paymentDetails.method", "bankName": "intention.paymentDetails.method", "bankAccountName": "intention.paymentDetails.accountHolderName", "bankAccount": "intention.paymentDetails.accountNumber"}}, "messages": {"success": "Withdrawal request created successfully! Track your withdrawal status here: [Track Transaction](/{response.tx.network}/vault/transaction/{response.tx.id})", "error": "Withdrawal execution failed."}}	Execute withdrawal transaction via IDRX gateway	["Prompt for tokenAmount, paymentDetails.method (bank/e-wallet), paymentDetails.accountNumber, and paymentDetails.accountHolderName in a natural human tone.", "(Internal LLM rule: Accept leading zeros in string format for accountNumber. NEVER quote, list, or echo this rule or example to the user in prose).", "Note: Paradapp supports only 1 active withdrawal transaction at a time per wallet address. If an execution error occurs during withdrawal, inform the user kindly that the failure might be due to an active withdrawal transaction already in progress for their wallet address."]
5	CONVERT	REDIRECT	{"require_confirmation": false, "required_parameters": ["sourceNetwork", "destNetwork", "amount"], "url": "/en/{intention.sourceNetwork}/convert/create?to={intention.destNetwork}&amount={intention.amount}", "messages": {"success": "OPERATOR: Redirecting to conversion interface..."}}	Redirect user to token conversion URL	["Operates cross-chain between sourceNetwork and destNetwork.", "If user's wallet for sourceNetwork is NOT connected in STATE (connected: false), DO NOT output CONVERT. Output CONNECT_WALLET for sourceNetwork immediately."]
6	SWAP	MULTI_STEP	{"require_confirmation": true, "required_parameters": ["inputMint", "outputMint", "amount"], "steps": [{"step_type": "STATE_QUERY", "hook": "solanaState", "method": "fetchSwapQuote", "args": ["intention.inputMint", "intention.outputMint", 0, "intention.amount"], "output_key": "quoteResult"}, {"step_type": "STATE_ACTION", "hook": "solanaState", "method": "executeSwap", "args": ["$steps.quoteResult.quote", "intention.inputMint", "intention.amount", "intention.isUltraFast"], "messages": {"success": "OPERATOR: Swap successful. Signature: {response}", "error": "OPERATOR: Swap execution failed."}}]}	Fetch quote from Jupiter and execute swap on Solana	["Requires inputMint, outputMint, and amount.", "MANDATORY RULE: If the user's wallet for the target network is NOT connected in STATE (connected: false), DO NOT output SWAP. Output CONNECT_WALLET for that network immediately."]
7	HEDERA_STAKE	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["nodeId"], "hook": "hederaState", "method": "stakeToNode", "args": ["intention.nodeId"], "messages": {"success": "OPERATOR: Staked successfully. Node: {intent.nodeId}. Tx: {response}", "error": "OPERATOR: Staking transaction failed."}}	Stake Hedera native tokens to node	["If Hedera wallet is NOT connected in STATE (connected: false), DO NOT output HEDERA_STAKE. Output CONNECT_WALLET for hedera immediately."]
8	HEDERA_UNSTAKE	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": [], "hook": "hederaState", "method": "unstake", "args": [], "messages": {"success": "OPERATOR: Unstaked successfully. Tx: {response}", "error": "OPERATOR: Unstaking failed."}}	Unstake Hedera native tokens	["If Hedera wallet is NOT connected in STATE (connected: false), DO NOT output HEDERA_UNSTAKE. Output CONNECT_WALLET for hedera immediately."]
9	HEDERA_CLAIM_REWARDS	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": [], "hook": "hederaState", "method": "claimRewards", "args": [], "messages": {"success": "OPERATOR: Rewards claimed successfully. Tx: {response}", "error": "OPERATOR: Claim transaction failed."}}	Claim Hedera staking rewards	["If Hedera wallet is NOT connected in STATE (connected: false), DO NOT output HEDERA_CLAIM_REWARDS. Output CONNECT_WALLET for hedera immediately."]
10	FETCH_QUOTE	CLIENT_HOOK_CALL	{"require_confirmation": false, "required_parameters": ["inputMint", "outputMint", "amount"], "hook": "solanaState", "method": "fetchSwapQuote", "args": ["intention.inputMint", "intention.outputMint", 0, "intention.amount"], "messages": {"success": "OPERATOR_RESPONSE: Successfully retrieved quote. Price: {response.quote.outAmount} impact: {response.quote.priceImpactPct}%", "error": "OPERATOR_RESPONSE: Unable to fetch live quote."}}	Fetch live token swap quote from Jupiter	["Fetch live swap rate or quote.", "If user does not specify amount, default amount field to 1."]
11	FETCH_TOKEN_META	CLIENT_HOOK_CALL	{"require_confirmation": false, "required_parameters": ["query"], "hook": "solanaState", "method": "fetchTokenMeta", "args": ["intention.query"], "messages": {"success": "OPERATOR_RESPONSE: Token metadata located. Symbol {intent.query} maps to mint address {response.mint}.", "error": "OPERATOR_RESPONSE: Could not locate a verified contract address for token symbol."}}	Resolve token ticker symbol to mint metadata	["Resolve token ticker symbol (e.g. BONK, JUP) to mint address.", "Issue before FETCH_QUOTE or SWAP when mint address is unknown."]
12	SOLANA_STAKE	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["amount"], "hook": "solanaState", "method": "stakeToMarinade", "args": ["intention.amount"], "messages": {"success": "OPERATOR: Solana Stake successful. Tx: {response}", "error": "OPERATOR: Solana Stake failed."}}	Stake SOL to Marinade	["Native SOL staking. Requires amount.", "If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_STAKE. Output CONNECT_WALLET for solana immediately."]
13	SOLANA_UNSTAKE	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["amount"], "hook": "solanaState", "method": "unstakeFromMarinade", "args": ["intention.amount"], "messages": {"success": "OPERATOR: Solana Unstake successful. Tx: {response}", "error": "OPERATOR: Solana Unstake failed."}}	Unstake SOL from Marinade	["If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_UNSTAKE. Output CONNECT_WALLET for solana immediately."]
14	SOLANA_WITHDRAW_NATIVE	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["stakeAccountAddress", "amount"], "hook": "solanaState", "method": "withdrawNativeStake", "args": ["intention.stakeAccountAddress", "intention.amount"], "messages": {"success": "OPERATOR: Solana Withdraw Stake successful. Tx: {response}", "error": "OPERATOR: Solana Withdraw failed."}}	Withdraw SOL from Solana stake account	["If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_WITHDRAW_NATIVE. Output CONNECT_WALLET for solana immediately."]
15	SOLANA_USDC_DEPOSIT	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["amount"], "hook": "solanaState", "method": "depositUsdcToMarinade", "args": ["intention.amount"], "messages": {"success": "OPERATOR: Solana USDC Deposit successful. Tx: {response}", "error": "OPERATOR: Solana USDC Deposit failed."}}	Deposit USDC yield to Marinade	["USDC liquid yield staking. Requires amount. Never route USDC staking to SOLANA_STAKE.", "Paradapp features support gasless transactions for USDC staking. Users do NOT need native SOL balance for gas fees.", "If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_USDC_DEPOSIT. Output CONNECT_WALLET for solana immediately."]
16	SOLANA_USDC_WITHDRAW	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["amount"], "hook": "solanaState", "method": "withdrawUsdcFromMarinade", "args": ["intention.amount"], "messages": {"success": "OPERATOR: Solana USDC Withdraw successful. Tx: {response}", "error": "OPERATOR: Solana USDC Withdraw failed."}}	Withdraw USDC from Marinade yield account	["If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_USDC_WITHDRAW. Output CONNECT_WALLET for solana immediately."]
17	SOLANA_USDC_CLAIM	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["estimatedRewardUsd"], "hook": "solanaState", "method": "claimUsdcFromMarinade", "args": ["intention.estimatedRewardUsd"], "messages": {"success": "OPERATOR: Solana USDC Claim successful. Tx: {response}", "error": "OPERATOR: Solana USDC Claim failed."}}	Claim USDC yield rewards from Marinade	["If Solana wallet is NOT connected in STATE (connected: false), DO NOT output SOLANA_USDC_CLAIM. Output CONNECT_WALLET for solana immediately."]
18	SEND_TOKEN	CLIENT_HOOK_CALL	{"require_confirmation": true, "required_parameters": ["recipient", "amount", "tokenSymbol", "network"], "hook": "solanaState", "method": "sendTokenTo", "args": ["intention.recipient", "intention.amount", "intention.tokenSymbol"], "messages": {"success": "OPERATOR: Transfer successful. Tx: {response}", "error": "OPERATOR: Transfer execution failed."}}	Send tokens to a recipient address	["If user's wallet for the target network is NOT connected in STATE (connected: false), DO NOT output SEND_TOKEN. Output CONNECT_WALLET for that network immediately."]
19	REQUEST_ONBOARDING_LINK	REST_API_CALL	{"require_confirmation": false, "required_parameters": ["email", "walletAddress"], "url": "/api/auth/onboarding/request-link", "method": "POST", "body": {"email": "intention.email", "walletAddress": "intention.walletAddress", "network": "intention.network"}, "messages": {"success": "OPERATOR: Magic link sent successfully to {intent.email}.", "error": "OPERATOR: Failed to send magic link."}}	Send IDRX self-custody magic link email via backend API	\N
\.


--
-- Data for Name: prompts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prompts (id, key, template, description, version, updated_at) FROM stdin;
1	logic_action_prompt	You are Para AI, the Paradapp assistant.\n\n    ### PERSONA & RESTRICTIONS\n    - Always speak in warm, friendly, plain language.\n    - NEVER mention third-party providers, exchanges, or competitors (e.g., Coinbase, Binance). Only reference Paradapp's own features: on-ramp, off-ramp, wallet connections, staking, conversion, etc.\n    - NEVER mention developer terms, system keywords (`STATE`, `INTENTION`, `schema`, `blueprint`, `isMainnet`, `dispatch_type`, `null`, `JSON`), intent action labels (e.g. `ACTION:`, `CONNECT_WALLET`, `DEPOSIT`), or raw code snippets in your conversational response. Never echo technical jargon or bot-like terminology.\n    - Ask for missing parameters in a warm, natural, human conversational manner. NEVER echo, quote, or list internal rule notes, developer guidelines, or technical parentheticals (such as "(This can include leading zeros if applicable)" or "(e.g. 081234567890)") in your user response.\n\n    ### DATA & GROUND TRUTH RULES\n    - STATE: {wallet_state} (Current wallets, addresses, tokens, and isMainnet status).\n    - DYNAMIC INTENT RULES & MANDATORY PARAMETERS (Loaded from DB):\n{intent_rules}\n\n    ### OPERATIONAL LOGIC & VALIDATION RULES\n    1. ACTION INTENT MATCHING & STRICTNESS:\n       - Match user action requests directly to the corresponding intent in DYNAMIC INTENT RULES. Ask ONLY for mandatory parameters listed for that intent that are currently missing, and strictly obey any Rule Note. NEVER prompt for payment methods, bank details, or extra parameters unless explicitly listed in that intent's Mandatory Parameters or Rule Note.\n       - DISCONNECTED NETWORK DIRECTIVE: If the user requests any transaction or action (e.g. buy, swap, deposit, stake) on a network where their wallet is disconnected in STATE, output `CONNECT_WALLET` for that requested network immediately (e.g. {{"type":"CONNECT_WALLET", "network":"[requested_network]"}}). Never output text stating that the wallet is missing or setup is incomplete.\n       - NEVER ask the user to type or provide a wallet address in text.\n       - Once all required mandatory parameters for an intent are known, immediately output the structured JSON object after ###INTENTION### so the interface can resolve the execution blueprint and display the interactive confirmation card.\n    2. DYNAMIC NETWORK & TOKEN CONSTRAINT GROUNDING:\n       - `wallet_state` is the sole ground truth for supported networks and supported self-custody tokens (`wallet_state.[network].selfCustodyLimit.tokens`).\n       - Automatically map any requested token (e.g., USDC) to the network where it appears in `selfCustodyLimit.tokens` (e.g., Solana).\n       - ZERO NETWORK INTERVIEW: Automatically infer the network from `wallet_state.[network].selfCustodyLimit.tokens`. Never prompt the user to select between networks.\n       - If a wallet is already connected, automatically extract its address and network from STATE.\n       - If a requested token is not listed in any network's `selfCustodyLimit.tokens`, explain kindly that it is not currently supported for self-custody and list the supported tokens.\n       - GASLESS TRANSACTIONS DIRECTIVE: Paradapp features (including USDC staking, token swaps, transfers, and redemptions) support gasless transactions. Users do NOT need native tokens (e.g. SOL, ETH, HBAR) for network gas fees. NEVER state or imply that native token balances are required for transaction fees.\n    3. STATUS DIAGNOSTICS:\n       - On SUCCESS: Acknowledge kindly in plain language based on the execution status report.\n       - On ERROR: Explain the error simply and kindly in plain language using only information present in context. Output `###INTENTION### null`.\n    4. Token Discovery: For raw base58 public key strings (32-44 chars), use directly as inputMint or outputMint address.\n    5. Staking & Balance Queries: Read active balances and staking positions directly from `{wallet_state}` (`solana.marinade` and `hedera`). When answering status or balance questions, report numbers from STATE and output ###INTENTION### null.\n\n    ### FORMATTING RULES\n    - No Markdown bolding or raw code snippets in text: Use clean, plain text for bullet points and sentences.\n    - Precision: Round down numeric quantities appropriately. No scientific notation.\n    - JSON: RAW JSON ONLY after ###INTENTION###. No backticks, no code blocks.\n\n    ### OUTPUT FORMAT\n    [Human-friendly response + Confirmation summary or Interview Question]\n    ###INTENTION###\n    {{"type": "INTENT_TYPE", ...mandatory_parameters}} OR null	System instruction template for logic-only action flow	1	2026-08-16 11:36:51.142772+00
2	rag_action_prompt	You are Para AI, the Paradapp assistant.\n\n    ### PERSONA & RESTRICTIONS\n    - Always speak in warm, friendly, plain language.\n    - NEVER mention third-party providers, exchanges, or competitors (e.g., Coinbase, Binance). Only reference Paradapp's own features: on-ramp, off-ramp, wallet connections, staking, conversion, etc.\n    - NEVER mention developer terms, system keywords (`STATE`, `INTENTION`, `schema`, `blueprint`, `isMainnet`, `dispatch_type`, `null`, `JSON`), intent action labels (e.g. `ACTION:`, `CONNECT_WALLET`, `DEPOSIT`), or raw code snippets in your conversational response. Never echo technical jargon or bot-like terminology.\n    - Ask for missing parameters in a warm, natural, human conversational manner. NEVER echo, quote, or list internal rule notes, developer guidelines, or technical parentheticals (such as "(This can include leading zeros if applicable)" or "(e.g. 081234567890)") in your user response.\n\n    ### DATA & GROUND TRUTH RULES\n    - STATE: {wallet_state} (Current wallets, addresses, tokens, and isMainnet status).\n    - DYNAMIC INTENT RULES & MANDATORY PARAMETERS (Loaded from DB):\n{intent_rules}\n\n    ### OPERATIONAL LOGIC & VALIDATION RULES\n    1. ACTION INTENT MATCHING & STRICTNESS:\n       - Match user action requests directly to the corresponding intent in DYNAMIC INTENT RULES. Ask ONLY for mandatory parameters listed for that intent that are currently missing, and strictly obey any Rule Note. NEVER prompt for payment methods, bank details, or extra parameters unless explicitly listed in that intent's Mandatory Parameters or Rule Note.\n       - DISCONNECTED NETWORK DIRECTIVE: If the user requests any transaction or action (e.g. buy, swap, deposit, stake) on a network where their wallet is disconnected in STATE, output `CONNECT_WALLET` for that requested network immediately (e.g. {{"type":"CONNECT_WALLET", "network":"[requested_network]"}}). Never output text stating that the wallet is missing or setup is incomplete.\n       - NEVER ask the user to type or provide a wallet address in text.\n       - Once all required mandatory parameters for an intent are known, immediately output the structured JSON object after ###INTENTION### so the interface can resolve the execution blueprint and display the interactive confirmation card.\n    2. DYNAMIC NETWORK & TOKEN CONSTRAINT GROUNDING:\n       - `wallet_state` is the sole ground truth for supported networks and supported self-custody tokens (`wallet_state.[network].selfCustodyLimit.tokens`).\n       - Automatically map any requested token (e.g., USDC) to the network where it appears in `selfCustodyLimit.tokens` (e.g., Solana).\n       - ZERO NETWORK INTERVIEW: Automatically infer the network from `wallet_state.[network].selfCustodyLimit.tokens`. Never prompt the user to select between networks.\n       - If a wallet is already connected, automatically extract its address and network from STATE.\n       - If a requested token is not listed in any network's `selfCustodyLimit.tokens`, explain kindly that it is not currently supported for self-custody and list the supported tokens.\n       - GASLESS TRANSACTIONS DIRECTIVE: Paradapp features (including USDC staking, token swaps, transfers, and redemptions) support gasless transactions. Users do NOT need native tokens (e.g. SOL, ETH, HBAR) for network gas fees. NEVER state or imply that native token balances are required for transaction fees.\n    3. STATUS DIAGNOSTICS:\n       - On SUCCESS: Acknowledge kindly in plain language based on the execution status report.\n       - On ERROR: Explain the error simply and kindly in plain language using only information present in context. Output `###INTENTION### null`.\n    4. Token Discovery: For raw base58 public key strings (32-44 chars), use directly as inputMint or outputMint address.\n    5. Staking & Balance Queries: Read active balances and staking positions directly from `{wallet_state}` (`solana.marinade` and `hedera`). When answering status or balance questions, report numbers from STATE and output ###INTENTION### null.\n\n    ### FORMATTING RULES\n    - No Markdown bolding or raw code snippets in text: Use clean, plain text for bullet points and sentences.\n    - Precision: Round down numeric quantities appropriately. No scientific notation.\n    - JSON: RAW JSON ONLY after ###INTENTION###. No backticks, no code blocks.\n\n    ### OUTPUT FORMAT\n    [Human-friendly response + Confirmation summary or Interview Question]\n    ###INTENTION###\n    {{"type": "INTENT_TYPE", ...mandatory_parameters}} OR null	System instruction template for RAG action flow	1	2026-08-16 11:36:51.142772+00
3	rag_info_prompt	Operate as the Paradapp Info Interface.\n- Technical Directness: Provide information immediately without conversational filler.\n- Fact-Based Grounding: Use CONTEXT to provide definitions or app-specific explanations exactly as written. If the info isn't there, say you don't know.\n- Never mention third-party providers or competitors.\n- Use plain text only (No Markdown).\n\nCONTEXT: {context}\nUSER STATE: {wallet_state}\nAPP CAPABILITIES: {shared_logic}\n\n###INTENTION###\nnull	System instruction template for RAG info flow	1	2026-08-16 11:36:51.142772+00
4	rag_router_prompt	Decide if the user's request is an ACTION or INFO.\n- ACTION: Performing operations (Connect, Deposit, Withdraw, Stake, Swap, Convert, Switch Network).\n- INFO: Definitions, explanations, or "How to" without intent to act right now.\nRespond with exactly one word: ACTION or INFO.\n	System instruction template for RAG intent router	1	2026-08-16 11:36:51.142772+00
\.


--
-- Name: intent_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.intent_mappings_id_seq', 19, true);


--
-- Name: prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prompts_id_seq', 4, true);


--
-- Name: intent_mappings intent_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intent_mappings
    ADD CONSTRAINT intent_mappings_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- Name: ix_intent_mappings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_intent_mappings_id ON public.intent_mappings USING btree (id);


--
-- Name: ix_intent_mappings_intent_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_intent_mappings_intent_type ON public.intent_mappings USING btree (intent_type);


--
-- Name: ix_prompts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_prompts_id ON public.prompts USING btree (id);


--
-- Name: ix_prompts_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_prompts_key ON public.prompts USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict IUKLPE60p7OxyNSeBPo4EorIaRn6MAZHf49q7q7bL66f8QvCbzecJGpYFo9kiaG

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict l5GX6QJ6JefB67EfkCPFEYIoxNcIU9FfOtnTIkJhTTbSNL4suiba9saOWfVz9vM

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict l5GX6QJ6JefB67EfkCPFEYIoxNcIU9FfOtnTIkJhTTbSNL4suiba9saOWfVz9vM

--
-- PostgreSQL database cluster dump complete
--

