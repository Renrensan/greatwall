--
-- PostgreSQL database cluster dump
--

\restrict JDh7iwbPealaObTrAfSVY0MrFXCbb6LiRrBQzGCiY53JS0zFgM94dchmmhGTn1y

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE paradapp_user;
ALTER ROLE paradapp_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:HWOD6sq9o9NLfB/ykJ+EeA==$/L2esGTQ/DOJiMYZBSSrlcCH5oF+Ms5SEZRUUjoYRSY=:JuqecWL8+Ox0Um2joHrIAIOvouqyF+RSCO829nBLVGE=';

--
-- User Configurations
--








\unrestrict JDh7iwbPealaObTrAfSVY0MrFXCbb6LiRrBQzGCiY53JS0zFgM94dchmmhGTn1y

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict KsiOM9Xy2z2rfGRyzhzq1k7cpzPcsdMrWINdDe55TYLIVexAMyi5DxGstbrtChl

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict KsiOM9Xy2z2rfGRyzhzq1k7cpzPcsdMrWINdDe55TYLIVexAMyi5DxGstbrtChl

--
-- Database "paradapp_v3" dump
--

--
-- PostgreSQL database dump
--

\restrict EIKGUJGgmyIKEmidYcAdukQxUHZdJ9uhhIxCFley7LrNArRghShANXZwBVWa6Y6

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: paradapp_v3; Type: DATABASE; Schema: -; Owner: paradapp_user
--

CREATE DATABASE paradapp_v3 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE paradapp_v3 OWNER TO paradapp_user;

\unrestrict EIKGUJGgmyIKEmidYcAdukQxUHZdJ9uhhIxCFley7LrNArRghShANXZwBVWa6Y6
\connect paradapp_v3
\restrict EIKGUJGgmyIKEmidYcAdukQxUHZdJ9uhhIxCFley7LrNArRghShANXZwBVWa6Y6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: evolution; Type: SCHEMA; Schema: -; Owner: paradapp_user
--

CREATE SCHEMA evolution;


ALTER SCHEMA evolution OWNER TO paradapp_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: DeviceMessage; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."DeviceMessage" AS ENUM (
    'ios',
    'android',
    'web',
    'unknown',
    'desktop'
);


ALTER TYPE evolution."DeviceMessage" OWNER TO paradapp_user;

--
-- Name: DifyBotType; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."DifyBotType" AS ENUM (
    'chatBot',
    'textGenerator',
    'agent',
    'workflow'
);


ALTER TYPE evolution."DifyBotType" OWNER TO paradapp_user;

--
-- Name: InstanceConnectionStatus; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."InstanceConnectionStatus" AS ENUM (
    'open',
    'close',
    'connecting'
);


ALTER TYPE evolution."InstanceConnectionStatus" OWNER TO paradapp_user;

--
-- Name: OpenaiBotType; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."OpenaiBotType" AS ENUM (
    'assistant',
    'chatCompletion'
);


ALTER TYPE evolution."OpenaiBotType" OWNER TO paradapp_user;

--
-- Name: SessionStatus; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."SessionStatus" AS ENUM (
    'opened',
    'closed',
    'paused'
);


ALTER TYPE evolution."SessionStatus" OWNER TO paradapp_user;

--
-- Name: TriggerOperator; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."TriggerOperator" AS ENUM (
    'contains',
    'equals',
    'startsWith',
    'endsWith',
    'regex'
);


ALTER TYPE evolution."TriggerOperator" OWNER TO paradapp_user;

--
-- Name: TriggerType; Type: TYPE; Schema: evolution; Owner: paradapp_user
--

CREATE TYPE evolution."TriggerType" AS ENUM (
    'all',
    'keyword',
    'none',
    'advanced'
);


ALTER TYPE evolution."TriggerType" OWNER TO paradapp_user;

--
-- Name: NetworkEnv; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public."NetworkEnv" AS ENUM (
    'MAINNET',
    'TESTNET'
);


ALTER TYPE public."NetworkEnv" OWNER TO paradapp_user;

--
-- Name: NetworkType; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public."NetworkType" AS ENUM (
    'BITCOIN',
    'HEDERA',
    'ETHEREUM',
    'SOLANA',
    'POLKADOT'
);


ALTER TYPE public."NetworkType" OWNER TO paradapp_user;

--
-- Name: TokenType; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public."TokenType" AS ENUM (
    'BTC',
    'HBAR',
    'ETH',
    'SOL',
    'USDC',
    'DOT'
);


ALTER TYPE public."TokenType" OWNER TO paradapp_user;

--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'WAITING',
    'PENDING',
    'PAID',
    'COMPLETED',
    'FAILED',
    'EXPIRED'
);


ALTER TYPE public."TransactionStatus" OWNER TO paradapp_user;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public."TransactionType" AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL'
);


ALTER TYPE public."TransactionType" OWNER TO paradapp_user;

--
-- Name: task_status; Type: TYPE; Schema: public; Owner: paradapp_user
--

CREATE TYPE public.task_status AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public.task_status OWNER TO paradapp_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: paradapp_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO paradapp_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Chat; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Chat" (
    id text NOT NULL,
    "remoteJid" character varying(100) NOT NULL,
    labels jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone,
    "instanceId" text NOT NULL,
    name character varying(100),
    "unreadMessages" integer DEFAULT 0 NOT NULL
);


ALTER TABLE evolution."Chat" OWNER TO paradapp_user;

--
-- Name: Chatwoot; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Chatwoot" (
    id text NOT NULL,
    enabled boolean DEFAULT true,
    "accountId" character varying(100),
    token character varying(100),
    url character varying(500),
    "nameInbox" character varying(100),
    "signMsg" boolean DEFAULT false,
    "signDelimiter" character varying(100),
    number character varying(100),
    "reopenConversation" boolean DEFAULT false,
    "conversationPending" boolean DEFAULT false,
    "mergeBrazilContacts" boolean DEFAULT false,
    "importContacts" boolean DEFAULT false,
    "importMessages" boolean DEFAULT false,
    "daysLimitImportMessages" integer,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    logo character varying(500),
    organization character varying(100),
    "ignoreJids" jsonb
);


ALTER TABLE evolution."Chatwoot" OWNER TO paradapp_user;

--
-- Name: Contact; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Contact" (
    id text NOT NULL,
    "remoteJid" character varying(100) NOT NULL,
    "pushName" character varying(100),
    "profilePicUrl" character varying(500),
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Contact" OWNER TO paradapp_user;

--
-- Name: Dify; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Dify" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "botType" evolution."DifyBotType" NOT NULL,
    "apiUrl" character varying(255),
    "apiKey" character varying(255),
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    description character varying(255),
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."Dify" OWNER TO paradapp_user;

--
-- Name: DifySetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."DifySetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "difyIdFallback" character varying(100),
    "instanceId" text NOT NULL,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."DifySetting" OWNER TO paradapp_user;

--
-- Name: Evoai; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Evoai" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    description character varying(255),
    "agentUrl" character varying(255),
    "apiKey" character varying(255),
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Evoai" OWNER TO paradapp_user;

--
-- Name: EvoaiSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."EvoaiSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "evoaiIdFallback" character varying(100),
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."EvoaiSetting" OWNER TO paradapp_user;

--
-- Name: EvolutionBot; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."EvolutionBot" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    description character varying(255),
    "apiUrl" character varying(255),
    "apiKey" character varying(255),
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."EvolutionBot" OWNER TO paradapp_user;

--
-- Name: EvolutionBotSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."EvolutionBotSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "botIdFallback" character varying(100),
    "instanceId" text NOT NULL,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."EvolutionBotSetting" OWNER TO paradapp_user;

--
-- Name: Flowise; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Flowise" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    description character varying(255),
    "apiUrl" character varying(255),
    "apiKey" character varying(255),
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."Flowise" OWNER TO paradapp_user;

--
-- Name: FlowiseSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."FlowiseSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "flowiseIdFallback" character varying(100),
    "instanceId" text NOT NULL,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."FlowiseSetting" OWNER TO paradapp_user;

--
-- Name: Instance; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Instance" (
    id text NOT NULL,
    name character varying(255) NOT NULL,
    "connectionStatus" evolution."InstanceConnectionStatus" DEFAULT 'open'::evolution."InstanceConnectionStatus" NOT NULL,
    "ownerJid" character varying(100),
    "profilePicUrl" character varying(500),
    integration character varying(100),
    number character varying(100),
    token character varying(255),
    "clientName" character varying(100),
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone,
    "profileName" character varying(100),
    "businessId" character varying(100),
    "disconnectionAt" timestamp without time zone,
    "disconnectionObject" jsonb,
    "disconnectionReasonCode" integer
);


ALTER TABLE evolution."Instance" OWNER TO paradapp_user;

--
-- Name: IntegrationSession; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."IntegrationSession" (
    id text NOT NULL,
    "sessionId" character varying(255) NOT NULL,
    "remoteJid" character varying(100) NOT NULL,
    "pushName" text,
    status evolution."SessionStatus" NOT NULL,
    "awaitUser" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    parameters jsonb,
    context jsonb,
    "botId" text,
    type character varying(100)
);


ALTER TABLE evolution."IntegrationSession" OWNER TO paradapp_user;

--
-- Name: IsOnWhatsapp; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."IsOnWhatsapp" (
    id text NOT NULL,
    "remoteJid" character varying(100) NOT NULL,
    "jidOptions" text NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone NOT NULL,
    lid character varying(100)
);


ALTER TABLE evolution."IsOnWhatsapp" OWNER TO paradapp_user;

--
-- Name: Kafka; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Kafka" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Kafka" OWNER TO paradapp_user;

--
-- Name: Label; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Label" (
    id text NOT NULL,
    "labelId" character varying(100),
    name character varying(100) NOT NULL,
    color character varying(100) NOT NULL,
    "predefinedId" character varying(100),
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Label" OWNER TO paradapp_user;

--
-- Name: Media; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Media" (
    id text NOT NULL,
    "fileName" character varying(500) NOT NULL,
    type character varying(100) NOT NULL,
    mimetype character varying(100) NOT NULL,
    "createdAt" date DEFAULT CURRENT_TIMESTAMP,
    "messageId" text NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Media" OWNER TO paradapp_user;

--
-- Name: Message; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Message" (
    id text NOT NULL,
    key jsonb NOT NULL,
    "pushName" character varying(100),
    participant character varying(100),
    "messageType" character varying(100) NOT NULL,
    message jsonb NOT NULL,
    "contextInfo" jsonb,
    source evolution."DeviceMessage" NOT NULL,
    "messageTimestamp" integer NOT NULL,
    "chatwootMessageId" integer,
    "chatwootInboxId" integer,
    "chatwootConversationId" integer,
    "chatwootContactInboxSourceId" character varying(100),
    "chatwootIsRead" boolean,
    "instanceId" text NOT NULL,
    "webhookUrl" character varying(500),
    "sessionId" text,
    status character varying(30)
);


ALTER TABLE evolution."Message" OWNER TO paradapp_user;

--
-- Name: MessageUpdate; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."MessageUpdate" (
    id text NOT NULL,
    "keyId" character varying(100) NOT NULL,
    "remoteJid" character varying(100) NOT NULL,
    "fromMe" boolean NOT NULL,
    participant character varying(100),
    "pollUpdates" jsonb,
    status character varying(30) NOT NULL,
    "messageId" text NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."MessageUpdate" OWNER TO paradapp_user;

--
-- Name: N8n; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."N8n" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    description character varying(255),
    "webhookUrl" character varying(255),
    "basicAuthUser" character varying(255),
    "basicAuthPass" character varying(255),
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."N8n" OWNER TO paradapp_user;

--
-- Name: N8nSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."N8nSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "n8nIdFallback" character varying(100),
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."N8nSetting" OWNER TO paradapp_user;

--
-- Name: Nats; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Nats" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Nats" OWNER TO paradapp_user;

--
-- Name: OpenaiBot; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."OpenaiBot" (
    id text NOT NULL,
    "assistantId" character varying(255),
    model character varying(100),
    "systemMessages" jsonb,
    "assistantMessages" jsonb,
    "userMessages" jsonb,
    "maxTokens" integer,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "openaiCredsId" text NOT NULL,
    "instanceId" text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "botType" evolution."OpenaiBotType" NOT NULL,
    description character varying(255),
    "functionUrl" character varying(500),
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."OpenaiBot" OWNER TO paradapp_user;

--
-- Name: OpenaiCreds; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."OpenaiCreds" (
    id text NOT NULL,
    "apiKey" character varying(255),
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    name character varying(255)
);


ALTER TABLE evolution."OpenaiCreds" OWNER TO paradapp_user;

--
-- Name: OpenaiSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."OpenaiSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "openaiCredsId" text NOT NULL,
    "openaiIdFallback" character varying(100),
    "instanceId" text NOT NULL,
    "speechToText" boolean DEFAULT false,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."OpenaiSetting" OWNER TO paradapp_user;

--
-- Name: Proxy; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Proxy" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    host character varying(100) NOT NULL,
    port character varying(100) NOT NULL,
    protocol character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Proxy" OWNER TO paradapp_user;

--
-- Name: Pusher; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Pusher" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "appId" character varying(100) NOT NULL,
    key character varying(100) NOT NULL,
    secret character varying(100) NOT NULL,
    cluster character varying(100) NOT NULL,
    "useTLS" boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Pusher" OWNER TO paradapp_user;

--
-- Name: Rabbitmq; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Rabbitmq" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Rabbitmq" OWNER TO paradapp_user;

--
-- Name: Session; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Session" (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    creds text,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE evolution."Session" OWNER TO paradapp_user;

--
-- Name: Setting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Setting" (
    id text NOT NULL,
    "rejectCall" boolean DEFAULT false NOT NULL,
    "msgCall" character varying(100),
    "groupsIgnore" boolean DEFAULT false NOT NULL,
    "alwaysOnline" boolean DEFAULT false NOT NULL,
    "readMessages" boolean DEFAULT false NOT NULL,
    "readStatus" boolean DEFAULT false NOT NULL,
    "syncFullHistory" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    "wavoipToken" character varying(100)
);


ALTER TABLE evolution."Setting" OWNER TO paradapp_user;

--
-- Name: Sqs; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Sqs" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Sqs" OWNER TO paradapp_user;

--
-- Name: Template; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Template" (
    id text NOT NULL,
    "templateId" character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    template jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    "webhookUrl" character varying(500)
);


ALTER TABLE evolution."Template" OWNER TO paradapp_user;

--
-- Name: Typebot; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Typebot" (
    id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    url character varying(500) NOT NULL,
    typebot character varying(100) NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone,
    "triggerType" evolution."TriggerType",
    "triggerOperator" evolution."TriggerOperator",
    "triggerValue" text,
    "instanceId" text NOT NULL,
    "debounceTime" integer,
    "ignoreJids" jsonb,
    description character varying(255),
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."Typebot" OWNER TO paradapp_user;

--
-- Name: TypebotSetting; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."TypebotSetting" (
    id text NOT NULL,
    expire integer DEFAULT 0,
    "keywordFinish" character varying(100),
    "delayMessage" integer,
    "unknownMessage" character varying(100),
    "listeningFromMe" boolean DEFAULT false,
    "stopBotFromMe" boolean DEFAULT false,
    "keepOpen" boolean DEFAULT false,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    "debounceTime" integer,
    "typebotIdFallback" character varying(100),
    "ignoreJids" jsonb,
    "splitMessages" boolean DEFAULT false,
    "timePerChar" integer DEFAULT 50
);


ALTER TABLE evolution."TypebotSetting" OWNER TO paradapp_user;

--
-- Name: Webhook; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Webhook" (
    id text NOT NULL,
    url character varying(500) NOT NULL,
    enabled boolean DEFAULT true,
    events jsonb,
    "webhookByEvents" boolean DEFAULT false,
    "webhookBase64" boolean DEFAULT false,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL,
    headers jsonb
);


ALTER TABLE evolution."Webhook" OWNER TO paradapp_user;

--
-- Name: Websocket; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution."Websocket" (
    id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    events jsonb NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone NOT NULL,
    "instanceId" text NOT NULL
);


ALTER TABLE evolution."Websocket" OWNER TO paradapp_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: evolution; Owner: paradapp_user
--

CREATE TABLE evolution._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE evolution._prisma_migrations OWNER TO paradapp_user;

--
-- Name: Dapp; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."Dapp" (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    url text NOT NULL,
    "logoPath" text,
    "favoriteCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    network public."NetworkType" NOT NULL,
    description_idn text
);


ALTER TABLE public."Dapp" OWNER TO paradapp_user;

--
-- Name: DappFeature; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."DappFeature" (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "dappId" integer NOT NULL,
    description_idn text,
    title_idn text
);


ALTER TABLE public."DappFeature" OWNER TO paradapp_user;

--
-- Name: DappFeature_id_seq; Type: SEQUENCE; Schema: public; Owner: paradapp_user
--

CREATE SEQUENCE public."DappFeature_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DappFeature_id_seq" OWNER TO paradapp_user;

--
-- Name: DappFeature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: paradapp_user
--

ALTER SEQUENCE public."DappFeature_id_seq" OWNED BY public."DappFeature".id;


--
-- Name: DappSection; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."DappSection" (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "dappId" integer NOT NULL,
    description_idn text,
    title_idn text
);


ALTER TABLE public."DappSection" OWNER TO paradapp_user;

--
-- Name: DappSection_id_seq; Type: SEQUENCE; Schema: public; Owner: paradapp_user
--

CREATE SEQUENCE public."DappSection_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DappSection_id_seq" OWNER TO paradapp_user;

--
-- Name: DappSection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: paradapp_user
--

ALTER SEQUENCE public."DappSection_id_seq" OWNED BY public."DappSection".id;


--
-- Name: Dapp_id_seq; Type: SEQUENCE; Schema: public; Owner: paradapp_user
--

CREATE SEQUENCE public."Dapp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Dapp_id_seq" OWNER TO paradapp_user;

--
-- Name: Dapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: paradapp_user
--

ALTER SEQUENCE public."Dapp_id_seq" OWNED BY public."Dapp".id;


--
-- Name: IdrxAccount; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."IdrxAccount" (
    "walletAddress" text NOT NULL,
    "idrxApiKey" text NOT NULL,
    "idrxApiSecret" text NOT NULL,
    "kycOnboardingAddress" text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    email text,
    "idrxEmail" text
);


ALTER TABLE public."IdrxAccount" OWNER TO paradapp_user;

--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."Transaction" (
    id text NOT NULL,
    type public."TransactionType" NOT NULL,
    status public."TransactionStatus" DEFAULT 'WAITING'::public."TransactionStatus" NOT NULL,
    "tokenAmount" double precision,
    "tokenType" public."TokenType" NOT NULL,
    "idrAmount" integer,
    "walletAddress" text NOT NULL,
    "paymentDetails" jsonb,
    "txHash" text,
    "cexTxId" text,
    "refAddress" text,
    "refAmount" double precision,
    "xenditTxId" text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "networkEnv" public."NetworkEnv" DEFAULT 'TESTNET'::public."NetworkEnv" NOT NULL,
    network public."NetworkType" NOT NULL,
    "refTxHash" text
);


ALTER TABLE public."Transaction" OWNER TO paradapp_user;

--
-- Name: UserFavoriteDapp; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public."UserFavoriteDapp" (
    id text NOT NULL,
    "userAddress" text NOT NULL,
    "dappId" integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    network public."NetworkType" NOT NULL
);


ALTER TABLE public."UserFavoriteDapp" OWNER TO paradapp_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO paradapp_user;

--
-- Name: _sqlx_migrations; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public._sqlx_migrations (
    version bigint NOT NULL,
    description text NOT NULL,
    installed_on timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    checksum bytea NOT NULL,
    execution_time bigint NOT NULL
);


ALTER TABLE public._sqlx_migrations OWNER TO paradapp_user;

--
-- Name: admin_audit_logs; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public.admin_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid,
    admin_username character varying(100) NOT NULL,
    action character varying(100) NOT NULL,
    target_table character varying(100) NOT NULL,
    target_id text,
    details jsonb,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_logs OWNER TO paradapp_user;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public.admin_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) DEFAULT 'ADMIN'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL
);


ALTER TABLE public.admin_users OWNER TO paradapp_user;

--
-- Name: marketing_tasks; Type: TABLE; Schema: public; Owner: paradapp_user
--

CREATE TABLE public.marketing_tasks (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone_number character varying(50) NOT NULL,
    task_type character varying(100) NOT NULL,
    payload jsonb,
    status public.task_status DEFAULT 'PENDING'::public.task_status,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.marketing_tasks OWNER TO paradapp_user;

--
-- Name: marketing_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: paradapp_user
--

CREATE SEQUENCE public.marketing_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_tasks_id_seq OWNER TO paradapp_user;

--
-- Name: marketing_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: paradapp_user
--

ALTER SEQUENCE public.marketing_tasks_id_seq OWNED BY public.marketing_tasks.id;


--
-- Name: Dapp id; Type: DEFAULT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."Dapp" ALTER COLUMN id SET DEFAULT nextval('public."Dapp_id_seq"'::regclass);


--
-- Name: DappFeature id; Type: DEFAULT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappFeature" ALTER COLUMN id SET DEFAULT nextval('public."DappFeature_id_seq"'::regclass);


--
-- Name: DappSection id; Type: DEFAULT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappSection" ALTER COLUMN id SET DEFAULT nextval('public."DappSection_id_seq"'::regclass);


--
-- Name: marketing_tasks id; Type: DEFAULT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.marketing_tasks ALTER COLUMN id SET DEFAULT nextval('public.marketing_tasks_id_seq'::regclass);


--
-- Data for Name: Chat; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Chat" (id, "remoteJid", labels, "createdAt", "updatedAt", "instanceId", name, "unreadMessages") FROM stdin;
cmqnw42so0004r54dff5y177d	120363420394299704@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	Paradapp Early Adopters	0
cmqnw42so0005r54d572p75sx	65842469404740@lid	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0008r54dz61sxr90	0@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	WhatsApp Business	0
cmqnw42so0009r54dfkfzlbat	120363402874234431@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	Paradapp Community	0
cmqnw42so000ar54dcdg6h8ip	120363417652295399@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	Discussion Chat	0
cmqnw42so000br54doxkdnl74	276183644156050@lid	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000cr54dzn521235	62881082489258@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000dr54d40b38xci	6281353058012@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000er54d5h6rzoja	62895392547878@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000fr54d1jeev5v6	6287860202653@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000gr54dmapyptct	135308700041380@lid	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000hr54d1h34lg39	6281330891491@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000ir54d7xsrag6a	6281139900078@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000jr54d3d63nx8a	6281239300841@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000kr54d21x2m6li	6281330802401@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000lr54dm2020yph	120363404501280283@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	75	0
cmqnw42so000mr54dt1a0n8mq	6282247973243@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000nr54dvnldj9xz	6281337010229@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000or54dpc27ha3b	628170993101@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000pr54djl3j2ce1	989333710574@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000qr54du7eahh2x	6281236441453@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000rr54d3kve1o3e	6289654812465@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000sr54d2bef1p96	6282124022467@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000tr54drt5uyz9b	6281252056202@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000ur54diwxdkqkf	6285896198131@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000vr54d7pposknt	6287778109407@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000wr54doipgr1f7	6281543435569@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000xr54du61devxq	6282256042756@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000yr54dto9yudef	6281378112072@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so000zr54d87exwyq4	6282117576141@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0010r54dnuyhq42d	6281357842119@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0011r54dccpa2ge1	6285156650954@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0012r54dfd2470pr	6285156821368@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0013r54dxal8ja7y	628121600427@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0014r54dx0m8x4r8	639814270008@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0015r54dg7ldi4iw	6285737622874@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0016r54dysuncmu9	6287866104495@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0017r54daazkoif8	6281334695040@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42so0018r54dstcrivub	6281284063078@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0019r54dj4ma3nz2	6281230447026@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001ar54d2fthsbj5	6289681301850@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001br54dj75n8s62	6287832983514@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001cr54dipuds7ds	639814270009@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001dr54di9c2fetl	6281299696081@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001er54doxr2x8ix	6285101800800@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001fr54drsv886bi	6285311781853@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001gr54drif4ep27	6285559660233@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001hr54d0o0wnbzj	6281938801986@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001ir54d3zgb81sm	447453685550@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001jr54dl1t2on7b	6289644678127@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001kr54daxkp6cuf	6285606199717@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001lr54di7i8yvyz	6289643439687@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001mr54dlgmc0fjf	6281215419170@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001nr54ds9xyfmxy	6289659221770@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001or54d4tq8kq8y	6287818159392@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001pr54dmhkfd3ox	6285737437138@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001qr54dov4fx3sj	6282247107601@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001rr54dj6mqusaz	62817344649@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001sr54dvo661wqx	6281339093759@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001tr54dns4wcmex	6281818888044@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001ur54d1v7rngvs	6281353168585@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001vr54dbjswxnaw	120363422199972335@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	BitVault Bitcoin Class #1	0
cmqnw42sp001wr54dvvpha4vh	6285211181735@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001xr54dfgm4a426	6281110001617@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001yr54dm3o8dgfa	6287766523711@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp001zr54dj9900w24	6285746543969@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0020r54dm5gjrapu	6281111111111@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0021r54dxpg0qk9h	6282341820260@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0022r54dsksjkvdl	6282331103769@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0023r54d7dfj4s8o	6281237300103@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0024r54dhgnfcx9s	6288975244189@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0025r54d8tlybdc3	120363307403775750@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	STELLAR STRATEGIES  EventRG3	0
cmqnw42sp0026r54di9c6bv9t	6281929753406@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0027r54d9buqqimc	6287782662961@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0028r54dsqaupl3o	6289636974140@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0029r54duiapfd18	628111014017@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002ar54d6xkusquy	628567762491@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002br54dgl3dk8le	6281392232573@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002cr54dgyupig6z	14153225608@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002dr54dqtvrn5di	6281119263967@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002er54d0215lzvt	6285733412244@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002fr54dj0xfiyvt	6282145549479@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002gr54dbnhhqx2t	6289669278407@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002hr54dm7w4xwwk	6282359051429@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002ir54d0jx6p9fl	6281239091224@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002jr54da5ffqpod	6285792494609@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002kr54dw8c35s9r	6285756040489@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002lr54due85ds7r	6285857847816@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002mr54dkrcsyv5n	6282123888232@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002nr54dok7mvfe6	6282112148261@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002or54dn4ifnb5r	6281907736598@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002pr54duud37x43	6285175081135@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002qr54dana20tcx	6285770338305@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002rr54d48zsgoaz	62895326481168@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002sr54drs4jo5mm	6287853847141@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002tr54dzzv59s3m	6281246973030@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002ur54d62gd38zf	120363129308373140@g.us	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	Onboarding Travybug	0
cmqnw42sp002vr54dz2ao5j7b	6287835166088@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002wr54do6wbkghj	6281353337222@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002xr54dcv98oc1g	6287858061838@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002yr54db1okzphr	6283857440668@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp002zr54d95lfp1nu	6282243373001@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0030r54d91yiumvy	6282216981643@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0031r54d5hu3wrco	6287762827988@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0032r54dk0v6pcvi	62895385843422@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0033r54dhu6xed0v	6281234371102@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0034r54djla3cznj	628563797179@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0035r54dar2atqtb	6282221239887@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0036r54dhm1q68a8	6282216138670@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0037r54dcoebud3f	6281210746201@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0038r54dgfvuklzb	6281398813853@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp0039r54d58jq62nk	6282369304046@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003ar54d1ah15v3o	6281315494095@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003br54dxlo582t8	62895333111213@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003cr54d68jhy6fz	6285746999067@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003dr54d4kh6iprw	6287772635356@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003er54dpo9huiaq	6281236876162@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003fr54d92t59wrp	62895333615211@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003gr54d74wvbt9x	6288210673430@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003hr54dujgbimc3	6282144862077@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003ir54dl6nmnolc	6289616699042@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003jr54dsywskvau	6283847825162@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw42sp003kr54d957gu9ao	6287855599444@s.whatsapp.net	\N	2026-06-21 14:36:50.856	2026-06-21 14:36:50.856	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00oor54d9uokm1rp	205157820317735@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00opr54dexd6nc5a	197929876869245@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00oqr54dp8rx3sp1	175707346993187@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00orr54dqrspj27y	259588494487735@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00osr54dxj87aism	256633187889303@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00otr54d2dmvx1v2	260546322555038@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00our54d7lz1qafe	274512935407627@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00ovr54dshcep5jo	214989084323891@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00owr54d0deuznvn	150040588865625@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00oxr54dweqcbq0k	138345191624801@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00oyr54dxvnbzj08	54262633619586@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00ozr54dy49wk6ta	238804694761520@lid	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmqnw5fdl00p0r54d1j5jtacp	120363402073736990@g.us	\N	2026-06-21 14:37:53.817	2026-06-21 14:37:53.817	23d8699a-16ab-4406-9e59-9c374964b83c	Paradapp Community	0
cmqnw42so0007r54dnnqat3uy	167929614229740@lid	\N	2026-06-21 14:36:50.856	2026-07-06 23:43:06.564	23d8699a-16ab-4406-9e59-9c374964b83c	Eka	1
cmqnw42so0006r54dtn9m44ni	113739474936038@lid	\N	2026-06-21 14:36:50.856	2026-08-08 21:01:47.123	23d8699a-16ab-4406-9e59-9c374964b83c	\N	0
cmr91gusv0148r54dwo4zrpai	120363409068752753@g.us	\N	2026-07-06 09:49:54.799	2026-07-06 11:44:15.616	23d8699a-16ab-4406-9e59-9c374964b83c	Testing	0
\.


--
-- Data for Name: Chatwoot; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Chatwoot" (id, enabled, "accountId", token, url, "nameInbox", "signMsg", "signDelimiter", number, "reopenConversation", "conversationPending", "mergeBrazilContacts", "importContacts", "importMessages", "daysLimitImportMessages", "createdAt", "updatedAt", "instanceId", logo, organization, "ignoreJids") FROM stdin;
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Contact" (id, "remoteJid", "pushName", "profilePicUrl", "createdAt", "updatedAt", "instanceId") FROM stdin;
cmqnw42v0006qr54d5ra3jezi	0@s.whatsapp.net	WhatsApp Business	\N	2026-06-21 14:36:50.94	2026-06-21 14:36:50.94	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6w006yr54dgwsy2l57	6282247973243@s.whatsapp.net		https://pps.whatsapp.net/v/t61.24694-24/723444758_2073323353264659_3616762052771042486_n.jpg?ccb=11-4&oh=01_Q5Aa5AGmQp4aGwuAf3LSQWoIFTcBUS24SSASf0EUhO4jyyHbAA&oe=6A589A8C&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-07-06 11:45:34.093	23d8699a-16ab-4406-9e59-9c374964b83c
cmqrjj11w00yir54df36hkpm5	88643997815017@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/727863880_1708665756952040_200703887199706923_n.jpg?ccb=11-4&oh=01_Q5Aa4wHx18vcbvyqMYtgsR9Z83GvwQPTPZK_zsBDfn_5htb4oA&oe=6A485994&_nc_sid=5e03e0&_nc_cat=109	2026-06-24 03:55:38.132	2026-06-24 03:55:38.132	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006tr54d6opagewy	120363404501280283@g.us	75	\N	2026-06-21 14:36:50.94	2026-06-21 14:37:50.961	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006ur54dg5o9tewl	120363422199972335@g.us	BitVault Bitcoin Class #1	https://pps.whatsapp.net/v/t61.24694-24/491877628_1062149071907856_7211460322119608030_n.jpg?ccb=11-4&oh=01_Q5Aa4wGT6tm_shXvK10Gc6z6_tEzpYT5xF_dLf2ZiHj7kNQ1Tw&oe=6A450AA9&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:36:50.94	2026-06-21 14:37:50.961	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006wr54d65mvlbxz	120363129308373140@g.us	Onboarding Travybug	\N	2026-06-21 14:36:50.94	2026-06-21 14:37:50.961	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006vr54dxw7qktrw	120363307403775750@g.us	STELLAR STRATEGIES  EventRG3	\N	2026-06-21 14:36:50.94	2026-06-21 14:37:50.961	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007rr54dl43sz484	6281236876162@s.whatsapp.net	Nando	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0070r54du9kergf6	6281999526413@s.whatsapp.net	LGraine Authentic Bakery	https://pps.whatsapp.net/v/t61.24694-24/312207296_180380214641442_183975467777558450_n.jpg?ccb=11-4&oh=01_Q5Aa4wEertyh7O7lrWAKUeysqajbpHzLGbozDlMVOkj2RM6Oaw&oe=6A451BE2&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.394	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0071r54dsubltiha	6287824505018@s.whatsapp.net	Bali Beans Umalas	https://pps.whatsapp.net/v/t61.24694-24/237053218_330985962099540_6867782001692891447_n.jpg?ccb=11-4&oh=01_Q5Aa4wFcxL6rcJRwT4ICXQ4iESHVmQ_0T9TG_1Z09GL7c13nOg&oe=6A450078&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0073r54ds3uggwql	6287865534999@s.whatsapp.net	Stand Cafe & Resto	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0074r54ddft7846k	6287860111339@s.whatsapp.net	Espress Coffee Canggu	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0075r54drc5iss9e	6281617575757@s.whatsapp.net	Ketela Eatery & Lifestyle	https://pps.whatsapp.net/v/t61.24694-24/255922778_780967482682976_3025549261477848650_n.jpg?ccb=11-4&oh=01_Q5Aa4wExw_KfL8Cbla9d47DqZwYqGt6dqYQEuMuQgYOuP7qkew&oe=6A451DCA&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0076r54d2hi6hbwm	6283124392266@s.whatsapp.net	brocode	https://pps.whatsapp.net/v/t61.24694-24/258743366_280629213998644_1857454674578981694_n.jpg?ccb=11-4&oh=01_Q5Aa4wGY14TckggWWm16UmTqW414jvIDdf9MB-S0VW5QwGHgpw&oe=6A450EAA&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0078r54dg6if1w60	628888088188@s.whatsapp.net	LD	https://pps.whatsapp.net/v/t61.24694-24/473397027_1168553581301627_518035504868339030_n.jpg?ccb=11-4&oh=01_Q5Aa4wFKEOM-Tw1JHbmlTdjsolhKbkV1_yIoccz_NM3aS9AS-w&oe=6A44F893&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007ar54d60mthurj	6281236111044@s.whatsapp.net	Bu kadek surasmini Kampung kepiting owner	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007br54d8dd1786a	6282147909060@s.whatsapp.net	The Korowai	https://pps.whatsapp.net/v/t61.24694-24/248475746_405592627727537_3261019749629666907_n.jpg?ccb=11-4&oh=01_Q5Aa4wGv3Ws31FJr3gLHUzWW-4-zIOrWjC6p73rQy8zThC-Q2Q&oe=6A44F6BA&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007er54dx5bn7pgu	6285754837440@s.whatsapp.net	Willy Bakery	https://pps.whatsapp.net/v/t61.24694-24/645623498_2512294072560702_2078944186878271888_n.jpg?ccb=11-4&oh=01_Q5Aa4wFwYNlGeW5_sS97pv1KSliyFFWEyzmONJSZvLe9oq9cig&oe=6A44FE9E&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.397	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007fr54dpkwnjnp8	6281999372666@s.whatsapp.net	Chantilly Coffee and Cake	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.397	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6w006zr54d5zdow7wa	6289654812465@s.whatsapp.net	Eka	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007jr54d4a4tjzup	6287861527536@s.whatsapp.net	N'jung Bali Camp	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007kr54dz3zpk3ko	6285237697001@s.whatsapp.net	ETCO tea & coffee	https://pps.whatsapp.net/v/t61.24694-24/518106428_4198564443805408_446606474395617751_n.jpg?ccb=11-4&oh=01_Q5Aa4wFj9Igdiv6PHMVigS5GVl8s2blMDF7jV0hpMqc_sQ62AQ&oe=6A45246C&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007mr54d7wvuzsxx	6281320325965@s.whatsapp.net	Warung Kopi Delima	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007nr54dzhx3a4qk	6281999318965@s.whatsapp.net	Brons Cafe Owner	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007or54dihhw30k5	6281358627370@s.whatsapp.net	Dafi	https://pps.whatsapp.net/v/t61.24694-24/668548767_1644172796902393_869033697247579960_n.jpg?ccb=11-4&oh=01_Q5Aa4wEzed3E8N74dCXbDxH6Qjza75TFiy45e-KFKthrt5L25w&oe=6A451664&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007qr54dhdmql4hj	628113817755@s.whatsapp.net	Titi Ubud Club	https://pps.whatsapp.net/v/t61.24694-24/344692958_1233967573905042_3993288839594721759_n.jpg?ccb=11-4&oh=01_Q5Aa4wGDwCyD6swwSEZN6zAwGKpcV4zXgoGRogw8fssLjT0aAg&oe=6A450BD6&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006pr54dzqlrqejt	120363420394299704@g.us	Paradapp Early Adopters	https://pps.whatsapp.net/v/t61.24694-24/646098041_842142404960318_8176416835886307201_n.jpg?ccb=11-4&oh=01_Q5Aa4wG-6HUB2TJd-eI9SRekIqglH8CYvCFFxybMK0wWfyfFCA&oe=6A44EF20&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:36:50.94	2026-06-21 14:37:54.567	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007tr54do25tuiuy	6285858678056@s.whatsapp.net	Semeja Coffee Bali	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007hr54dtkqgjp77	6281353168585@s.whatsapp.net	papi	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008nr54du5foisyv	6281262457811@s.whatsapp.net	Mia Sorella	https://pps.whatsapp.net/v/t61.24694-24/317704242_852777822710890_5463294583712362746_n.jpg?ccb=11-4&oh=01_Q5Aa4wFOcdCoaIEyeL7jwjPZlEKRtbu9XKX7dPRuBp4LU8DExQ&oe=6A450F4D&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008pr54d2gry8j7s	628124614569@s.whatsapp.net	Ryoshi House Of Jazz	https://pps.whatsapp.net/v/t61.24694-24/696498497_1663401758064038_5222925859146816262_n.jpg?ccb=11-4&oh=01_Q5Aa4wH-kVcZvgRVgQDUwFhXUPAw1AnYOJb_OjiAYVCpwTZDlQ&oe=6A45061B&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008sr54decuiz1f4	6287766608500@s.whatsapp.net	Starbee Coffee & Food	https://pps.whatsapp.net/v/t61.24694-24/646292964_1522329359483402_6403434627137894423_n.jpg?ccb=11-4&oh=01_Q5Aa4wF1Op0tld1JDiEMNADNCbMmF754JwRIXdFuFY5qGdnxQA&oe=6A4509FD&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008ur54dt9xqkimm	6281337226978@s.whatsapp.net	Gelato Republic Seminyak	https://pps.whatsapp.net/v/t61.24694-24/637204164_1318056003485268_4028495323703723559_n.jpg?ccb=11-4&oh=01_Q5Aa4wEkd6cjVgxGWBt5bujSSNFx-t13vINUX1OMpLo3U0Nx0g&oe=6A44FBCA&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008xr54dw93ks6uz	6281238898406@s.whatsapp.net	Expat Roasters Beach Walk	https://pps.whatsapp.net/v/t61.24694-24/298648758_427184969199596_3585346700498240430_n.jpg?ccb=11-4&oh=01_Q5Aa4wE-X4dHVaV9d3rXTSNO6UbYZIZEME0V3bpyMp8m4xzTew&oe=6A44F645&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.396	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008kr54dt0l8tmrl	6281907736598@s.whatsapp.net	Sasqia Zahra	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0091r54dpomhsw4s	6281297959552@s.whatsapp.net	Le Bon Goût Factory Bali	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.397	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0092r54dgw6tji3g	6282247114441@s.whatsapp.net	Milu Bali	https://pps.whatsapp.net/v/t61.24694-24/161783609_272062234686806_6631816595485437524_n.jpg?ccb=11-4&oh=01_Q5Aa4wEZxEnZjA0EFmxQap0e7hXp5tf_J6NW7LKlbEssh5wjAg&oe=6A44F496&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0095r54dzqh3zh0a	6281803693418@s.whatsapp.net	Greend Box	https://pps.whatsapp.net/v/t61.24694-24/473401327_636725725374173_3737610974861070364_n.jpg?ccb=11-4&oh=01_Q5Aa4wEAP8R8q70EquMwS8uX1czT5EZyv-uIcpEqkP5fnF-MDA&oe=6A451621&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007ur54dcsr4cd0p	6281281608003@s.whatsapp.net	Yoko Napitu 7Surf Bali	https://pps.whatsapp.net/v/t61.24694-24/445680439_1142604886850595_6669741249695336344_n.jpg?ccb=11-4&oh=01_Q5Aa4wFcdml4IoE4itpzs-CuFJd49IL2v8CFjEiZqg6YGxdgDQ&oe=6A44F58A&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007vr54dvtpn8t97	6282146841068@s.whatsapp.net	Bali Kiss Gelato and Sweets	https://pps.whatsapp.net/v/t61.24694-24/697821561_2564154007359905_3605688957983738435_n.jpg?ccb=11-4&oh=01_Q5Aa4wESxYXVT_iLPcREUfGIgK_h2ZgziiOzrIR_-o04LtYMEg&oe=6A44F49B&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007wr54dnsjv0dqt	62818434404@s.whatsapp.net	Kana Caffettiera	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007zr54d1az7f9o2	6281337311604@s.whatsapp.net	Surfers bar bali	https://pps.whatsapp.net/v/t61.24694-24/225933481_131740289148796_7699854083045733070_n.jpg?ccb=11-4&oh=01_Q5Aa4wFaiLuQIgIHxWUTknKiuTvZAYbq0uhhZVTjVR6BLDYuaQ&oe=6A44FB73&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0081r54dcy7m6948	6281280015758@s.whatsapp.net	Bali Beach Glamping	https://pps.whatsapp.net/v/t61.24694-24/584843578_1755329605158298_5063126571949777149_n.jpg?ccb=11-4&oh=01_Q5Aa4wHEJyNDwaNVLcWyxwZoMQoXBiLBnnWloFK1oFgfRSFIvQ&oe=6A452219&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0084r54d54t11dm8	6281246782755@s.whatsapp.net	Kopi Atik	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0085r54dvvxz7wwx	6281353972746@s.whatsapp.net	Stock Iced Coffee 1	https://pps.whatsapp.net/v/t61.24694-24/456606058_531667489226698_3091395775044512360_n.jpg?ccb=11-4&oh=01_Q5Aa4wGfETda337J3SdJH5v5aXrUqJOxOjOW7sMwVKK0t5OQ6w&oe=6A44FA31&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0086r54ddvgn3754	6281239326883@s.whatsapp.net	WARUNG KAMPUNGKU SEMINYAK-BEACH	https://pps.whatsapp.net/v/t61.24694-24/295182365_1130596081144278_3850975237552697608_n.jpg?ccb=11-4&oh=01_Q5Aa4wF8ihfCZRmcJfEEmdZiQw9dUEw__LqBeEcz9b5zIHKOMA&oe=6A451E5F&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0088r54dbrj605tv	6281338337474@s.whatsapp.net	3D Museum DMZ	https://pps.whatsapp.net/v/t61.24694-24/588708638_847829524878040_5617235499152554205_n.jpg?ccb=11-4&oh=01_Q5Aa4wGeqHrZklUTJvunIKfs9fd6TiMIxIReUDVtr3FVg6NXWQ&oe=6A450936&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008cr54dp57s6dav	6287860649060@s.whatsapp.net	The Sloth Bali	https://pps.whatsapp.net/v/t61.24694-24/56390566_1282303158612933_470314127391195136_n.jpg?ccb=11-4&oh=01_Q5Aa4wG6xQycfDqjSvadepie9cb6WRFqVS6Nk0JE6Be6RNGQrw&oe=6A4518F5&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008dr54dmiow4j6q	6282144147382@s.whatsapp.net	UP2U Surf School Bali	https://pps.whatsapp.net/v/t61.24694-24/582502499_2160018744806192_5937647519387679999_n.jpg?ccb=11-4&oh=01_Q5Aa4wF9WXz29N37CnyTZSsEiGVe_Rx6KHxl86whh9JkPBOBOQ&oe=6A451AB9&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008fr54d73lbrj54	6281916395087@s.whatsapp.net	Shady Shack 2	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008gr54da7hj7rgs	6282146441346@s.whatsapp.net	Kupi Umalas	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008ir54dydmfcokg	6281529829040@s.whatsapp.net	Tana Cafe	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.403	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008zr54dmvq5xilv	6282117576141@s.whatsapp.net	Christofel	https://pps.whatsapp.net/v/t61.24694-24/422452892_1220668655556946_8788743383415376020_n.jpg?ccb=11-4&oh=01_Q5Aa4wHXm3LZzTqpXkeHQc4BHhatXejEEFqniiPvzm0AiyufpQ&oe=6A451809&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009br54dca9siu8j	6285792666762@s.whatsapp.net	khu_BoO seminyak	https://pps.whatsapp.net/v/t61.24694-24/515047137_2478240789237765_3218467074439205528_n.jpg?ccb=11-4&oh=01_Q5Aa4wHP6rucrZfByqv7aIItEW1RCmFXp7ddICW1gQoFRxjlHw&oe=6A44F2AF&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009cr54d15mfjm99	6282247370506@s.whatsapp.net	BOLD	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009dr54dx55uprxl	6285790280260@s.whatsapp.net	bang feri	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009fr54dlr7t7fse	628111180053@s.whatsapp.net	Dharma Coffee & Juice Canggu	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009gr54dq2012w86	6285933881348@s.whatsapp.net	Padi Club Bar And Restaurant	https://pps.whatsapp.net/v/t61.24694-24/673922274_3660316964131688_9044972060431553691_n.jpg?ccb=11-4&oh=01_Q5Aa4wE6j4S-JE3sRMQE5AmYsYp1V0MmnhFsPQLWoVG06Jb2jw&oe=6A450B87&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009ir54dyp3ci2jo	628123973188@s.whatsapp.net	Boss Suryadi 1	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009jr54d665fv9bn	6287863229639@s.whatsapp.net	Lovina Dolphin Tour Ticket 1	https://pps.whatsapp.net/v/t61.24694-24/592130860_1682894392835220_1969896108909027103_n.jpg?ccb=11-4&oh=01_Q5Aa4wFP_BRlWM__vLVvZgqbsJhuFIMJUj2JWhF2sBNzSrInOg&oe=6A44F619&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009lr54digpjji7x	6285163196604@s.whatsapp.net	abrar T	https://pps.whatsapp.net/v/t61.24694-24/445109632_486822304140475_138126386733362043_n.jpg?ccb=11-4&oh=01_Q5Aa4wFSmbMOdr1MEeg5xlln2_2IM7EZQck4bM1S1f2ceo_Vpw&oe=6A45027E&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009or54dvbkd4bdi	6281338878097@s.whatsapp.net	RAIA Bali - Seminyak	https://pps.whatsapp.net/v/t61.24694-24/300111246_553293783223200_3594582061916715537_n.jpg?ccb=11-4&oh=01_Q5Aa4wFDhFiBnpa5suDIRT9JTbj2HrboH8xxiffM3bdOo_X_DA&oe=6A450CA6&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009qr54d6nzp4p0b	62811865168@s.whatsapp.net	Picheaven Bali	https://pps.whatsapp.net/v/t61.24694-24/328791924_1223909844884661_8544799446461224365_n.jpg?ccb=11-4&oh=01_Q5Aa4wGgxNidU7JV3ZWqLRt4LllNUx7CUemsog1ESrEBnBJ9kA&oe=6A452124&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009ur54dzjptroxe	628113988776@s.whatsapp.net	Nyaman Cafe & Boutique	https://pps.whatsapp.net/v/t61.24694-24/421877453_457601570325030_4433185872443403934_n.jpg?ccb=11-4&oh=01_Q5Aa4wEJwF6SLQLjUZgirSzUc42w1ir3dss2JXCwI6aWMcpPyw&oe=6A44F53F&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009vr54dsrd20fi9	6281338903206@s.whatsapp.net	Warung nasi babi	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009wr54d6wz6jz8w	62811937690@s.whatsapp.net	Titik Temu Coffee Ubud	https://pps.whatsapp.net/v/t61.24694-24/111202605_2705972146349677_1761835717128803482_n.jpg?ccb=11-4&oh=01_Q5Aa4wG5PAHIw1jnE2otKyox5ednHJvJ6VkzsXQdcxm2uB3EMw&oe=6A4511FB&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009yr54dmhn2tjjy	6282144560066@s.whatsapp.net	Pison Coffee	https://pps.whatsapp.net/v/t61.24694-24/491877123_671602755688091_4211153835311643386_n.jpg?ccb=11-4&oh=01_Q5Aa4wFYQF-gk_wagR8zrEir0gO7s7N2dtrcSkNVvpNtGGNbbA&oe=6A44FC1A&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a4r54d46fdxe5k	6281933102422@s.whatsapp.net	Sahasa Coffee and Eatery	https://pps.whatsapp.net/v/t61.24694-24/440725806_1481985912754543_268654844099580647_n.jpg?ccb=11-4&oh=01_Q5Aa4wHA0nSVJzKtUM9h-tmwWrXBH0IBdpSgbyEqbWT3kRri2A&oe=6A451D5C&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.409	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a5r54dugb8l3uk	6281246140493@s.whatsapp.net	Expat Roasters Brew Bar	https://pps.whatsapp.net/v/t61.24694-24/158172189_666280894767983_5379705247082523501_n.jpg?ccb=11-4&oh=01_Q5Aa4wHOY5L76odmcQc3z1qVotIaHowsaSW8DEjJcuDz1wb6qg&oe=6A4517D8&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.409	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a7r54daohu3wzn	6287858154915@s.whatsapp.net	Kopi by Dapur Omi	https://pps.whatsapp.net/v/t61.24694-24/714203135_895389823572614_2617142433627684558_n.jpg?ccb=11-4&oh=01_Q5Aa4wGK-TYxqMNQuplhuqUEVyiaviqr7LJhEZ2axSlkWSe87Q&oe=6A4502E3&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.41	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00aar54dlp33xp7b	6281236472677@s.whatsapp.net	Gema Bahari	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.41	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a9r54du9bmedj0	6283119947615@s.whatsapp.net	JBC badminton	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.41	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00abr54dhg416r6k	628568989499@s.whatsapp.net	Little Langkah	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.41	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00adr54dlf6zsnaj	6287802058355@s.whatsapp.net	Good Soil Cafe	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.411	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00aer54dja36h811	628123866408@s.whatsapp.net	Ebikes Bali	https://pps.whatsapp.net/v/t61.24694-24/56106011_804199383274431_7490440663784226816_n.jpg?ccb=11-4&oh=01_Q5Aa4wH7IARAzLM8qtY3Yw-l7ECKdxIdn_zKN9C99plpmf9jLg&oe=6A44F6B5&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.411	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00afr54dfiqikjfj	6287883569885@s.whatsapp.net	Jonathan Christian	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.411	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00agr54d33w9ftff	6281936083546@s.whatsapp.net	Nyoman Beach Bar	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.412	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00ahr54d386fzmn1	6281210436436@s.whatsapp.net	Surf Well Bali	https://pps.whatsapp.net/v/t61.24694-24/368226295_848730616761632_3001152645839939239_n.jpg?ccb=11-4&oh=01_Q5Aa4wE-MKlm-MVFWij5qNnEfB01Qdje8e3htc4_GMCl0tpLaw&oe=6A44F22D&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.413	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00ajr54d4v0magvj	628123838777@s.whatsapp.net	Vivin Brownies	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.414	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00akr54d2a9zw15m	6281290298427@s.whatsapp.net	Kebon Vintage Cars	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00alr54dqlrt92q8	6281999196336@s.whatsapp.net	Wanagiri Camp	https://pps.whatsapp.net/v/t61.24694-24/644780823_27011344811806240_4969295981420748388_n.jpg?ccb=11-4&oh=01_Q5Aa4wH5AUZ6O2nwtH4H0STGDV_5pQvP6kKqXJvkhwWHOvaWoQ&oe=6A451530&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a1r54dcg70sjpg	628121600427@s.whatsapp.net	Maria Meidiary	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqtcb7cn00zxr54dbk5qin3f	65167656235062@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/730473800_937092636014008_1942301385259139045_n.jpg?ccb=11-4&oh=01_Q5Aa4wF5T8cjIkECzYnwihBGmiFyXKDqTbJBCU8585xpXmwmiw&oe=6A4A031E&_nc_sid=5e03e0&_nc_cat=101	2026-06-25 10:09:08.087	2026-06-25 10:09:08.087	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bur54dkh4j11jp	6281805521544@s.whatsapp.net	Bali Style Surf Lesson	https://pps.whatsapp.net/v/t61.24694-24/265502462_343053767694165_7518723538616752141_n.jpg?ccb=11-4&oh=01_Q5Aa4wHLPVjrA-0ah8JWaKc9Qfd8o_n3NUaf8CrY1aP0g3894Q&oe=6A44FFD8&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.412	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000bwr54ds8i5ku1n	6285739367472@s.whatsapp.net	Taman Ayun Temple	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.413	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000bxr54dy69mmqnw	6281212227110@s.whatsapp.net	kak mella	https://pps.whatsapp.net/v/t61.24694-24/612375237_1614984732980976_1350371829138177740_n.jpg?ccb=11-4&oh=01_Q5Aa4wHYEUWF_dWQKtrG3LQuM5OR-Mo3NRvuCk6VfrP_WruaSg&oe=6A44F99C&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.414	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c0r54d4mo8ue6f	6281933700888@s.whatsapp.net	Vue Beach Club Canggu 2	https://pps.whatsapp.net/v/t61.24694-24/457298202_354006527783163_1612921626211950187_n.jpg?ccb=11-4&oh=01_Q5Aa4wFta9SmLLlFeelcTp_R1zzPdcRLCKJTRf4mga2gPgcCmQ&oe=6A44FA15&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00aor54dcgm4x697	6287877291018@s.whatsapp.net	Joju Seminyak Bali	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00apr54dp86gyn7s	628113567770@s.whatsapp.net	Wake Cup Coffee at Kerobokan	https://pps.whatsapp.net/v/t61.24694-24/658391056_26995248170124422_3049509463142161206_n.jpg?ccb=11-4&oh=01_Q5Aa4wH9tHaIaaqMaOWULIMlSSsc9eEBIoqNGVSe_qgggPQwoA&oe=6A44F77F&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00arr54d632hwaqd	6285210982929@s.whatsapp.net	JUMA COFFEE & ARTS	https://pps.whatsapp.net/v/t61.24694-24/674849236_2475889702896327_1735512040745701460_n.jpg?ccb=11-4&oh=01_Q5Aa4wGoQoVPZZDAsSoz4RYLT_WfrNBVoYqL8ebERVy3GKnc5Q&oe=6A4521C5&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00atr54dx7c94a5a	6285101725367@s.whatsapp.net	Pinggir Pantai Jimbaran	https://pps.whatsapp.net/v/t61.24694-24/69333101_112831846936844_5227108990123073025_n.jpg?ccb=11-4&oh=01_Q5Aa4wFtR7HQjClVaEJ6RsKPVoily893gBo1ZOlRLsLMDJ4uyw&oe=6A44F15E&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00aur54damzxyo6h	6281916324317@s.whatsapp.net	RDV BAR	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00ayr54d22a11hn4	6288210673430@s.whatsapp.net	Ivan	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.421	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00azr54dijlsjqeq	6281808641111@s.whatsapp.net	Kebon Vintage Cars 2	https://pps.whatsapp.net/v/t61.24694-24/473400985_1119278603543089_7824722684039965683_n.jpg?ccb=11-4&oh=01_Q5Aa4wFZiUmgpbcxe4oJD6atEON9XZ7mPCLpRqOqEjlxO0eYbg&oe=6A45228B&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b0r54d3r61k6rf	6281338702266@s.whatsapp.net	Turtle Bar Bali	https://pps.whatsapp.net/v/t61.24694-24/427350755_1452918695364312_7908696185349637204_n.jpg?ccb=11-4&oh=01_Q5Aa4wEg_-HkJzAn6Pa63TsSIi65INR9v4m0q5jOcAjOoJkhGA&oe=6A4512B1&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b1r54dqagq30w2	6281267221321@s.whatsapp.net	Achay	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b3r54dipyuj0qw	6285737883289@s.whatsapp.net	Dovetail	https://pps.whatsapp.net/v/t61.24694-24/714910599_979674331524440_9077798916104755900_n.jpg?ccb=11-4&oh=01_Q5Aa4wEMCMZKsjoiLLu4Zwavcy2eGo8LL1ME5e0swJ8WRr1mSg&oe=6A4520BE&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b6r54d4u8p94ae	628170667088@s.whatsapp.net	Boss Suryadi 2	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b7r54dz5o3njl2	6287862077011@s.whatsapp.net	Satu Satu Coffee	https://pps.whatsapp.net/v/t61.24694-24/56153873_2791441287748621_8579226014465392640_n.jpg?ccb=11-4&oh=01_Q5Aa4wGh4OI0rti12KETT_-E2Wm7W85C6EnyzO9JyM-TR8mEVw&oe=6A44F103&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b9r54dev04lgqv	6597289468@s.whatsapp.net	Jun Hao	https://pps.whatsapp.net/v/t61.24694-24/406072150_943962713954662_7646685723814217488_n.jpg?ccb=11-4&oh=01_Q5Aa4wHjdb1tHg2hhDvC0JQ87M5UaN7uSgtwphFuG5lJqUVLKA&oe=6A44F73C&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bbr54dtanc5kqa	6281311070070@s.whatsapp.net	DINA noodle & coffee	https://pps.whatsapp.net/v/t61.24694-24/534423448_1092272116373992_171123210721029590_n.jpg?ccb=11-4&oh=01_Q5Aa4wEBm8FgJPhC9yKm2YWYCXxlmPMaR02QX0EPS2uv8N6SdA&oe=6A452324&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bdr54d9rj86n5v	6281805492727@s.whatsapp.net	Kopi & Roti Cafe	https://pps.whatsapp.net/v/t61.24694-24/615291047_858563366975893_2965890562460829057_n.jpg?ccb=11-4&oh=01_Q5Aa4wHL4zrA_Dcq51QloSmrypQfCgHCxTr9GTvpxkuneypHXw&oe=6A452615&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bfr54dnumipda0	628111355514@s.whatsapp.net	Imam Santoso	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.425	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bir54d2a49pc3w	6287840385057@s.whatsapp.net	Sabre Coffee Shop & Roastery	https://pps.whatsapp.net/v/t61.24694-24/99156869_1154045498270293_8451142117361359563_n.jpg?ccb=11-4&oh=01_Q5Aa4wHdPaCy7QObkS0swI4tKPxKfLBN6T77l696vrtkeOdm8Q&oe=6A4516DF&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bjr54dbod0xwjd	6285693933374@s.whatsapp.net	Kak Nita	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00blr54dzu1z4sz6	6281338532651@s.whatsapp.net	Desa wisata Cau Belayu	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bmr54dp0qli2ki	6287760043385@s.whatsapp.net	ella n dut beach bar	https://pps.whatsapp.net/v/t61.24694-24/56106046_2378250372451814_4318974324938637312_n.jpg?ccb=11-4&oh=01_Q5Aa4wHpuetNPmKMPWhSGvG7hI3ElaUVpQ5IkF6MjfD0Sb_Kew&oe=6A4516FA&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bnr54dn6667aa3	6282236609868@s.whatsapp.net	Pit Stop	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bor54dzkivsaq1	6282147397069@s.whatsapp.net	Legian Pub Bali	https://pps.whatsapp.net/v/t61.24694-24/361254249_1722929604799685_114492604966157968_n.jpg?ccb=11-4&oh=01_Q5Aa4wFZSDdhiFukgTK5Wi2T7hCFPPSJbsYwqc-ZOeqV3i8A7Q&oe=6A4506B1&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bpr54drxikxh1c	6285731762295@s.whatsapp.net	Karamel Cafe & Bakery	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmr0duouu0124r54dq3ts0ev8	69591439040597@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/540787665_1047756034347451_7677310250442584519_n.jpg?ccb=11-4&oh=01_Q5Aa4wEvy0C6fpN4YWBgpgpw0TFuB5IpmyRq9X2ZaEUIJc11LA&oe=6A5080B7&_nc_sid=5e03e0&_nc_cat=100	2026-06-30 08:26:40.086	2026-06-30 08:26:40.086	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c3r54dy58nhsgv	6281337050520@s.whatsapp.net	JUST CAFE BUMBAK	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c4r54dbhzgv5os	6281337111790@s.whatsapp.net	TITIS BAR SANUR	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cnr54dozyz146h	6281237300103@s.whatsapp.net	Udaya	https://pps.whatsapp.net/v/t61.24694-24/546524244_887243700444223_7822849249194123025_n.jpg?ccb=11-4&oh=01_Q5Aa4wFOi19icxa6VvJhX0vrf_x_0_1-vBIOdJbnX5aCzZStFw&oe=6A44FF83&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c6r54dpny2w9ph	6287862248348@s.whatsapp.net	Enjoy Kitchen Seminyak	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c7r54drl5fjo7h	6281238673454@s.whatsapp.net	Wahana Wisata Sambhrama Ashram	https://pps.whatsapp.net/v/t61.24694-24/423816264_1128079005227834_8764052857323957390_n.jpg?ccb=11-4&oh=01_Q5Aa4wFrWIBFytaP_HAo1yIG7jxIl-vIg03-jYBWjPMD3-29EQ&oe=6A44F924&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000car54dknk0oh97	6287803476351@s.whatsapp.net	The Korowai 2	https://pps.whatsapp.net/v/t61.24694-24/158416268_207486221280909_3974245637976006761_n.jpg?ccb=11-4&oh=01_Q5Aa4wEqvyq5GsUecyMZhuP6M5JVJW3uSg7TIK-XX9q0r_8q9g&oe=6A44F81D&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.42	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000ccr54d4c72gv62	6287758332705@s.whatsapp.net	Sipp Coffee	https://pps.whatsapp.net/v/t61.24694-24/534416887_864915326088121_4459379059698460373_n.jpg?ccb=11-4&oh=01_Q5Aa4wGetAWYIxOTxLpjamDhUkWvcNh1s9D3MYjVhmDv6MrcmQ&oe=6A451A14&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.421	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cer54dvnthsamo	6281338963173@s.whatsapp.net	Granary Cafe & Workspace	https://pps.whatsapp.net/v/t61.24694-24/309978761_164515536187824_7678881225884870343_n.jpg?ccb=11-4&oh=01_Q5Aa4wFKxXnCLrSKSa52Qr-lVMJhpE6icUIDyasvY306bJpAHQ&oe=6A450935&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000chr54dpko65dzf	6281584495757@s.whatsapp.net	Ketela Eatery & Lifestyle 2	https://pps.whatsapp.net/v/t61.24694-24/257018396_293621402985919_6443836604695029463_n.jpg?ccb=11-4&oh=01_Q5Aa4wExN2boMQYejq_nzu04EoFrMacXGlsXvgaQlU4UOyjNZw&oe=6A450622&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cjr54d2ibvn7oc	628113991718@s.whatsapp.net	Paradiso Ubud 1	https://pps.whatsapp.net/v/t61.24694-24/170671424_417351026590791_6141073890439865150_n.jpg?ccb=11-4&oh=01_Q5Aa4wGObIfBfqcCoNKxN9OyBNQL6aSnxTqKqKVLbimT1uj4vw&oe=6A4511CE&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cmr54d3twzyhts	6281374373926@s.whatsapp.net	Mas Sepra	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cor54d5x1l3ien	62818563931@s.whatsapp.net	The Reuniom Club	https://pps.whatsapp.net/v/t61.24694-24/325661560_2475587315928177_8936129826076817450_n.jpg?ccb=11-4&oh=01_Q5Aa4wHBv9oFq1ctfOCx9a2lEH5gtAJHJoYPP0YMoFCeZgXf9Q&oe=6A44EFEF&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000crr54digp1o2ze	6282127310866@s.whatsapp.net	Calle Ocho Seminyak	https://pps.whatsapp.net/v/t61.24694-24/311570186_1260391424738558_8364405436098574488_n.jpg?ccb=11-4&oh=01_Q5Aa4wGeCKJY8VjcLmA5ROZlIqm8F3gcOgHimIUPydoSYzlblw&oe=6A451F9B&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000ctr54dgxeyona1	628979167072@s.whatsapp.net	Komura Coffee and Beverages	https://pps.whatsapp.net/v/t61.24694-24/429839230_1645317022875028_7602909107229423957_n.jpg?ccb=11-4&oh=01_Q5Aa4wGnGI7FfnTsJJqDpVseMAloy10q7QYSKiYICPdCEuUXIA&oe=6A4519E9&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.425	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cvr54duna92fa6	6282138826688@s.whatsapp.net	Canggu Bali coffee	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cwr54d8j9i144y	6281353307453@s.whatsapp.net	Umalas Brew Bar	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cyr54dzuyhbciu	6285931267589@s.whatsapp.net	Roti Bakar Basah By Kitchen Putra	https://pps.whatsapp.net/v/t61.24694-24/467328755_1762056707945074_6656503195790786902_n.jpg?ccb=11-4&oh=01_Q5Aa4wEEJ-HiZSASIPEJKO-SzRKXJsJQDPeiyI0JgbSPi8FiCQ&oe=6A44F919&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d1r54dh7ivwb5q	6281353823856@s.whatsapp.net	Pak Alit Jatiluwih	https://pps.whatsapp.net/v/t61.24694-24/339615523_1153847695284167_3021483077427564323_n.jpg?ccb=11-4&oh=01_Q5Aa4wFJ47vD_n8FvxVa9s3ZBqZf8x7dtAjYROwUzBQ4taWoAg&oe=6A45056C&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d2r54dt85bcdie	6285239303464@s.whatsapp.net	Kak Ade	https://pps.whatsapp.net/v/t61.24694-24/345655148_254247210476632_2566936236510074512_n.jpg?ccb=11-4&oh=01_Q5Aa4wHffLaXYktad514fqZ7_4ZIXiTEgtd-HgJMsjCTnx1LBg&oe=6A452261&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d4r54df5uomybi	6281364209637@s.whatsapp.net	zidane basket	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d5r54dannj2zoo	6281973733199@s.whatsapp.net	Banave Cafe	https://pps.whatsapp.net/v/t61.24694-24/604193739_2046275522839565_8678704373828075062_n.jpg?ccb=11-4&oh=01_Q5Aa4wFX5jPyLF7dJUdyUq9eo1e95Rdqt1Gpjpwhalp-BTSk_Q&oe=6A451278&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.428	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d7r54d85au1n3z	6281558520340@s.whatsapp.net	kak pipit three penguins gelato	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.429	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d9r54dzk26hyfp	6285102444468@s.whatsapp.net	Revolver Espresso/ Baby revolver	https://pps.whatsapp.net/v/t61.24694-24/488538617_651847607664621_3006658184846987946_n.jpg?ccb=11-4&oh=01_Q5Aa4wEDICQSr5ZykxlH-esvId0Am7M5ZP6jfaT1GqTxs_YHvQ&oe=6A44FFB7&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dcr54dftj9weoe	6281999961028@s.whatsapp.net	My bar sanur	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000der54dffye2h6o	6281246245389@s.whatsapp.net	QSORA HOME	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000ddr54d066jbern	6285237007807@s.whatsapp.net	Nate’s bar	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c5r54d9vasfc6s	6281337010229@s.whatsapp.net	Ce senyen	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0072r54d22oo8jbq	6281236668399@s.whatsapp.net	Nasi Ayam Kedewetan Bu Mangku ubud	https://pps.whatsapp.net/v/t61.24694-24/479696233_1360813335263204_1303479212777117875_n.jpg?ccb=11-4&oh=01_Q5Aa4wGJON64p_1cjFaVIfjKTbKVmuQwDdNOzXgyqEo0yE37hg&oe=6A450B47&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008or54dm8e5808x	628113993318@s.whatsapp.net	Secret Spot Canggu	https://pps.whatsapp.net/v/t61.24694-24/328063992_223830960008669_2266605992089304998_n.jpg?ccb=11-4&oh=01_Q5Aa4wEoZsDSDtesHD9pMoFCzWHC5O6kjilKIJoELsj_enBFzw&oe=6A4509F1&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008rr54db2pq1jjx	628999995434@s.whatsapp.net	Komang Cahya (Woogigs C00006)	https://pps.whatsapp.net/v/t61.24694-24/534425006_1672162310782678_5634324031289971841_n.jpg?ccb=11-4&oh=01_Q5Aa4wHSng00cZ6Pzy1PfSKXW8x7MGf9OwaC9b2U4OK_f6qz4A&oe=6A44F42B&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008tr54d9j77hchf	6281323339098@s.whatsapp.net	Funday Cake & Dessert	https://pps.whatsapp.net/v/t61.24694-24/424533244_907004874308340_6853809251475957070_n.jpg?ccb=11-4&oh=01_Q5Aa4wEmQ_Yvlo1DQ9XcUh7tJkQ9zZnW1JquIpzn9FZbLdyjAQ&oe=6A44F955&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008vr54d4abdi8yb	6281353187457@s.whatsapp.net	Sun Sun Warung 1	https://pps.whatsapp.net/v/t61.24694-24/182063278_514531666592867_9089222934354502790_n.jpg?ccb=11-4&oh=01_Q5Aa4wHr08XcMhj1gjVxpvudVVnRI-RZsZ00tlh4kFq0OJzWng&oe=6A45244C&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0090r54dfksrxbow	6281808558000@s.whatsapp.net	Van Koffi	https://pps.whatsapp.net/v/t61.24694-24/663918361_1482592373248058_8396592179953720624_n.jpg?ccb=11-4&oh=01_Q5Aa4wEwZHWYihKjpIIRPioBLsxjGty8hAJAYg4FIf4BLkqCFA&oe=6A450CCD&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.397	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007lr54djperb0ru	6285337589474@s.whatsapp.net	BAKSO Iga Tulangan Kedonganan	https://pps.whatsapp.net/v/t61.24694-24/56105948_2227798214136044_8030128223926878208_n.jpg?ccb=11-4&oh=01_Q5Aa4wE4Rv8T65u65JDrU1sCyOrb5aXEc1CWk9kPVNwcZDISAw&oe=6A450479&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0098r54dsqho124a	6281315494095@s.whatsapp.net	Sarah	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009ar54d9ipybl3h	628996904522@s.whatsapp.net	bang sani	https://pps.whatsapp.net/v/t61.24694-24/473411134_2971945106295014_3259447979558045905_n.jpg?ccb=11-4&oh=01_Q5Aa4wEz5ZuOxW760abnRq0y3sDB1hLJf96PxZ2GPWDa1MRCzg&oe=6A450ADE&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007sr54dijbeu8th	6289619292181@s.whatsapp.net	Ixora Cakes, Breads & Pastries	https://pps.whatsapp.net/v/t61.24694-24/239272238_273618404148363_8250493066499480146_n.jpg?ccb=11-4&oh=01_Q5Aa4wHn3zsbxRquhxtZ09n5pmi4i05khA9YlLe3--L7U21sBA&oe=6A44EE14&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009hr54dus87x1cu	6287747923290@s.whatsapp.net	Oli Kopi 3	https://pps.whatsapp.net/v/t61.24694-24/376425106_1669338993478083_1377988560968023523_n.jpg?ccb=11-4&oh=01_Q5Aa4wExXsuyUyKha5HWA85NkK_kWo48N9krkYd0LDDDqvWKaw&oe=6A451273&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007yr54dinnlv651	6281259602211@s.whatsapp.net	Fiet Cycling Coffee Culture	https://pps.whatsapp.net/v/t61.24694-24/473403275_1195865292244084_4282814842776278367_n.jpg?ccb=11-4&oh=01_Q5Aa4wG-TWkbvUK0ZkQYYkcJpVI18kHUVVnIWfBrLyatbSR9Wg&oe=6A451CCE&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009kr54dcqbxtbgz	6281238701147@s.whatsapp.net	Kedai Nata 21X	https://pps.whatsapp.net/v/t61.24694-24/491867332_1216052256628328_4011003478157879130_n.jpg?ccb=11-4&oh=01_Q5Aa4wFCxSdZsVuz6fSfjeZ35MQvyo06h-d1P0STt6NYfSK5Hw&oe=6A44EFD6&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0082r54df6b4m0cn	6281283386641@s.whatsapp.net	Seniman Coffee	https://pps.whatsapp.net/v/t61.24694-24/171901661_1188899894846894_7843309920891466825_n.jpg?ccb=11-4&oh=01_Q5Aa4wGTvWujaIvw79qBHfEG4Cj5sVPMnjxzXSaMyMb9VxVNdg&oe=6A452077&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0087r54d8utijmjm	6287703054619@s.whatsapp.net	Gourmet Cafe	https://pps.whatsapp.net/v/t61.24694-24/71091606_271103080534062_3551643992878002229_n.jpg?ccb=11-4&oh=01_Q5Aa4wFgf2XEDcZl4bNUQhDieWqL_xAeV8kV2hi0asqtTvv_YA&oe=6A451B89&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009tr54dnudxnrus	6281999126444@s.whatsapp.net	Megumi Coffee & Eatery	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009xr54ddcdgpun1	6282144469335@s.whatsapp.net	Dabar	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008hr54dbc5f7w8l	6287862186508@s.whatsapp.net	Persepsi Kupi	https://pps.whatsapp.net/v/t61.24694-24/626930943_897654826438188_4676366504277073425_n.jpg?ccb=11-4&oh=01_Q5Aa4wGiOjxPI31eGWdRti8UzPPVgwMBmpmrsylouWvTR8phwA&oe=6A44FB14&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000djr54d02ezzqyn	628979357235@s.whatsapp.net	Dang Cookies - Seminyak	https://pps.whatsapp.net/v/t61.24694-24/455596425_904273528434770_6631805339602497781_n.jpg?ccb=11-4&oh=01_Q5Aa4wGAJUcQjRyyrY8b8IzC9GGG39OABrg3mYCoT_NpjEhgHA&oe=6A450E39&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dlr54d2gicpn79	6285282825517@s.whatsapp.net	Bite Bali	https://pps.whatsapp.net/v/t61.24694-24/431230734_807008107445906_7676222670067652500_n.jpg?ccb=11-4&oh=01_Q5Aa4wHJW448_JOlbg-h344jf3BLgUr-wPRrCHZep3J_N2ZXIg&oe=6A4511E6&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dnr54dkwwgiblv	6285100893233@s.whatsapp.net	Carla House 2	https://pps.whatsapp.net/v/t61.24694-24/491869220_1650018838983057_569801652407396677_n.jpg?ccb=11-4&oh=01_Q5Aa4wHltjjtLsFoNzpkJZFlZNWCvWNs4GWrqhU2I8sWms5szA&oe=6A4502C0&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dpr54dxtpcdnrx	6281314103649@s.whatsapp.net	Kopi Cukil	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.434	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7100dqr54dplg08hq8	6281239696420@s.whatsapp.net	Farine	https://pps.whatsapp.net/v/t61.24694-24/97315901_183748973084649_8267557881986920372_n.jpg?ccb=11-4&oh=01_Q5Aa4wEBD5Ku-3Fi5POjn-jASolw2o5-YlfyBopCB3rKrC-Gkw&oe=6A45014D&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.434	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00kwr54d7jr9rcaa	62895333615211@s.whatsapp.net	ASTER	https://pps.whatsapp.net/v/t61.24694-24/473401913_571912518997414_5835704126799013080_n.jpg?ccb=11-4&oh=01_Q5Aa4wEoyHRYDneJ4p8nK2WseyJLvu1jYGd07ddZnVu6ApBpgA&oe=6A450115&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:52.091	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00l0r54dl2u9civv	6282216981643@s.whatsapp.net	Er	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00l1r54dr9wfa4sl	6281246973030@s.whatsapp.net	Rizal Ramadhan	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00l2r54dxd3cvg55	6281234371102@s.whatsapp.net	hilmi	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00l3r54d5iio1krk	62895326481168@s.whatsapp.net	Vilia	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00l4r54disdhjpfc	6287762827988@s.whatsapp.net	Bella Anjani	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00l5r54dff9yu2jg	6282243373001@s.whatsapp.net	Flo	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00l8r54dv7rbhu15	6281353337222@s.whatsapp.net	Gita Ardynmas Mertawan	https://pps.whatsapp.net/v/t61.24694-24/697798336_843921655442222_696630703043926210_n.jpg?ccb=11-4&oh=01_Q5Aa4wG9qLW25_Zq8z7Qh2Ph83RYI8B6v1iavSsEtjBdcVd_YQ&oe=6A4524C4&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00l9r54de8821rs4	6282112148261@s.whatsapp.net	Cory Rahmani	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lfr54dgbsoykn5	6282359051429@s.whatsapp.net	Mangagus	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lar54d0yyrpdeo	6283857440668@s.whatsapp.net	Irhan Hisyam	https://pps.whatsapp.net/v/t61.24694-24/582660640_1541233960919663_4870238142974446254_n.jpg?ccb=11-4&oh=01_Q5Aa4wFaKW9HpXXACtrZD-Ia4kHzQSDXEkBliibVyE26Vn393g&oe=6A45246E&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lhr54dj4eljkhk	6281929753406@s.whatsapp.net	Joe Wu	https://pps.whatsapp.net/v/t61.24694-24/695302938_1500192741844456_4440609403073622703_n.jpg?ccb=11-4&oh=01_Q5Aa4wFJKmxMPelLPgl-DYUlJWwtLYgzFFDwnhjMHSCjgLmTuA&oe=6A44F0DF&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00ljr54d8g4daa11	6288987246471@s.whatsapp.net	annisa abas	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00ler54dqs452boa	628567762491@s.whatsapp.net	Afriandi Ferdinan	https://pps.whatsapp.net/v/t61.24694-24/645794195_1266652194956065_4580720623745032331_n.jpg?ccb=11-4&oh=01_Q5Aa4wFQuI7CaO09gsQa_258HCVD8B0akUo0JIXg1vZwEQRvKQ&oe=6A45042D&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lkr54dg4zhii5a	62881037080146@s.whatsapp.net	ayu lestar	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.447	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00llr54dxfet2nwt	628815572991@s.whatsapp.net	SITI KOMARIAH	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.447	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lmr54dpr05tc4g	62881036976345@s.whatsapp.net	Laura	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.447	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lor54d4ryshjr9	6282302095190@s.whatsapp.net	Lucki	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lpr54dwvmgi7p0	6281252056202@s.whatsapp.net	Tika Wulantari	https://pps.whatsapp.net/v/t61.24694-24/671282372_1272511921288529_6893137927267053760_n.jpg?ccb=11-4&oh=01_Q5Aa4wH6pngcuyDH-RphGwCwcybBdFD-iN5A7j0T8_p8Wg4kvQ&oe=6A4517BF&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lsr54d3shqi502	6285311781853@s.whatsapp.net	Rickyy	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lrr54dp2pee2w6	6285101800800@s.whatsapp.net	Rama Darma	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lur54dopz2ajgf	6281284063078@s.whatsapp.net	Ardhia Helmi	https://pps.whatsapp.net/v/t61.24694-24/485461485_1819007012256127_6469399783036076621_n.jpg?ccb=11-4&oh=01_Q5Aa4wEGZIJ4FdBZfdfPnMLRuWalb4DY9yyQUMQcrMpeJ38SPg&oe=6A451571&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lxr54d81a337o7	6281299696081@s.whatsapp.net	PG	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lyr54d7zjfdc95	6285156821368@s.whatsapp.net	Laurent	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lzr54dh9d7q7jw	6287832983514@s.whatsapp.net	Kevin Theo	https://pps.whatsapp.net/v/t61.24694-24/697603242_2794894697536301_5291692363835067105_n.jpg?ccb=11-4&oh=01_Q5Aa4wEedjHuBcem138LtZvalJko8RsejduO7zWeRPYdvIF21w&oe=6A450CBE&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m0r54d4xyfgsad	6281330802401@s.whatsapp.net	Indira	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m2r54djfr4oth5	6281339093759@s.whatsapp.net	Calvin Mandar	https://pps.whatsapp.net/v/t61.24694-24/534423061_1220031336217165_2267740511369749120_n.jpg?ccb=11-4&oh=01_Q5Aa4wH1CfV53vh6GnWKu4iyXTqtnyv_yv74k2OUvoAR4YpzhQ&oe=6A44FB70&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m5r54dcjqqxe5g	6281230447026@s.whatsapp.net	Bells	https://pps.whatsapp.net/v/t61.24694-24/644728815_972925795669485_7023640684402936300_n.jpg?ccb=11-4&oh=01_Q5Aa4wHvfVguJUzaKFQ_rSyr9EM-qsEYuU0C7LXeIYw89xxptQ&oe=6A45125E&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00m7r54ddx924ryh	6287860868103@s.whatsapp.net	Archellio	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00m8r54dfeo54j3f	6285737622874@s.whatsapp.net	Yuga Wicaksana	https://pps.whatsapp.net/v/t61.24694-24/672873069_2268945620512286_1191479444204587489_n.jpg?ccb=11-4&oh=01_Q5Aa4wFmarH5UCo1DQX8UdV-lwZCmyupmhzUg3U54jLWykWitQ&oe=6A44FA05&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mbr54db8rf0jer	6281334695040@s.whatsapp.net	Angga Leo	https://pps.whatsapp.net/v/t61.24694-24/534428668_845586898618803_4193646279054025297_n.jpg?ccb=11-4&oh=01_Q5Aa4wFtP6h7_rRl3yrtX8mSKS0x-5xLGRp7iyjlHfD9WkQG7Q&oe=6A44F44A&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mdr54ddrbjd3yk	6285606199717@s.whatsapp.net	Acha	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mer54dzpaa8tqw	6285856024730@s.whatsapp.net	Ferdy_23	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqulmd95010mr54d3f2bb4sg	62881082489258@s.whatsapp.net	\N	\N	2026-06-26 07:17:31.673	2026-06-26 07:17:31.673	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008mr54ds55upz57	6281999308284@s.whatsapp.net	Pak Nyoman Bersih Mangrove	https://pps.whatsapp.net/v/t61.24694-24/534421504_1015660723858246_4748440931738169626_n.jpg?ccb=11-4&oh=01_Q5Aa4wG0-TnGKZ0nS-f740vBh7h1KhV7gtoZkgF6DXeotmB2bQ&oe=6A4521C6&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008qr54dzqji7pm5	6285721512860@s.whatsapp.net	Kak Eka MG 13 (Timah) timah	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0077r54ddfll506h	6285100181011@s.whatsapp.net	Carla House 1	https://pps.whatsapp.net/v/t61.24694-24/309836212_176164751664132_4201434965377455513_n.jpg?ccb=11-4&oh=01_Q5Aa4wGRSFjLP8GJFuBswafuddN7o-L4CC-uBpwinWYhqE_u6Q&oe=6A450E68&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0079r54dwrg60x1m	6281246149184@s.whatsapp.net	The Loft Canggu 1	https://pps.whatsapp.net/v/t61.24694-24/672607692_2393597344442978_6193510854000559855_n.jpg?ccb=11-4&oh=01_Q5Aa4wGBBr2DSP1EpYxMqdizZD2hFrHpugbUDtaVtZzZUZmCzw&oe=6A451260&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008wr54dimn3n7gn	6281999916185@s.whatsapp.net	Warung D'Kubu Kerobokan	https://pps.whatsapp.net/v/t61.24694-24/264140478_613100016783799_8856860062466216908_n.jpg?ccb=11-4&oh=01_Q5Aa4wGIqTi_aH0npmoMakzSIbKdh1Sk73luz38AL7RPsFTvkQ&oe=6A4502B5&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007cr54dd4sk7sut	6282144213431@s.whatsapp.net	Darling Beach Bar	https://pps.whatsapp.net/v/t61.24694-24/310621795_154742876922735_6125255426081388359_n.jpg?ccb=11-4&oh=01_Q5Aa4wGGm_FWZyCAajL7HIUO_SnIcJXetb6rmDPxBy8Uil-flA&oe=6A451D46&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.395	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007dr54dded5z5q9	6282359507456@s.whatsapp.net	Ceritakita Bakso Iga & Grill, Kesambi Kerobokan	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.396	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008yr54di6rs5g9o	6287786865656@s.whatsapp.net	Perama d&d Cafe	https://pps.whatsapp.net/v/t61.24694-24/461247101_491966927149129_8601345224760661298_n.jpg?ccb=11-4&oh=01_Q5Aa4wFo4v7uqBst6tDrnC-yu4mA94_brWItyFh5yycV72bEcw&oe=6A44F78E&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.396	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007gr54d1gqfriie	6281337380237@s.whatsapp.net	The Bakers Bistro	https://pps.whatsapp.net/v/t61.24694-24/662284630_1519090579752092_2997927030377101683_n.jpg?ccb=11-4&oh=01_Q5Aa4wEzDrKko4Cz2qL-WBvwEuNj0jGJp2Uc8nvQfRGqFFwIcQ&oe=6A452636&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.397	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007ir54dv4gc6ya4	62895630478421@s.whatsapp.net	Makna Coffee	https://pps.whatsapp.net/v/t61.24694-24/620274911_1521799125949470_210731036976826319_n.jpg?ccb=11-4&oh=01_Q5Aa4wHDpNyds3OWDQ_bNL1YlX09010pg7sHjxBYHFOCnH4bZA&oe=6A44FDD8&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0093r54d1c0p50t3	6285338509922@s.whatsapp.net	Warung Nasi Bali Men Weti	https://pps.whatsapp.net/v/t61.24694-24/438911154_492594816639204_5950273289301496521_n.jpg?ccb=11-4&oh=01_Q5Aa4wFCG_rMhg7I8aQo9EHFP8lnEZpksuTj-YHx_a5xOg7lYQ&oe=6A44FD95&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0096r54dtw5mctez	628553902323@s.whatsapp.net	Seken Coffee - Bakery & Pizza Seminyak	https://pps.whatsapp.net/v/t61.24694-24/675446879_1370439365133998_3300085595101154582_n.jpg?ccb=11-4&oh=01_Q5Aa4wFzyUAMUd8Nltax8uQcA3-1qL9hK85_GoJChdeyLEjF4A&oe=6A44FAC2&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0097r54dq6wv0ll1	6281238428343@s.whatsapp.net	Revolver Espresso Oberoi	https://pps.whatsapp.net/v/t61.24694-24/491870633_705700518578155_2271636752077748581_n.jpg?ccb=11-4&oh=01_Q5Aa4wE5anbcntmoVJQ0AabXJuskK2n1GwNUZvbE70t0bWLPlw&oe=6A450FDE&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007pr54dfyx2l4d4	628112400072@s.whatsapp.net	Bagus T Rasyidin	https://pps.whatsapp.net/v/t61.24694-24/592088651_25876301788706576_2054805805118686145_n.jpg?ccb=11-4&oh=01_Q5Aa4wGeYl_xeomae8wXczcMYQwTcHyp_Z2v1njSeU3v3IR1-A&oe=6A44FCB1&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0099r54d527mqr10	6281236116466@s.whatsapp.net	Shady Shack 1	https://pps.whatsapp.net/v/t61.24694-24/203497368_198559395514933_6678844205252732879_n.jpg?ccb=11-4&oh=01_Q5Aa4wG20uqXYwLstW0nZKw0F3OyftjMoUB_uZW4K87nrdNdIw&oe=6A44FC4F&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.398	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x007xr54dj7wkxnjs	628113889980@s.whatsapp.net	Vue Beach Club Canggu 1	https://pps.whatsapp.net/v/t61.24694-24/141812193_711384899544002_6730576692174460612_n.jpg?ccb=11-4&oh=01_Q5Aa4wHFZ1a5loqrcAGOwl3scsYqzsjC0t67WyfwuSAnrnuP7g&oe=6A45180D&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0080r54dledi7z51	6281907978295@s.whatsapp.net	Sunia Coffee	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.4	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009mr54d56pfvdwg	6281239300841@s.whatsapp.net	Komala ❤	https://pps.whatsapp.net/v/t61.24694-24/699759358_1435538418599549_2137945251301059696_n.jpg?ccb=11-4&oh=01_Q5Aa4wHmv4D35JSYKdMJ8DFoYndGJuP5Qo4eLcZccPSqPXX3yQ&oe=6A450DA7&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008lr54d0nqzlu6j	6282171090013@s.whatsapp.net	Ciefu	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mgr54dr0c9pn8b	989333710574@s.whatsapp.net	مهتاب	https://pps.whatsapp.net/v/t61.24694-24/537545043_3123440947830844_2822476702357660207_n.jpg?ccb=11-4&oh=01_Q5Aa4wEuWAHSgT84hyZ_xWB3Pmp8mq8VhyYhmlkhFxX7U2fhjw&oe=6A4506F2&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mhr54dfcqwett5	6282133866175@s.whatsapp.net	A R K A	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mjr54deqyez8zo	6281294726177@s.whatsapp.net	Haidar Afif (34)	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mlr54dnw4h3ada	6282147342362@s.whatsapp.net	.	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mnr54djclmg9mv	6289688072039@s.whatsapp.net	Wayan Phantom	https://pps.whatsapp.net/v/t61.24694-24/668458395_849642231526892_1351352772542804428_n.jpg?ccb=11-4&oh=01_Q5Aa4wEflf0dPlmsIdtsySCXGS8vDMHno65p7HZcXPBSuRQ3jQ&oe=6A450899&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:52.091	2026-06-21 14:37:53.45	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mor54dbcg55dbt	628113923335@s.whatsapp.net	sofyanto tyson	https://pps.whatsapp.net/v/t61.24694-24/604029319_1495694691510656_9032636175182301994_n.jpg?ccb=11-4&oh=01_Q5Aa4wH0XKoQsegJDRM603culkP5M58iOxXRQbw8neYYo3lKcg&oe=6A451596&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:52.091	2026-06-21 14:37:53.45	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mpr54d6ncrntga	6285733827967@s.whatsapp.net	Rickyy	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.45	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009nr54d43p4cbwz	6285937041001@s.whatsapp.net	Shenyen Ce	https://pps.whatsapp.net/v/t61.24694-24/485461485_1875403779902142_7489747750538740671_n.jpg?ccb=11-4&oh=01_Q5Aa4wFl7NeX85LtKqpnC5icLbYnpinLEMIzUyda3CPD_iuOzQ&oe=6A452262&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009rr54dpdr1ap83	628113951202@s.whatsapp.net	Bali Buda Ubud	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0089r54dbk6rgsd2	6281138017826@s.whatsapp.net	The Best Brew	https://pps.whatsapp.net/v/t61.24694-24/491884717_1307864157410453_4900263897934025995_n.jpg?ccb=11-4&oh=01_Q5Aa4wE8CTNC9QkuSWd5wuurCqyiOl5wlb_zwzy6sqb9VoLE0Q&oe=6A45263C&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008br54dkgzgdqkw	6285855551986@s.whatsapp.net	Public resto & cafe	https://pps.whatsapp.net/v/t61.24694-24/425413785_455660663510668_9186123129782660071_n.jpg?ccb=11-4&oh=01_Q5Aa4wGuVx1Ar11848gS8U6n6slYCbP2LY7zQHn7iYHRVi96gQ&oe=6A45123D&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008er54d0gu42669	6285714425629@s.whatsapp.net	gamelan coffe canggu	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.402	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y00a0r54dx2hp0b9v	6282359351844@s.whatsapp.net	Simply Brew	https://pps.whatsapp.net/v/t61.24694-24/62093623_695705000895416_5873737037093273600_n.jpg?ccb=11-4&oh=01_Q5Aa4wEmjuO9WOmXdCwKojesHNivd451Rf7GG8CUPg_IfmPHXA&oe=6A44FB28&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.407	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a3r54do5r9cnpl	6287761420667@s.whatsapp.net	Scran	https://pps.whatsapp.net/v/t61.24694-24/55964174_563477340807465_4873970144956645376_n.jpg?ccb=11-4&oh=01_Q5Aa4wEYzC-zl3JbKXZvmTcvijS3q0pVeig-g18HN-FFFkh1tA&oe=6A451CB2&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.409	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a8r54dckqz7a9s	6287856204826@s.whatsapp.net	The Bali Local Bar	https://pps.whatsapp.net/v/t61.24694-24/534424263_1956582731940157_7118866702348385102_n.jpg?ccb=11-4&oh=01_Q5Aa4wHgXvfk1BuD2oFmVPeXVsctFBm1Gq2OzbTkr2thsKw2wQ&oe=6A44F2D3&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.41	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00amr54dhmf2k5l4	6287861159608@s.whatsapp.net	Butter-Beurre	https://pps.whatsapp.net/v/t61.24694-24/620211671_1616763536177999_1482015331490503049_n.jpg?ccb=11-4&oh=01_Q5Aa4wFtbXtsKBQMGCh6oPuV9HyT_MjP41THFsuGajuVJjtfPg&oe=6A4501C9&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00anr54dkfhrbxpm	6283832053665@s.whatsapp.net	Lovina Dolphin Tour Ticket 2	https://pps.whatsapp.net/v/t61.24694-24/625842780_1349711163549021_2407270505300971757_n.jpg?ccb=11-4&oh=01_Q5Aa4wGGRsBoA-Cu4HP126I_8xm5seMQbrPHiePpqDFQ46GQ0A&oe=6A44FABD&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00aqr54dhgb291sw	6281314106489@s.whatsapp.net	Service Asus	https://pps.whatsapp.net/v/t61.24694-24/507802154_740932952433784_1995025121265340778_n.jpg?ccb=11-4&oh=01_Q5Aa4wF_m8HpXoatE4b6GTrgHgULiOVX8Mb8fAqmTdymRbQKPA&oe=6A451CF4&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00axr54d5ywtg9h1	6281239620260@s.whatsapp.net	Bintang Laut Cafe	https://pps.whatsapp.net/v/t61.24694-24/684127458_2106956813206525_172774540192350371_n.jpg?ccb=11-4&oh=01_Q5Aa4wFOTzBauXA7-Ut4BzEKbzcHSCjBAm4U61EGAAKYzRZ1AQ&oe=6A4503E6&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.421	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cdr54d15xkeidf	628111090039@s.whatsapp.net	Briocherie Bali	https://pps.whatsapp.net/v/t61.24694-24/260426313_1435175206914630_8583123206763478276_n.jpg?ccb=11-4&oh=01_Q5Aa4wEq9AUWE3xMYFFujFAIVblgRSAVcLTvEDjXO_g1ZxzymA&oe=6A450A7E&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.422	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b4r54ddrn8tig6	6285646915897@s.whatsapp.net	Smashed Box	https://pps.whatsapp.net/v/t61.24694-24/468866976_961727582561601_8866368650787193115_n.jpg?ccb=11-4&oh=01_Q5Aa4wFilvz6i88OlqczYJxUFn_uWp9aXk_Ezy51KA8BVX31rw&oe=6A450569&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000ckr54dk9kx8i1r	6281239995213@s.whatsapp.net	Mind eatery & bar	https://pps.whatsapp.net/v/t61.24694-24/510370273_2002834400365828_3510783225870496176_n.jpg?ccb=11-4&oh=01_Q5Aa4wHc3nZs6c2y3-cqo8LWTfaziRGeFBXbmSRBJPWIHkAb2w&oe=6A450C2D&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bar54d30ioudvc	628118727878@s.whatsapp.net	sugarhead BAKEHOUSE & ACADEMY	https://pps.whatsapp.net/v/t61.24694-24/510713319_1422393512539530_1375922346486640251_n.jpg?ccb=11-4&oh=01_Q5Aa4wGBTxNB6egAAYUyJFa6IIXpud9o23KvnZ3fhCvFC3skrw&oe=6A450EC5&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cqr54d4tfmfxyv	6282144199428@s.whatsapp.net	Chubby Rabbit Bar Bali	https://pps.whatsapp.net/v/t61.24694-24/165561327_968512840522010_7713298192043451901_n.jpg?ccb=11-4&oh=01_Q5Aa4wG1LTuRRWseh_-mb5Kz2XEywBo_sXXZV-hzYsdgaRUMrg&oe=6A450D1F&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bgr54d6z2ls4ge	6285811500888@s.whatsapp.net	WA tiket com	https://pps.whatsapp.net/v/t61.24694-24/518550113_1457746765568875_4872365827418729343_n.jpg?ccb=11-4&oh=01_Q5Aa4wGxAGIAmmOflxlQHDozdSfVA1_rh7a7PEQb3W91Z4E4nA&oe=6A44FC53&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000czr54dqhlo34pm	62895800007505@s.whatsapp.net	Dunsanak Kedonganan	https://pps.whatsapp.net/v/t61.24694-24/597722870_1240937517690101_5667886592336801100_n.jpg?ccb=11-4&oh=01_Q5Aa4wEpNZeeFjw_gImhWjKSYkVGyoE6ZDj6lvwWjW5L-KOZFA&oe=6A44FE69&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bqr54d7i6iupbm	628179730430@s.whatsapp.net	Tanjung Benoa Bali Watersport	https://pps.whatsapp.net/v/t61.24694-24/328151232_132179329748234_698223097119317169_n.jpg?ccb=11-4&oh=01_Q5Aa4wGKV9HadJhWtCKgrq2D8QnwiN9Y5bd4GMoqL4mEITtMQA&oe=6A44F796&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d6r54d7icyl9ox	6285739526616@s.whatsapp.net	Surya Cafe Jimbaran Seafood	https://pps.whatsapp.net/v/t61.24694-24/285127110_704405570813842_2398986330969584707_n.jpg?ccb=11-4&oh=01_Q5Aa4wHyaIrE-Jm1wQt_ZBTXbARfE7y3uy-8Oh0rREimxx3S7Q&oe=6A451372&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.428	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dfr54dkdpq0868	6281246678405@s.whatsapp.net	Wade Restaurant	https://pps.whatsapp.net/v/t61.24694-24/629628832_1621792239030510_5513010470447021134_n.jpg?ccb=11-4&oh=01_Q5Aa4wH1RcO7aD55XAPmOLilPCWDqSwfr9nPxudVoELKm5JSkQ&oe=6A451A74&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dir54d4jzx4vcl	628118867000@s.whatsapp.net	Hova Cake	https://pps.whatsapp.net/v/t61.24694-24/516621092_753139020658474_928314496089316698_n.jpg?ccb=11-4&oh=01_Q5Aa4wGDhZCQ6E0RLR2mNAXmBtkny2Fsr3QD-gIVM86uQK10SA&oe=6A44F53F&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dor54d42j6f04s	628123952424@s.whatsapp.net	Warung D'Abian	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.433	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x0083r54dx8y09ift	6285624153785@s.whatsapp.net	Cisitu Rara	https://pps.whatsapp.net/v/t61.24694-24/637227728_1015170587859368_3069656886129213583_n.jpg?ccb=11-4&oh=01_Q5Aa4wGu8h1GAlJVK304YE0MnO7azYVtoo0cS09-7ELrRmR6-w&oe=6A4513F9&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009pr54dndfxlqpe	6285896198131@s.whatsapp.net	Zulfikri Adha	https://pps.whatsapp.net/v/t61.24694-24/595512578_1592613392169746_6839932206236059634_n.jpg?ccb=11-4&oh=01_Q5Aa4wF33GzYKgcP0ZS0fpoOa0KIaEdTlCtvimTKvjhtlyPz4A&oe=6A4525B3&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009sr54d4xxywar4	628179764685@s.whatsapp.net	Sidemen Adventure	https://pps.whatsapp.net/v/t61.24694-24/56622704_1462576910546294_6902375674351190016_n.jpg?ccb=11-4&oh=01_Q5Aa4wGbGaq6nhlGbrgI8rUK7CtQN8YvfaNmr-GSXq1m9kz8JA&oe=6A45246E&_nc_sid=5e03e0&_nc_cat=106	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6x008ar54dk9rpny2k	6287822841600@s.whatsapp.net	How I Met Coffee	https://pps.whatsapp.net/v/t61.24694-24/596399473_1902452960438393_2124513488497754393_n.jpg?ccb=11-4&oh=01_Q5Aa4wGLP4iktSwhfKqCxn97lQhGt7Y2aLDbaaKY36XKtvjCsw&oe=6A450B59&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.401	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009zr54dq6we0yvp	6282124992949@s.whatsapp.net	Ruth's Cakes Canggu	https://pps.whatsapp.net/v/t61.24694-24/531696434_1945318336331406_5888103975823817508_n.jpg?ccb=11-4&oh=01_Q5Aa4wEd18TP6mqMQ3_4y7tZbPQs53sK99EZiXt2i31N-Uwg-g&oe=6A451D62&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.403	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a2r54dgrplxxu7	628113974888@s.whatsapp.net	Secret Garden Village	https://pps.whatsapp.net/v/t61.24694-24/429925293_1523491744877824_6790844747566800431_n.jpg?ccb=11-4&oh=01_Q5Aa4wGljF1lwE5pWvA5bQaNBVrJp1S6RYtCsAiIhOLqghApSA&oe=6A44FF08&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.408	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bsr54dusba0zgd	628113970101@s.whatsapp.net	The Alantara Sanur	https://pps.whatsapp.net/v/t61.24694-24/187696354_500278591538241_5037427941328280783_n.jpg?ccb=11-4&oh=01_Q5Aa4wHcp1i_9bFvvWqsbg-AaKG2bH0H92bIaPcSCkAEaQcbHA&oe=6A451744&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.409	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00acr54dom6nr526	6285737445765@s.whatsapp.net	Mangku Mastra Yoga	https://pps.whatsapp.net/v/t61.24694-24/301369386_1086537265312259_5414034200745248264_n.jpg?ccb=11-4&oh=01_Q5Aa4wEAb7hOlwChpcHGmDmGRU3Fjh1j6rQjgSsOsSnNxI0a5Q&oe=6A451866&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.411	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000bzr54dii9jwqwf	628113927444@s.whatsapp.net	BELCHIC CAFE | THE CRUST FACTORY	https://pps.whatsapp.net/v/t61.24694-24/368125782_3437692609877626_2977732637456737041_n.jpg?ccb=11-4&oh=01_Q5Aa4wHAW9pjotvmNCXt6mvgNurUAEQrbQr7LppUbASIq8DGOw&oe=6A45127D&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c2r54d6qwoxqkc	6281338426781@s.whatsapp.net	Pur Goa Lawah	https://pps.whatsapp.net/v/t61.24694-24/548893844_1631747371573733_8788338208365989149_n.jpg?ccb=11-4&oh=01_Q5Aa4wEylSjmg69hHjTJymPCDyNOU-Zn1BorsU5ceJWivDlHDA&oe=6A44FB50&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00asr54dy2pq08dv	628113803266@s.whatsapp.net	Ubud Yoga Centre	https://pps.whatsapp.net/v/t61.24694-24/328286932_828900095760257_939721754145777684_n.jpg?ccb=11-4&oh=01_Q5Aa4wFJY0NHXQIbG_7lpCVUlGW9bNpLXkWP80jQ9nQcnD1bmA&oe=6A4522D7&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c8r54deiq8knrn	6281337382099@s.whatsapp.net	Har's Garden	https://pps.whatsapp.net/v/t61.24694-24/325983206_1199001601457404_4854525849452911083_n.jpg?ccb=11-4&oh=01_Q5Aa4wGfwRhBQUoLrmhHFn3hIAv8Cpa13rK8aqyRDIj38Y9lUg&oe=6A44F4A9&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00avr54dcos9b4v0	628113977213@s.whatsapp.net	Bali Ice Skating Arena	https://pps.whatsapp.net/v/t61.24694-24/319927924_1059846548478135_7944381201820039492_n.jpg?ccb=11-4&oh=01_Q5Aa4wFUDaZczF8odTgdMVxOSxbAzge0sa6ZJ5b9-hBguVstdA&oe=6A450E12&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.419	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cbr54d3jhnau9f	628113892205@s.whatsapp.net	I Am Vegan Babe	https://pps.whatsapp.net/v/t61.24694-24/541517242_1146504010756752_164147281803121183_n.jpg?ccb=11-4&oh=01_Q5Aa4wGrDGVJLi59ZkGUxKnIcQkpOMQNvCn9cPTBM42Ogk2E3g&oe=6A45165D&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.421	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cfr54d7kcfspqn	6281529333888@s.whatsapp.net	Crypto Cafe Bali	https://pps.whatsapp.net/v/t61.24694-24/298581568_3224555174452161_8888246017646465248_n.jpg?ccb=11-4&oh=01_Q5Aa4wFhJN1X2wwEV-Em9jbL64VLtnZmjtE3-D2zw5_vQdSkoA&oe=6A450ED8&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b2r54ddtmgpwhd	6281802000444@s.whatsapp.net	Pearl Cakes Bali	https://pps.whatsapp.net/v/t61.24694-24/389775356_197452590001956_3887296491453047449_n.jpg?ccb=11-4&oh=01_Q5Aa4wERKCW7q5mfpapm_eacP1tuvnTnaO_JytlLl8BcK8Taig&oe=6A450971&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00ber54ddqeoyzrz	6287860645634@s.whatsapp.net	Seminyak Ice Roll	https://pps.whatsapp.net/v/t61.24694-24/635557774_1611792813338879_7627222949645788556_n.jpg?ccb=11-4&oh=01_Q5Aa4wFLEQbGkSBD9M21Gsib4KxWa9sVVNSjPYcN3_z2OIwUgg&oe=6A4514E2&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.425	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cur54d5mbotb4w	6282236524409@s.whatsapp.net	warung meranggi	https://pps.whatsapp.net/v/t61.24694-24/55963552_654612994988064_5356865601652391936_n.jpg?ccb=11-4&oh=01_Q5Aa4wHjOvActbzy4bvhdeQT_KIxXBzL57GY4dC63cn9BfwcdA&oe=6A4519B7&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.425	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d0r54ddjfr9dz3	6281317925023@s.whatsapp.net	Atgreengo's bar	https://pps.whatsapp.net/v/t61.24694-24/413226854_1012477183607581_8544557068123605678_n.jpg?ccb=11-4&oh=01_Q5Aa4wEiGMFvMq5uwkfDBok_Quef2TZKeaMGPfQfvxMD4VpgMg&oe=6A4515C4&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d3r54dk4vn7xvl	6281933112002@s.whatsapp.net	MoniQue's Cakes & Dessert	https://pps.whatsapp.net/v/t61.24694-24/60372348_644203852710994_6517057274710589440_n.jpg?ccb=11-4&oh=01_Q5Aa4wEKkjqvSp53ZrNG4pCEHvTbuUR2HTN3IdcOhbx8r8iBNw&oe=6A4519B0&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.427	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00brr54dnj6ksg6v	48697210579@s.whatsapp.net	Marek	https://pps.whatsapp.net/v/t61.24694-24/55952297_2643084785707647_4476410693385453568_n.jpg?ccb=11-4&oh=01_Q5Aa4wFvq0QXuvjBFS474-jRjMm4C1Zn_kq68wZg3Z5DjVeszA&oe=6A44F5E0&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.428	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00kkr54dw33wc8xm	6289616699042@s.whatsapp.net	Rama	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00kzr54djus094fv	6281210746201@s.whatsapp.net	Maria Anne	https://pps.whatsapp.net/v/t61.24694-24/544588579_1586212676070433_1455474365022187983_n.jpg?ccb=11-4&oh=01_Q5Aa4wE_Mt9lRineTFDG47zZb_TIOtJ_wEKpJHpndYlKxqZjWA&oe=6A4525B9&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y008jr54dpipjut9y	6282223401469@s.whatsapp.net	st. bernard coffee	https://pps.whatsapp.net/v/t61.24694-24/465958395_602262978896037_179002218175044189_n.jpg?ccb=11-4&oh=01_Q5Aa4wEelqv5EzvG5DWyDqsesiwcvM_XPBnaxM-Ga2yUi1oynQ&oe=6A45244E&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.403	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00a6r54dnsw9td3d	6281280599057@s.whatsapp.net	Adrenalin Sports Bar	https://pps.whatsapp.net/v/t61.24694-24/469982014_1976076579505667_6609789895156056859_n.jpg?ccb=11-4&oh=01_Q5Aa4wGWo-Nwgl_CalUntxWjrPHaNoJRFYE9IaJ9yNqIUBl1yQ&oe=6A44F9D5&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.409	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00btr54d8238aq0p	6281237461709@s.whatsapp.net	Roti Paz	https://pps.whatsapp.net/v/t61.24694-24/74660346_197538634772866_5772793002062261020_n.jpg?ccb=11-4&oh=01_Q5Aa4wE2GqrqbSsMlZDBoLzhYJKczesh0rxcooaFuPA0I0iU4w&oe=6A451266&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.411	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000bvr54dag4muot5	628174701005@s.whatsapp.net	T. M. O Coffee Bali	https://pps.whatsapp.net/v/t61.24694-24/166729455_381355306876813_9158988674478991932_n.jpg?ccb=11-4&oh=01_Q5Aa4wEJ5cZz82k8teRb2oTq4YiaC7_X31iYsykfBdcZiBG45w&oe=6A4509CD&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.412	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00air54d5m77rvya	6281339614110@s.whatsapp.net	The Bluejay Café	https://pps.whatsapp.net/v/t61.24694-24/257623393_3221260428111219_531312892167817041_n.jpg?ccb=11-4&oh=01_Q5Aa4wHO3vHs7VMceoT_nzbmoZSfwZ_-a-BQX3nXCus61CkviQ&oe=6A45076E&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:50.983	2026-06-21 14:37:53.414	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000byr54d3n2u0rfy	6285792571628@s.whatsapp.net	Kongko Coffee	https://pps.whatsapp.net/v/t61.24694-24/718480724_1565997301765940_9891900688647888_n.jpg?ccb=11-4&oh=01_Q5Aa4wGDHSIjJrB__21YDWmdLRP7KzsdvstlINscezZstzTMcw&oe=6A44F99D&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.415	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c1r54dulahon09	6287787755216@s.whatsapp.net	Core Coffee Lab and Retail	https://pps.whatsapp.net/v/t61.24694-24/311703342_437459415255206_8561049212713780576_n.jpg?ccb=11-4&oh=01_Q5Aa4wH0B6_SbF6LtdC1QlLz-ib5MZRuxRl3XX2lJu0QuVnSeA&oe=6A4508DB&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.418	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000c9r54d3qa3wjgp	6281239390607@s.whatsapp.net	Wahana Wisata Sambhrama Ashram	https://pps.whatsapp.net/v/t61.24694-24/661614727_850368624822796_4657478285117824018_n.jpg?ccb=11-4&oh=01_Q5Aa4wFT_jvMuuw6HPDyyG9nv8OUImZRoy4hprTj2lCc4A21NA&oe=6A4515F8&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:50.983	2026-06-21 14:37:53.419	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00awr54d0wsfdmoq	6287862282757@s.whatsapp.net	Phil's And Wayan Bar	https://pps.whatsapp.net/v/t61.24694-24/537697360_26283628437965719_6493896837182880382_n.jpg?ccb=11-4&oh=01_Q5Aa4wFGfB8lk4kW-6Evn_Z-r8ZjGuUWX8qmM-NYyUYz23Xm9Q&oe=6A45189E&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.42	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cgr54dhethqjxq	6285100619419@s.whatsapp.net	Mandailing Estate Coffee	https://pps.whatsapp.net/v/t61.24694-24/534423992_1199265165450052_8331355301967479468_n.jpg?ccb=11-4&oh=01_Q5Aa4wEIyimnWK9HaYJMA4VzgPUV2FLkHQi7-aFX49GsabH1IQ&oe=6A4519E7&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cir54dl7ewdwwt	628123900382@s.whatsapp.net	Bali Akah Bonsai Class	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b5r54drx9aur0g	6281805873888@s.whatsapp.net	Baker's Corner Popular Deli Canggu	https://pps.whatsapp.net/v/t61.24694-24/464362256_539863025452191_7143809284871597542_n.jpg?ccb=11-4&oh=01_Q5Aa4wGPXrtrjSIlHtkM4Obma_MRvMF6olJF8mgplI3Il5QIzA&oe=6A4500DB&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000clr54dnm2udsnm	628113951501@s.whatsapp.net	Bali Buda Canggu	https://pps.whatsapp.net/v/t61.24694-24/518078758_732194609414584_6710045804045597707_n.jpg?ccb=11-4&oh=01_Q5Aa4wH10YHJowdMXAAaep0yJ1OD_xAdO_EXfewEBwSMkzSBQw&oe=6A4512E8&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00b8r54db52d34jb	6281339661705@s.whatsapp.net	Sobat Coffee & Eatery	https://pps.whatsapp.net/v/t61.24694-24/646860913_1714239379627971_6388187782619561154_n.jpg?ccb=11-4&oh=01_Q5Aa4wHhTJ0xMZTei9geRi-aR3APT0r6p81LN7uvWMVdi-Z04A&oe=6A44F8C0&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cpr54dffkbjvp1	6282144058003@s.whatsapp.net	Are Roti Bakar	https://pps.whatsapp.net/v/t61.24694-24/437939361_823691023023642_7336015048361660293_n.jpg?ccb=11-4&oh=01_Q5Aa4wEotsVrHatistGVdiozIs8t_QlvppZoYUWZyllnTx-75g&oe=6A4502F5&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bcr54dikjly78z	6285936720149@s.whatsapp.net	Loka coffee	https://pps.whatsapp.net/v/t61.24694-24/677757356_907016422351341_3971368358973665766_n.jpg?ccb=11-4&oh=01_Q5Aa4wHPUNSvVMw2WFkGfDgpXrOO3ipUnqUMF2iLLJKy3XqFOA&oe=6A450325&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.424	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000csr54ddwuoz7xm	628164701597@s.whatsapp.net	Bali Mini Golf	https://pps.whatsapp.net/v/t61.24694-24/342325468_6319938801403945_631764815868622644_n.jpg?ccb=11-4&oh=01_Q5Aa4wFKTthV4eKGN2AEYJFr5b35ZuJ2T46xErTFH8A06BuGkg&oe=6A450957&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:50.983	2026-06-21 14:37:53.425	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bhr54dghb00wst	628113979480@s.whatsapp.net	Elephant Safari Park Lodge Bali	https://pps.whatsapp.net/v/t61.24694-24/308046007_797448711345831_3152027228934142632_n.jpg?ccb=11-4&oh=01_Q5Aa4wEfx2tsRqfxjrmssBSwWYRbxi5VeK8F-0Gvzld_CLuVkQ&oe=6A451F55&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6z00bkr54dmx7v8w8m	6281905537868@s.whatsapp.net	Bali Reptile Park	https://pps.whatsapp.net/v/t61.24694-24/115806633_3255403337853814_6728296700020310339_n.jpg?ccb=11-4&oh=01_Q5Aa4wE8qQGgi1u7425N05DQ09nL8TpKorkKxMgLKdGm2NgNuQ&oe=6A450CEE&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:37:50.983	2026-06-21 14:37:53.426	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dbr54dplqxkb88	6281238338640@s.whatsapp.net	Sayana Coffee & Nature Space	https://pps.whatsapp.net/v/t61.24694-24/571278916_2109864269773062_3740723320343132592_n.jpg?ccb=11-4&oh=01_Q5Aa4wGSEgvJIPWI31pmKtf3o4_KmGBZlrMbB3kgk64iRXfwVA&oe=6A452343&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dhr54d149t2ccp	6281934306268@s.whatsapp.net	Coffee Qita	\N	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dkr54d0ydjtfzd	6287730785888@s.whatsapp.net	Outside Drinkery Bali	https://pps.whatsapp.net/v/t61.24694-24/152332529_480474316487290_4044082774481208502_n.jpg?ccb=11-4&oh=01_Q5Aa4wHF7Yi9P71VXSY4k6CZPpYkeRNr3rfDb4Q3ed-6oDHYZA&oe=6A44FF2F&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00klr54dex2o98h9	6287860202653@s.whatsapp.net	Kelwin Shen	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y0094r54dq2q1uelk	6281353058012@s.whatsapp.net	fernando	https://pps.whatsapp.net/v/t61.24694-24/684136542_1015621701020077_6187639042816022122_n.jpg?ccb=11-4&oh=01_Q5Aa4wEi7WFeDayI-orBp3D_sQbrnUQCCzg6z4XTfVZdVF5DRA&oe=6A44FF4E&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000d8r54dqdh1e2cs	6281284872275@s.whatsapp.net	Revolver Espresso Canggu	https://pps.whatsapp.net/v/t61.24694-24/675505571_1534271061747097_7339012197352915801_n.jpg?ccb=11-4&oh=01_Q5Aa4wHIWbUIz1aZPjv3mo9QiYSmUbqUSJE1Ja3qVkO06WXP3Q&oe=6A44FE9D&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.43	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dar54d01af9y0n	6281337931045@s.whatsapp.net	Ubud Sunset Pool Bar	https://pps.whatsapp.net/v/t61.24694-24/473412656_652891904143831_8830790293542975898_n.jpg?ccb=11-4&oh=01_Q5Aa4wG1H1LMSDYUTXhvrj_w3Mv6mRf8W4TM0ggRqlXQ9Kymdw&oe=6A451D69&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:50.983	2026-06-21 14:37:53.431	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dgr54dq54whqnk	6281299666088@s.whatsapp.net	si cepat	https://pps.whatsapp.net/v/t61.24694-24/157586466_895062377991649_3766664292285622262_n.jpg?ccb=11-4&oh=01_Q5Aa4wEBZlGWjimYbgSqIqdtgWoWlyxwzHnGZIPf-uuGKsXzIg&oe=6A44F4C2&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000dmr54d0g88q1w3	6281389902199@s.whatsapp.net	Brorey	https://pps.whatsapp.net/v/t61.24694-24/667329112_1575045230710027_9017767813482809351_n.jpg?ccb=11-4&oh=01_Q5Aa4wEA_O6ICdJL8BSk4bKyT5wklgxMZmHa9Ae2qlqgA7D9BA&oe=6A44F625&_nc_sid=5e03e0&_nc_cat=101	2026-06-21 14:37:50.983	2026-06-21 14:37:53.432	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1n00kyr54dek0cf6zl	6285746999067@s.whatsapp.net	arifintjong7	https://pps.whatsapp.net/v/t61.24694-24/593259052_1515301653058175_3521611244679895054_n.jpg?ccb=11-4&oh=01_Q5Aa4wHqjRy85-I1_msdMKun7xLO3dBGGKV9T-a-r_CzIXD0gQ&oe=6A44F65E&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00l7r54d5ngb4y14	6285770338305@s.whatsapp.net	Octaviadewiputu	https://pps.whatsapp.net/v/t61.24694-24/627356075_1235755785167201_7821047363548964008_n.jpg?ccb=11-4&oh=01_Q5Aa4wFXmombDnIl-n0KAgnFlvVi6tGT1qy2N5D4y4Nf6gkAVA&oe=6A451C25&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lir54ddafwprfo	628813568297@s.whatsapp.net	Raya	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lvr54d234mh3vf	6283851306418@s.whatsapp.net	Monster 👽	https://pps.whatsapp.net/v/t61.24694-24/724445698_1350592313615899_6438766853611300912_n.jpg?ccb=11-4&oh=01_Q5Aa4wFwfmQEE_vJgdiMiwjCK0bWP9ZP4mz4rCE5vVFQbVsyJQ&oe=6A450625&_nc_sid=5e03e0&_nc_cat=107	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d6y009er54d8rmgbazu	6282247107601@s.whatsapp.net	Dhiyo	https://pps.whatsapp.net/v/t61.24694-24/589278896_1003970082151914_8262235149270470238_n.jpg?ccb=11-4&oh=01_Q5Aa4wFMCvXkXKyL2DbMpO5hDjNjepN4NN0r3wB0_ESxFRyAcQ&oe=6A44FB75&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:50.983	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mkr54de33tm3nt	6281330891491@s.whatsapp.net	陈玲	https://pps.whatsapp.net/v/t61.24694-24/678722231_1519126932893260_8678722522890148963_n.jpg?ccb=11-4&oh=01_Q5Aa4wETXEHAU1dHdZ8VlLdjU6T-oZQ3IcHby9AcfOZf71VwyA&oe=6A451687&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5fh500ubr54d78p7vprj	120363402073736990@g.us	Paradapp Community	\N	2026-06-21 14:37:53.945	2026-06-21 14:37:54.57	23d8699a-16ab-4406-9e59-9c374964b83c
cmr92uz4i014kr54d8byhqgra	167929614229740@lid	Eka	https://pps.whatsapp.net/v/t61.24694-24/657241080_1608432016888184_7445400860340164159_n.jpg?ccb=11-4&oh=01_Q5Aa5AHGUhm_ghc2iJzSwo6Vcb98HS6F-CCMJ13f_i3tVXLtfA&oe=6A5952DC&_nc_sid=5e03e0&_nc_cat=105	2026-07-06 10:28:53.202	2026-07-06 23:43:06.843	23d8699a-16ab-4406-9e59-9c374964b83c
cmqp2yxug00vrr54dudaoqvsr	150109325156451@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/646453171_2851793515155681_5030346446079241500_n.jpg?ccb=11-4&oh=01_Q5Aa5QG7rpo0ljSSzSlHJauds_DyojdBb4gXv2eDkmNV0TtGsw&oe=6A8E721C&_nc_sid=5e03e0&_nc_cat=109	2026-06-22 10:36:34.648	2026-08-16 05:05:54.177	23d8699a-16ab-4406-9e59-9c374964b83c
cmqvvtuqa010yr54da8ipksap	215916797276341@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/534426905_1706279884026811_2221625910977327653_n.jpg?ccb=11-4&oh=01_Q5Aa4wFQzdPv1yrwV30u91FkDKJ3fPZjFSQGFjJ1lHeYXwy8gA&oe=6A4CAB3C&_nc_sid=5e03e0&_nc_cat=111	2026-06-27 04:51:03.25	2026-06-27 07:47:35.28	23d8699a-16ab-4406-9e59-9c374964b83c
cmrcmszu10188r54d1djydpkh	275509434953825@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/749755948_1053328513871898_7229421873944998698_n.jpg?ccb=11-4&oh=01_Q5Aa5AFVyygMpSHqTGUujQoioShQuZ_q-D6yJXLoy4vo0IBwgw&oe=6A6C3792&_nc_sid=5e03e0&_nc_cat=109	2026-07-08 22:10:31.658	2026-07-21 06:19:03.144	23d8699a-16ab-4406-9e59-9c374964b83c
cmrz5qboz01cor54du20asgjo	202529266774216@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/675012756_2549568098789563_6866907802598595574_n.jpg?ccb=11-4&oh=01_Q5Aa5QFDG_bW7qJPCjsQcm0R4JQoB4tFAq0Bdj_gsvfxSAz9kw&oe=6A87A48B&_nc_sid=5e03e0&_nc_cat=109	2026-07-24 16:31:15.633	2026-08-11 02:45:22.57	23d8699a-16ab-4406-9e59-9c374964b83c
cmr1cj4rp012er54dhz140gz3	110462297440377@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/685956857_28333646349554588_4595046174841894201_n.jpg?ccb=11-4&oh=01_Q5Aa5AGOtfeEqp39gby0Z7BhQTThKdQTydfliSeIt7HPJ4DQKQ&oe=6A691D0F&_nc_sid=5e03e0&_nc_cat=100	2026-07-01 00:37:27.397	2026-07-19 00:53:24.35	23d8699a-16ab-4406-9e59-9c374964b83c
cmqpzf33200w6r54dtbcu8s55	257290183651425@lid	\N	\N	2026-06-23 01:44:55.646	2026-08-09 09:02:59.358	23d8699a-16ab-4406-9e59-9c374964b83c
cmrj7x22q0198r54d1w9xkvt7	72507671482583@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/638764872_1586174273132815_7036950469232716908_n.jpg?ccb=11-4&oh=01_Q5Aa5AFGTiiQH6bJNnN9knetv-OVIGEQmVnfqz4FB994Ob-h_w&oe=6A69908A&_nc_sid=5e03e0&_nc_cat=103	2026-07-13 12:48:10.178	2026-07-19 06:02:13.065	23d8699a-16ab-4406-9e59-9c374964b83c
cmspjh1op0040of4cdfo8trmp	148902925832317@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/696561078_2250035295836882_7759812432912182418_n.jpg?ccb=11-4&oh=01_Q5Aa5QGzHnFf-pKOlIfptQ2d7gL-fRcmbMukbzld-w3iuK3Yag&oe=6A8BF7C4&_nc_sid=5e03e0&_nc_cat=107	2026-08-12 03:37:57.962	2026-08-14 07:58:55.966	23d8699a-16ab-4406-9e59-9c374964b83c
cmr6d96kn013jr54d30fno4na	242773093556413@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/714063134_904463392275972_4159829912210203184_n.jpg?ccb=11-4&oh=01_Q5Aa5QE5pp7lx0dn_DjG96hFLs8KClLAG-wNW7jAGbJUuhKBiQ&oe=6A8C7E43&_nc_sid=5e03e0&_nc_cat=100	2026-07-04 12:56:33.671	2026-08-14 20:45:24.745	23d8699a-16ab-4406-9e59-9c374964b83c
cms4j2nl801dor54dp5evhtnd	100768606601424@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/699240009_1553836436231219_1080993850412621696_n.jpg?ccb=11-4&oh=01_Q5Aa5AFaaWhD07nuKDO8VS-f0ii5FvXqltTR19PuHok9Wko9GA&oe=6A758126&_nc_sid=5e03e0&_nc_cat=100	2026-07-28 10:43:36.812	2026-07-28 10:43:36.812	23d8699a-16ab-4406-9e59-9c374964b83c
cmr8nmi0i0147r54d4vkn07j5	30443231572123@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/534417096_1340065974552958_1082547426114462802_n.jpg?ccb=11-4&oh=01_Q5Aa5QHBSkH4CcUvh0i55X70PLAvhiJLIuht-29dvc_LAjRVnQ&oe=6A8E04F0&_nc_sid=5e03e0&_nc_cat=105	2026-07-06 03:22:23.539	2026-08-15 23:27:27.595	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5d7000cxr54di9i87t7w	6281357842119@s.whatsapp.net	Bang Gris (Wika)	https://pps.whatsapp.net/v/t61.24694-24/724493091_1371672091693711_9010827476095899663_n.jpg?ccb=11-4&oh=01_Q5Aa4wHC87_DwiI9AoK_Sf7d9R5tVHIaVuWzzv72WzbMvaSQ4g&oe=6A451D29&_nc_sid=5e03e0&_nc_cat=105	2026-06-21 14:37:50.983	2026-06-21 14:37:53.444	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lcr54dd95aojsz	6285175081135@s.whatsapp.net	Kevin	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m3r54d0zkksxcb	62817344649@s.whatsapp.net	Ode | GRPL	https://pps.whatsapp.net/v/t61.24694-24/56879468_2311240079088043_8407023359476367360_n.jpg?ccb=11-4&oh=01_Q5Aa4wGN1ADkUBZcfTKqhd-sbEodxDiFp2qg---H5p4Nml354g&oe=6A451077&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mar54dax18vjiw	6285737437138@s.whatsapp.net	Krisna	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mcr54drfdc8sn0	6281215419170@s.whatsapp.net	Mr. R	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mfr54dtdd98x0t	6282124022467@s.whatsapp.net	namerror	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006rr54dncndoa9f	120363402874234431@g.us	Paradapp Community	\N	2026-06-21 14:36:50.94	2026-06-21 14:37:54.569	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqbawqu00wkr54d3n1y92bv	3792623927460@lid	\N	\N	2026-06-23 07:17:36.198	2026-06-23 07:17:36.198	23d8699a-16ab-4406-9e59-9c374964b83c
cmrctunc2018gr54dv3ip2cxt	268577357737990@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/677925940_1711387683429971_4381939097800635893_n.jpg?ccb=11-4&oh=01_Q5Aa5QGUut7mUeqT5czB46JHd0iJXEONuPiR643SbPFsNjnMYw&oe=6A87111E&_nc_sid=5e03e0&_nc_cat=110	2026-07-09 01:27:46.082	2026-08-10 16:44:15.774	23d8699a-16ab-4406-9e59-9c374964b83c
cmr1s3vsb012or54d2rcux0pg	210556610973819@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/699263531_1340159954363636_5290389223428780974_n.jpg?ccb=11-4&oh=01_Q5Aa5AE9zkvnAXjxjL4ByQCI0WoONsSr1MHDNKoczWrE7i7nWw&oe=6A68415B&_nc_sid=5e03e0&_nc_cat=108	2026-07-01 07:53:29.771	2026-07-18 07:45:10.956	23d8699a-16ab-4406-9e59-9c374964b83c
cmrzsu9sy01cur54dnq2kfzsj	44676350504981@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/757112451_1404168038246242_4643169457164952809_n.jpg?ccb=11-4&oh=01_Q5Aa5AGPXq2UXczbZ_CxD_ERdgoKH3xcftEhPWlxn8x9sjv6ww&oe=6A76CCC5&_nc_sid=5e03e0&_nc_cat=108	2026-07-25 03:18:10.978	2026-07-29 08:39:17.931	23d8699a-16ab-4406-9e59-9c374964b83c
cmsa4ry3e0003of4ci360pg98	132250683359359@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/677242100_4476372352637659_5451456012741211409_n.jpg?ccb=11-4&oh=01_Q5Aa5AHULVTYlEJxq885RGOuNSj3QZwgSRnxKCYkciZsLv5INw&oe=6A7ACFC5&_nc_sid=5e03e0&_nc_cat=109	2026-08-01 08:49:59.64	2026-08-01 08:49:59.64	23d8699a-16ab-4406-9e59-9c374964b83c
cmsh9ygax001rof4c5yjrqlak	136717449298004@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/677514850_2862300497437163_6910893534686936960_n.jpg?ccb=11-4&oh=01_Q5Aa5QEgZ_LvaRwnFbIWMXn--iIt93x0G8O1c9WQnKY50aBsvA&oe=6A814CDD&_nc_sid=5e03e0&_nc_cat=109	2026-08-06 08:49:24.489	2026-08-06 08:49:24.489	23d8699a-16ab-4406-9e59-9c374964b83c
cmr92wlsc015kr54dnekehrug	113739474936038@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/677831967_4108402272785168_7281719807353740360_n.jpg?ccb=11-4&oh=01_Q5Aa5AGDMkO9O3mOr-Kk7ZjA6Oe3Z7QA9egwxPqm0Q_BtakDtg&oe=6A588338&_nc_sid=5e03e0&_nc_cat=104	2026-07-06 10:30:09.228	2026-07-06 10:30:19.658	23d8699a-16ab-4406-9e59-9c374964b83c
cmsra2xys004kof4c45kv5c5s	195370294472892@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/700372229_2061241481157825_3297099214864420077_n.jpg?ccb=11-4&oh=01_Q5Aa5QHa8ARXwFOAUb72YhEdt3rpj8dAcGE_JpNaICGPGrNEQA&oe=6A8AAFE1&_nc_sid=5e03e0&_nc_cat=102	2026-08-13 08:50:35.764	2026-08-13 08:50:35.764	23d8699a-16ab-4406-9e59-9c374964b83c
cmqo8cj6c00vlr54dlo1wrx0u	112395133432025@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/646480168_1753065289272159_6798018511873939318_n.jpg?ccb=11-4&oh=01_Q5Aa5QGm74JMwEdZ0U2S6crj1zHwZW-oGjr-eEoTqiXcYcDwBw&oe=6A8B3EF7&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 20:19:20.724	2026-08-13 20:12:44.11	23d8699a-16ab-4406-9e59-9c374964b83c
cmr91jiqi014cr54d43nn7nwa	120363409068752753@g.us	Eka	\N	2026-07-06 09:51:59.13	2026-07-06 11:00:13.597	23d8699a-16ab-4406-9e59-9c374964b83c
cmrkgtk1x019ir54dx4dy03cu	16347299848379@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/699555215_919411334523624_4616936835521038764_n.jpg?ccb=11-4&oh=01_Q5Aa5AFeCOwvo2jhTv8PQnuySIa_hGFrX-g93EuZpHDSiY0GbA&oe=6A63012A&_nc_sid=5e03e0&_nc_cat=111	2026-07-14 09:45:09.573	2026-07-14 09:45:09.573	23d8699a-16ab-4406-9e59-9c374964b83c
cmrm46niq019qr54dxz7h66bs	182549380866059@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/743817232_2103687820213517_8120876462940220325_n.jpg?ccb=11-4&oh=01_Q5Aa5AHPE7Y32kHmvMZKM_QMXLpK9YNvXjOYqLKoZgzJVMKA6g&oe=6A64A27A&_nc_sid=5e03e0&_nc_cat=102	2026-07-15 13:26:57.938	2026-07-15 13:26:57.938	23d8699a-16ab-4406-9e59-9c374964b83c
cmqu5zmny010br54dq1stwlcx	241042825703612@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/722908536_1259005633959303_270829240945848795_n.jpg?ccb=11-4&oh=01_Q5Aa5AF1qaz4zQSIhNZthwWlfYFQ0Fn__t2L_WP1Wyj3CVrLfw&oe=6A64F8E0&_nc_sid=5e03e0&_nc_cat=103	2026-06-25 23:59:56.542	2026-07-15 21:03:45.459	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00l6r54d3d53dd4i	6287853847141@s.whatsapp.net	Ari Bisma	https://pps.whatsapp.net/v/t61.24694-24/676896720_749399084896938_1992922249110227854_n.jpg?ccb=11-4&oh=01_Q5Aa4wFN4x_ZVQOypCvtJKIEHVkNPiG4pgjQQLM5j-tK_rO9hg&oe=6A452515&_nc_sid=5e03e0&_nc_cat=100	2026-06-21 14:37:52.091	2026-06-21 14:37:53.445	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00ldr54d0wv3nfbs	6285792494609@s.whatsapp.net	ngurah aditya	https://pps.whatsapp.net/v/t61.24694-24/534418754_4276783499232014_3056101976337887749_n.jpg?ccb=11-4&oh=01_Q5Aa4wGixoCS1crK3wL_S_6rplq8U74zKl3fdJwzm5E3M8daPg&oe=6A44F37B&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:52.091	2026-06-21 14:37:53.446	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lnr54dlyjxoy8p	6282331103769@s.whatsapp.net	OkyTresia🐼	https://pps.whatsapp.net/v/t61.24694-24/470807375_942651587804705_7893706399113193537_n.jpg?ccb=11-4&oh=01_Q5Aa4wGpRT0fc_MDslyDzpC7s0xpRZInxskBRZDghBbWrERG7A&oe=6A451FB3&_nc_sid=5e03e0&_nc_cat=109	2026-06-21 14:37:52.091	2026-06-21 14:37:53.447	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lqr54d5fmpj0l9	6287866104495@s.whatsapp.net	Alam	https://pps.whatsapp.net/v/t61.24694-24/670896455_2373499849805113_3057959738201768264_n.jpg?ccb=11-4&oh=01_Q5Aa4wG78EXhGFjD2x1nBHoi_xe6Sb83yHUi5_JOYViPN8v9Fg&oe=6A450B78&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00ltr54dcunu6q4u	6289681301850@s.whatsapp.net	Demmy Wenanda	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00lwr54d4np7g2en	639814270009@s.whatsapp.net	Natalie Hershlag	https://pps.whatsapp.net/v/t61.24694-24/595558608_1017532920724468_5124117749810514623_n.jpg?ccb=11-4&oh=01_Q5Aa4wGuK7JqGEso-Xe4AcIAVy6CELh6PHreDl9dpXSeZbdsgA&oe=6A4520A1&_nc_sid=5e03e0&_nc_cat=108	2026-06-21 14:37:52.091	2026-06-21 14:37:53.448	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m4r54dtgxyqs68	6281938801986@s.whatsapp.net	Santi	https://pps.whatsapp.net/v/t61.24694-24/506222763_670619555975394_4672502436271189168_n.jpg?ccb=11-4&oh=01_Q5Aa4wFEM2KIC5rTKmZnTJAhc2r1T_hWUDrUIzkw4F3cekpCWA&oe=6A451245&_nc_sid=5e03e0&_nc_cat=104	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1o00m6r54dcomtr53z	6285559660233@s.whatsapp.net	Rifa	\N	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00m9r54ddti1d97d	6287818159392@s.whatsapp.net	KBhaga	https://pps.whatsapp.net/v/t61.24694-24/420073523_2205450423166364_2997577261946165277_n.jpg?ccb=11-4&oh=01_Q5Aa4wFJEtXriMpFu2KlSv_-irmiWOfkDAnlw0nHGSxFlnRgJg&oe=6A44F6EB&_nc_sid=5e03e0&_nc_cat=110	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mir54ddo3ffa32	62895415850555@s.whatsapp.net	MURR	https://pps.whatsapp.net/v/t61.24694-24/687949571_1028440353041120_2299006254358196829_n.jpg?ccb=11-4&oh=01_Q5Aa4wGwBoi-alMwFMzPrZnp-4sibBds5H46wIiXMGsqO_xLwA&oe=6A451A23&_nc_sid=5e03e0&_nc_cat=102	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5e1p00mmr54dih2wg7ce	6281338896416@s.whatsapp.net	Adhimastra I Ketut	https://pps.whatsapp.net/v/t61.24694-24/415403440_896220465218096_7621766420388828864_n.jpg?ccb=11-4&oh=01_Q5Aa4wGc9zFTHNxbUo6V9P_FdrIifP5fxakOHZ9opUCzlGMwzg&oe=6A451ECE&_nc_sid=5e03e0&_nc_cat=103	2026-06-21 14:37:52.091	2026-06-21 14:37:53.449	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw42v0006sr54darpyszi3	120363417652295399@g.us	Discussion Chat	https://pps.whatsapp.net/v/t61.24694-24/685666718_1293069342953387_5496334034730015735_n.jpg?ccb=11-4&oh=01_Q5Aa4wE8UEMtnJQ2ZZOfZfQNoN_aFKuwcTSwW1gIUey4rqUqNQ&oe=6A450EE0&_nc_sid=5e03e0&_nc_cat=111	2026-06-21 14:36:50.94	2026-06-21 14:37:54.569	23d8699a-16ab-4406-9e59-9c374964b83c
cmqrfd64i00ygr54dw8szkcte	205157820317735@lid	\N	\N	2026-06-24 01:59:06.305	2026-06-24 01:59:06.305	23d8699a-16ab-4406-9e59-9c374964b83c
cmqzw7clw011yr54dtfrtw6ym	170514899316971@lid	\N	\N	2026-06-30 00:12:37.652	2026-06-30 00:12:37.652	23d8699a-16ab-4406-9e59-9c374964b83c
cms0d79a601cwr54d2md91fs5	209379706024155@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/658299936_949218088206821_592912003019131589_n.jpg?ccb=11-4&oh=01_Q5Aa5QFcmp0QVE2DeoseT9SWMXkIvOIiLxWkVsTsk2CnTQRIuw&oe=6A8A7E2F&_nc_sid=5e03e0&_nc_cat=103	2026-07-25 12:48:09.129	2026-08-13 07:04:59.309	23d8699a-16ab-4406-9e59-9c374964b83c
cmr8gyr9d0145r54d7g9zupnk	30679035330708@lid	\N	\N	2026-07-06 00:15:58.082	2026-07-06 00:15:58.082	23d8699a-16ab-4406-9e59-9c374964b83c
cmr91jiws014er54dj61eqcc6	185486836560069@lid	\N	\N	2026-07-06 09:51:59.357	2026-07-06 09:51:59.357	23d8699a-16ab-4406-9e59-9c374964b83c
cmr1suxx0012qr54df9ufbds1	71206363468003@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/760409960_1967965293998726_3511580227880546427_n.jpg?ccb=11-4&oh=01_Q5Aa5AFnY1l_6Q41WngLwMsMaoT7YqWjfAv5XvPMu-b9CWyUzA&oe=6A7B146F&_nc_sid=5e03e0&_nc_cat=111	2026-07-01 08:14:32.244	2026-08-01 12:30:04.231	23d8699a-16ab-4406-9e59-9c374964b83c
cmr93zkwu016or54dz8fw90w5	6285117722465@s.whatsapp.net	Eka	https://pps.whatsapp.net/v/t61.24694-24/657241080_1608432016888184_7445400860340164159_n.jpg?ccb=11-4&oh=01_Q5Aa5AHGUhm_ghc2iJzSwo6Vcb98HS6F-CCMJ13f_i3tVXLtfA&oe=6A5952DC&_nc_sid=5e03e0&_nc_cat=105	2026-07-06 11:00:27.678	2026-07-06 23:43:06.559	23d8699a-16ab-4406-9e59-9c374964b83c
cmrf4m9qw018qr54d847c489b	187290823454916@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/534414830_1848004339493214_5174063895072809_n.jpg?ccb=11-4&oh=01_Q5Aa5AGT4nZeHUxCMQCL0IOYtZWFBJ_zt7b32cbHNhQaM5QG-Q&oe=6A5E1A49&_nc_sid=5e03e0&_nc_cat=110	2026-07-10 16:04:43.353	2026-07-10 16:04:43.353	23d8699a-16ab-4406-9e59-9c374964b83c
cmrlit8m0019kr54dh7sha4eb	53708666724528@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/534425641_1757073192093110_3638237882179818204_n.jpg?ccb=11-4&oh=01_Q5Aa5AEHeeohdORSzYIvIAS7_ja5GTLLsRj0CYR2nDgJgsjsbg&oe=6A6E1F3D&_nc_sid=5e03e0&_nc_cat=110	2026-07-15 03:28:40.151	2026-07-22 17:53:07.475	23d8699a-16ab-4406-9e59-9c374964b83c
cmrwsd5op01ccr54dt87go9u7	172357071151321@lid	\N	\N	2026-07-23 00:41:33.961	2026-07-23 00:41:33.961	23d8699a-16ab-4406-9e59-9c374964b83c
cmskg8d2q002fof4cga27vvpb	10205597331554@lid	\N	https://pps.whatsapp.net/v/t61.24694-24/657055199_27564771666538929_510464447073921074_n.jpg?ccb=11-4&oh=01_Q5Aa5QESE3Vb4aznwwifjYHfiUOqzp2a8_wJNcFfjkjSi1cU2w&oe=6A845460&_nc_sid=5e03e0&_nc_cat=109	2026-08-08 14:08:23.09	2026-08-08 14:08:23.09	23d8699a-16ab-4406-9e59-9c374964b83c
\.


--
-- Data for Name: Dify; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Dify" (id, enabled, "botType", "apiUrl", "apiKey", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "instanceId", description, "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: DifySetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."DifySetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "createdAt", "updatedAt", "difyIdFallback", "instanceId", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: Evoai; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Evoai" (id, enabled, description, "agentUrl", "apiKey", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "splitMessages", "timePerChar", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: EvoaiSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."EvoaiSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "splitMessages", "timePerChar", "createdAt", "updatedAt", "evoaiIdFallback", "instanceId") FROM stdin;
\.


--
-- Data for Name: EvolutionBot; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."EvolutionBot" (id, enabled, description, "apiUrl", "apiKey", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "instanceId", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: EvolutionBotSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."EvolutionBotSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "createdAt", "updatedAt", "botIdFallback", "instanceId", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: Flowise; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Flowise" (id, enabled, description, "apiUrl", "apiKey", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "instanceId", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: FlowiseSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."FlowiseSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "createdAt", "updatedAt", "flowiseIdFallback", "instanceId", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: Instance; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Instance" (id, name, "connectionStatus", "ownerJid", "profilePicUrl", integration, number, token, "clientName", "createdAt", "updatedAt", "profileName", "businessId", "disconnectionAt", "disconnectionObject", "disconnectionReasonCode") FROM stdin;
23d8699a-16ab-4406-9e59-9c374964b83c	paradapp-worker	open	6281337887161@s.whatsapp.net	https://pps.whatsapp.net/v/t61.24694-24/646453171_2851793515155681_5030346446079241500_n.jpg?ccb=11-4&oh=01_Q5Aa5QG897WiaHd0Ss6vf1-xJDdXmNmFfSgIF9rZO3vWcYHWvg&oe=6A8E39DC&_nc_sid=5e03e0&_nc_cat=109	WHATSAPP-BAILEYS	\N	CA132CFE-596F-4555-ADBE-F9AA72D038DC	evolution_exchange	2026-06-21 14:35:55.375	2026-08-16 01:21:36.794	Paradapp	\N	\N	\N	\N
\.


--
-- Data for Name: IntegrationSession; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."IntegrationSession" (id, "sessionId", "remoteJid", "pushName", status, "awaitUser", "createdAt", "updatedAt", "instanceId", parameters, context, "botId", type) FROM stdin;
\.


--
-- Data for Name: IsOnWhatsapp; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."IsOnWhatsapp" (id, "remoteJid", "jidOptions", "createdAt", "updatedAt", lid) FROM stdin;
cmqnw42va006xr54d1g8tuw3r	0@s.whatsapp.net	0@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:36:50.95	2026-06-21 14:36:50.95	\N
cmqnw5dq000drr54d5pe1w6nd	628113889980@s.whatsapp.net	628113889980@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.171	2026-06-21 14:37:51.171	\N
cmqnw5dq600dsr54dmlz23y7v	6281337311604@s.whatsapp.net	6281337311604@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.171	2026-06-21 14:37:51.171	\N
cmqnw5drg00dtr54dujeolywm	6289654812465@s.whatsapp.net	6289654812465@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.178	2026-06-21 14:37:51.178	\N
cmqnw5dri00dur54df2ec0riw	62818434404@s.whatsapp.net	62818434404@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.178	2026-06-21 14:37:51.178	\N
cmqnw5drj00dvr54duaxwqvw5	6281999526413@s.whatsapp.net	6281999526413@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.179	2026-06-21 14:37:51.179	\N
cmqnw5dro00dxr54dvwn4vvxc	6287824505018@s.whatsapp.net	6287824505018@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.192	2026-06-21 14:37:51.192	\N
cmqnw5drp00dyr54d3onshyau	6281259602211@s.whatsapp.net	6281259602211@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.199	2026-06-21 14:37:51.199	\N
cmqnw5drp00dzr54dusyjkbig	6281907978295@s.whatsapp.net	6281907978295@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.21	2026-06-21 14:37:51.21	\N
cmqnw5drq00e0r54d8fcpl7ir	6281236668399@s.whatsapp.net	6281236668399@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.21	2026-06-21 14:37:51.21	\N
cmqnw5drr00e1r54dpbyq1jk1	6287865534999@s.whatsapp.net	6287865534999@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.211	2026-06-21 14:37:51.211	\N
cmqnw5drs00e2r54d0t9se4jj	6287860111339@s.whatsapp.net	6287860111339@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.221	2026-06-21 14:37:51.221	\N
cmqnw5drs00e3r54dzzllcji0	6281280015758@s.whatsapp.net	6281280015758@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.224	2026-06-21 14:37:51.224	\N
cmqnw5drt00e4r54da53lnpcd	6281283386641@s.whatsapp.net	6281283386641@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.232	2026-06-21 14:37:51.232	\N
cmqnw5dru00e5r54dyknsvehj	6285624153785@s.whatsapp.net	6285624153785@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.234	2026-06-21 14:37:51.234	\N
cmqnw5drv00e6r54d4is498ng	6281617575757@s.whatsapp.net	6281617575757@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.242	2026-06-21 14:37:51.242	\N
cmqnw5drw00e7r54dirt4ej08	6283124392266@s.whatsapp.net	6283124392266@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.25	2026-06-21 14:37:51.25	\N
cmqnw5drw00e8r54dhdrsg9mb	6285100181011@s.whatsapp.net	6285100181011@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.251	2026-06-21 14:37:51.251	\N
cmqnw5drx00e9r54dodr6frlp	6281246782755@s.whatsapp.net	6281246782755@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.26	2026-06-21 14:37:51.26	\N
cmqnw5drx00ear54dsymbhyc8	6281353972746@s.whatsapp.net	6281353972746@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.262	2026-06-21 14:37:51.262	\N
cmqnw5dry00ebr54d0eo6lo6i	6281239326883@s.whatsapp.net	6281239326883@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.262	2026-06-21 14:37:51.262	\N
cmqnw5drz00ecr54dvfi9lsep	628888088188@s.whatsapp.net	628888088188@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.263	2026-06-21 14:37:51.263	\N
cmqnw5ds000edr54dyoyu12ed	6281246149184@s.whatsapp.net	6281246149184@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.268	2026-06-21 14:37:51.268	\N
cmqnw5ds000eer54dkpdah4gm	6281236111044@s.whatsapp.net	6281236111044@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.281	2026-06-21 14:37:51.281	\N
cmqnw5ds100efr54dyzfj9w2c	6287703054619@s.whatsapp.net	6287703054619@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.281	2026-06-21 14:37:51.281	\N
cmqnw5ds200egr54dvxlwttbl	6281338337474@s.whatsapp.net	6281338337474@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.281	2026-06-21 14:37:51.281	\N
cmqnw5ds300ehr54dmzq9hvbq	6282147909060@s.whatsapp.net	6282147909060@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.287	2026-06-21 14:37:51.287	\N
cmqnw5ds400eir54ddift927o	6282144213431@s.whatsapp.net	6282144213431@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.293	2026-06-21 14:37:51.293	\N
cmqnw5ds400ejr54du2u8twaf	6281138017826@s.whatsapp.net	6281138017826@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.299	2026-06-21 14:37:51.299	\N
cmqnw5ds500ekr54dcvei8tq2	6287822841600@s.whatsapp.net	6287822841600@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.299	2026-06-21 14:37:51.299	\N
cmqnw5ds600elr54drjb3oi45	6285855551986@s.whatsapp.net	6285855551986@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.304	2026-06-21 14:37:51.304	\N
cmqnw5ds700emr54d8eugo8as	6282359507456@s.whatsapp.net	6282359507456@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.311	2026-06-21 14:37:51.311	\N
cmqnw5ds800enr54doxp4sx6h	6285754837440@s.whatsapp.net	6285754837440@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.315	2026-06-21 14:37:51.315	\N
cmqnw5ds800eor54dktxsf2of	6281999372666@s.whatsapp.net	6281999372666@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.315	2026-06-21 14:37:51.315	\N
cmqnw5ds900epr54duuygo2o9	6287860649060@s.whatsapp.net	6287860649060@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.327	2026-06-21 14:37:51.327	\N
cmqnw5dsa00eqr54ditfgx3gl	6282144147382@s.whatsapp.net	6282144147382@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.33	2026-06-21 14:37:51.33	\N
cmqnw5dsa00err54dfdikruol	6285714425629@s.whatsapp.net	6285714425629@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.33	2026-06-21 14:37:51.33	\N
cmqnw5dsb00esr54d8n9c89dg	6281337380237@s.whatsapp.net	6281337380237@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.333	2026-06-21 14:37:51.333	\N
cmqnw5dsc00etr54d98h5wmne	6281353168585@s.whatsapp.net	6281353168585@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.336	2026-06-21 14:37:51.336	\N
cmqnw5dsc00eur54d8dacoy64	62895630478421@s.whatsapp.net	62895630478421@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.339	2026-06-21 14:37:51.339	\N
cmqnw5dsd00evr54d9oc104hj	6281916395087@s.whatsapp.net	6281916395087@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.341	2026-06-21 14:37:51.341	\N
cmqnw5dse00ewr54d0h2zh0qb	6282146441346@s.whatsapp.net	6282146441346@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.341	2026-06-21 14:37:51.341	\N
cmqnw5dsf00exr54ds7tecn2p	6287861527536@s.whatsapp.net	6287861527536@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.389	2026-06-21 14:37:51.389	\N
cmqnw5dsf00eyr54dy5qi6jbf	6285237697001@s.whatsapp.net	6285237697001@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.39	2026-06-21 14:37:51.39	\N
cmqnw5dsg00ezr54d79h72g9y	6281320325965@s.whatsapp.net	6281320325965@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.396	2026-06-21 14:37:51.396	\N
cmqnw5dsg00f0r54d2zwy5lxa	6285337589474@s.whatsapp.net	6285337589474@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.396	2026-06-21 14:37:51.396	\N
cmqnw5dsh00f1r54d1aw7jait	6281999318965@s.whatsapp.net	6281999318965@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.401	2026-06-21 14:37:51.401	\N
cmqnw5dsi00f2r54dzgpg52ji	6281358627370@s.whatsapp.net	6281358627370@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.413	2026-06-21 14:37:51.413	\N
cmqnw5dsj00f3r54d20ah33mh	628112400072@s.whatsapp.net	628112400072@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.413	2026-06-21 14:37:51.413	\N
cmqnw5dsj00f4r54dcqo7ovbq	628113817755@s.whatsapp.net	628113817755@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.413	2026-06-21 14:37:51.413	\N
cmqnw5dsk00f5r54d5tooyfke	6281236876162@s.whatsapp.net	6281236876162@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.413	2026-06-21 14:37:51.413	\N
cmqnw5dsk00f6r54depwcseb1	6289619292181@s.whatsapp.net	6289619292181@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.413	2026-06-21 14:37:51.413	\N
cmqnw5dsl00f7r54do3pib48p	6285858678056@s.whatsapp.net	6285858678056@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.42	2026-06-21 14:37:51.42	\N
cmqnw5dsm00f8r54d7uzigysu	6281281608003@s.whatsapp.net	6281281608003@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.422	2026-06-21 14:37:51.422	\N
cmqnw5dsn00f9r54dl2wwxq5m	6282146841068@s.whatsapp.net	6282146841068@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.425	2026-06-21 14:37:51.425	\N
cmqnw5dsp00fdr54dmh7oq129	6281907736598@s.whatsapp.net	6281907736598@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.429	2026-06-21 14:37:51.429	\N
cmqnw5dsr00fgr54donyjvtyt	6281262457811@s.whatsapp.net	6281262457811@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.434	2026-06-21 14:37:51.434	\N
cmqnw5dsu00fkr54d3321iw2r	628999995434@s.whatsapp.net	628999995434@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.439	2026-06-21 14:37:51.439	\N
cmqnw5dsx00fnr54dvdt5ar7h	6281337226978@s.whatsapp.net	6281337226978@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.444	2026-06-21 14:37:51.444	\N
cmqnw5dt200frr54dbqxrdmde	6287786865656@s.whatsapp.net	6287786865656@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.45	2026-06-21 14:37:51.45	\N
cmqnw5dt500fvr54diyr3l36z	6281297959552@s.whatsapp.net	6281297959552@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.457	2026-06-21 14:37:51.457	\N
cmqnw5dt600fxr54dh3xrbj2e	6281353058012@s.whatsapp.net	6281353058012@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.458	2026-06-21 14:37:51.458	\N
cmqnw5dt800fzr54dwsoctukm	628553902323@s.whatsapp.net	628553902323@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.462	2026-06-21 14:37:51.462	\N
cmqnw5dt900g1r54dyyx47sce	6281315494095@s.whatsapp.net	6281315494095@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.465	2026-06-21 14:37:51.465	\N
cmqnw5dta00g3r54dd2qy8zef	628113567770@s.whatsapp.net	628113567770@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.467	2026-06-21 14:37:51.467	\N
cmqnw5dtd00g7r54di7beahbe	628113803266@s.whatsapp.net	628113803266@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.474	2026-06-21 14:37:51.474	\N
cmqnw5dtg00gbr54dirgcomjf	6287862282757@s.whatsapp.net	6287862282757@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.48	2026-06-21 14:37:51.48	\N
cmqnw5dtl00gfr54dibg3hput	6281338702266@s.whatsapp.net	6281338702266@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.484	2026-06-21 14:37:51.484	\N
cmqnw5dtq00gjr54d710q3al1	6285646915897@s.whatsapp.net	6285646915897@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.491	2026-06-21 14:37:51.491	\N
cmqnw5dtr00glr54dfdbxphp0	628170667088@s.whatsapp.net	628170667088@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.492	2026-06-21 14:37:51.492	\N
cmqnw5dtt00gnr54d64wexecx	6285792666762@s.whatsapp.net	6285792666762@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.495	2026-06-21 14:37:51.495	\N
cmqnw5dtw00grr54d2pko05t0	628111180053@s.whatsapp.net	628111180053@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.503	2026-06-21 14:37:51.503	\N
cmqnw5dty00gtr54dsnkv1g7s	6287747923290@s.whatsapp.net	6287747923290@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.504	2026-06-21 14:37:51.504	\N
cmqnw5dtz00gvr54dvgr6mnl2	6287863229639@s.whatsapp.net	6287863229639@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.504	2026-06-21 14:37:51.504	\N
cmqnw5du100gxr54d88ta8kpi	6285163196604@s.whatsapp.net	6285163196604@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.509	2026-06-21 14:37:51.509	\N
cmqnw5du200gzr54dve61tlmf	6597289468@s.whatsapp.net	6597289468@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.511	2026-06-21 14:37:51.511	\N
cmqnw5du400h2r54d3pycikzr	6281805492727@s.whatsapp.net	6281805492727@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.513	2026-06-21 14:37:51.513	\N
cmqnw5du700h6r54drgylu7ht	6285811500888@s.whatsapp.net	6285811500888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.518	2026-06-21 14:37:51.518	\N
cmqnw5du900h9r54dj025a7il	6281338878097@s.whatsapp.net	6281338878097@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.522	2026-06-21 14:37:51.522	\N
cmqnw5duj00hcr54d7eo1usb4	628113979480@s.whatsapp.net	628113979480@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.525	2026-06-21 14:37:51.525	\N
cmqnw5dul00her54dwo3pj92q	6285693933374@s.whatsapp.net	6285693933374@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.528	2026-06-21 14:37:51.528	\N
cmqnw5dum00hgr54djwuroxbw	6281999126444@s.whatsapp.net	6281999126444@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.531	2026-06-21 14:37:51.531	\N
cmqnw5duo00hir54dyu0mf8h4	628179764685@s.whatsapp.net	628179764685@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.532	2026-06-21 14:37:51.532	\N
cmqnw5dup00hkr54d5hj1ync5	6281338532651@s.whatsapp.net	6281338532651@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.537	2026-06-21 14:37:51.537	\N
cmqnw5dus00hnr54dznqkugvj	6282236609868@s.whatsapp.net	6282236609868@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.54	2026-06-21 14:37:51.54	\N
cmqnw5duv00hrr54d24c2qn5d	6282147397069@s.whatsapp.net	6282147397069@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.545	2026-06-21 14:37:51.545	\N
cmqnw5dux00htr54da2zmriz1	6282124992949@s.whatsapp.net	6282124992949@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.549	2026-06-21 14:37:51.549	\N
cmqnw5duz00hvr54dhlh4y2y3	6282359351844@s.whatsapp.net	6282359351844@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.552	2026-06-21 14:37:51.552	\N
cmqnw5dv000hxr54dndtrp43i	628113970101@s.whatsapp.net	628113970101@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.555	2026-06-21 14:37:51.555	\N
cmqnw5dv300i1r54dme2iqxwv	628174701005@s.whatsapp.net	628174701005@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.563	2026-06-21 14:37:51.563	\N
cmqnw5dv600i4r54dlrm6nic0	6281933102422@s.whatsapp.net	6281933102422@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.565	2026-06-21 14:37:51.565	\N
cmqnw5dv800i7r54dh1wsgkah	6281280599057@s.whatsapp.net	6281280599057@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.57	2026-06-21 14:37:51.57	\N
cmqnw5dva00ibr54dupwprkoj	628113927444@s.whatsapp.net	628113927444@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.578	2026-06-21 14:37:51.578	\N
cmqnw5dvd00ifr54dpts8uuha	6287787755216@s.whatsapp.net	6287787755216@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.584	2026-06-21 14:37:51.584	\N
cmqnw5dvf00iir54di09s1jju	628568989499@s.whatsapp.net	628568989499@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.589	2026-06-21 14:37:51.589	\N
cmqnw5dvh00ijr54dlihuo6zj	6285737445765@s.whatsapp.net	6285737445765@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.597	2026-06-21 14:37:51.597	\N
cmqnw5dvj00imr54dg79deokq	6281337111790@s.whatsapp.net	6281337111790@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.603	2026-06-21 14:37:51.603	\N
cmqnw5dvm00inr54dil2stjqy	6281337010229@s.whatsapp.net	6281337010229@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.605	2026-06-21 14:37:51.605	\N
cmqnw5dvp00iqr54detlukfyt	6287883569885@s.whatsapp.net	6287883569885@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.611	2026-06-21 14:37:51.611	\N
cmqnw5dvv00iur54d250j25z6	6281210436436@s.whatsapp.net	6281210436436@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.616	2026-06-21 14:37:51.616	\N
cmqnw5dvx00iwr54drz8hvft5	6281339614110@s.whatsapp.net	6281339614110@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.618	2026-06-21 14:37:51.618	\N
cmqnw5dw000j0r54ddftjyp7i	6281290298427@s.whatsapp.net	6281290298427@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.624	2026-06-21 14:37:51.624	\N
cmqnw5dw300j4r54d6ucgeivi	6287861159608@s.whatsapp.net	6287861159608@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.633	2026-06-21 14:37:51.633	\N
cmqnw5dw800j8r54dxi07c5m8	6281584495757@s.whatsapp.net	6281584495757@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.641	2026-06-21 14:37:51.641	\N
cmqnw5dwb00jcr54dwthl0v17	628113991718@s.whatsapp.net	628113991718@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.648	2026-06-21 14:37:51.648	\N
cmqnw5dwe00jfr54d5aa5uh11	6281374373926@s.whatsapp.net	6281374373926@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.653	2026-06-21 14:37:51.653	\N
cmqnw5dwg00jhr54dzt77u21j	6282144199428@s.whatsapp.net	6282144199428@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.659	2026-06-21 14:37:51.659	\N
cmqnw5dwi00jjr54dryt6q6d4	6282144058003@s.whatsapp.net	6282144058003@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.659	2026-06-21 14:37:51.659	\N
cmqnw5dwj00jlr54dhos282mb	628164701597@s.whatsapp.net	628164701597@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.665	2026-06-21 14:37:51.665	\N
cmqnw5dsn00far54dy38lajk4	6287862186508@s.whatsapp.net	6287862186508@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.428	2026-06-21 14:37:51.428	\N
cmqnw5dsp00fcr54dmchuv7il	6282223401469@s.whatsapp.net	6282223401469@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.429	2026-06-21 14:37:51.429	\N
cmqnw5dsq00fer54dsbdl9yr6	6282171090013@s.whatsapp.net	6282171090013@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.432	2026-06-21 14:37:51.432	\N
cmqnw5dst00fir54dbpnjh9qa	628124614569@s.whatsapp.net	628124614569@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.439	2026-06-21 14:37:51.439	\N
cmqnw5dsw00fmr54ddgc25xi8	6281323339098@s.whatsapp.net	6281323339098@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.444	2026-06-21 14:37:51.444	\N
cmqnw5dsz00for54dzry4s7yk	6281353187457@s.whatsapp.net	6281353187457@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.444	2026-06-21 14:37:51.444	\N
cmqnw5dt100fqr54dpb7804uo	6281238898406@s.whatsapp.net	6281238898406@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.45	2026-06-21 14:37:51.45	\N
cmqnw5dt300fsr54dwnhphon9	6282117576141@s.whatsapp.net	6282117576141@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.455	2026-06-21 14:37:51.455	\N
cmqnw5dt400fur54drv8o9wmt	6282247114441@s.whatsapp.net	6282247114441@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.457	2026-06-21 14:37:51.457	\N
cmqnw5dt700fyr54dgsvt35jk	6281803693418@s.whatsapp.net	6281803693418@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.462	2026-06-21 14:37:51.462	\N
cmqnw5dta00g2r54dok1u886n	6281236116466@s.whatsapp.net	6281236116466@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.466	2026-06-21 14:37:51.466	\N
cmqnw5dtc00g5r54dldb9u474	6281314106489@s.whatsapp.net	6281314106489@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.469	2026-06-21 14:37:51.469	\N
cmqnw5dtf00g9r54dozbd2yry	6281916324317@s.whatsapp.net	6281916324317@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.474	2026-06-21 14:37:51.474	\N
cmqnw5dth00gdr54dly5stbjf	6288210673430@s.whatsapp.net	6288210673430@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.48	2026-06-21 14:37:51.48	\N
cmqnw5dtn00ggr54d34eie5k7	6281267221321@s.whatsapp.net	6281267221321@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.485	2026-06-21 14:37:51.485	\N
cmqnw5dtp00gir54durrto6x0	6285737883289@s.whatsapp.net	6285737883289@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.488	2026-06-21 14:37:51.488	\N
cmqnw5dts00gmr54dlago9hub	6287862077011@s.whatsapp.net	6287862077011@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.492	2026-06-21 14:37:51.492	\N
cmqnw5dtu00gpr54dzr3mhdlz	6285790280260@s.whatsapp.net	6285790280260@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.499	2026-06-21 14:37:51.499	\N
cmqnw5dtx00gsr54d987j22lp	6285933881348@s.whatsapp.net	6285933881348@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.504	2026-06-21 14:37:51.504	\N
cmqnw5du000gwr54dzqkut9uj	6281238701147@s.whatsapp.net	6281238701147@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.507	2026-06-21 14:37:51.507	\N
cmqnw5du300h0r54dn47vvccr	628118727878@s.whatsapp.net	628118727878@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.513	2026-06-21 14:37:51.513	\N
cmqnw5du600h4r54dwjxnvm4m	6287860645634@s.whatsapp.net	6287860645634@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.516	2026-06-21 14:37:51.516	\N
cmqnw5du900h8r54d0zuzv5j5	6285937041001@s.whatsapp.net	6285937041001@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.521	2026-06-21 14:37:51.521	\N
cmqnw5dui00hbr54dxn8wniav	6285896198131@s.whatsapp.net	6285896198131@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.523	2026-06-21 14:37:51.523	\N
cmqnw5dul00hfr54d3sugo76x	628113951202@s.whatsapp.net	628113951202@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.528	2026-06-21 14:37:51.528	\N
cmqnw5duo00hjr54d9phpdy51	628113988776@s.whatsapp.net	628113988776@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.536	2026-06-21 14:37:51.536	\N
cmqnw5dur00hmr54ddtntp7uh	62811937690@s.whatsapp.net	62811937690@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.54	2026-06-21 14:37:51.54	\N
cmqnw5dut00hor54d5985tvay	6281338903206@s.whatsapp.net	6281338903206@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.54	2026-06-21 14:37:51.54	\N
cmqnw5duv00hqr54dbqb8lg7k	6282144469335@s.whatsapp.net	6282144469335@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.545	2026-06-21 14:37:51.545	\N
cmqnw5duy00hur54dynrr1wjf	628179730430@s.whatsapp.net	628179730430@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.55	2026-06-21 14:37:51.55	\N
cmqnw5dv100hyr54dmjurnl25	628113974888@s.whatsapp.net	628113974888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.559	2026-06-21 14:37:51.559	\N
cmqnw5dv200i0r54dvuezt4n3	628121600427@s.whatsapp.net	628121600427@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.56	2026-06-21 14:37:51.56	\N
cmqnw5dv400i2r54d4vmkbl1u	6287761420667@s.whatsapp.net	6287761420667@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.563	2026-06-21 14:37:51.563	\N
cmqnw5dv700i6r54d1tksfmyi	6285739367472@s.whatsapp.net	6285739367472@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.567	2026-06-21 14:37:51.567	\N
cmqnw5dv800i8r54dpqhir0cv	6281212227110@s.whatsapp.net	6281212227110@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.571	2026-06-21 14:37:51.571	\N
cmqnw5dva00iar54d6io0ehxh	6287856204826@s.whatsapp.net	6287856204826@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.576	2026-06-21 14:37:51.576	\N
cmqnw5dvb00icr54djox1fo5k	6287858154915@s.whatsapp.net	6287858154915@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.578	2026-06-21 14:37:51.578	\N
cmqnw5dvd00ier54dy77bviim	6281933700888@s.whatsapp.net	6281933700888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.582	2026-06-21 14:37:51.582	\N
cmqnw5dve00igr54d6cv69fuk	6281338426781@s.whatsapp.net	6281338426781@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.587	2026-06-21 14:37:51.587	\N
cmqnw5dvh00ikr54dpvrticm9	6287802058355@s.whatsapp.net	6287802058355@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.598	2026-06-21 14:37:51.598	\N
cmqnw5dvn00ior54dvadzq1ba	6287862248348@s.whatsapp.net	6287862248348@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.606	2026-06-21 14:37:51.606	\N
cmqnw5dvt00isr54dwbsx7f3k	6281936083546@s.whatsapp.net	6281936083546@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.611	2026-06-21 14:37:51.611	\N
cmqnw5dvw00ivr54d7vzbdx0o	6281337382099@s.whatsapp.net	6281337382099@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.616	2026-06-21 14:37:51.616	\N
cmqnw5dvy00iyr54dnwuu6zsj	6287803476351@s.whatsapp.net	6287803476351@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.62	2026-06-21 14:37:51.62	\N
cmqnw5dw200j2r54dkt59xo61	628111090039@s.whatsapp.net	628111090039@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.628	2026-06-21 14:37:51.628	\N
cmqnw5dw500j6r54dkjk73h44	6281338963173@s.whatsapp.net	6281338963173@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.637	2026-06-21 14:37:51.637	\N
cmqnw5dwa00jar54d5v2thzfe	6285100619419@s.whatsapp.net	6285100619419@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.642	2026-06-21 14:37:51.642	\N
cmqnw5dwe00jer54dsm16zez5	628113951501@s.whatsapp.net	628113951501@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.652	2026-06-21 14:37:51.652	\N
cmqnw5dwh00jir54d5b7zsxmi	62818563931@s.whatsapp.net	62818563931@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.659	2026-06-21 14:37:51.659	\N
cmqnw5dwk00jmr54dznle67ax	628979167072@s.whatsapp.net	628979167072@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.668	2026-06-21 14:37:51.668	\N
cmqnw5dwl00jor54du9x6pcyc	6282236524409@s.whatsapp.net	6282236524409@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.668	2026-06-21 14:37:51.668	\N
cmqnw5dwo00jsr54dae6ezbf8	62895800007505@s.whatsapp.net	62895800007505@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.676	2026-06-21 14:37:51.676	\N
cmqnw5dwr00jwr54duuqmmeiy	6281933112002@s.whatsapp.net	6281933112002@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.688	2026-06-21 14:37:51.688	\N
cmqnw5dws00jyr54duvyrgb72	6281558520340@s.whatsapp.net	6281558520340@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.691	2026-06-21 14:37:51.691	\N
cmqnw5dwv00k2r54d44o332w7	6285102444468@s.whatsapp.net	6285102444468@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.695	2026-06-21 14:37:51.695	\N
cmqnw5dso00fbr54dcordglok	6281529829040@s.whatsapp.net	6281529829040@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.428	2026-06-21 14:37:51.428	\N
cmqnw5dsq00ffr54du6we06lm	6281999308284@s.whatsapp.net	6281999308284@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.434	2026-06-21 14:37:51.434	\N
cmqnw5dss00fhr54deej125v4	628113993318@s.whatsapp.net	628113993318@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.436	2026-06-21 14:37:51.436	\N
cmqnw5dsu00fjr54dr07m3jql	6285721512860@s.whatsapp.net	6285721512860@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.439	2026-06-21 14:37:51.439	\N
cmqnw5dsw00flr54dc6er3vpd	6287766608500@s.whatsapp.net	6287766608500@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.443	2026-06-21 14:37:51.443	\N
cmqnw5dt000fpr54dlrrlhzmk	6281999916185@s.whatsapp.net	6281999916185@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.447	2026-06-21 14:37:51.447	\N
cmqnw5dt300ftr54d9nulhftd	6281808558000@s.whatsapp.net	6281808558000@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.455	2026-06-21 14:37:51.455	\N
cmqnw5dt500fwr54dyltrt7pb	6285338509922@s.whatsapp.net	6285338509922@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.457	2026-06-21 14:37:51.457	\N
cmqnw5dt800g0r54d1owt1pif	6281238428343@s.whatsapp.net	6281238428343@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.462	2026-06-21 14:37:51.462	\N
cmqnw5dtb00g4r54dv5pz1s34	628996904522@s.whatsapp.net	628996904522@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.467	2026-06-21 14:37:51.467	\N
cmqnw5dtd00g6r54doxl9caey	6285210982929@s.whatsapp.net	6285210982929@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.473	2026-06-21 14:37:51.473	\N
cmqnw5dte00g8r54dbi7yjydy	6285101725367@s.whatsapp.net	6285101725367@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.474	2026-06-21 14:37:51.474	\N
cmqnw5dtg00gar54dba7zqkt1	628113977213@s.whatsapp.net	628113977213@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.477	2026-06-21 14:37:51.477	\N
cmqnw5dth00gcr54drfwy9pdn	6281239620260@s.whatsapp.net	6281239620260@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.48	2026-06-21 14:37:51.48	\N
cmqnw5dtk00ger54dtx9cxpo9	6281808641111@s.whatsapp.net	6281808641111@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.484	2026-06-21 14:37:51.484	\N
cmqnw5dto00ghr54dwgeh2oft	6281802000444@s.whatsapp.net	6281802000444@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.485	2026-06-21 14:37:51.485	\N
cmqnw5dtq00gkr54daxyc67b1	6281805873888@s.whatsapp.net	6281805873888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.492	2026-06-21 14:37:51.492	\N
cmqnw5dtt00gor54do5fnfp4w	6282247370506@s.whatsapp.net	6282247370506@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.498	2026-06-21 14:37:51.498	\N
cmqnw5dtw00gqr54dsrdu5udi	6282247107601@s.whatsapp.net	6282247107601@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.501	2026-06-21 14:37:51.501	\N
cmqnw5dty00gur54d0xzigwfy	628123973188@s.whatsapp.net	628123973188@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.504	2026-06-21 14:37:51.504	\N
cmqnw5du100gyr54d77bmps8h	6281339661705@s.whatsapp.net	6281339661705@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.509	2026-06-21 14:37:51.509	\N
cmqnw5du400h1r54dqhkza5vu	6281311070070@s.whatsapp.net	6281311070070@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.513	2026-06-21 14:37:51.513	\N
cmqnw5du500h3r54dxng05zvm	6285936720149@s.whatsapp.net	6285936720149@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.514	2026-06-21 14:37:51.514	\N
cmqnw5du700h5r54d57kx4wjp	628111355514@s.whatsapp.net	628111355514@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.517	2026-06-21 14:37:51.517	\N
cmqnw5du800h7r54dmevsdmys	6281239300841@s.whatsapp.net	6281239300841@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.518	2026-06-21 14:37:51.518	\N
cmqnw5dug00har54dgaapck0o	62811865168@s.whatsapp.net	62811865168@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.523	2026-06-21 14:37:51.523	\N
cmqnw5duk00hdr54dao0gd79d	6287840385057@s.whatsapp.net	6287840385057@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.527	2026-06-21 14:37:51.527	\N
cmqnw5dun00hhr54dk3rgcv4r	6281905537868@s.whatsapp.net	6281905537868@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.532	2026-06-21 14:37:51.532	\N
cmqnw5dup00hlr54d8gj56hhx	6287760043385@s.whatsapp.net	6287760043385@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.537	2026-06-21 14:37:51.537	\N
cmqnw5duu00hpr54dz3d7q4lm	6285731762295@s.whatsapp.net	6285731762295@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.542	2026-06-21 14:37:51.542	\N
cmqnw5duw00hsr54d3qevey4e	6282144560066@s.whatsapp.net	6282144560066@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.548	2026-06-21 14:37:51.548	\N
cmqnw5duz00hwr54ddxmcel8v	48697210579@s.whatsapp.net	48697210579@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.555	2026-06-21 14:37:51.555	\N
cmqnw5dv100hzr54d8rqkmsmn	6281237461709@s.whatsapp.net	6281237461709@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.559	2026-06-21 14:37:51.559	\N
cmqnw5dv500i3r54dkuynxjt8	6281805521544@s.whatsapp.net	6281805521544@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.563	2026-06-21 14:37:51.563	\N
cmqnw5dv600i5r54d5bnzzyty	6281246140493@s.whatsapp.net	6281246140493@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.567	2026-06-21 14:37:51.567	\N
cmqnw5dv900i9r54dwfjf94cy	6285792571628@s.whatsapp.net	6285792571628@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.572	2026-06-21 14:37:51.572	\N
cmqnw5dvc00idr54d9pneuqga	6283119947615@s.whatsapp.net	6283119947615@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.582	2026-06-21 14:37:51.582	\N
cmqnw5dve00ihr54dl6s9vakv	6281236472677@s.whatsapp.net	6281236472677@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.587	2026-06-21 14:37:51.587	\N
cmqnw5dvi00ilr54dxnpmexkb	6281337050520@s.whatsapp.net	6281337050520@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.6	2026-06-21 14:37:51.6	\N
cmqnw5dvn00ipr54d26zoifq3	628123866408@s.whatsapp.net	628123866408@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.61	2026-06-21 14:37:51.61	\N
cmqnw5dvt00irr54d1p2jad6l	6281238673454@s.whatsapp.net	6281238673454@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.611	2026-06-21 14:37:51.611	\N
cmqnw5dvu00itr54dp4clvg72	6281239390607@s.whatsapp.net	6281239390607@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.615	2026-06-21 14:37:51.615	\N
cmqnw5dvx00ixr54dtppeh6sa	628123838777@s.whatsapp.net	628123838777@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.62	2026-06-21 14:37:51.62	\N
cmqnw5dw000izr54d3uyo451m	6287758332705@s.whatsapp.net	6287758332705@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.624	2026-06-21 14:37:51.624	\N
cmqnw5dw100j1r54dxr6oydat	628113892205@s.whatsapp.net	628113892205@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.626	2026-06-21 14:37:51.626	\N
cmqnw5dw300j3r54dtcjnsipc	6281999196336@s.whatsapp.net	6281999196336@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.633	2026-06-21 14:37:51.633	\N
cmqnw5dw400j5r54dbl0sigzf	6283832053665@s.whatsapp.net	6283832053665@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.636	2026-06-21 14:37:51.636	\N
cmqnw5dw700j7r54dgxscmbg8	6281529333888@s.whatsapp.net	6281529333888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.638	2026-06-21 14:37:51.638	\N
cmqnw5dw900j9r54d1lf8rg8m	6287877291018@s.whatsapp.net	6287877291018@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.642	2026-06-21 14:37:51.642	\N
cmqnw5dwb00jbr54dmr3wwifa	628123900382@s.whatsapp.net	628123900382@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.644	2026-06-21 14:37:51.644	\N
cmqnw5dwd00jdr54dc9zgxhxg	6281239995213@s.whatsapp.net	6281239995213@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.648	2026-06-21 14:37:51.648	\N
cmqnw5dwf00jgr54dotwxh4f9	6281237300103@s.whatsapp.net	6281237300103@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.653	2026-06-21 14:37:51.653	\N
cmqnw5dwi00jkr54dp26edtne	6282127310866@s.whatsapp.net	6282127310866@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.663	2026-06-21 14:37:51.663	\N
cmqnw5dwk00jnr54d2ojfkwit	6282138826688@s.whatsapp.net	6282138826688@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.668	2026-06-21 14:37:51.668	\N
cmqnw5dwn00jqr54dz4laofvf	6281353307453@s.whatsapp.net	6281353307453@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.672	2026-06-21 14:37:51.672	\N
cmqnw5dwm00jpr54dpgysgtor	6285931267589@s.whatsapp.net	6285931267589@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.672	2026-06-21 14:37:51.672	\N
cmqnw5dwn00jrr54dz62a61cs	6281357842119@s.whatsapp.net	6281357842119@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.672	2026-06-21 14:37:51.672	\N
cmqnw5dwq00jur54db3aiaxz9	6281353823856@s.whatsapp.net	6281353823856@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.681	2026-06-21 14:37:51.681	\N
cmqnw5dwr00jxr54d3iperv5a	6281364209637@s.whatsapp.net	6281364209637@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.688	2026-06-21 14:37:51.688	\N
cmqnw5dwu00k0r54d8281jlc6	6285739526616@s.whatsapp.net	6285739526616@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.692	2026-06-21 14:37:51.692	\N
cmqnw5dww00k3r54d2w6ypypp	6281337931045@s.whatsapp.net	6281337931045@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.695	2026-06-21 14:37:51.695	\N
cmqnw5dwz00k7r54d9hp2thxt	6281246245389@s.whatsapp.net	6281246245389@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.701	2026-06-21 14:37:51.701	\N
cmqnw5dx200k9r54dzetnuj4y	6281299666088@s.whatsapp.net	6281299666088@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.705	2026-06-21 14:37:51.705	\N
cmqnw5dx300kbr54dv3zrbb3g	628118867000@s.whatsapp.net	628118867000@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.709	2026-06-21 14:37:51.709	\N
cmqnw5dx500kdr54dspgnwz69	6287730785888@s.whatsapp.net	6287730785888@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.711	2026-06-21 14:37:51.711	\N
cmqnw5dx800khr54d4xgnx63i	6285100893233@s.whatsapp.net	6285100893233@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.718	2026-06-21 14:37:51.718	\N
cmqnw5e5w00msr54drn6tex6z	6287860202653@s.whatsapp.net	6287860202653@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.128	2026-06-21 14:37:52.128	\N
cmqnw5e6100mwr54d7f7bdqmi	639814270009@s.whatsapp.net	639814270009@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.149	2026-06-21 14:37:52.149	\N
cmqnw5e6300mzr54d4erqdz09	6285156821368@s.whatsapp.net	6285156821368@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.157	2026-06-21 14:37:52.157	\N
cmqnw5e6600n3r54dfy7ua9zu	6281938801986@s.whatsapp.net	6281938801986@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.17	2026-06-21 14:37:52.17	\N
cmqnw5e6800n7r54dnx0zbaqo	6287860868103@s.whatsapp.net	6287860868103@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.177	2026-06-21 14:37:52.177	\N
cmqnw5e6c00nbr54dt7470xw3	6285737622874@s.whatsapp.net	6285737622874@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.186	2026-06-21 14:37:52.186	\N
cmqnw5e6f00nfr54d41u7g29w	6285737437138@s.whatsapp.net	6285737437138@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.19	2026-06-21 14:37:52.19	\N
cmqnw5e6g00nhr54dadhajnzr	6287762827988@s.whatsapp.net	6287762827988@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.194	2026-06-21 14:37:52.194	\N
cmqnw5e6i00njr54dn8tpiu09	6282243373001@s.whatsapp.net	6282243373001@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.197	2026-06-21 14:37:52.197	\N
cmqnw5e6o00nlr54dxxrjalrn	6285606199717@s.whatsapp.net	6285606199717@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.198	2026-06-21 14:37:52.198	\N
cmqnw5e6v00npr54ddk5cqh54	6281353337222@s.whatsapp.net	6281353337222@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.205	2026-06-21 14:37:52.205	\N
cmqnw5e7200nrr54dpxt13qhp	989333710574@s.whatsapp.net	989333710574@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.207	2026-06-21 14:37:52.207	\N
cmqnw5e7600ntr54dka9fstmh	6283857440668@s.whatsapp.net	6283857440668@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.211	2026-06-21 14:37:52.211	\N
cmqnw5e7800nvr54dbkusm73v	6281294726177@s.whatsapp.net	6281294726177@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.215	2026-06-21 14:37:52.215	\N
cmqnw5e7a00nxr54ditw4fvi6	6285792494609@s.whatsapp.net	6285792494609@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.218	2026-06-21 14:37:52.218	\N
cmqnw5e7d00nzr54d17wg9yet	6285175081135@s.whatsapp.net	6285175081135@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.22	2026-06-21 14:37:52.22	\N
cmqnw5e7f00o1r54dyew9c62r	6282147342362@s.whatsapp.net	6282147342362@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.224	2026-06-21 14:37:52.224	\N
cmqnw5e7h00o3r54dvxvpxqq2	6282359051429@s.whatsapp.net	6282359051429@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.225	2026-06-21 14:37:52.225	\N
cmqnw5e7i00o5r54dx3olhwrt	6281929753406@s.whatsapp.net	6281929753406@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.23	2026-06-21 14:37:52.23	\N
cmqnw5e7k00o7r54ds4he41hz	628813568297@s.whatsapp.net	628813568297@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.233	2026-06-21 14:37:52.233	\N
cmqnw5e7l00o9r54d8vcctkaa	62881037080146@s.whatsapp.net	62881037080146@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.237	2026-06-21 14:37:52.237	\N
cmqnw5e7n00obr54dab725awh	628815572991@s.whatsapp.net	628815572991@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.241	2026-06-21 14:37:52.241	\N
cmqnw5e7o00odr54dgvp1k5az	6282331103769@s.whatsapp.net	6282331103769@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.242	2026-06-21 14:37:52.242	\N
cmqnw5e7q00ofr54dpndfpiuw	6281252056202@s.whatsapp.net	6281252056202@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.246	2026-06-21 14:37:52.246	\N
cmqnw5e7s00ohr54dg1bkbpw7	6285101800800@s.whatsapp.net	6285101800800@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.249	2026-06-21 14:37:52.249	\N
cmqnw5dwp00jtr54dmj4okdvu	6281317925023@s.whatsapp.net	6281317925023@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.676	2026-06-21 14:37:51.676	\N
cmqnw5dwq00jvr54diqjwj5r5	6285239303464@s.whatsapp.net	6285239303464@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.685	2026-06-21 14:37:51.685	\N
cmqnw5dwt00jzr54d2yehhemq	6281973733199@s.whatsapp.net	6281973733199@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.691	2026-06-21 14:37:51.691	\N
cmqnw5dwv00k1r54dnasngio0	6281284872275@s.whatsapp.net	6281284872275@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.693	2026-06-21 14:37:51.693	\N
cmqnw5dwy00k5r54dx8taaak1	6281238338640@s.whatsapp.net	6281238338640@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.699	2026-06-21 14:37:51.699	\N
cmqnw5dx000k8r54dmyts52n8	6281246678405@s.whatsapp.net	6281246678405@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.704	2026-06-21 14:37:51.704	\N
cmqnw5dx400kcr54deonapmim	628979357235@s.whatsapp.net	628979357235@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.709	2026-06-21 14:37:51.709	\N
cmqnw5dx600kfr54dph446qb2	6281389902199@s.whatsapp.net	6281389902199@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.712	2026-06-21 14:37:51.712	\N
cmqnw5dxb00kjr54dexld8dd8	6281239696420@s.whatsapp.net	6281239696420@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.731	2026-06-21 14:37:51.731	\N
cmqnw5e5v00mrr54dw36rr1xp	6289616699042@s.whatsapp.net	6289616699042@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.128	2026-06-21 14:37:52.128	\N
cmqnw5e6000mvr54db44ifvf1	6283851306418@s.whatsapp.net	6283851306418@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.141	2026-06-21 14:37:52.141	\N
cmqnw5e6200mxr54dv242pewl	6281299696081@s.whatsapp.net	6281299696081@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.151	2026-06-21 14:37:52.151	\N
cmqnw5e6400n1r54doxhv01va	6281339093759@s.whatsapp.net	6281339093759@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.163	2026-06-21 14:37:52.163	\N
cmqnw5e6700n5r54dh3duqxyl	6285746999067@s.whatsapp.net	6285746999067@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.174	2026-06-21 14:37:52.174	\N
cmqnw5e6a00n9r54djtf2g4dm	6285559660233@s.whatsapp.net	6285559660233@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.18	2026-06-21 14:37:52.18	\N
cmqnw5e6d00ndr54drzbfzrgt	6281234371102@s.whatsapp.net	6281234371102@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.188	2026-06-21 14:37:52.188	\N
cmqnw5e6f00ngr54d15fx4hxt	62895326481168@s.whatsapp.net	62895326481168@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.192	2026-06-21 14:37:52.192	\N
cmqnw5e6i00nkr54dmez7v5oh	6281215419170@s.whatsapp.net	6281215419170@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.198	2026-06-21 14:37:52.198	\N
cmqnw5e6q00nnr54dgw8swhw7	6285856024730@s.whatsapp.net	6285856024730@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.203	2026-06-21 14:37:52.203	\N
cmqnw5e6u00nor54dtr375s9d	6287853847141@s.whatsapp.net	6287853847141@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.203	2026-06-21 14:37:52.203	\N
cmqnw5e7400nsr54d9gktfji9	6282112148261@s.whatsapp.net	6282112148261@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.209	2026-06-21 14:37:52.209	\N
cmqnw5e7900nwr54d8gfc5pbk	62895415850555@s.whatsapp.net	62895415850555@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.215	2026-06-21 14:37:52.215	\N
cmqnw5e7e00o0r54de0arli84	628567762491@s.whatsapp.net	628567762491@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.223	2026-06-21 14:37:52.223	\N
cmqnw5e7h00o4r54dkexqinql	6289688072039@s.whatsapp.net	6289688072039@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.227	2026-06-21 14:37:52.227	\N
cmqnw5e7k00o8r54d6g8jjjmw	6285733827967@s.whatsapp.net	6285733827967@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.234	2026-06-21 14:37:52.234	\N
cmqnw5e7n00ocr54dx6hz6ryf	62881036976345@s.whatsapp.net	62881036976345@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.242	2026-06-21 14:37:52.242	\N
cmqnw5e7r00ogr54dmals3qvq	6287866104495@s.whatsapp.net	6287866104495@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.248	2026-06-21 14:37:52.248	\N
cmqnw5dwx00k4r54drcer2oc7	6285237007807@s.whatsapp.net	6285237007807@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.699	2026-06-21 14:37:51.699	\N
cmqnw5dwz00k6r54durtj44zz	6281999961028@s.whatsapp.net	6281999961028@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.699	2026-06-21 14:37:51.699	\N
cmqnw5dx200kar54ddag5twgx	6281934306268@s.whatsapp.net	6281934306268@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.707	2026-06-21 14:37:51.707	\N
cmqnw5dx500ker54d9cgb7gh7	6285282825517@s.whatsapp.net	6285282825517@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.712	2026-06-21 14:37:51.712	\N
cmqnw5dx700kgr54d8tzeq22p	6281314103649@s.whatsapp.net	6281314103649@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.717	2026-06-21 14:37:51.717	\N
cmqnw5dx900kir54dkrutjzer	628123952424@s.whatsapp.net	628123952424@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.724	2026-06-21 14:37:51.724	\N
cmqnw5e5i00mqr54dlbyu7cl9	6285311781853@s.whatsapp.net	6285311781853@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.122	2026-06-21 14:37:52.122	\N
cmqnw5e5y00mtr54d4x0er299	6289681301850@s.whatsapp.net	6289681301850@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.133	2026-06-21 14:37:52.133	\N
cmqnw5e6000mur54drmdi57cu	6281284063078@s.whatsapp.net	6281284063078@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.137	2026-06-21 14:37:52.137	\N
cmqnw5e6200myr54doryoy3pf	6287832983514@s.whatsapp.net	6287832983514@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.152	2026-06-21 14:37:52.152	\N
cmqnw5e6400n0r54d15m6667y	6281330802401@s.whatsapp.net	6281330802401@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.16	2026-06-21 14:37:52.16	\N
cmqnw5e6500n2r54dh0a231uk	62817344649@s.whatsapp.net	62817344649@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.166	2026-06-21 14:37:52.166	\N
cmqnw5e6700n4r54dt4fvjdit	62895333615211@s.whatsapp.net	62895333615211@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.171	2026-06-21 14:37:52.171	\N
cmqnw5e6800n6r54ds8wy8wp2	6281230447026@s.whatsapp.net	6281230447026@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.175	2026-06-21 14:37:52.175	\N
cmqnw5e6a00n8r54d7hat9hhy	6281210746201@s.whatsapp.net	6281210746201@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.179	2026-06-21 14:37:52.179	\N
cmqnw5e6b00nar54dhub5db7p	6281246973030@s.whatsapp.net	6281246973030@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.185	2026-06-21 14:37:52.185	\N
cmqnw5e6d00ncr54dx664zp41	6282216981643@s.whatsapp.net	6282216981643@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.186	2026-06-21 14:37:52.186	\N
cmqnw5e6e00ner54duwor1uoi	6287818159392@s.whatsapp.net	6287818159392@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.19	2026-06-21 14:37:52.19	\N
cmqnw5e6h00nir54d8qnpdryh	6281334695040@s.whatsapp.net	6281334695040@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.194	2026-06-21 14:37:52.194	\N
cmqnw5e6o00nmr54d0tqheq64	6285770338305@s.whatsapp.net	6285770338305@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.202	2026-06-21 14:37:52.202	\N
cmqnw5e6y00nqr54dnqw4piab	6282124022467@s.whatsapp.net	6282124022467@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.207	2026-06-21 14:37:52.207	\N
cmqnw5e7700nur54dby4dkty2	6282133866175@s.whatsapp.net	6282133866175@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.211	2026-06-21 14:37:52.211	\N
cmqnw5e7b00nyr54dph1anpxy	6281330891491@s.whatsapp.net	6281330891491@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.22	2026-06-21 14:37:52.22	\N
cmqnw5e7g00o2r54dpw3k4qzn	6281338896416@s.whatsapp.net	6281338896416@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.224	2026-06-21 14:37:52.224	\N
cmqnw5e7j00o6r54d0ljaoltm	628113923335@s.whatsapp.net	628113923335@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.231	2026-06-21 14:37:52.231	\N
cmqnw5e7m00oar54dl93wbxsv	6288987246471@s.whatsapp.net	6288987246471@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.238	2026-06-21 14:37:52.238	\N
cmqnw5e7p00oer54des8zzozn	6282302095190@s.whatsapp.net	6282302095190@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:52.243	2026-06-21 14:37:52.243	\N
cmqnwcqrc00ucr54dywwr3oq3	6281239990810@s.whatsapp.net	6281239990810@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:43:35.161	2026-06-21 14:43:35.161	\N
cmqp3j5ps00vur54dvt3futx6	6285738102839@s.whatsapp.net	6285738102839@s.whatsapp.net@s.whatsapp.net	2026-06-22 10:52:17.968	2026-06-22 10:52:17.968	\N
cmqsvvlpo00znr54dabj6vqe9	6282146077890@s.whatsapp.net	6282146077890@s.whatsapp.net@s.whatsapp.net	2026-06-25 02:29:06.347	2026-06-25 02:29:06.347	\N
cmqulmd8z010kr54dcakcfl1n	62881082489258@s.whatsapp.net	62881082489258@s.whatsapp.net@s.whatsapp.net	2026-06-26 07:17:31.668	2026-06-26 07:17:31.668	lid
cmr68gqml0139r54dmu8df58r	6281338772338@s.whatsapp.net	6281338772338@s.whatsapp.net@s.whatsapp.net	2026-07-04 10:42:28.173	2026-07-04 10:42:28.173	\N
cmqnxemvn00urr54desoqoisn	6285117722465@s.whatsapp.net	6285117722465@s.whatsapp.net@s.whatsapp.net	2026-06-21 15:13:03.059	2026-07-06 11:00:27.676	lid
cmqnw5drm00dwr54d6rn059m3	6282247973243@s.whatsapp.net	6282247973243@s.whatsapp.net@s.whatsapp.net	2026-06-21 14:37:51.179	2026-07-06 11:01:56.233	lid
cmskpgnt4002sof4ck6jrlsrk	6282146504913@s.whatsapp.net	6282146504913@s.whatsapp.net@s.whatsapp.net	2026-08-08 18:26:46.789	2026-08-08 18:26:46.789	\N
\.


--
-- Data for Name: Kafka; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Kafka" (id, enabled, events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: Label; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Label" (id, "labelId", name, color, "predefinedId", "createdAt", "updatedAt", "instanceId") FROM stdin;
cmqnw5fcr00ojr54db47c7bep	6	Unread	0	\N	2026-06-21 14:37:53.787	2026-06-21 14:37:53.787	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5fcy00olr54ds3sg0i9i	7	Favorites	0	\N	2026-06-21 14:37:53.793	2026-06-21 14:37:53.793	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnw5fd800onr54dqin6tas5	8	Groups	0	\N	2026-06-21 14:37:53.805	2026-06-21 14:37:53.805	23d8699a-16ab-4406-9e59-9c374964b83c
\.


--
-- Data for Name: Media; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Media" (id, "fileName", type, mimetype, "createdAt", "messageId", "instanceId") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Message" (id, key, "pushName", participant, "messageType", message, "contextInfo", source, "messageTimestamp", "chatwootMessageId", "chatwootInboxId", "chatwootConversationId", "chatwootContactInboxSourceId", "chatwootIsRead", "instanceId", "webhookUrl", "sessionId", status) FROM stdin;
cmqnw42ua003lr54duaizvktc	{"id": "3B4C86D79117CCED96A3", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "gE8w+eNN+K4EXr6FAGfE+wqPux2eoT7xjWLtvfBac6Q=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B222245701FBEAB77F0", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/595840171_2109152616684471_4441859798028663361_n.enc?ccb=11-4&oh=01_Q5Aa4wH1O2pMjbtHTEBv2lpp7OXYoknghpE8F_t02_R-stiKIw&oe=6A5C9978&_nc_sid=5e03e0&mms3=true", "width": 2880, "height": 1624, "caption": "Kita habis update gasless transaction di Solana, jadi kalian ga perlu punya token solana untuk bayar network fee, tapi pakai token yang kalian punya utk bayar network fee. Enjoy buat lebih seamless kalian transaksi on chain di jaringan Solana. Jadi ini bsa bantu kalian yg ga prnh punya solana tetap bsa transaksi dngan baik di dapp termasuk staking usdc, jual beli token,  us stock, dan withdraw. Klau ada kendala apa terkait penggunaan app jangan malu bertanya", "mediaKey": "2xveBMlhIGS5dL3N2qpUoFcFzrQ8FU/7c9m1BMtyNSM=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/595840171_2109152616684471_4441859798028663361_n.enc?ccb=11-4&oh=01_Q5Aa4wH1O2pMjbtHTEBv2lpp7OXYoknghpE8F_t02_R-stiKIw&oe=6A5C9978&_nc_sid=5e03e0", "fileLength": {"low": 105923, "high": 0, "unsigned": true}, "fileSha256": "ncQVGTxsA8p0rX+s8toQPElRMCkYKmH0uX0Pg2uilYY=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [19250, 17783, 39935, 28953], "scansSidecar": "vBWI9MdVYfTf3WDr07q3eIimH6n5P4Z0JRIBeyI9pDN8xjL0in1kVg==", "fileEncSha256": "7VqjVD0mTXKZG9XtW2nUWhHltYT5zaba3K2Re4rwkd8=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1781868825, "high": 0, "unsigned": false}, "midQualityFileSha256": "xupbBv7BR3jE9Y5qu3akX3IuGcASdLZIIuOl916WXnc=", "interactiveAnnotations": []}}}}	\N	unknown	1781868826	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ua003mr54dr4rdvp7d	{"id": "A5A15D5511D20A0F0E2149E1CB1356E8", "fromMe": true, "remoteJid": "65842469404740@lid"}	Você	\N	templateButtonReplyMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "cza2Q0J1KOEbJESZZKN9iGxTOJdp+NCddgyttMiRB48="}, "templateButtonReplyMessage": {"selectedId": "DID_NOT_REQUEST_CODE", "contextInfo": {"stanzaId": "FEE3AB02AED0C600D9", "quotedType": 0, "participant": "65842469404740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"templateMessage": {"hydratedTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}, "hydratedFourRowTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}}}, "statusAttributions": []}, "selectedIndex": 1, "selectedDisplayText": "Saya tidak menerima kode"}}	{"stanzaId": "FEE3AB02AED0C600D9", "quotedType": 0, "participant": "65842469404740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"templateMessage": {"hydratedTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}, "hydratedFourRowTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}}}, "statusAttributions": []}	android	1781841347	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ua003nr54dtnlvnyct	{"id": "3EB05BD25E9441CFD3247C", "fromMe": true, "remoteJid": "113739474936038@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/536385013_1920343011981721_3467069621062072652_n.enc?ccb=11-4&oh=01_Q5Aa4wF6pHAn6J3-sjKyh4PH3lUoY6pKcct2pY6O5itXW1dRmg&oe=6A5B501D&_nc_sid=5e03e0&mms3=true", "caption": "hi, this is parahub slide for you to learn!", "fileName": "ParaHub_Materi.pdf", "mediaKey": "CmtXaD66LpsG6XoNSrJ04fsUQQyNubLdrmLeHeN3zQo=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/536385013_1920343011981721_3467069621062072652_n.enc?ccb=11-4&oh=01_Q5Aa4wF6pHAn6J3-sjKyh4PH3lUoY6pKcct2pY6O5itXW1dRmg&oe=6A5B501D&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "rY/kVsVQTbjKZQL9sTBk9G2Q9fe8xNJcDJz3XihikUs=", "mediaKeyTimestamp": {"low": 1781787953, "high": 0, "unsigned": false}}}	null	web	1781787955	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003or54dzrcx5vb0	{"id": "3EB016B5BF704C389EFFC3", "fromMe": true, "remoteJid": "167929614229740@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/549427749_4236770523302973_89289661049594800_n.enc?ccb=11-4&oh=01_Q5Aa4wEaOhk47QYgyg0U2-vzDEkrb1RXNd1yJH9zS4aQSv28iA&oe=6A5B6006&_nc_sid=5e03e0&mms3=true", "fileName": "ParaHub_Materi.pdf", "mediaKey": "jPrrQ7ToBzcRu/tZkQK4KHz0GBfbSHpj3TL0kxvZEzM=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/549427749_4236770523302973_89289661049594800_n.enc?ccb=11-4&oh=01_Q5Aa4wEaOhk47QYgyg0U2-vzDEkrb1RXNd1yJH9zS4aQSv28iA&oe=6A5B6006&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "WeAFkM4KbjweEgjirBuTftr6DKkLwx6qkUPL2k2thJI=", "mediaKeyTimestamp": {"low": 1781787731, "high": 0, "unsigned": false}}}	null	web	1781787734	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003pr54dv9s26zov	{"id": "1569165038060490-1", "fromMe": false, "remoteJid": "0@s.whatsapp.net"}	WhatsApp Business	\N	interactiveMessage	{"interactiveMessage": {"body": {"text": "*Take control of your chats with lists.*\\n\\nYou can create up to 20 lists—rename or reorganize them to work for you. Easily find the chats you need, when you need them.\\n\\n⭐️ Pro-tip: Create a “New Orders” or “New Customers” list to quickly reply to time sensitive messages."}, "header": {"videoMessage": {"width": 1080, "height": 1080, "caption": "*Take control of your chats with lists.*\\n\\nYou can create up to 20 lists—rename or reorganize them to work for you. Easily find the chats you need, when you need them.\\n\\n⭐️ Pro-tip: Create a “New Orders” or “New Customers” list to quickly reply to time sensitive messages.", "seconds": 21, "mediaKey": "m2Z1cexOEYEQUYZw0CunmVgLBBe0aMh7NczzNE/hgjs=", "mimetype": "video/mp4", "staticUrl": "https://static.whatsapp.net/downloadable?category=PSA&id=1006341001221807188&num=1babf5ef-027a-4df2-95ab-4d00bbb1e421&_nc_cat=1", "fileLength": {"low": 8417934, "high": 0, "unsigned": true}, "fileSha256": "D0wourkG3sC+7BHbHX2WcS8VMvmNwNFXJDjAG0YXVhY=", "annotations": [], "fileEncSha256": "wWWiZdRHkFFMp3xU1xHdXFAi7W5eo11E+htiL7tk+ik=", "processedVideos": [], "interactiveAnnotations": []}, "hasMediaAttachment": true}, "nativeFlowMessage": {"buttons": [{"name": "cta_url", "buttonParamsJson": "{\\"display_text\\":\\"Try now\\",\\"payment_link_preview\\":false,\\"url\\":\\"whatsapp-smb:\\\\/\\\\/biztab\\\\/labels\\",\\"webview_interaction\\":true}"}], "messageParamsJson": ""}}, "messageContextInfo": {"threadId": [], "messageSecret": "NrdYAfZ1OCtCmpMNPVNu72RpfnFsDrRbEta6bmbz7MU="}}	null	desktop	1781769779	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003qr54doej3n2an	{"id": "AC8D5A1ECFE69DAB698B784394F4920E", "fromMe": false, "remoteJid": "276183644156050@lid"}	276183644156050	\N	conversation	{"conversation": "Lince", "messageContextInfo": {"threadId": [], "messageSecret": "LPVmooOMHbg68j//CbfTtaopEcsKJlplGPdHAL3hHxg="}}	\N	android	1780457518	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003rr54dn19556g1	{"id": "A5C2A9889DFE76A6ED94F6C4BADBC1A3", "fromMe": true, "remoteJid": "6281353058012@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "jngn kirim gnian", "messageContextInfo": {"threadId": [], "messageSecret": "cknmVpD2htk6ry/hCa4KVy+2yizn7VjkGADwGv/7vGg="}}	\N	android	1770392698	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uc0042r54dinm89o5b	{"id": "3F85D1A621F42125345F", "fromMe": false, "remoteJid": "6282124022467@s.whatsapp.net"}	6282124022467	\N	conversation	{"conversation": "untuk rencana mau beli jenis apa, sedang saya pertanyakan"}	\N	desktop	1753030624	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0043r54dlcwdhs5g	{"id": "8E8A4F97390D4435BE1013118609620A", "fromMe": true, "remoteJid": "6281252056202@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "iyaa bagus wkwk, so proud", "messageContextInfo": {"threadId": [], "messageSecret": "wJhFFxIvhc4GOlGuWJrhG0XzX0KdEKly81NfBOSU+Xk="}}	\N	android	1752227693	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003sr54dv9b6441n	{"id": "909161BAD0F045D0F3", "fromMe": false, "remoteJid": "62895392547878@s.whatsapp.net"}	62895392547878	\N	templateMessage	{"templateMessage": {"templateId": "1993538474582246", "hydratedTemplate": {"hydratedButtons": [{"index": 0, "quickReplyButton": {"id": "Diskusi Singkat - JO", "displayText": "Diskusi Singkat - JO"}}, {"index": 1, "quickReplyButton": {"id": "Hubungi Sales - JO", "displayText": "Hubungi Sales - JO"}}], "hydratedContentText": "Halo Bapak/Ibu, salam kenal saya *Jefri dari Mekari Talenta*. \\n\\nSaat ini perusahaannya tentu terus berkembang. Biasanya, di fase ini pengelolaan HR (absensi, cuti, hingga payroll) mulai terasa menantang jika masih manual. \\n\\nIzin bertanya, saat ini di perusahaannya apakah administrasinya sudah menggunakan sistem atau masih manual, Pak/Bu? \\n\\nBanyak rekan HR beralih ke Talenta untuk otomatisasi payroll & absensi agar lebih akurat dan hemat waktu. Jika ada waktu 15-20 menit minggu ini, saya ingin berbagi best practice bagaimana kami membantu perusahaan serupa merapikan sistem HR mereka. \\n\\nDiskusi ini santai saja dan tanpa komitmen apa pun. Bagaimana menurut Bapak/Ibu?"}, "hydratedFourRowTemplate": {"hydratedButtons": [{"index": 0, "quickReplyButton": {"id": "Diskusi Singkat - JO", "displayText": "Diskusi Singkat - JO"}}, {"index": 1, "quickReplyButton": {"id": "Hubungi Sales - JO", "displayText": "Hubungi Sales - JO"}}], "hydratedContentText": "Halo Bapak/Ibu, salam kenal saya *Jefri dari Mekari Talenta*. \\n\\nSaat ini perusahaannya tentu terus berkembang. Biasanya, di fase ini pengelolaan HR (absensi, cuti, hingga payroll) mulai terasa menantang jika masih manual. \\n\\nIzin bertanya, saat ini di perusahaannya apakah administrasinya sudah menggunakan sistem atau masih manual, Pak/Bu? \\n\\nBanyak rekan HR beralih ke Talenta untuk otomatisasi payroll & absensi agar lebih akurat dan hemat waktu. Jika ada waktu 15-20 menit minggu ini, saya ingin berbagi best practice bagaimana kami membantu perusahaan serupa merapikan sistem HR mereka. \\n\\nDiskusi ini santai saja dan tanpa komitmen apa pun. Bagaimana menurut Bapak/Ibu?"}}}	null	desktop	1769757735	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003tr54drduzs0xn	{"id": "A5B4ABA721B585D5988CD895EDB80DD7", "fromMe": true, "remoteJid": "6287860202653@s.whatsapp.net"}	Você	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/620856577_861379616775909_7921430845833244224_n.enc?ccb=11-4&oh=01_Q5Aa3gGR7dPi2WwzqB2VbctilIAABGgkc9iYGRlU7Gdyf9MwHg&oe=69985F6D&_nc_sid=5e03e0&mms3=true", "width": 1600, "height": 1142, "mediaKey": "mBI593PkM0LsrzAKrthQWMGGAUoWVn8lGh1zSSi8vKg=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/620856577_861379616775909_7921430845833244224_n.enc?ccb=11-4&oh=01_Q5Aa3gGR7dPi2WwzqB2VbctilIAABGgkc9iYGRlU7Gdyf9MwHg&oe=69985F6D&_nc_sid=5e03e0", "fileLength": {"low": 154543, "high": 0, "unsigned": true}, "fileSha256": "Yw6rNOZIjvvzXE4fnMY4DkEp2shFmBjy/gxbzXrx5i8=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "USHFkBYW2RHd0z44zo6nIHJVdjtmJxZRITOaDhAUfAw=", "mediaKeyTimestamp": {"low": 1769014247, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "ZxNqcpUqasKwk/tcDlTaIkY5n6xMRvQLwJebmzTOeaE="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1769014247	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ub003ur54d8pscyurf	{"id": "81B4B67E38D5FCD6B7", "fromMe": false, "remoteJid": "135308700041380@lid"}	135308700041380	\N	interactiveMessage	{"interactiveMessage": {"body": {"text": "Yuk bantu kami lebih baik lagi dengan isi survei kepuasan pelanggan di bawah ini. (Please share your experience by filling out our short satisfaction survey below.)"}, "nativeFlowMessage": {"buttons": [{"name": "cta_url", "buttonParamsJson": "{\\"display_text\\":\\"Rate your experience\\",\\"url\\":\\"https:\\\\/\\\\/forecoffee.zendesk.com\\\\/hc\\\\/en-us\\\\/survey_responses\\\\/01KDSPH2MHQHFGAK0ERQQ404PB?access_token=3-jSWmSzKJRV03y5RJiHK76iqQ\\",\\"payment_link_preview\\":false,\\"webview_interaction\\":true}"}], "messageParamsJson": ""}}}	null	desktop	1767167790	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003vr54dhcw0juz2	{"id": "3ACC5F4F245BB53B7DEE", "fromMe": false, "remoteJid": "6281330891491@s.whatsapp.net"}	6281330891491	\N	conversation	{"conversation": "sama bsk uang pasar", "messageContextInfo": {"threadId": [], "messageSecret": "7mlKLVO1JjUk69UytZxOagaGFSqGc8RlKGOBAe2nxJI="}}	\N	ios	1763110372	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003wr54dm3y851mc	{"id": "0B8A061E8E7B535EEE", "fromMe": false, "remoteJid": "6281139900078@s.whatsapp.net"}	6281139900078	\N	conversation	{"conversation": "Maaf, nomor anda telah melewati batas permintaan kupon. Setiap nomor berkesempatan untuk mendapatkan 1 kupon selama periode promo. Promo ini berlaku hingga tanggal 15 November 2025. Setelah tanggal tersebut anda dapat lagi menerima kupon promo spesial dari kami.\\r\\nNantikan promo berikutnya dari Starbucks."}	\N	desktop	1762852566	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003xr54dnpvrnsme	{"id": "3BFBCBDB56F5749102B6", "fromMe": false, "remoteJid": "6281239300841@s.whatsapp.net"}	6281239300841	\N	conversation	{"conversation": "oowh yes beda yaa", "messageContextInfo": {"threadId": [], "messageSecret": "SfAzHSFPnQYUL9ENvb8jAaAMSKALxouM/Ui0Ou8ueeg="}}	\N	unknown	1762692341	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003yr54dvw8nw5h5	{"id": "A5CC82A377B930472CD465E6B42D5739", "fromMe": true, "remoteJid": "6281330802401@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "jangan kunci pintu", "messageContextInfo": {"threadId": [], "messageSecret": "PA6Hrtx5C0ucccQzAXQbPqgJ4p4JzZJ5e+vN2EWvbEk="}}	\N	android	1761412238	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub003zr54dst1ma5uf	{"id": "A51E4DC2AF3FAE0A33A4BD2AEB405F86", "fromMe": true, "remoteJid": "6281337010229@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "bitcoin bitvault dri 0.025 dh jdi 0.03395653", "messageContextInfo": {"threadId": [], "messageSecret": "tCKuBVhe+jC78hWCN9jradQArvsAsRBZNuNhgPg/tVQ="}}	\N	android	1760798616	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ub0040r54d1zbkm2au	{"id": "B337F21B2555B5E4E9", "fromMe": false, "remoteJid": "628170993101@s.whatsapp.net"}	628170993101	\N	templateMessage	{"templateMessage": {"templateId": "1705387353663430", "hydratedTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/554864426_801965905529919_3809301419029840167_n.enc?ccb=11-4&oh=01_Q5Aa2gGZX_IhQD7B8YMDDBfqYn_hNoYEGHpDX-n1OA8iys_F1g&oe=68FE4DCE&_nc_sid=5e03e0&mms3=true", "width": 1200, "height": 675, "caption": "_All set! We've received your request_\\n\\nCuma Kopi Kenangan yang tau kamu nungguin promo PISTACHIO SERIES dari Kopi Kenangan 😉\\n\\n*Beli 2 Menu Pistachio Series* apapun, dapatkan *GRATIS* Americano / Kopi Susu Black Aren cuma *40RIBUAN* aja 🤑\\n\\nSelagi kuota masih ada, buruan datang ke outlet terdekat atau order via aplikasi 👇", "mediaKey": "CYkdxTAlXrsAgMLsSGMfAwvz90hzWI9xtUDQyj00wEg=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/554864426_801965905529919_3809301419029840167_n.enc?ccb=11-4&oh=01_Q5Aa2gGZX_IhQD7B8YMDDBfqYn_hNoYEGHpDX-n1OA8iys_F1g&oe=68FE4DCE&_nc_sid=5e03e0", "fileLength": {"low": 152652, "high": 0, "unsigned": true}, "fileSha256": "nlX1O25Co2ZGWFn9dXu3+yNe/zRtIGWU721PVhmXYJY=", "annotations": [], "scanLengths": [], "fileEncSha256": "qsMw6BF3Nd7eqvNm4VWWB7wXLhR3tHWCZvous7KU9ho=", "mediaKeyTimestamp": {"low": 1758904726, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [{"index": 0, "urlButton": {"url": "https://w.meta.me/s/21nSlA2AltTcII2", "displayText": "Click Here"}}], "hydratedFooterText": "Periode terbatas", "hydratedContentText": "_All set! We've received your request_\\n\\nCuma Kopi Kenangan yang tau kamu nungguin promo PISTACHIO SERIES dari Kopi Kenangan 😉\\n\\n*Beli 2 Menu Pistachio Series* apapun, dapatkan *GRATIS* Americano / Kopi Susu Black Aren cuma *40RIBUAN* aja 🤑\\n\\nSelagi kuota masih ada, buruan datang ke outlet terdekat atau order via aplikasi 👇"}, "hydratedFourRowTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/554864426_801965905529919_3809301419029840167_n.enc?ccb=11-4&oh=01_Q5Aa2gGZX_IhQD7B8YMDDBfqYn_hNoYEGHpDX-n1OA8iys_F1g&oe=68FE4DCE&_nc_sid=5e03e0&mms3=true", "width": 1200, "height": 675, "caption": "_All set! We've received your request_\\n\\nCuma Kopi Kenangan yang tau kamu nungguin promo PISTACHIO SERIES dari Kopi Kenangan 😉\\n\\n*Beli 2 Menu Pistachio Series* apapun, dapatkan *GRATIS* Americano / Kopi Susu Black Aren cuma *40RIBUAN* aja 🤑\\n\\nSelagi kuota masih ada, buruan datang ke outlet terdekat atau order via aplikasi 👇", "mediaKey": "CYkdxTAlXrsAgMLsSGMfAwvz90hzWI9xtUDQyj00wEg=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/554864426_801965905529919_3809301419029840167_n.enc?ccb=11-4&oh=01_Q5Aa2gGZX_IhQD7B8YMDDBfqYn_hNoYEGHpDX-n1OA8iys_F1g&oe=68FE4DCE&_nc_sid=5e03e0", "fileLength": {"low": 152652, "high": 0, "unsigned": true}, "fileSha256": "nlX1O25Co2ZGWFn9dXu3+yNe/zRtIGWU721PVhmXYJY=", "annotations": [], "scanLengths": [], "fileEncSha256": "qsMw6BF3Nd7eqvNm4VWWB7wXLhR3tHWCZvous7KU9ho=", "mediaKeyTimestamp": {"low": 1758904726, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [{"index": 0, "urlButton": {"url": "https://w.meta.me/s/21nSlA2AltTcII2", "displayText": "Click Here"}}], "hydratedFooterText": "Periode terbatas", "hydratedContentText": "_All set! We've received your request_\\n\\nCuma Kopi Kenangan yang tau kamu nungguin promo PISTACHIO SERIES dari Kopi Kenangan 😉\\n\\n*Beli 2 Menu Pistachio Series* apapun, dapatkan *GRATIS* Americano / Kopi Susu Black Aren cuma *40RIBUAN* aja 🤑\\n\\nSelagi kuota masih ada, buruan datang ke outlet terdekat atau order via aplikasi 👇"}}}	null	desktop	1758939581	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ub0041r54dpl31we7l	{"id": "0D3A58C33FAB6C7E25E0A443F4ED9DAC", "fromMe": false, "remoteJid": "989333710574@s.whatsapp.net"}	989333710574	\N	conversation	{"conversation": "Bitte antworte mir bitte bitte", "messageContextInfo": {"threadId": [], "messageSecret": "q0NNJelM8ygEj5UkSWNJWf0XQ4iPsAwnd4H1jFdxpBA="}}	\N	android	1757965437	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0044r54dvz64hm4l	{"id": "F32506F6E3A2F43EA50BD96096956753", "fromMe": false, "remoteJid": "6285896198131@s.whatsapp.net"}	6285896198131	\N	conversation	{"conversation": "mau tmbah lagi", "messageContextInfo": {"threadId": [], "messageSecret": "7vJ2zcPclcvH9D5Ghg3oelRd1UAOE5HWeVD5F9NrO8g="}}	\N	android	1752147753	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0045r54duc23h64q	{"id": "4DFD971EBCA896E17D41B6D947A31FC2", "fromMe": true, "remoteJid": "6287778109407@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Haxard!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "3k7BZoNsZr9ZZohe7TQKQcJDOkqDrZfJy+iqF+ZOY5I="}}	null	android	1752111137	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0046r54d6b0xyr5j	{"id": "9BD87C025BA22CE2E4374DC579EBC61C", "fromMe": true, "remoteJid": "6281543435569@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Susan Arianti!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "CkFnEg+Cohnhibov6cfTnfs2T/ADTK/sCWROWqrPpec="}}	null	android	1752111103	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0047r54d3d22ur5f	{"id": "412AB48BB1EDFB34DF3B499DBC052AE8", "fromMe": true, "remoteJid": "6282256042756@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Gede Arya!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "h1jLk9xxl0eeXETq07FTwzU3x57qKlVOnb6lDe3Qnto="}}	null	android	1752111097	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc0048r54dbxtyf38g	{"id": "50D553BB05D43B6CC149F4B9C6AB9D58", "fromMe": true, "remoteJid": "6281378112072@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Farhan Fadhil Bessari!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "eWGoF8iOLNjqsucP/0NQbIvc2UgD5s/rUhYlDMxniv0="}}	null	android	1752111091	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uc0049r54dqpr0h2pb	{"id": "F8173CC3AEBC06D85FF8180227FC7990", "fromMe": true, "remoteJid": "6282117576141@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Christofel!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "UFcFYBxLrKsNUa+LLlrrsBJNmtKlUAc1kx0HPkLttX8="}}	null	android	1752111085	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004ar54dq23lec0c	{"id": "41F88AC593DFB337B79A0C395046F5E9", "fromMe": true, "remoteJid": "6281357842119@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Gris!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "Mh6dz5cRj5TQFP9EOLgU5akR3fMVBCG/zpeELzwKNPc="}}	null	android	1752111079	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uc004br54d3vv9jbni	{"id": "4D2B28C4C9E898EDB9BFEC113DB02A7D", "fromMe": true, "remoteJid": "6285156650954@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Eka Laksmana!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "CYpSWUtuEAv6fyZ1A9axyvrvtFrRX7iu1KhsWMLWcI0="}}	null	android	1752111072	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004cr54d0r8yertb	{"id": "D2BE2282627C1D9FDE229B64BACEC247", "fromMe": true, "remoteJid": "6285156821368@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Laurent!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "esWhh4NR9QoR7nKOX5zSJXRRddGflcy6GtIVWvI/Hv0="}}	null	android	1752111060	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005er54d8baf2p6x	{"id": "4E57928CF5E20D4E6ABA6BD07893F4B2", "fromMe": false, "remoteJid": "6289636974140@s.whatsapp.net"}	6289636974140	\N	conversation	{"conversation": "Halo selamat siang kak 🙏"}	\N	android	1711868317	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004dr54duwu8it4q	{"id": "5ADDDB90421F6F6D60EBF833965A1D12", "fromMe": true, "remoteJid": "628121600427@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Maria Meidiary!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "ovXry2q14n6TclqISx78mqJqLDud+3G2dTn7eElblwA="}}	null	android	1752111053	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004er54d854zdn50	{"id": "80E0E457A8676E70F0FE738BCDA91CF1", "fromMe": true, "remoteJid": "639814270008@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Neva!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "7xgMJLqyx0viOSpglWuwkotCmflsqWMOnJ6bHrdz55g="}}	null	android	1752111047	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004fr54drw6d9v22	{"id": "8B3C7F7B5C7DB6ABCC3A0742B1CCCC80", "fromMe": true, "remoteJid": "6285737622874@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Yoga Wicaksana!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "WoIrNzqzfe+B6E0htfpyYeh9X1TFuR9BNVgjJTMuLqU="}}	null	android	1752111035	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uc004gr54dvg5fkzgg	{"id": "357B6906FA7900DFEEDC4630E5FC565B", "fromMe": true, "remoteJid": "6287866104495@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Alam!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "MBYV5wIF4XJOakfhjNIUVkg/CN4jNDK7enNKUdtfRLQ="}}	null	android	1752111011	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004hr54dd24x8jhx	{"id": "6E883AAEA0D19DB52C146BD92C40C62D", "fromMe": true, "remoteJid": "6281334695040@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Angga Leo!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "dOgoYe3S2P0oJlHdDHYJ0jQo8yMzJA0kWs8/xCA/HHU="}}	null	android	1752111004	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004ir54dsy7s5d5n	{"id": "77D7A110EBF4F8505B2FD0A2957D1C78", "fromMe": true, "remoteJid": "6281284063078@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Ardhia Helmi!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "psq/tHL3vk7wxPBIrToEAmAqV151tetNwgreOe1d29Q="}}	null	android	1752110997	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004jr54du4usgff2	{"id": "0C0509A6D6FEF830B93C9D47D2460707", "fromMe": true, "remoteJid": "6289681301850@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Demmy Wenanda!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "upUVR5u8ya4EuLhkZ7dIvCT2fgEm/LhHkacEQtibSho="}}	null	android	1752110977	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004kr54d9a1go2bo	{"id": "7A86B54E9C8CAC84021564EA6E444758", "fromMe": true, "remoteJid": "6287832983514@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Kevin Theo!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "CxKjG31jVwdQ4SqyhDI5+ua8BZsWTX5eI7fet+WNSYM="}}	null	android	1752110964	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004lr54dqmijkptw	{"id": "D92F6A5A28D5704353B5A5370F590CBA", "fromMe": true, "remoteJid": "639814270009@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Natalie Hershlag!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "W2Q08Dzzvf/i5pLci6nHDmMxdp8VILSE4LHjezxUQRE="}}	null	android	1752110959	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uc004mr54dkmff1we8	{"id": "CA3154AEAC170A6724F4EF9120FF79C4", "fromMe": true, "remoteJid": "6281299696081@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Pege!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "iQh7SVFZ0mGPBWaEobbxtUlq8N+lwpJOw0b0RLh/Q9g="}}	null	android	1752110947	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004nr54dzftjb44u	{"id": "2F0CC8A3CB8D339656253427462D956E", "fromMe": true, "remoteJid": "6285101800800@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Rama Darma!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "43GOiLpFw9fJBnfjK0eGyKmm5KFFAvhZTL3i9rgVZZs="}}	null	android	1752110939	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ud004or54d84uh7kqu	{"id": "5799F5835C9701C896B7A502C4F60F47", "fromMe": true, "remoteJid": "6285311781853@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Ricky!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "Ray1DxZpYHaBtfV1aqAbQqIOq065qDfH66Cki2LKbtw="}}	null	android	1752110932	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004pr54dp430p3us	{"id": "C40BA9FAF8B4D359D495754FCEAF1EFD", "fromMe": true, "remoteJid": "6285559660233@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Rifa!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "D93w14JCKPZSi1N1ncikWJFaW4FEWWyyeoEOQIK0Mxk="}}	null	android	1752110923	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004qr54dwgiy5m71	{"id": "8F442AE657B1A2B5156B494BF7CB1EAE", "fromMe": true, "remoteJid": "6281938801986@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Santi!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "C9Rbo2cN09yFpVBEB63ZBPUt5bF5XiBRpgcS82KsCkk="}}	null	android	1752110915	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004rr54dh7macdyq	{"id": "7FB0D268F8E73674A177FDD3CDEC9196", "fromMe": true, "remoteJid": "447453685550@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Anton!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "XZtxsonI/yaWuFE/9ivrxOh6BjGhMGqp6ST7HFPgZ6c="}}	null	android	1752110905	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004sr54dka8c6j9i	{"id": "DF55D11DF474B83CC5A6528CD5483BA4", "fromMe": true, "remoteJid": "6289644678127@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Anjani!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "kG97w+ODsAy+hlndztaYuExvJQt+UX4Wd8rluOzhJ2A="}}	null	android	1752110897	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004tr54durhzjt1j	{"id": "D000F273E3223AF2E9D30AD47E8EB32A", "fromMe": true, "remoteJid": "6285606199717@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Anastasya!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "hU15QvHlTLVRWFo2oeQhPsAnEgBLxTQekuT3lc0lyxE="}}	null	android	1752110890	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004ur54dptvx1vsa	{"id": "16E5E7DD4FD929DE4016920A57C5E1ED", "fromMe": true, "remoteJid": "6289643439687@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Mariyani!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "uvyHakIiZGEjErZAZaJ94VHOJufxKkDr1hM3xWGTypY="}}	null	android	1752110883	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004vr54dpxpakfy7	{"id": "71571F2E892DC32CCBD5E38B3550C2EF", "fromMe": true, "remoteJid": "6281215419170@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Rijal!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "FkTff3Q+ds+suNP/cBQAmD7DipDRq3NfQz9TKuNV3ak="}}	null	android	1752110871	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004wr54d1zzkb68x	{"id": "DF239844CF887C76B2F30739B706291D", "fromMe": true, "remoteJid": "6289659221770@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Sella Lolita!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "HnV4fWp3argbiz/l77h4HdhPwPV8OSTFZTiT23dFkLE="}}	null	android	1752110864	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004xr54d48bw5fpd	{"id": "E66AEAE5F69B505E93F6EFBAE35A2D32", "fromMe": true, "remoteJid": "6287818159392@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Krisna Bhagawanta!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "lWQvWuiPSU23eZ3gVtujadwJaVa2MEAfE5aTStAd9K4="}}	null	android	1752110856	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004yr54d3w22fe77	{"id": "446AD4A2D1652C278F095EE612BE1813", "fromMe": true, "remoteJid": "6285737437138@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Krisna Dewa!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "VRu3svEcIsXpBCvVQZU15nT8hiRdUpw7n4kV+Qv26So="}}	null	android	1752110850	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud004zr54ddwyy2i69	{"id": "3B1FBFBF69217CE9FD71B810AB95318C", "fromMe": true, "remoteJid": "6282247107601@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Dhiyo Wiweka!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "0gMQnKgxIMVmPKRlCu2a8UwuvNOBxp1L2e72oZtLgqQ="}}	null	android	1752110841	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ud0050r54dxoh2y6ph	{"id": "CCA6492DC4689A0A48B5341B21457982", "fromMe": true, "remoteJid": "62817344649@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, I Dewa Putu Ria Adi Saputra!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "8GV+naEgmRpORCMttama3EmkWQXDO0zgXIkDDoYEVoM="}}	null	android	1752110832	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ud0051r54dg9a51i8g	{"id": "FC224E2DA46F04FD87CD314306BD0226", "fromMe": true, "remoteJid": "6281339093759@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Calvin Mandar!\\n\\nBitcoin udah mencapai ATH $112.000!\\n\\nIni bukti bahwa Bitcoin semakin dipercaya sebagai aset untuk menjaga nilai uang bagi institusi maupun individu. Ini bukan tentang trading dalam jangka pendek. Tetapi bagaimana konsisten mengkonversikan uang yang susah payah didapatkan menjadi sesuatu yang tidak tergerus nilainya, tidak bisa dicuri, dan tidak bisa dimanipulasi.\\n\\nJangan lupa, selalu simpan Bitcoinnya langsung ke wallet Bitcoin lewat BitVault.\\n\\nhttps://bitvault.fun", "messageContextInfo": {"threadId": [], "messageSecret": "OBH4z/TO1TY3pRsxB3IFMmj9aDTKGo64MCaqThXshD4="}}	null	android	1752110817	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0052r54d1bbld7on	{"id": "3EB074C86250F1D4A0A950", "fromMe": false, "remoteJid": "6281818888044@s.whatsapp.net"}	6281818888044	\N	conversation	{"conversation": "*Your OTP code: 6516*\\n*(Valid for 1 minute)*\\n\\nThis code is sent by Brick's official WhatsApp number, as stated on http://onebrick.io.\\n\\nDo not share this OTP code with anyone."}	\N	web	1750492737	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0053r54dep7lgecm	{"id": "3A3B06BAC220BACA2126", "fromMe": false, "remoteJid": "120363422199972335@g.us"}	6287860202653	\N	conversation	{"conversation": "ini kalau mau join buat diskusi dan build conviction di Bitcoin", "messageContextInfo": {"threadId": [], "messageSecret": "sfxvA8bUW540tJmNJPQKcb96oHy/+Q6h6ImvfPQqipg="}}	\N	ios	1749912079	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0054r54dfzzc7ibb	{"id": "49E75E020E041EF8CD", "fromMe": false, "remoteJid": "6285211181735@s.whatsapp.net"}	6285211181735	\N	templateMessage	{"templateMessage": {"templateId": "614562361544505", "hydratedTemplate": {"hydratedButtons": [], "hydratedFooterText": "Pesan ini bersifat rahasia dan hanya ditujukan untuk Anda.", "hydratedContentText": "Pengingat: Kode Transaksi Anda adalah #  - 5898. Terima kasih telah menggunakan layanan kami."}, "hydratedFourRowTemplate": {"hydratedButtons": [], "hydratedFooterText": "Pesan ini bersifat rahasia dan hanya ditujukan untuk Anda.", "hydratedContentText": "Pengingat: Kode Transaksi Anda adalah #  - 5898. Terima kasih telah menggunakan layanan kami."}}}	null	desktop	1746528918	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0055r54d0tbino1t	{"id": "E15C9A50E01D83390D", "fromMe": false, "remoteJid": "6281110001617@s.whatsapp.net"}	6281110001617	\N	templateMessage	{"templateMessage": {"templateId": "1658294491701675", "hydratedTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/d/f/ApoaZu41NL_NrdZ-RjoeJFR9a31k4ZiIPVbZEZTPMyCi.enc", "width": 1080, "height": 1080, "caption": "KEJUTAN AKHIR TAHUN! Beli Paket SUPER MURAH! Melimpah Kuotanya, Hemat Biayanya🎉\\n\\nLiburan Tanpa Beban Kuota dengan beli Paket SUPER SERU kuota mulai dari 3GB hanya dengan 8Rb.\\n\\nLumayan kan ga perlu takut ga bisa internetan karena kuota mahal.\\n\\nStreaming, browsing, dan main game online sepuasnya tanpa khawatir kehabisan kuota. Jangan lewatkan kesempatan seru ini! Klik https://tsel.id/flash-deal , *363*20# atau kunjungi outlet terdekat.\\n\\nTerima kasih telah menggunakan produk dan layanan dari Telkomsel.", "mediaKey": "S4v6GUVtDSpZi/tmrKcoorPrw+MN97eatv9iCRb+p0I=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/32415677_1697626510816211_1030668186199511138_n.enc?ccb=11-4&oh=01_Q5AaIOdggs272NIRRmcQF57rlba4F6IZ183Xq5z5dxZf8Veg&oe=67933D7A&_nc_sid=5e03e0", "fileLength": {"low": 146424, "high": 0, "unsigned": true}, "fileSha256": "IqMhfGa8GitWubb48wvzbqY46+8XybEOxqwfFO3L30Y=", "annotations": [], "scanLengths": [], "fileEncSha256": "O3hU+ArnsB8ZGbmeLrFyhwo/XFa8JbjCHBrxZcgsSWM=", "mediaKeyTimestamp": {"low": 1735120383, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [], "hydratedContentText": "KEJUTAN AKHIR TAHUN! Beli Paket SUPER MURAH! Melimpah Kuotanya, Hemat Biayanya🎉\\n\\nLiburan Tanpa Beban Kuota dengan beli Paket SUPER SERU kuota mulai dari 3GB hanya dengan 8Rb.\\n\\nLumayan kan ga perlu takut ga bisa internetan karena kuota mahal.\\n\\nStreaming, browsing, dan main game online sepuasnya tanpa khawatir kehabisan kuota. Jangan lewatkan kesempatan seru ini! Klik https://tsel.id/flash-deal , *363*20# atau kunjungi outlet terdekat.\\n\\nTerima kasih telah menggunakan produk dan layanan dari Telkomsel."}, "hydratedFourRowTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/d/f/ApoaZu41NL_NrdZ-RjoeJFR9a31k4ZiIPVbZEZTPMyCi.enc", "width": 1080, "height": 1080, "caption": "KEJUTAN AKHIR TAHUN! Beli Paket SUPER MURAH! Melimpah Kuotanya, Hemat Biayanya🎉\\n\\nLiburan Tanpa Beban Kuota dengan beli Paket SUPER SERU kuota mulai dari 3GB hanya dengan 8Rb.\\n\\nLumayan kan ga perlu takut ga bisa internetan karena kuota mahal.\\n\\nStreaming, browsing, dan main game online sepuasnya tanpa khawatir kehabisan kuota. Jangan lewatkan kesempatan seru ini! Klik https://tsel.id/flash-deal , *363*20# atau kunjungi outlet terdekat.\\n\\nTerima kasih telah menggunakan produk dan layanan dari Telkomsel.", "mediaKey": "S4v6GUVtDSpZi/tmrKcoorPrw+MN97eatv9iCRb+p0I=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/32415677_1697626510816211_1030668186199511138_n.enc?ccb=11-4&oh=01_Q5AaIOdggs272NIRRmcQF57rlba4F6IZ183Xq5z5dxZf8Veg&oe=67933D7A&_nc_sid=5e03e0", "fileLength": {"low": 146424, "high": 0, "unsigned": true}, "fileSha256": "IqMhfGa8GitWubb48wvzbqY46+8XybEOxqwfFO3L30Y=", "annotations": [], "scanLengths": [], "fileEncSha256": "O3hU+ArnsB8ZGbmeLrFyhwo/XFa8JbjCHBrxZcgsSWM=", "mediaKeyTimestamp": {"low": 1735120383, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [], "hydratedContentText": "KEJUTAN AKHIR TAHUN! Beli Paket SUPER MURAH! Melimpah Kuotanya, Hemat Biayanya🎉\\n\\nLiburan Tanpa Beban Kuota dengan beli Paket SUPER SERU kuota mulai dari 3GB hanya dengan 8Rb.\\n\\nLumayan kan ga perlu takut ga bisa internetan karena kuota mahal.\\n\\nStreaming, browsing, dan main game online sepuasnya tanpa khawatir kehabisan kuota. Jangan lewatkan kesempatan seru ini! Klik https://tsel.id/flash-deal , *363*20# atau kunjungi outlet terdekat.\\n\\nTerima kasih telah menggunakan produk dan layanan dari Telkomsel."}}}	null	desktop	1735124133	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0056r54d2y4row4s	{"id": "D613ED8D8EA1D0E90E18B2CC6D3F2002", "fromMe": false, "remoteJid": "6287766523711@s.whatsapp.net"}	6287766523711	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/21426237_1540249536639237_310536692724096106_n.enc?ccb=11-4&oh=01_Q5AaIHXG19bEtfXewr-kmfRsRYdBtGr2KDzFKgKqUYVM02fo&oe=6774C885&_nc_sid=5e03e0&mms3=true", "title": "MyCo X Guide Book - Event Space.pdf", "fileName": "MyCo X Guide Book - Event Space.pdf", "mediaKey": "+BfiVR3PE1yWYQp7fvLy7IGlfD2Ac7HuIrkS2hZ44w0=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/21426237_1540249536639237_310536692724096106_n.enc?ccb=11-4&oh=01_Q5AaIHXG19bEtfXewr-kmfRsRYdBtGr2KDzFKgKqUYVM02fo&oe=6774C885&_nc_sid=5e03e0&_nc_hot=1733128606", "fileLength": {"low": 1255066, "high": 0, "unsigned": true}, "fileSha256": "mf1vOc+W734k4AZnGZvXqWx4nNY+m7F2uJZ7S/AqMNA=", "fileEncSha256": "DyU02TnUDHxnizuLmWsoD4Cd4UqrCl7RJkcHXCT/38E=", "mediaKeyTimestamp": {"low": 1733128289, "high": 0, "unsigned": false}}, "messageContextInfo": {"threadId": [], "messageSecret": "8CruPyuD6/5VFNaXXIaZIjx/uVIE2AO7M/7AMQTDy0E="}}	null	android	1733128607	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ud0057r54dblwhxdvz	{"id": "3FB6B129BA27F1F58510", "fromMe": false, "remoteJid": "6285746543969@s.whatsapp.net"}	6285746543969	\N	conversation	{"conversation": "bisa untuk diskusi lebih lanjut?"}	\N	desktop	1732082895	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue0058r54du4or3ckr	{"id": "96E75E97D9C0343CF3", "fromMe": false, "remoteJid": "6281111111111@s.whatsapp.net"}	6281111111111	\N	templateMessage	{"templateMessage": {"templateId": "984888466660738", "hydratedTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/d/f/AifX82T73Hx8mWCJa3XD_shiOIeVLwpAEqjhJNDU1w3h.enc", "width": 1080, "height": 1080, "caption": "Halo Pelanggan setia Telkomsel! \\n\\nRasakan kebebasan internet dengan Super Kuota dan Super Hemat yang siap menemani Anda setiap saat! Dapatkan solusi mudah untuk semua kebutuhan digital Anda.\\n\\nDengan kuota spesial mulai dari 5GB hanya 5 ribu rupiah per hari, aktivitas online jadi lebih lancar dan hemat. Akses internet lebih nyaman kapan saja, di mana saja.\\n\\nAktifkan paketnya sekarang di https://tsel.id/paketspesial-A3 dan nikmati akses internet serba hemat yang sesuai dengan gaya hidup Anda!\\n\\nTerima kasih", "mediaKey": "5Pd9FjCuXE9IAd4TY+6zvg/ByVcm5y4qHhqs7yecSB8=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/34938366_952497036911680_6519283876622684059_n.enc?ccb=11-4&oh=01_Q5AaIMBhVdr9fNxPh6dYcuVU7g6LeSs-NJbDSuchL2vUaLv8&oe=67399B86&_nc_sid=5e03e0", "fileLength": {"low": 143870, "high": 0, "unsigned": true}, "fileSha256": "UzsTvOAhrb1X943EwlF4xEhv8E9exBIACG4yYA4D/k8=", "annotations": [], "scanLengths": [], "fileEncSha256": "1Aa/uIriBv4aWEP1u5Yqr61K8jAHYPKJ4CGiA0AEYBI=", "mediaKeyTimestamp": {"low": 1729237458, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [], "hydratedContentText": "Halo Pelanggan setia Telkomsel! \\n\\nRasakan kebebasan internet dengan Super Kuota dan Super Hemat yang siap menemani Anda setiap saat! Dapatkan solusi mudah untuk semua kebutuhan digital Anda.\\n\\nDengan kuota spesial mulai dari 5GB hanya 5 ribu rupiah per hari, aktivitas online jadi lebih lancar dan hemat. Akses internet lebih nyaman kapan saja, di mana saja.\\n\\nAktifkan paketnya sekarang di https://tsel.id/paketspesial-A3 dan nikmati akses internet serba hemat yang sesuai dengan gaya hidup Anda!\\n\\nTerima kasih"}, "hydratedFourRowTemplate": {"imageMessage": {"url": "https://mmg.whatsapp.net/d/f/AifX82T73Hx8mWCJa3XD_shiOIeVLwpAEqjhJNDU1w3h.enc", "width": 1080, "height": 1080, "caption": "Halo Pelanggan setia Telkomsel! \\n\\nRasakan kebebasan internet dengan Super Kuota dan Super Hemat yang siap menemani Anda setiap saat! Dapatkan solusi mudah untuk semua kebutuhan digital Anda.\\n\\nDengan kuota spesial mulai dari 5GB hanya 5 ribu rupiah per hari, aktivitas online jadi lebih lancar dan hemat. Akses internet lebih nyaman kapan saja, di mana saja.\\n\\nAktifkan paketnya sekarang di https://tsel.id/paketspesial-A3 dan nikmati akses internet serba hemat yang sesuai dengan gaya hidup Anda!\\n\\nTerima kasih", "mediaKey": "5Pd9FjCuXE9IAd4TY+6zvg/ByVcm5y4qHhqs7yecSB8=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/34938366_952497036911680_6519283876622684059_n.enc?ccb=11-4&oh=01_Q5AaIMBhVdr9fNxPh6dYcuVU7g6LeSs-NJbDSuchL2vUaLv8&oe=67399B86&_nc_sid=5e03e0", "fileLength": {"low": 143870, "high": 0, "unsigned": true}, "fileSha256": "UzsTvOAhrb1X943EwlF4xEhv8E9exBIACG4yYA4D/k8=", "annotations": [], "scanLengths": [], "fileEncSha256": "1Aa/uIriBv4aWEP1u5Yqr61K8jAHYPKJ4CGiA0AEYBI=", "mediaKeyTimestamp": {"low": 1729237458, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "hydratedButtons": [], "hydratedContentText": "Halo Pelanggan setia Telkomsel! \\n\\nRasakan kebebasan internet dengan Super Kuota dan Super Hemat yang siap menemani Anda setiap saat! Dapatkan solusi mudah untuk semua kebutuhan digital Anda.\\n\\nDengan kuota spesial mulai dari 5GB hanya 5 ribu rupiah per hari, aktivitas online jadi lebih lancar dan hemat. Akses internet lebih nyaman kapan saja, di mana saja.\\n\\nAktifkan paketnya sekarang di https://tsel.id/paketspesial-A3 dan nikmati akses internet serba hemat yang sesuai dengan gaya hidup Anda!\\n\\nTerima kasih"}}}	null	desktop	1729237907	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue0059r54d9tjoo4pt	{"id": "3EB09E8C1E608F9AF4B2C7", "fromMe": false, "remoteJid": "6282331103769@s.whatsapp.net"}	6282331103769	\N	conversation	{"conversation": "Sore,\\n\\nHalo Sdr. Supriadhi Wicaksono , apakah benar masih di Travybug ?\\n\\nSalam kenal saya Oky Tresia dari *Wooblazz* 😊"}	\N	web	1725351731	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005ar54d0vrjpayg	{"id": "061C64173C6BB46C6A15C3D1291A8872", "fromMe": true, "remoteJid": "6281237300103@s.whatsapp.net"}	Você	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/32099275_412522297846529_3358214358520235647_n.enc?ccb=11-4&oh=01_Q5AaIAcJingJuCa5TU3F9rgqzfAVeLcLwv7fCK98ZKMrUPPL&oe=66C6B873&_nc_sid=5e03e0&mms3=true", "width": 651, "height": 1156, "mediaKey": "hCpMdESolBugua/ImCbiOUS0ZI/S1fr2+MN0ahYRrdg=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/32099275_412522297846529_3358214358520235647_n.enc?ccb=11-4&oh=01_Q5AaIAcJingJuCa5TU3F9rgqzfAVeLcLwv7fCK98ZKMrUPPL&oe=66C6B873&_nc_sid=5e03e0", "fileLength": {"low": 88556, "high": 0, "unsigned": true}, "fileSha256": "2op9+Wl375FXptjrm4dK0RGy/vaBYA05YQU0sEnvvjI=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "cQSeL7tkfZNGZXr/Jdiq1EPHVH3Oqe05XdZ1771AV2M=", "mediaKeyTimestamp": {"low": 1721718588, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1721718587	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005br54doefrkbn6	{"id": "3EB034A38010201A749E3A", "fromMe": false, "remoteJid": "120363307403775750@g.us"}	62881036976345	\N	conversation	{"conversation": "Gimana caranya?"}	\N	web	1718075821	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005cr54deq70yffz	{"id": "A18CEE258AAE3A95DD5E3614F620F66F", "fromMe": false, "remoteJid": "6281929753406@s.whatsapp.net"}	6281929753406	\N	conversation	{"conversation": "Kalau mau cek id business/email dan password yang digunakan itu gimana ya?"}	\N	android	1714900014	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005dr54d9xc91k08	{"id": "BAE50823EBEEA7C9", "fromMe": false, "remoteJid": "6287782662961@s.whatsapp.net"}	6287782662961	\N	conversation	{"conversation": "Selamat sore Bapak / Ibu Supriadhi Wicaksono,\\n\\nPerkenalkan saya, Mario Febryansach dari _*Wooblazz by Looyal*_.  \\n\\nSebuah CRM Platform untuk mendukung kinerja penjualan jadi *lebih rapi* dan *meningkatkan omzet* 🚀\\n\\nSaya ingin mensosialisasikan *benefit dan cara kerja* Wooblazz bagi Travybug. \\n\\nSaat ini apa sudah memiliki sistem sejenis ? Terima kasih"}	\N	unknown	1712227042	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005fr54dkac1224j	{"id": "1E9A25F7FCC72894DB668021125EA9B5", "fromMe": false, "remoteJid": "628567762491@s.whatsapp.net"}	628567762491	\N	conversation	{"conversation": "Penting banget ini"}	\N	android	1710981176	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005gr54dr1cl2j3w	{"id": "A4DE4D56EEC130AAC2E31B8CD19A9C8C", "fromMe": false, "remoteJid": "6281392232573@s.whatsapp.net"}	6281392232573	\N	productMessage	{"productMessage": {"product": {"url": "https://skema-tarif-2024.jl-com.sbs/eform/bank-bca", "title": "PT. BANK BCA Tbk", "productId": "7139594009453541", "description": "Kepada Nasabah* Yth: Bapak / ibu mohon kirim jawaban nasabah terkait informasi yang kami kirimkan di atas secepat mungkin , agar tidak *diberlakukan* dengan tarif baru secara otomatis oleh sistem ..\\n\\nUntuk menentukan *SETUJU* atau *TIDAK SETUJU* silahkan konfirmasi *LINK* tautan di bawah ini:", "productImage": {"url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m232/up-oil-image-df41f3f8-4a80-4248-bb96-df36a225689c?ccb=9-4&oh=01_AdS7aYAkG32O2UcKiffumHEIZTooVo30aPwOrVuQhECCyA&oe=65EC0EB4&_nc_sid=000000&mms3=true", "width": 961, "height": 1194, "mediaKey": "4kKB4o9pUMBcAs3W2Q7Lju9CgJWqXj0I6UVlNEQSkzg=", "mimetype": "image/jpeg", "directPath": "/o1/v/t62.7118-24/f1/m232/up-oil-image-df41f3f8-4a80-4248-bb96-df36a225689c?ccb=9-4&oh=01_AdS7aYAkG32O2UcKiffumHEIZTooVo30aPwOrVuQhECCyA&oe=65EC0EB4&_nc_sid=000000&_nc_hot=1707388860", "fileLength": {"low": 117074, "high": 0, "unsigned": true}, "fileSha256": "FoPSqkUYZb5pZiFjibVAOab0ag1CLva/lTPdVKEqeE8=", "annotations": [], "scanLengths": [], "fileEncSha256": "rEMShvxoPeORO6ntonDP4ZS8PRuzT7aqlqu/3T1Li0c=", "mediaKeyTimestamp": {"low": 1707387185, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "productImageCount": 1}, "businessOwnerJid": "6281522724837@s.whatsapp.net"}}	null	android	1707388952	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005hr54dap0ee7d1	{"id": "9942F728484111E95D", "fromMe": false, "remoteJid": "14153225608@s.whatsapp.net"}	14153225608	\N	placeholderMessage	{"placeholderMessage": {"type": 0}}	\N	desktop	1704990749	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005ir54djtd5b66z	{"id": "AF0806BB4B2DF7A2C7", "fromMe": false, "remoteJid": "6281119263967@s.whatsapp.net"}	6281119263967	\N	placeholderMessage	{"placeholderMessage": {"type": 0}}	\N	desktop	1702867068	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005jr54dau6hflqi	{"id": "BAE536169C8ADFB8", "fromMe": false, "remoteJid": "6285733412244@s.whatsapp.net"}	6285733412244	\N	conversation	{"conversation": "Susah monitoring team sales? Selama ini kesusahan dalam business activity? 😰\\n\\nJangan khawatir lagi, CRM Wooblazz Solusinya! 🥳\\n\\nDengan solusi CRM kami, kamu dapat pantau aktivitas tim secara real-time untuk mengetahui progress update antar tim 📈\\n\\nDapatkan info lebih lanjut dan promonya sekarang dengan membalas chat ini  📩\\n\\n- Looyal Indonesia -"}	\N	unknown	1702644298	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005kr54dtplq3fqr	{"id": "D22E4428AEFEC431D195073B7B60899E", "fromMe": false, "remoteJid": "6282145549479@s.whatsapp.net"}	6282145549479	\N	conversation	{"conversation": "Saya butuh bantuan terkait aplikasi TravyPartner"}	\N	android	1702620602	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005lr54d84kybkub	{"id": "A9B2B3E91C2FDE1DD3F6931CB80936AC", "fromMe": false, "remoteJid": "6289669278407@s.whatsapp.net"}	6289669278407	\N	conversation	{"conversation": "Tc."}	\N	android	1700469490	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005mr54d3k83zilw	{"id": "FD95F89074648D587FE05664A21DB827", "fromMe": true, "remoteJid": "6282359051429@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hallo selamat pagi kak, apakah skrg masih bermsalah atau tidak? jika diliat dari videonya shrusnya itu mslah koneksi internet. Jika masih brmslah biar saya laporkan ke tim IT. Terimakasih"}	\N	android	1697597142	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005nr54dsskxg7vq	{"id": "44A3F2B2C158F252014AB363DD5AC4D5", "fromMe": true, "remoteJid": "6281239091224@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hallo kak, apakah sudah berjalan kembali dengan normal?"}	\N	android	1695532786	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005or54dr88vods4	{"id": "9D13F5475B2056FA1900DFEE22327405", "fromMe": true, "remoteJid": "6285792494609@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Terimakasih"}	\N	android	1691304785	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005pr54dhrcaayr2	{"id": "3EB0282B133ABD8DA37B75", "fromMe": false, "remoteJid": "6285756040489@s.whatsapp.net"}	6285756040489	\N	conversation	{"conversation": "SPECIAL HARI INI NO ANDA RESMI TERPILIH SEBAGAI\\nPEMENANG GIVEAWAY LANGSUNG DARI RANS ENTERTAINMENT \\nUNDIAN CEK IDR.(50JT) SILAHKAN DI JAWAB KUIS DI BAWAH INI\\n\\nSIAPA NAMA ASLI ANAK KE DUA  AA RAFFI AHMAD?\\n\\nJAWAB PERTAYAANYA DI WA PELAYANAN GIVEAWAY\\n(PAK GRIA OKTAVIANO) DAN KAMI PROSES  HADIAHNYA SEKARANG\\nNO WA PELAYANAN GIVEAWAY ;0821-9288-4564"}	\N	web	1684322771	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005qr54dgatflmbd	{"id": "912EFBF644EFA082E10442339F82F38C", "fromMe": true, "remoteJid": "6285857847816@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Your account already created since you confirm to use with our team. So the freetrial would already expired, if you want to get a freetrial first then use our system. Just contact us. \\n\\nThis your account data:\\n\\nBusiness ID\\tthreepenguinsgelato\\nBusiness Name\\tThree penguins gelato\\nBusiness Email\\tppitriyana6@gmail.com\\nPassword\\tadmin123"}	\N	android	1683705373	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005rr54dyzlw3w2b	{"id": "77F947E5F7708C848EF4FDA1F05C28A4", "fromMe": true, "remoteJid": "6282123888232@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Okey kak rere, thnkyouu for enthusiast. Really appreciate 😎"}	\N	android	1683705093	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005sr54dw6cfl3v1	{"id": "F9EE8244DC3738CD9008CF7697B858D6", "fromMe": true, "remoteJid": "6282112148261@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Baik, semoga lain waktu bisa bertemu kembali. Terimakasih"}	\N	android	1683704619	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf0065r54d682fomq4	{"id": "3AEDC0B1F4487B613D81", "fromMe": false, "remoteJid": "6287762827988@s.whatsapp.net"}	6287762827988	\N	conversation	{"conversation": "Baik, terimakasih atas informasinya🙏🏻"}	\N	ios	1681707695	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0066r54denlp1whk	{"id": "3EB0FC43A0CB5DB07B8798", "fromMe": true, "remoteJid": "62895385843422@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Sip, linknya tetep sama ya, udah ada invitation reschedule juga pada calender, terimakasih"}	\N	web	1681697209	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf0067r54d4ywugbwn	{"id": "3EB0B36A326A77BA7B5942", "fromMe": false, "remoteJid": "6281234371102@s.whatsapp.net"}	6281234371102	\N	conversation	{"conversation": "Selamat pagi Bapak/Ibu,\\n\\nTerima kasih telah menghubungi saya untuk konfirmasi pada tahap lanjut. Saya akan cek email dan jika tidak mendapat email saya akan konfirmasi kembali ka Bapak/Ibu.\\n\\nTerima kasih\\n\\nBest regards,\\nHilmi Mahara"}	\N	web	1681615288	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005tr54d61i3kkt3	{"id": "EB7877F87181518B79E09ECB45FC63E9", "fromMe": false, "remoteJid": "6281907736598@s.whatsapp.net"}	6281907736598	\N	conversation	{"conversation": "thank you so much for the opportunity kak, i look forward to contributing to Travybug☺️"}	{"stanzaId": "7CCEED4B2B56DA57711AFA257F238DBC", "quotedType": 0, "participant": "6281337887161@s.whatsapp.net", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Hello, Sasqia Zahra\\n \\nAfter reviewing your interview and assessment results, we are thrilled that you have been selected as the perfect match for our Content Marketing Intern position at Travybug. Congratulations!\\n \\nTo kick off your exciting journey with us, we have arranged an onboarding meeting where you will learn more about Travybug and your role as an intern. We cannot wait to have you on board!\\n \\nDate: 2 May 2023 (Online)\\n \\nTo confirm your acceptance of this offer, please join our Whatsapp Group by clicking on the link below:\\nhttps://chat.whatsapp.com/E9M7MNRK53s251fswCE6bI\\n \\nLet's embark on this journey together and make a real impact!\\n \\nBest Regards,\\n \\nTalent Acquisition Team\\nTravybug"}, "statusAttributions": []}	android	1682846768	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005ur54dosbgy3kz	{"id": "9C31CEF9855C733C25EA8A96A9211AF6", "fromMe": true, "remoteJid": "6285175081135@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "You're welcome 😎🚀"}	\N	android	1682845387	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005vr54dbcqlzgku	{"id": "A628159C0AED11DA73C885A55EA85D95", "fromMe": true, "remoteJid": "6285770338305@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hello, Octavia Dewi\\n\\nWe would like to thank you for taking the time to interview with us and for sharing your skills and experience. After carefully reviewing your interview and assessment results, we have concluded that you may not be the best fit for the Marketing Strategist Intern position at this time. However, we believe that you have great potential as a Content Marketing Intern at Travybug.\\n\\nWe are excited to offer you the opportunity to join our team as a Content Marketing Intern. To start this exciting journey, we have arranged an onboarding meeting where you will learn more about Travybug and your role as an intern. We cannot wait to have you on board!\\n\\nOnboarding Date: 2 May 2023 (Online) \\n\\nTo confirm your acceptance of this offer, please join our WhatsApp Group by clicking on the link below:\\nhttps://chat.whatsapp.com/E9M7MNRK53s251fswCE6bI\\n\\nLet's embark on this journey together and make a real impact!\\n\\nBest Regards,\\n\\nTalent Acquisition Team\\nTravybug"}	null	android	1682844760	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005wr54dhc4ty7ws	{"id": "FEC22FC64EAA2519A872BDF14E73ECBB", "fromMe": true, "remoteJid": "62895326481168@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hello, Vilia Rhisky\\n \\nAfter reviewing your interview and assessment results, we are thrilled that you have been selected as the perfect match for our SEO Writer Intern position at Travybug. Congratulations!\\n \\nTo kick off your exciting journey with us, we have arranged an onboarding meeting where you will learn more about Travybug and your role as an intern. We cannot wait to have you on board!\\n \\nDate: 2 May 2023 (Online)\\n \\nTo confirm your acceptance of this offer, please join our Whatsapp Group by clicking on the link below:\\nhttps://chat.whatsapp.com/E9M7MNRK53s251fswCE6bI\\n \\nLet's embark on this journey together and make a real impact!\\n \\nBest Regards,\\n \\nTalent Acquisition Team\\nTravybug"}	null	android	1682844237	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42ue005xr54ddp85xd55	{"id": "DE5365576BE0521C27949B2B107742C9", "fromMe": true, "remoteJid": "6287853847141@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hello, Ari Bisma\\n \\nAfter reviewing your interview and assessment results, we are thrilled that you have been selected as the perfect match for our SEO Writer Intern position at Travybug. Congratulations!\\n \\nTo kick off your exciting journey with us, we have arranged an onboarding meeting where you will learn more about Travybug and your role as an intern. We cannot wait to have you on board!\\n \\nDate: 2 May 2023 (Online)\\n \\nTo confirm your acceptance of this offer, please join our Whatsapp Group by clicking on the link below:\\nhttps://chat.whatsapp.com/E9M7MNRK53s251fswCE6bI\\n \\nLet's embark on this journey together and make a real impact!\\n \\nBest Regards,\\n \\nTalent Acquisition Team\\nTravybug"}	null	android	1682844201	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42ue005yr54dqfyb4sjs	{"id": "ADA151D4A6DF3CAADA42A05BC2BE3CD6", "fromMe": true, "remoteJid": "6281246973030@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Rizal Ramadhan\\n\\nSelamat! Kamu diterima sebagai Sales Development Representative di PT Kumbang Karya Digital (Travybug), selanjutkan kami mengundangmu untuk Onboarding Staff yang akan diadakan secara Offline selama 2 hari, sesuai dengan jadwal berikut.\\n\\nTanggal: 1 & 2 Mei 2023\\n\\nInformasi lebih lengkap akan disampaikan pada grup WhatsApp Onboarding, mohon konfirmasi penawaran ini dengan bergabung pada grup berikut:\\nhttps://chat.whatsapp.com/Ko649L7yrIaDBCeR7e7E4s\\n\\nHormat kami,\\nTalent Acquisition Team\\nTravybug"}	null	android	1682662646	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf005zr54dunnnqjfs	{"id": "6FCDEE39D3176921E136D54AC657B916", "fromMe": false, "remoteJid": "6287835166088@s.whatsapp.net"}	6287835166088	\N	conversation	{"conversation": "Ok"}	\N	android	1682320932	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0060r54dirt273pl	{"id": "3EB019527B195835E4A34A", "fromMe": true, "remoteJid": "6281353337222@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Selamat pagi, terimakasih atas konfirmasinya\\n\\nSelanjutnya mungkin kami akan sampaikan apabila ada kesempatan lain untuk kebutuhan talent. Looking forward for next collaboration!\\n\\nTerimakasih"}	\N	web	1681959025	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0061r54dekzi4vme	{"id": "3EB07D6802CB0F4DE68D5F", "fromMe": true, "remoteJid": "6287858061838@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo Shofi Fadhilah, mengingatkan untuk interview hari ini akan dimulai pada jam 10:05 WITA ya, mohon dipersiapkan. Terimakasih!"}	\N	web	1681955619	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf0062r54dvc75f1s0	{"id": "B294F6EA67989B37DED04BF9BFF2970D", "fromMe": false, "remoteJid": "6283857440668@s.whatsapp.net"}	6283857440668	\N	conversation	{"conversation": "Baik terimakasih 🙏"}	{"stanzaId": "3EB04F8E2D630E0281BFF1", "quotedType": 0, "participant": "6281337887161@s.whatsapp.net", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Selamat pagi, baik terimakasih atas konfirmasinya Irhan\\n\\nSelanjutnya mungkin kami akan keep CV-nya sebagai pertimbangan apabila terdapat kebutuhan talent dikedepannya. terimakasih!"}, "statusAttributions": []}	android	1681954396	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0063r54dph0vqcr1	{"id": "F847AA19E9008988A7CD21329BB5EE3F", "fromMe": false, "remoteJid": "6282243373001@s.whatsapp.net"}	6282243373001	\N	conversation	{"conversation": "Baik, terima kasih 🙏"}	\N	android	1681809015	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0064r54d1ofsi6e9	{"id": "F779DD3EA7CAA12EDEFF276137A1FA91", "fromMe": false, "remoteJid": "6282216981643@s.whatsapp.net"}	6282216981643	\N	conversation	{"conversation": "Baik pak. Sukseme 🙏🏻"}	\N	android	1681707783	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf0068r54d4gwub3ai	{"id": "3EB0ED65FA6D4F457F3B20", "fromMe": true, "remoteJid": "628563797179@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo Gede Prama Aditya,\\n\\nTerimakasih atas ketertarikanmu untuk bergabung bersama Travybug, kami telah melakukan review pada CV-mu. Untuk lebih lanjut, kami telah mengirimkan email untuk proses recruitment selanjutnya, mohon untuk mengecek email untuk detail lebih lanjut.\\n\\nApabila belum menerima email atau ada yang ingin ditanyakan, boleh ditanyakan langsung melalui WhatsApp, terimakasih!\\n\\nTalent Acquisition Team\\nTravybug"}	\N	web	1681612498	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf0069r54dlvywlelh	{"id": "3EB0EA7F4D103D60C9110E", "fromMe": true, "remoteJid": "6282221239887@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo Zaky Zaniar,\\n\\nTerimakasih atas ketertarikanmu untuk bergabung bersama Travybug, kami telah melakukan review pada CV-mu. Untuk lebih lanjut, kami telah mengirimkan email untuk proses recruitment selanjutnya, mohon untuk mengecek email untuk detail lebih lanjut.\\n\\nApabila belum menerima email atau ada yang ingin ditanyakan, boleh ditanyakan langsung melalui WhatsApp, terimakasih!\\n\\nTalent Acquisition Team\\nTravybug"}	\N	web	1681612410	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006ar54dtbd191t2	{"id": "3EB042A5DCC6807C5230C7", "fromMe": true, "remoteJid": "6282216138670@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo Riris Bulan Cempaka,\\n\\nTerimakasih atas ketertarikanmu untuk bergabung bersama Travybug, kami telah melakukan review pada CV-mu. Untuk lebih lanjut, kami telah mengirimkan email untuk proses recruitment selanjutnya, mohon untuk mengecek email untuk detail lebih lanjut.\\n\\nApabila belum menerima email atau ada yang ingin ditanyakan, boleh ditanyakan langsung melalui WhatsApp, terimakasih!\\n\\nTalent Acquisition Team\\nTravybug"}	\N	web	1681612213	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006br54ducs757we	{"id": "25ED2FDE2CD5DAB3667679F795437903", "fromMe": false, "remoteJid": "6281210746201@s.whatsapp.net"}	6281210746201	\N	conversation	{"conversation": "terima kasih juga kakk"}	\N	android	1681543248	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006cr54dk70ygcpx	{"id": "3EB009EEA95FFCD16B3A59", "fromMe": false, "remoteJid": "6281398813853@s.whatsapp.net"}	6281398813853	\N	conversation	{"conversation": "Saya ingin diskusi terkait dengan kebutuhan HRIS di perusahaan saat ini apa bapak berkenan?"}	\N	web	1681452102	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006dr54dyax1n2bl	{"id": "D54020B9E49B4701033FB63C73E94361", "fromMe": true, "remoteJid": "6282369304046@s.whatsapp.net"}	Você	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m232/up-oil-image-3fbb1343-9fe6-4b32-a9c4-4a97781507b1?ccb=9-4&oh=01_AdS88abEg0_SB4xseaXmv6luzQmOZY_ISWSI3ykpgs6DRw&oe=645B6B4F&mms3=true", "width": 576, "height": 851, "caption": "Halo, \\nBerikut rincian transaksi Anda di *Lapangan Bulu Tangkis Lima Arena*, pada\\n\\nTanggal _10 Apr 2023_\\nJam _18:44_\\n\\nDidukung oleh TravyPartner", "mediaKey": "Li8RIUcmpkigeFHtAefx91LOleft8py+LHps962uHMc=", "mimetype": "image/jpeg", "directPath": "/o1/v/t62.7118-24/f1/m232/up-oil-image-3fbb1343-9fe6-4b32-a9c4-4a97781507b1?ccb=9-4&oh=01_AdS88abEg0_SB4xseaXmv6luzQmOZY_ISWSI3ykpgs6DRw&oe=645B6B4F", "fileLength": {"low": 30192, "high": 0, "unsigned": true}, "fileSha256": "psiGn2R3b90WnAGJhPEDYkUx2U9W9hI35DNs2Kqxm/Q=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "b2opMTrEExJWQ3k25kCiWaGH86tCm9dRJ3NzoC//JXQ=", "mediaKeyTimestamp": {"low": 1681126901, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1681126901	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006er54dat9zgc6b	{"id": "FDC5E7438BF6D62BA8EE43E58666BD1F", "fromMe": true, "remoteJid": "6281315494095@s.whatsapp.net"}	Você	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/19154517_3529272830685066_6276707703539966577_n.enc?ccb=11-4&oh=01_AdRSRS3MPIo7kGt8od08mmOTSokl53_Yx20qDAxJwUKTzA&oe=64366A89&mms3=true", "width": 1156, "height": 867, "mediaKey": "TRvtt1NcukF7WVTPqpHGEVwm0s0dsd2Kgkty2SgIrTA=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/19154517_3529272830685066_6276707703539966577_n.enc?ccb=11-4&oh=01_AdRSRS3MPIo7kGt8od08mmOTSokl53_Yx20qDAxJwUKTzA&oe=64366A89", "fileLength": {"low": 192954, "high": 0, "unsigned": true}, "fileSha256": "aRAswVJ09WYJYltX6KC20tVZNyi4jrj0eP07wIWa2yo=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "vb3K6M2UBSKp6NzWt07+n4R1JByxBVABGg957VVY/yc=", "mediaKeyTimestamp": {"low": 1678703032, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1678703032	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006fr54dsunaxiyc	{"id": "5EF3BE13BABF5A28F66A8289513959DB", "fromMe": false, "remoteJid": "62895333111213@s.whatsapp.net"}	62895333111213	\N	conversation	{"conversation": "Perkenalkan kami dari GO!Design Media Graphic yaitu perusahaan yang menyediakan layanan jasa desain dan proses produksi langsung, yang terbagi menjadi lima divisi yaitu : \\n✅ Design\\n✅ Advertising \\n✅ Printing\\n✅ Souvenir \\n✅ Photo Video \\nyang siap menunjang media promosi perusahaan anda .  \\n     Satu lagi layanan yang kami berikan, anda tidak perlu membuang waktu  karena kami memiliki  layanan delivery service yang akan mengantarkan produk pesanan  ke tempat anda. Untuk informasi  lebih lanjut ,anda bisa langsung menghubungi kami 🙌\\n\\nGO! Design Media Graphic\\n📍Jln. Pulau Misol No 46 , Denpasar-bali \\n💡IG :  @godesignmediagraphic\\n📞0361-255687 / 085100102640\\n📩 http://www.godesign-mediagraphic.com/"}	\N	android	1678435402	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006gr54djjh5udmm	{"id": "3CB81A899B9211A22AB166EBA5A174FA", "fromMe": false, "remoteJid": "6285746999067@s.whatsapp.net"}	6285746999067	\N	conversation	{"conversation": "☝️Apakah Masih Membutuhkan Tambahan Anggota Team, Seperti Iklan Lowongan OLX Diatas☝️"}	\N	android	1677736756	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p6r54dilhqjwvr	{"id": "AC2452C7F9613673343AD7411871EE8A", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Ampunnn", "messageContextInfo": {"threadId": [], "messageSecret": "iGGOCuqzJA0CWeFywfMC4QM3rrKY+YM5rroMALgw1ZE="}}	{"stanzaId": "3B8EEC563A4EFF398150", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "jangan lupa rem spending guys, spertinya akan ada gejolak"}, "statusAttributions": []}	android	1780464716	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006hr54dsy7ps7sc	{"id": "124704C23BC785E3FD3AD5E609898C2A", "fromMe": true, "remoteJid": "6287772635356@s.whatsapp.net"}	Você	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/30562207_934527717962221_711183951884231930_n.enc?ccb=11-4&oh=01_AdQQ_PmX0ukEoKu6SqhffPwnd1HSxtsgCcLaWS4i0WkUog&oe=6424EB3B&mms3=true", "width": 576, "height": 851, "caption": "Halo, \\nBerikut rincian transaksi Anda di *Kopi Takira*, pada\\n\\nTanggal _28 Feb 2023_\\nJam _10:27_\\n\\nDidukung oleh Woogigs POS", "mediaKey": "2YRvnPjAuxp4ROoelIX27mwmKO97SPA0XJeZsfVvc2w=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/30562207_934527717962221_711183951884231930_n.enc?ccb=11-4&oh=01_AdQQ_PmX0ukEoKu6SqhffPwnd1HSxtsgCcLaWS4i0WkUog&oe=6424EB3B", "fileLength": {"low": 31032, "high": 0, "unsigned": true}, "fileSha256": "W3M3f3yQjwpr8IT9IQSapR7C9JZJac11Qi/7WBO3cB4=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "0n/Y7vTbM3rsXbO/c+ndxYmCe6aN2OEPqwAAxSEH+lw=", "mediaKeyTimestamp": {"low": 1677554711, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1677554711	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006ir54d40pcgklr	{"id": "3AEB9F4C5853752E84AA", "fromMe": false, "remoteJid": "6281236876162@s.whatsapp.net"}	6281236876162	\N	conversation	{"conversation": "Baik siap terima kasihh"}	\N	ios	1676860343	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006jr54dl5v8fooj	{"id": "D292101BEFD00690D961AF3D2B981964", "fromMe": false, "remoteJid": "62895333615211@s.whatsapp.net"}	62895333615211	\N	conversation	{"conversation": "Baik terimakasih 🙏🏻"}	\N	android	1676520206	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006kr54d28cwf7q2	{"id": "B28E00C26F063B1CA82F1F06AEE8C82D", "fromMe": false, "remoteJid": "6288210673430@s.whatsapp.net"}	6288210673430	\N	conversation	{"conversation": "Oke"}	\N	android	1676456226	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006lr54di3x0u167	{"id": "3E77D3D2D030C9B73BB3EB85C1F27123", "fromMe": false, "remoteJid": "6282144862077@s.whatsapp.net"}	6282144862077	\N	conversation	{"conversation": "Baik kak, terima kasih"}	\N	android	1676365700	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw42uf006mr54dahi34g92	{"id": "3E7274EFFBB7E0F414AE4CB183192AE9", "fromMe": true, "remoteJid": "6289616699042@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Halo, Dewa Gede Ngurah Bramasta!\\n\\nSetelah melakukan review pada CV dan interview tahap pertama, kami mengundangmu untuk melakukan screening lanjutan bersama Team Business Development Travybug. Screening akan dilakukan secara tatap muka sesuai dengan jadwal berikut:\\n\\n📅 Hari/Tanggal: Rabu, 15 Feb 2023\\n🕐 Waktu: 13.00 - 14.00 WITA\\n👔 Dresscode: Bebas Rapi dan Sopan\\n📍Alamat: Kantor Travybug - Jalan Blong Poh, Kirrin Residence, No. 7, Jimbaran, Kuta Selatan, Bali\\n🗾 Link Gmaps: https://bit.ly/Alamat-Travybug\\n\\nDiharapkan hadir tepat waktu untuk memperlancar proses screening, apabila ada hal yang ingin ditanyakan bisa langsung disampaikan melalui chat di sini.\\n\\nMohon konfirmasinya dan ditunggu kehadirannya!\\n\\nBest Regards,\\nHR Team\\nTravybug"}	null	android	1676279933	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006nr54dcvsfjce6	{"id": "F13282EFE4DC365A7376BFE5A036E568", "fromMe": true, "remoteJid": "6283847825162@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hai, Anatasya Septiani Klau\\n\\nTerimakasih karena sudah tertarik mendaftar sebagai SDR Part Time di Travybug!\\n\\nSetelah melakukan review terhadap CV yang kamu kirimkan, kami tertarik untuk mengetahui lebih lanjut tentang dirimu dan kami mengundangmu untuk melakukan interview melalui Google Meet sesuai dengan jadwal berikut:\\n\\nHari/Tanggal : Senin, 13 Feb 2023\\nWaktu : 13:00 - 13:30 WITA\\nLink Meet : meet.google.com/zkg-cfvn-zbw\\n\\nPastikan kestabilan koneksi internet dan device untuk memperlancar kegiatan interview, apabila ada hal yang ingin ditanyakan bisa langsung disampaikan melalui chat di sini.\\n\\nLooking forward to meeting you!\\n\\nBest Regards,\\nHR Team\\nTravybug"}	\N	android	1676020633	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw42uf006or54dv3ms6l6c	{"id": "D6F8A82FEAE7816EA73A30EE0454382B", "fromMe": true, "remoteJid": "6287855599444@s.whatsapp.net"}	Você	\N	conversation	{"conversation": "Hai, Anatasya Septiani Klau\\n\\nTerimakasih karena sudah tertarik mendaftar sebagai SDR Part Time di Travybug!\\n\\nSetelah melakukan review terhadap CV yang kamu kirimkan, kami tertarik untuk mengetahui lebih lanjut tentang dirimu dan kami mengundangmu untuk melakukan interview melalui Google Meet sesuai dengan jadwal berikut:\\n\\nHari/Tanggal : Senin, 13 Feb 2023\\nWaktu : 13:00 - 13:30 WITA\\nLink Meet : meet.google.com/zkg-cfvn-zbw\\n\\nPastikan kestabilan koneksi internet dan device untuk memperlancar kegiatan interview, apabila ada hal yang ingin ditanyakan bisa langsung disampaikan melalui chat di sini.\\n\\nLooking forward to meeting you!\\n\\nBest Regards,\\nHR Team\\nTravybug"}	\N	android	1676012568	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw5ffh00p1r54d9ffko6c3	{"id": "3B4C86D79117CCED96A3", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "gE8w+eNN+K4EXr6FAGfE+wqPux2eoT7xjWLtvfBac6Q=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B222245701FBEAB77F0", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/595840171_2109152616684471_4441859798028663361_n.enc?ccb=11-4&oh=01_Q5Aa4wH1O2pMjbtHTEBv2lpp7OXYoknghpE8F_t02_R-stiKIw&oe=6A5C9978&_nc_sid=5e03e0&mms3=true", "width": 2880, "height": 1624, "caption": "Kita habis update gasless transaction di Solana, jadi kalian ga perlu punya token solana untuk bayar network fee, tapi pakai token yang kalian punya utk bayar network fee. Enjoy buat lebih seamless kalian transaksi on chain di jaringan Solana. Jadi ini bsa bantu kalian yg ga prnh punya solana tetap bsa transaksi dngan baik di dapp termasuk staking usdc, jual beli token,  us stock, dan withdraw. Klau ada kendala apa terkait penggunaan app jangan malu bertanya", "mediaKey": "2xveBMlhIGS5dL3N2qpUoFcFzrQ8FU/7c9m1BMtyNSM=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/595840171_2109152616684471_4441859798028663361_n.enc?ccb=11-4&oh=01_Q5Aa4wH1O2pMjbtHTEBv2lpp7OXYoknghpE8F_t02_R-stiKIw&oe=6A5C9978&_nc_sid=5e03e0", "fileLength": {"low": 105923, "high": 0, "unsigned": true}, "fileSha256": "ncQVGTxsA8p0rX+s8toQPElRMCkYKmH0uX0Pg2uilYY=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [19250, 17783, 39935, 28953], "scansSidecar": "vBWI9MdVYfTf3WDr07q3eIimH6n5P4Z0JRIBeyI9pDN8xjL0in1kVg==", "fileEncSha256": "7VqjVD0mTXKZG9XtW2nUWhHltYT5zaba3K2Re4rwkd8=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1781868825, "high": 0, "unsigned": false}, "midQualityFileSha256": "xupbBv7BR3jE9Y5qu3akX3IuGcASdLZIIuOl916WXnc=", "interactiveAnnotations": []}}}}	\N	unknown	1781868826	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p2r54dxaib6yf8	{"id": "3B222245701FBEAB77F0", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/558691168_1025695076811549_9070620801608465180_n.enc?ccb=11-4&oh=01_Q5Aa4wGuzwSSScd6OU2IeH4ZrzSQwAWYeP175XYmoDubEzwsJA&oe=6A5CB2AD&_nc_sid=5e03e0&mms3=true", "width": 1280, "height": 722, "caption": "Kita habis update gasless transaction di Solana, jadi kalian ga perlu punya token solana untuk bayar network fee, tapi pakai token yang kalian punya utk bayar network fee. Enjoy buat lebih seamless kalian transaksi on chain di jaringan Solana. Jadi ini bsa bantu kalian yg ga prnh punya solana tetap bsa transaksi dngan baik di dapp termasuk staking usdc, jual beli token,  us stock, dan withdraw. Klau ada kendala apa terkait penggunaan app jangan malu bertanya", "mediaKey": "lw29k3USk0LRxhi2niIL/eyaOL07eGbJKaiQhYuEJdI=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/558691168_1025695076811549_9070620801608465180_n.enc?ccb=11-4&oh=01_Q5Aa4wGuzwSSScd6OU2IeH4ZrzSQwAWYeP175XYmoDubEzwsJA&oe=6A5CB2AD&_nc_sid=5e03e0", "fileLength": {"low": 33315, "high": 0, "unsigned": true}, "fileSha256": "sOxKnm+SBbAtQksPLkNyVSAI7/Fimej4QckJS9M+VGY=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [4980, 11763, 5038, 11532], "scansSidecar": "hHG0ZxVu8astN1lLKuSVXi0xvDyTBRIvE4OVAjfHHmBebJeNiIu8MQ==", "fileEncSha256": "6JUbnJIne2Oa1qPR/K82gY9c1NkvbWquqheHAW8J4SI=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1781868824, "high": 0, "unsigned": false}, "midQualityFileSha256": "47O814m5FJkIIbOj0LkZ/kE41WYg6R/ZKUNe6c4W5Ek=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "MHEXD9vROcWh/MPJ1LcDRLGn8QDEh7bCsZhpjSFGtP4="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1781868824	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p3r54d1jcduzwa	{"id": "AC2A4562949DB7B20B8607FF223C7A7A", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Eh ihsg dan usdidr babak belur juga", "messageContextInfo": {"threadId": [], "messageSecret": "MBprQr5TkCBe6QIpXk1mS51Emm18Y7qSD2dCzpLEQBo="}}	\N	android	1780464739	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p4r54d3amyjevp	{"id": "AC25AD03477E29A68ACED3148C19DB5F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "BTC Dan crypto juga crash", "messageContextInfo": {"threadId": [], "messageSecret": "VKI0kcCCwEKYy6NDXMkCGNOXE9SEDpyu22Z17y41BQo="}}	\N	android	1780464731	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p5r54dnjpyrjr0	{"id": "ACA7F07812F8ED74B504AE54883F985F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Bener banget sih ni bro kelwin", "messageContextInfo": {"threadId": [], "messageSecret": "OtHfASYdSbgU/oreS2jOOICnZsFureqodHPVh5aPmuA="}}	\N	android	1780464723	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p7r54dydp9bkxq	{"id": "3B8EEC563A4EFF398150", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "jangan lupa rem spending guys, spertinya akan ada gejolak", "messageContextInfo": {"threadId": [], "messageSecret": "EtflFKWbTFUKPguy4/JTiPsNAs1rcbqcisJxcTSiIFE="}}	\N	unknown	1780464672	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p8r54dirlxmvyv	{"id": "3BD7C96073BF89037E3C", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "wkwkkw", "messageContextInfo": {"threadId": [], "messageSecret": "JlFm0WBJ2hxJWyIiDYZNcQCCZkDmRc+VG6jygWmw0VI="}}	\N	unknown	1780464433	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00p9r54dny7ugtt5	{"id": "3B23E934D974802AF6C8", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "sampai bertemu di harga 20k guyss", "messageContextInfo": {"threadId": [], "messageSecret": "zXAM4Rq7oPlPI41YjXAIkvCqKQvliT+/l8Wnom14W2c="}}	\N	unknown	1780464429	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00par54dmcemrmrh	{"id": "3B1AD796E67F18C917F7", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "seru banget", "messageContextInfo": {"threadId": [], "messageSecret": "wjzz62bh/0rn1iK/AgA8t9UwScnpcECp43VbcNJD0dM="}}	\N	unknown	1780464361	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffh00pbr54dxflghfcs	{"id": "ACA9AC3BD9E43E3D72E9194E00AA2F77", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	212154322055172	\N	stickerMessage	{"stickerMessage": {"url": "https://mmg.whatsapp.net/v/t62.15575-24/641602339_3301419803359786_5889978446213928382_n.enc?ccb=11-4&oh=01_Q5Aa4gHnGnH6UvNe2FoVK1KJhSRaNXrXx8RZqQh60mk3o4SdOA&oe=6A4746B2&_nc_sid=5e03e0&mms3=true", "width": 64, "height": 64, "isAvatar": false, "isLottie": false, "mediaKey": "7gF0GtmaVv00Zd/aRB705oayC0+Cl1fXubsjPp4tqPY=", "mimetype": "image/webp", "directPath": "/v/t62.15575-24/641602339_3301419803359786_5889978446213928382_n.enc?ccb=11-4&oh=01_Q5Aa4gHnGnH6UvNe2FoVK1KJhSRaNXrXx8RZqQh60mk3o4SdOA&oe=6A4746B2&_nc_sid=5e03e0", "fileLength": {"low": 160896, "high": 0, "unsigned": true}, "fileSha256": "pSgkl15jivvt+tQY14bBwSgOHwXjCbNqSPkjI3bQSxE=", "isAnimated": true, "isAiSticker": false, "fileEncSha256": "jqktcjAfFvVyJ5UlEEMMcf8rmBe6QWUyb0iXshdhv0o=", "stickerSentTs": {"low": -1947077840, "high": 414, "unsigned": false}, "firstFrameLength": 160494, "firstFrameSidecar": "5BABtVw6VEI7jQ==", "mediaKeyTimestamp": {"low": 1780464348, "high": 0, "unsigned": false}}, "messageContextInfo": {"threadId": [], "messageSecret": "+FWO94r0VLnZzoTRTt6MOGfNuDK86wawQZTA01s22tg="}}	null	android	1780464350	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pcr54ddo0c34wx	{"id": "3B43951A44E46958CBCE", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQMJiNKX9qhLV61r76DfHW-LrbHUvNocv1aiEYkpMHqXAcDM7myLpuzGdnP7cIP0ESUsAgnUMkSEEhGfzjoHk_UZKaGXdf015Hc94Sd6yA?ccb=9-4&oh=01_Q5Aa4gFyzOtHIT8-ZLDHwVcLNOa7KSoCxfRVBCBE6aLWjLaJdA&oe=6A471645&_nc_sid=e6ed6c&mms3=true", "width": 1434, "height": 808, "mediaKey": "8YaGwYQdrHHBwgs1p5njywThv1VDTGCLLtli4t7ODKo=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m232/AQMJiNKX9qhLV61r76DfHW-LrbHUvNocv1aiEYkpMHqXAcDM7myLpuzGdnP7cIP0ESUsAgnUMkSEEhGfzjoHk_UZKaGXdf015Hc94Sd6yA?ccb=9-4&oh=01_Q5Aa4gFyzOtHIT8-ZLDHwVcLNOa7KSoCxfRVBCBE6aLWjLaJdA&oe=6A471645&_nc_sid=e6ed6c", "fileLength": {"low": 65734, "high": 0, "unsigned": true}, "fileSha256": "Wnj/zjiclXVxhtSKu5sNJXNVDU2FWrxTeFVwoKoz4Sk=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6509, 30270, 11497, 17456], "scansSidecar": "Jp7YYery2jvHJJlEej0fIyKNizGDb6b6Ywj5FTDt4H94MKv1QVs2Ng==", "fileEncSha256": "TFaZWxP2+yMONWnbAKTQpMAViuuylSKR7TfEwooWG9o=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780464259, "high": 0, "unsigned": false}, "midQualityFileSha256": "JTgiw8vvaSyvhiNwxIEcfgNxuKM1l3ZZUgJ1SV7Oaww=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "QTknB5hOhISuuU855jfLqRXaiYp4UJ7F2R8PWjPJRM8="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1780464262	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pdr54d8i442e9m	{"id": "AC0639994E278E8FA372F0AB1F0C2C81", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Wakakaka aman", "messageContextInfo": {"threadId": [], "messageSecret": "AOWWYz434/rlKXSZhbnckM8zyBbpCl71JdZYMRKugD4="}}	{"stanzaId": "3B3BCE16CE101CB8F699", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "sorry baru liat, harusnya sih mndkung ya, org dia bkerja utk trump wkwk"}, "statusAttributions": []}	android	1779793592	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00per54do09k5h4i	{"id": "AC0D6271789251768CDF5C73DA13FB24", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/620642381_1749980296168532_9210281436488324732_n.enc?ccb=11-4&oh=01_Q5Aa4gG1zoYjBaN0MvDQ_Dk3Y7EaOPfswwuqB0y4xI_Y5eJUZQ&oe=6A3D0875&_nc_sid=5e03e0&mms3=true", "width": 738, "height": 1600, "caption": "Udah 17855 broo", "mediaKey": "ShdF5u/vFXv2U/7s3kQX+88uFJaGqUX9R5j9TaVKOnk=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/620642381_1749980296168532_9210281436488324732_n.enc?ccb=11-4&oh=01_Q5Aa4gG1zoYjBaN0MvDQ_Dk3Y7EaOPfswwuqB0y4xI_Y5eJUZQ&oe=6A3D0875&_nc_sid=5e03e0", "fileLength": {"low": 70791, "high": 0, "unsigned": true}, "fileSha256": "mwWYJGGn7fEMQy8TLSnN0dDcdQfJC0dxLo/+GcxfuJ4=", "annotations": [], "contextInfo": {"stanzaId": "3B22484DF2267D59F624", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "kmarin simulasi baru 17676"}, "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [7097, 35085, 13493, 15116], "scansSidecar": "6B+smkrtBe0gaMCsT0eqUh5C2r11pX1ZDO+emVSXPaDNVHIWjVhaIA==", "fileEncSha256": "4leqewfR5hHABWQbzANb+cZDtGYssPCKblFmYndAHmw=", "mediaKeyTimestamp": {"low": 1779791322, "high": 0, "unsigned": false}, "midQualityFileSha256": "RBWrhCRQSQUQT7MKz5qMlayXGwdva4pbUKMIJyfC5o0=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "W93RWjIGU7M8PDQ0lnp5pAKWft4tGCPojgOBuFTg+1A="}}	{"stanzaId": "3B22484DF2267D59F624", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "kmarin simulasi baru 17676"}, "pairedMediaType": 0, "statusAttributions": []}	android	1779793581	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pfr54dx5wlbitr	{"id": "3B22484DF2267D59F624", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "kmarin simulasi baru 17676", "messageContextInfo": {"threadId": [], "messageSecret": "DJ0tYTjnmc92iq2mDU89VPt2Ckv/qzKJgemnzOUNDXc="}}	{"stanzaId": "3B4937423A72F2A87D41", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNKxY62nvm_tG2UCWg5pSAtfMGbYndrOL-CvnPQ-kvcfbbAtTlLamxHfXKXdGkIBKTKJQNSZr1Ad_lLlq0n4qAPBS4yiiJvLs17YimyPw?ccb=9-4&oh=01_Q5Aa4gFEgLDylaVagoV-K2DmfwTGiTJyBDDzg3LtqpqJNg82WA&oe=6A3204D5&_nc_sid=e6ed6c&mms3=true", "width": 1192, "height": 1160, "caption": "mau berbagi dikit, ini kira kira gambaran data historical usd yang naik terhadap idr 4% per tahunnya. Itu pun dngan anggap ekonomi kta slama 10 tahun terakhir relatively stable, dan bru bru ini mulai bnyk goncangan geopolitik yang membuat emerging market kayak negara indonesia relatively d rugikan. mngkin rata rata kenaikan dollar terhadap idr bsa lebih tinggi lagi. Kira kira aku simulasiin dngan tetap 4% per tahunnya dollar naik thdp idr, even idr nya kta taruh diproduk investasi market indonesia macam saham, reksadana, dll yg bsa naik 5% per tahun pun, masih bsa kalah dari dollar, apalagi kalau dollarnya bisa berbunga. Jadi simulasinya kira kira begini", "mediaKey": "9d5085lFlLxzayvuFmR4P0OUGWRd2ISWhshs+B1hFi0=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m233/AQNKxY62nvm_tG2UCWg5pSAtfMGbYndrOL-CvnPQ-kvcfbbAtTlLamxHfXKXdGkIBKTKJQNSZr1Ad_lLlq0n4qAPBS4yiiJvLs17YimyPw?ccb=9-4&oh=01_Q5Aa4gFEgLDylaVagoV-K2DmfwTGiTJyBDDzg3LtqpqJNg82WA&oe=6A3204D5&_nc_sid=e6ed6c", "fileLength": {"low": 84267, "high": 0, "unsigned": true}, "fileSha256": "Bnaq6oblP+eLezGAEFqHzOHtx1t5goo7WpuwxPEG4L0=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [8131, 36473, 16179, 23482], "scansSidecar": "o/aOQdckGuXTWX6+ftz1LAVlVbNSTAYzPRUBDKbTHUlHOl0jri3hcA==", "fileEncSha256": "EMelarPFvjnWJEgQPPOSqmCQIh2vE2QLoanjDkzrGq0=", "mediaKeyTimestamp": {"low": 1779085179, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	unknown	1779793018	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00plr54dmyqngqxi	{"id": "3B466D95DD0A78758895", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "QgkNG6WDPq2LE/bsjFVWmR2e2Q9NdugiXq80odxdCpM=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3BAC40DDB98EC838762D", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQPfWeLHHeSJgaYHL21ekdgZ-zmsMY2kwlGECt8CHwJBAwpKvwNFTWETzyB_M3QEKKCM_f_ReKnqL4wGJ0A0NldbKY0gVwHEzIndTava6Q?ccb=9-4&oh=01_Q5Aa4gGm141CIsNmkHeRKfziZ1j3ORtJO47-8236ulVEWwIU7g&oe=6A321DD0&_nc_sid=e6ed6c&mms3=true", "width": 2880, "height": 1620, "caption": "kira kira kalau put 1000 dollar, dapat sgtu setahunnya", "mediaKey": "6KKMxGH9yO80/Op/wlOYzs4uw7Xxf46pS/qJMCvia18=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQPfWeLHHeSJgaYHL21ekdgZ-zmsMY2kwlGECt8CHwJBAwpKvwNFTWETzyB_M3QEKKCM_f_ReKnqL4wGJ0A0NldbKY0gVwHEzIndTava6Q?ccb=9-4&oh=01_Q5Aa4gGm141CIsNmkHeRKfziZ1j3ORtJO47-8236ulVEWwIU7g&oe=6A321DD0&_nc_sid=e6ed6c", "fileLength": {"low": 207158, "high": 0, "unsigned": true}, "fileSha256": "IVN1SNwx515OZn2jfo4RJwL2QCaf8BZid4fyyz5AfkI=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [22209, 21361, 70647, 92939], "scansSidecar": "1vWnM5OjMhNEyFiqM/vIGXg3dh9jv3x3c7qPnPJVgeR0CxjGo0SRQQ==", "fileEncSha256": "wo03ohA6lQNhCjr7mkHt4PYuRIclMpCAmXe3qq/T9qE=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779085588, "high": 0, "unsigned": false}, "midQualityFileSha256": "Dj8BS5hy1Tz88B2UAYjiplkEIpjXzMDtUIf/Tnocarg=", "interactiveAnnotations": []}}}}	\N	unknown	1779085595	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pyr54d1gtesyla	{"id": "ACF3432D5EB52F2E7908D45A16994706", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Sisa beli bro wkwkw", "messageContextInfo": {"threadId": [], "messageSecret": "Qh9GSmFkMuJaNDSELd5JCF9gA2gA9fEYYCRBMPdJdk8="}}	{"stanzaId": "3BB48EB0E57A3AF03223", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "sisa beli agak lama atau masih rutin cicil dol?"}, "statusAttributions": []}	android	1779075512	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qor54diwszzzwp	{"id": "AC36925C1FE533A01C62D9B47AC638C4", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Fair enough bro", "messageContextInfo": {"threadId": [], "messageSecret": "An8oRLs3Vt5uTXgtwaV8wA/1dBYAHw3Pd/5rTuV20bc="}}	{"stanzaId": "3BB8CB7943DC560D109B", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "indo paling jelek wkwk, sorry to say"}, "statusAttributions": []}	android	1777525357	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pgr54deg1suv66	{"id": "3B538B1C1F15D34D176A", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQPcDKHAY_QSJVE37r8JqWuDFCvk5-XfNXlLeTNx_LLqP6shU-tgDNmUaGfGTuPk6MNpu1qa4-kFTFGMYTKvt1JnFC8owF8qMU8ciLJR0g?ccb=9-4&oh=01_Q5Aa4gH19gsECd5A0Aj3lVBygozsBH7yzy0DDqWFrSLwMKra8A&oe=6A3CE179&_nc_sid=e6ed6c&mms3=true", "width": 1446, "height": 608, "caption": "dah menyentuh 17800 rupiah", "mediaKey": "L/CLL9UcgmWatmBcg8nVAx2ubvFtFr9QNff8oDFpZxk=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m232/AQPcDKHAY_QSJVE37r8JqWuDFCvk5-XfNXlLeTNx_LLqP6shU-tgDNmUaGfGTuPk6MNpu1qa4-kFTFGMYTKvt1JnFC8owF8qMU8ciLJR0g?ccb=9-4&oh=01_Q5Aa4gH19gsECd5A0Aj3lVBygozsBH7yzy0DDqWFrSLwMKra8A&oe=6A3CE179&_nc_sid=e6ed6c", "fileLength": {"low": 56964, "high": 0, "unsigned": true}, "fileSha256": "lrJjEQoHM1q5cGB273fyhgvqQb5mHI6EGtdfGBRs6bU=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [5281, 25696, 10434, 15551], "scansSidecar": "wp9LZdmaQ0SMNpE1EtW6gCScFMHlAXgPtGOhtf8LD4z8KoGjxT8m+A==", "fileEncSha256": "qJX8amDB12OVyWLeZOExM5Gngjs6OvrehIYVSQVbg6M=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779792988, "high": 0, "unsigned": false}, "midQualityFileSha256": "czbjMwO/iysZJIlJXkqCfTOf0v6dbr2Wmw4yrltL05Y=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "jEIaptULtlQ51csQVgY30GyHsG9kuasS2Fj3sVq9XR0="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1779792990	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00phr54dqgk6f4re	{"id": "3B3BCE16CE101CB8F699", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "sorry baru liat, harusnya sih mndkung ya, org dia bkerja utk trump wkwk", "messageContextInfo": {"threadId": [], "messageSecret": "GfhUMjnLCr/DGqYI+YyUyJtgYNxvL1Tzy0OtyHFbyJw="}}	\N	unknown	1779792966	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pir54dj0r5bwdb	{"id": "AC6CEB20D35C4D619E34CE2F53FCFB29", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/706852968_4291295097751178_7152082453946861738_n.enc?ccb=11-4&oh=01_Q5Aa4gH0W1Ag5Kscz6E6TvRyAye_hOedMj1wvwnJIKeSLPPdCA&oe=6A388E5E&_nc_sid=5e03e0&mms3=true", "width": 1080, "height": 1900, "caption": "Pro BTC kah yang baru ? @185486836560069", "mediaKey": "InQud5MhF2Y5XA1MjWXSQvdU9Kn6UWhnWeMNNSG36V8=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/706852968_4291295097751178_7152082453946861738_n.enc?ccb=11-4&oh=01_Q5Aa4gH0W1Ag5Kscz6E6TvRyAye_hOedMj1wvwnJIKeSLPPdCA&oe=6A388E5E&_nc_sid=5e03e0", "fileLength": {"low": 126172, "high": 0, "unsigned": true}, "fileSha256": "LGXV0CBnrCCiYnRWfo7Ub+7toxhL61wPpyH79bbCdW8=", "annotations": [], "contextInfo": {"mentionedJid": ["185486836560069@lid"], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "0bf62XEVJogPtMbaEdBfCCjBto2lfskXiZ4ZIkcOCRg=", "mediaKeyTimestamp": {"low": 1779508650, "high": 0, "unsigned": false}, "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "1xyBbZKzUpt03qf7Dd75a0fZGRXQ/FWyuBp4urPeVFM="}}	{"mentionedJid": ["185486836560069@lid"], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	android	1779508651	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pjr54dyc11znp9	{"id": "ACC64A4EA2C51B2FCE6C1E2B1371BE6F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Wah", "messageContextInfo": {"threadId": [], "messageSecret": "m48cB2zTr5cQJmo2E5lGKMQEKi5yBV/NaPWC/3h9jko="}}	{"stanzaId": "3B4948A2D64734F69812", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQPYSuzosIAPnCugDV700ZMz_M2-UqZWbgBQ4drfheJAmtvnAmy25BQQHHmfRCt52w80cWUgxcGcwAQEt-yIeGKrswc2LwF8Yl-AbrfzxA?ccb=9-4&oh=01_Q5Aa4gGk1ktBr14Xj6P7nM0IsUsb36h3yNDreoKctCsZ460-Kw&oe=6A332B0E&_nc_sid=e6ed6c&mms3=true", "width": 1436, "height": 800, "caption": "dah nyentuh 17700 tadi pagi", "mediaKey": "QX1FwZ3Tp3XwJwSdUkqTAFhhD4wgxnndjd2ezr+ZkAI=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m233/AQPYSuzosIAPnCugDV700ZMz_M2-UqZWbgBQ4drfheJAmtvnAmy25BQQHHmfRCt52w80cWUgxcGcwAQEt-yIeGKrswc2LwF8Yl-AbrfzxA?ccb=9-4&oh=01_Q5Aa4gGk1ktBr14Xj6P7nM0IsUsb36h3yNDreoKctCsZ460-Kw&oe=6A332B0E&_nc_sid=e6ed6c", "fileLength": {"low": 68788, "high": 0, "unsigned": true}, "fileSha256": "CgUgubhNrJUA4244nfq7bNHTehwQVjSf8WFyOALum5w=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6539, 31077, 12386, 18784], "scansSidecar": "ahJGfV8Ofj2gIBxJwP6Y0/2vfmnPxk5EphSHUUcdROTCxYEXiqlmAw==", "fileEncSha256": "3mctgEPWltZXlMuwh8c2Ds3lS9aKAK7gBuOFEpiyK1g=", "mediaKeyTimestamp": {"low": 1779155087, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	android	1779155151	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pkr54d40711u1m	{"id": "3B4948A2D64734F69812", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQPYSuzosIAPnCugDV700ZMz_M2-UqZWbgBQ4drfheJAmtvnAmy25BQQHHmfRCt52w80cWUgxcGcwAQEt-yIeGKrswc2LwF8Yl-AbrfzxA?ccb=9-4&oh=01_Q5Aa4gGk1ktBr14Xj6P7nM0IsUsb36h3yNDreoKctCsZ460-Kw&oe=6A332B0E&_nc_sid=e6ed6c&mms3=true", "width": 1436, "height": 800, "caption": "dah nyentuh 17700 tadi pagi", "mediaKey": "QX1FwZ3Tp3XwJwSdUkqTAFhhD4wgxnndjd2ezr+ZkAI=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m233/AQPYSuzosIAPnCugDV700ZMz_M2-UqZWbgBQ4drfheJAmtvnAmy25BQQHHmfRCt52w80cWUgxcGcwAQEt-yIeGKrswc2LwF8Yl-AbrfzxA?ccb=9-4&oh=01_Q5Aa4gGk1ktBr14Xj6P7nM0IsUsb36h3yNDreoKctCsZ460-Kw&oe=6A332B0E&_nc_sid=e6ed6c", "fileLength": {"low": 68788, "high": 0, "unsigned": true}, "fileSha256": "CgUgubhNrJUA4244nfq7bNHTehwQVjSf8WFyOALum5w=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6539, 31077, 12386, 18784], "scansSidecar": "ahJGfV8Ofj2gIBxJwP6Y0/2vfmnPxk5EphSHUUcdROTCxYEXiqlmAw==", "fileEncSha256": "3mctgEPWltZXlMuwh8c2Ds3lS9aKAK7gBuOFEpiyK1g=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779155087, "high": 0, "unsigned": false}, "midQualityFileSha256": "T5jLk5AAOH3FtoOgEzfQNwsFZPMQQeHBvOrF2wJNxY8=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "e6W3oy3entmTCbyqnNFdmNEH3VvQfLY8uFnAxZoe/L4="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1779155089	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pmr54dos2ml4jt	{"id": "3BAC40DDB98EC838762D", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQOASDBnOqBxcEQmmGIjrs800u_WVRXC0_tedrkwNsTTGvshd1ZcHcK3Gn2VpQWkF8fdAfVSY_MwibMs9_OED8z1ydAxeTA-FBBgnjtBIw?ccb=9-4&oh=01_Q5Aa4gEVbhuaTiZk35t9hcYzyJj_oIP2qfI5fOwb_tUyA63tFw&oe=6A323829&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 720, "caption": "kira kira kalau put 1000 dollar, dapat sgtu setahunnya", "mediaKey": "kF7xrUu32C8Y8ZCcSEHIRgWsIrWASllbwaP4W23R1ss=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQOASDBnOqBxcEQmmGIjrs800u_WVRXC0_tedrkwNsTTGvshd1ZcHcK3Gn2VpQWkF8fdAfVSY_MwibMs9_OED8z1ydAxeTA-FBBgnjtBIw?ccb=9-4&oh=01_Q5Aa4gEVbhuaTiZk35t9hcYzyJj_oIP2qfI5fOwb_tUyA63tFw&oe=6A323829&_nc_sid=e6ed6c", "fileLength": {"low": 50366, "high": 0, "unsigned": true}, "fileSha256": "KguE9lI72iY7M4T1T8PlHsoghJwDSH203Q+nN7xvPP8=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [5524, 17509, 8585, 18746], "scansSidecar": "C0pXXrhQ0vf+ZRF2BIEvuHM42CLiGnhIm/WNFNu8Uiu6RzAAzoDILQ==", "fileEncSha256": "yP5L0DEYTSlyZhgDQx+n64qaO6/fz8NWAGNRodJk1IA=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779085573, "high": 0, "unsigned": false}, "midQualityFileSha256": "oZUBqTfW5JMHD4vka6aPHg8L4lLKSBpEIno/iso+YCE=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "/JewcyubUadUZxela/NS+tCsehNDuvsBrRAZInS3ysg="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1779085583	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00pnr54dsbbmpovz	{"id": "3BF15CE14B08065E1E52", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "ap7MNc8EMQ1cG8Z7fntAqOCLkVK8LbekKFqVlWgclmk=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B6356AEA6EDEED914D0", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMihIl6_9AT2MEfWF-98AZkokAPgVSwMEEBWlAq0bWmrb0MR1G308ET5tUhWSJZBenGNVMDnx4dORExlIV93wX1HB7yQwIrS7rz_IMaUg?ccb=9-4&oh=01_Q5Aa4gE3suwgBfi3JgM8dJaDbQBVSFLogI7woNlTaHp8iHCfOg&oe=6A320FBF&_nc_sid=e6ed6c&mms3=true", "width": 2880, "height": 1622, "caption": "jadi kalau kalian yang masih tunggu harga bitcoin turun, psti masih ada sisihkan cash, sebisakan mngkin tdk dalam idr, better put dalam usdc dan optionally bsa stake usdc buat dapat yield. Nanti kalau bitcoin dah turun k harga yang lebih pas, bsa kalian serok bitcoin lebih banyak jumlahnya. Skrg di paradapp dah bsa beli USDC dan stake USDC juga. \\n\\nhttps://paradapp.com/en/solana/vault/buy", "mediaKey": "zIU2JcaRiGubyf0Tuyrv9M4pb79I4SV/Mja/8abhcqM=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQMihIl6_9AT2MEfWF-98AZkokAPgVSwMEEBWlAq0bWmrb0MR1G308ET5tUhWSJZBenGNVMDnx4dORExlIV93wX1HB7yQwIrS7rz_IMaUg?ccb=9-4&oh=01_Q5Aa4gE3suwgBfi3JgM8dJaDbQBVSFLogI7woNlTaHp8iHCfOg&oe=6A320FBF&_nc_sid=e6ed6c", "fileLength": {"low": 186972, "high": 0, "unsigned": true}, "fileSha256": "EF9yyKqkrG3SftX36bvCx7Kjvs+l+KiYx1OcK5CUMqo=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [20705, 19342, 54947, 91976], "scansSidecar": "Kn1UtQlHttAyZwP71hMFw3NWX8EWx+WgP7L/k7ZkN9Jjjvf1jUz/6w==", "fileEncSha256": "WxUCZI9cdSN9YaPVkifrNId6QWriZ0NkJ1zLDp/idh8=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779085557, "high": 0, "unsigned": false}, "midQualityFileSha256": "Qw8L28owyURsEpJG6NDf/CJpoeoI8y4reIjPwYwCYh8=", "interactiveAnnotations": []}}}}	\N	unknown	1779085558	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00por54dpv8mqm98	{"id": "3B6356AEA6EDEED914D0", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQPPJZiplBBUI1zO8LNNpv1kEbOrmcPzqW6Gb1vvl-0hwjT1kua5Mh5Swh3XviX7PBNBAP8maV9aPhXhaoBoVVa1Po6VIVUOAP1JnOOTCg?ccb=9-4&oh=01_Q5Aa4gE7C3-KgzsOYiuqV5Pgxp8r-jJqr1iNOgDtZ_8RJtgHog&oe=6A321E79&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 721, "caption": "jadi kalau kalian yang masih tunggu harga bitcoin turun, psti masih ada sisihkan cash, sebisakan mngkin tdk dalam idr, better put dalam usdc dan optionally bsa stake usdc buat dapat yield. Nanti kalau bitcoin dah turun k harga yang lebih pas, bsa kalian serok bitcoin lebih banyak jumlahnya. Skrg di paradapp dah bsa beli USDC dan stake USDC juga. \\n\\nhttps://paradapp.com/en/solana/vault/buy", "mediaKey": "gDXQKgr1NgHQM9jZMwUH+0Pp+ZJDKFELD19ikVepMts=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m231/AQPPJZiplBBUI1zO8LNNpv1kEbOrmcPzqW6Gb1vvl-0hwjT1kua5Mh5Swh3XviX7PBNBAP8maV9aPhXhaoBoVVa1Po6VIVUOAP1JnOOTCg?ccb=9-4&oh=01_Q5Aa4gE7C3-KgzsOYiuqV5Pgxp8r-jJqr1iNOgDtZ_8RJtgHog&oe=6A321E79&_nc_sid=e6ed6c", "fileLength": {"low": 44611, "high": 0, "unsigned": true}, "fileSha256": "4Fv09pBBF7zRgxLLKljp3/Cg6ICKbg4UG+OM0ZaL0KE=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [5173, 14375, 6976, 18085], "scansSidecar": "HLKegK2jUA9pnEkL4jQVHAhrp0hqehx3M5+smESjtGnf3Q52BfRr5A==", "fileEncSha256": "CkwzDcmPSQ0xfOWyJ0U2ac5Ud/GAP5Drrmc5gYKO97g=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779085554, "high": 0, "unsigned": false}, "midQualityFileSha256": "Nrkqizx3u0YnyaoZq3bpHj5ntmGT8rBzh/votXRmSfQ=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "GJfC4p8hcnrO74FsoLihRmP+2hT01RNRjU4/LjJUU5Q="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1779085555	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffi00ppr54dcri62bes	{"id": "3B4937423A72F2A87D41", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNKxY62nvm_tG2UCWg5pSAtfMGbYndrOL-CvnPQ-kvcfbbAtTlLamxHfXKXdGkIBKTKJQNSZr1Ad_lLlq0n4qAPBS4yiiJvLs17YimyPw?ccb=9-4&oh=01_Q5Aa4gFEgLDylaVagoV-K2DmfwTGiTJyBDDzg3LtqpqJNg82WA&oe=6A3204D5&_nc_sid=e6ed6c&mms3=true", "width": 1192, "height": 1160, "caption": "mau berbagi dikit, ini kira kira gambaran data historical usd yang naik terhadap idr 4% per tahunnya. Itu pun dngan anggap ekonomi kta slama 10 tahun terakhir relatively stable, dan bru bru ini mulai bnyk goncangan geopolitik yang membuat emerging market kayak negara indonesia relatively d rugikan. mngkin rata rata kenaikan dollar terhadap idr bsa lebih tinggi lagi. Kira kira aku simulasiin dngan tetap 4% per tahunnya dollar naik thdp idr, even idr nya kta taruh diproduk investasi market indonesia macam saham, reksadana, dll yg bsa naik 5% per tahun pun, masih bsa kalah dari dollar, apalagi kalau dollarnya bisa berbunga. Jadi simulasinya kira kira begini", "mediaKey": "9d5085lFlLxzayvuFmR4P0OUGWRd2ISWhshs+B1hFi0=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m233/AQNKxY62nvm_tG2UCWg5pSAtfMGbYndrOL-CvnPQ-kvcfbbAtTlLamxHfXKXdGkIBKTKJQNSZr1Ad_lLlq0n4qAPBS4yiiJvLs17YimyPw?ccb=9-4&oh=01_Q5Aa4gFEgLDylaVagoV-K2DmfwTGiTJyBDDzg3LtqpqJNg82WA&oe=6A3204D5&_nc_sid=e6ed6c", "fileLength": {"low": 84267, "high": 0, "unsigned": true}, "fileSha256": "Bnaq6oblP+eLezGAEFqHzOHtx1t5goo7WpuwxPEG4L0=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [8131, 36473, 16179, 23482], "scansSidecar": "o/aOQdckGuXTWX6+ftz1LAVlVbNSTAYzPRUBDKbTHUlHOl0jri3hcA==", "fileEncSha256": "EMelarPFvjnWJEgQPPOSqmCQIh2vE2QLoanjDkzrGq0=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779085179, "high": 0, "unsigned": false}, "midQualityFileSha256": "fd77TJ7rAFiPo7JcDBX2SlUxo2+DSNdE3d68ao56tfI=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "cdgXrErIkmZpHZjxJsz2WvpaCZ4M88TbxtHRHv13IhQ="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1779085181	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pqr54daefvxtde	{"id": "AC7A4314B057B1B78939486BB5233A27", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Wah menarik juga", "messageContextInfo": {"threadId": [], "messageSecret": "VMy4YlutisGxP0P/WnCdk6MSO7dzzXrYuKJypXrBW5g="}}	{"stanzaId": "3B2524B577EAA4F6503B", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "On chain USDC skrg bsa dapat yield 4-9% yearly terus liquid juga"}, "statusAttributions": []}	android	1779083887	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00prr54dmo22u5bh	{"id": "3B2524B577EAA4F6503B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "On chain USDC skrg bsa dapat yield 4-9% yearly terus liquid juga", "messageContextInfo": {"threadId": [], "messageSecret": "+3UC4wYrTehrVwA4NcNjLWoKI2x3aMvGa0Ot2qquxU0="}}	\N	unknown	1779083772	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00psr54drtdzazku	{"id": "AC01FCC37F10BBC9F52FC48919219674", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	protocolMessage	{"protocolMessage": {"key": {"id": "AC1C13CF0B7FCD061D7ACD8611B7E3D6", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "266266531090456@lid"}, "type": 14, "timestampMs": {"low": 967195816, "high": 414, "unsigned": false}, "editedMessage": {"conversation": "Kayaknya aku beli iseng buat hedging ajaaa bro"}}, "messageContextInfo": {"threadId": [], "messageSecret": "S24neiNZim2myGrrAlF67KcCqL2SwvXn+z0pGS3gfMg="}}	\N	android	1779083652	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00ptr54d0kypwo1b	{"id": "AC2AEC38E569A6EFA6C46E3ACEA63441", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Engga sih", "messageContextInfo": {"threadId": [], "messageSecret": "5vIeKCT+5Qn7bCE0w3EcgsM/4NEDG2rZRClbPhnbRC0="}}	{"stanzaId": "3BF269BD3347686D4252", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "dapat bunga ga dol sana?"}, "statusAttributions": []}	android	1779083643	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pur54dv5cfl25w	{"id": "3BF269BD3347686D4252", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dapat bunga ga dol sana?", "messageContextInfo": {"threadId": [], "messageSecret": "xrvVoOx3j3tEsjTfXbfGbmAirgGUUxts9wVKDtmIgP0="}}	{"stanzaId": "AC584F867C4B821889C48CD484B5E1C8", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Nyicil USD ini di Pocket Valas BCA juga bisa ges\\nTpi balik lagi ini centralize sih wkwkw"}, "statusAttributions": []}	unknown	1779083474	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pvr54d2o9d17qx	{"id": "AC584F867C4B821889C48CD484B5E1C8", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Nyicil USD ini di Pocket Valas BCA juga bisa ges\\nTpi balik lagi ini centralize sih wkwkw", "messageContextInfo": {"threadId": [], "messageSecret": "As+fZltgTXeeRU9haKcDn1RqW+kFlEAfh1zTzlBzFFo="}}	\N	android	1779075539	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pwr54dmpzef9gd	{"id": "ACC82B8D2BCBCEADB86026697F17BC20", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Hahahha", "messageContextInfo": {"threadId": [], "messageSecret": "LseCzGAcDGGlCO5cdQM/5lpsK95sifvY/9KOf7h+bAk="}}	\N	android	1779075519	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pxr54dfiq7phsc	{"id": "AC288B1C62949C6C44CD75E9A78B7277", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Lupa udh nyicil", "messageContextInfo": {"threadId": [], "messageSecret": "InOOQCuuc0ekpCbwNvSUy3o8xrpOsvUGqDorIIQ5YWE="}}	\N	android	1779075516	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00q9r54dgmfkgodb	{"id": "3BA2A5C9B9F5EA49BD27", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "mau nanya ges, kalian masih ada simpan rupiah bntuk cash atau dalam bentuk aset apa?", "messageContextInfo": {"threadId": [], "messageSecret": "yDbOghNyz+txVWtjz9eDSq/c1A7bdna8QbXTKVB2SDg="}}	\N	unknown	1779072525	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00pzr54diadvekvw	{"id": "3BDA218B24B00A19D44F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "gpp kita ga pake dolar kok 🗿", "messageContextInfo": {"threadId": [], "messageSecret": "eJ8KAVjmPa97YiJsKp4F9D8iTtpCglq3SBJkJzKKeTI="}}	{"stanzaId": "3B8968A94067CDB6424C", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c&mms3=true", "width": 1474, "height": 816, "mediaKey": "X2KW3fC5dCwb7SCT7CMLIYLdfdXSvVLOUyno+9aDhfw=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c", "fileLength": {"low": 66103, "high": 0, "unsigned": true}, "fileSha256": "W5nRBdoMagk2nUXGMxIdd0YTwG92bNQKxH0CZEskNnM=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6592, 29966, 11562, 17981], "scansSidecar": "HfUHeeTLE2SFzVRv8Wal0Ucy9AI9jZLiYjZitrtKznW7VPNXNusDWg==", "fileEncSha256": "Y+N3VDTn7uZ2M1Yl0udER2Ap2kLCt0dl0B9dl+u5lvI=", "mediaKeyTimestamp": {"low": 1779072399, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	unknown	1779074962	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q0r54dht2k2fx9	{"id": "3BCD5C0B1DFAB4ADAEBC", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dan ketar ketir", "messageContextInfo": {"threadId": [], "messageSecret": "W2iUadWqZyG+Kf4uwzaKR7AEikJ7W9z/PwVeww1Q4F4="}}	\N	unknown	1779074268	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q1r54dafmyzqpi	{"id": "3BE36F5C395B4ECD0BCA", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "aga bngung", "messageContextInfo": {"threadId": [], "messageSecret": "1RzYDSUgqIp2/zoTm3Br9/ftxXVX/srNIv3QO9A9RMA="}}	\N	unknown	1779074249	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q2r54dseybtvvy	{"id": "3BDB87B0BA37599D7F83", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "mslahnya doi denial jir", "messageContextInfo": {"threadId": [], "messageSecret": "v/cucjTcCOfcpbLxWqNEQnNFKSwO/GEfjDpFb2KPqto="}}	{"stanzaId": "3A2DFB238126354248A0", "quotedType": 0, "participant": "187290823454916@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "tp kacau yak bisa melemahbterus gini"}, "statusAttributions": []}	unknown	1779074243	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q3r54dcjztmn8h	{"id": "3BB48EB0E57A3AF03223", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "sisa beli agak lama atau masih rutin cicil dol?", "messageContextInfo": {"threadId": [], "messageSecret": "0BvdN0nMwDUnnELzEFA6x960RLtxac3TKQCYlan8lGM="}}	{"stanzaId": "ACD174F93E139556448790AB5C295AB1", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Dalam bentuk BTC"}, "statusAttributions": []}	unknown	1779074137	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q4r54dm5tt4pv7	{"id": "AC1405400DA940904BB73528F8C70637", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "All time low broh🫠", "messageContextInfo": {"threadId": [], "messageSecret": "oWN+lWzjzE+bUPCxRR/g3lBKZimrj43G2XrPY6+nt/o="}}	{"stanzaId": "3A2DFB238126354248A0", "quotedType": 0, "participant": "187290823454916@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "tp kacau yak bisa melemahbterus gini"}, "statusAttributions": []}	android	1779073560	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q5r54dgaf7e1nx	{"id": "AC0D9C5A7F18CEE1C8217767DCE78F67", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Tpi sama sama lagi koreksi wkwkw", "messageContextInfo": {"threadId": [], "messageSecret": "kBiEfwN//II2haMRsPIQ+ZaLikf9gdkPMdyYKA+Vevw="}}	\N	android	1779073545	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q6r54deuubbi4m	{"id": "ACCDD071A1592A99ABADE4F459D3FC6F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	protocolMessage	{"protocolMessage": {"key": {"id": "ACD174F93E139556448790AB5C295AB1", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "266266531090456@lid"}, "type": 14, "timestampMs": {"low": 957076560, "high": 414, "unsigned": false}, "editedMessage": {"extendedTextMessage": {"text": "Dalam bentuk BTC", "contextInfo": {"stanzaId": "3B8968A94067CDB6424C", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c&mms3=true", "width": 1474, "height": 816, "mediaKey": "X2KW3fC5dCwb7SCT7CMLIYLdfdXSvVLOUyno+9aDhfw=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c", "fileLength": {"low": 66103, "high": 0, "unsigned": true}, "fileSha256": "W5nRBdoMagk2nUXGMxIdd0YTwG92bNQKxH0CZEskNnM=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6592, 29966, 11562, 17981], "scansSidecar": "HfUHeeTLE2SFzVRv8Wal0Ucy9AI9jZLiYjZitrtKznW7VPNXNusDWg==", "fileEncSha256": "Y+N3VDTn7uZ2M1Yl0udER2Ap2kLCt0dl0B9dl+u5lvI=", "mediaKeyTimestamp": {"low": 1779072399, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}, "previewType": 0, "endCardTiles": [], "inviteLinkGroupTypeV2": 0}}}, "messageContextInfo": {"threadId": [], "messageSecret": "7trPIpXJNF2EpFRquVqZ+UDhTvauvkVjKxddfWKPrfQ="}}	\N	android	1779073526	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q7r54d0cbddpuw	{"id": "3A2DFB238126354248A0", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	187290823454916	\N	conversation	{"conversation": "tp kacau yak bisa melemahbterus gini", "messageContextInfo": {"threadId": [], "messageSecret": "KwTJA2MYt54vUgvachGFSYs6AJA68c8ynGH1JAAWZRA="}}	\N	ios	1779073521	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffj00q8r54dzsai1da7	{"id": "3A8D6C2235BA5EB2A785", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	187290823454916	\N	conversation	{"conversation": "usdc seperti kata bos kelwin", "messageContextInfo": {"threadId": [], "messageSecret": "Ah1SnGhUWhQ+znvOMYa0IlZ1XhEAvY4gNNQOIYCQT4I="}}	\N	ios	1779073506	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qar54d0fgi8bdu	{"id": "3B8968A94067CDB6424C", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c&mms3=true", "width": 1474, "height": 816, "mediaKey": "X2KW3fC5dCwb7SCT7CMLIYLdfdXSvVLOUyno+9aDhfw=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQPEGQHHYmmAhwDMAZ1gF4Eq_Bwk-TlCCQnGS3rkMYmdvNOjDqpoQTZChOciyftGmhgD2aFeV-nYN838Q4xiT_Z6QYxyMIP-kAb53wjrPg?ccb=9-4&oh=01_Q5Aa4gEgknGMnqBKgEa87Pgi6N0--4pHC4CuqoI-bNQuxTsisA&oe=6A31DD16&_nc_sid=e6ed6c", "fileLength": {"low": 66103, "high": 0, "unsigned": true}, "fileSha256": "W5nRBdoMagk2nUXGMxIdd0YTwG92bNQKxH0CZEskNnM=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [6592, 29966, 11562, 17981], "scansSidecar": "HfUHeeTLE2SFzVRv8Wal0Ucy9AI9jZLiYjZitrtKznW7VPNXNusDWg==", "fileEncSha256": "Y+N3VDTn7uZ2M1Yl0udER2Ap2kLCt0dl0B9dl+u5lvI=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1779072399, "high": 0, "unsigned": false}, "midQualityFileSha256": "UVBMDKSGvZLZWUmTG5r0pnslavdqhqropdAbEx3AjWE=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "17C0Hx6DciRSYiFxw0Mb4HjhJp+MfWoeUAq2cwF8F8E="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1779072401	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qbr54dmy5sahde	{"id": "3B02FF02CDF71621325B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "aman dol wkwk, hrusnya mmang d sini utk diskusi diskusi", "messageContextInfo": {"threadId": [], "messageSecret": "TKc5oAt11BX2FeO3ObSavfhjpEp4K5uESIVwdHlYOy4="}}	\N	unknown	1777528320	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qcr54d46mg8q6c	{"id": "3EB0B3890D5676E91ED077", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "thankyouu discuss dan insightnya bro", "messageContextInfo": {"threadId": [], "messageSecret": "b5vvG50QN49gL3FibVL3chAbVQkM/4w9STveEKtH8BE="}}	\N	web	1777528160	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qdr54duq6vew26	{"id": "3EB0BEDE4C8F1CF94A2032", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "itu aja aku keponya", "messageContextInfo": {"threadId": [], "messageSecret": "c3hrh6vGhn9XNIXFP7PHCAL5rmMFx88AFgXP+izJcdw="}}	\N	web	1777528150	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qer54dhg6zk9ox	{"id": "3EB013B7F777BF56FE5066", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "okeylahh", "messageContextInfo": {"threadId": [], "messageSecret": "f5QEVnj+9lVXm3gauvtrrBOiYG3vjGiuMtatYG+mBr0="}}	\N	web	1777528147	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qfr54dw1f02t5d	{"id": "3B3A0569FE465D0CDC7E", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "wkwk", "messageContextInfo": {"threadId": [], "messageSecret": "+myIGOoJCrXAydxAjhB61pEkfVPXkk4mC4ofoQ4dfg8="}}	\N	unknown	1777525813	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qgr54diwr4tbs8	{"id": "3B4364EE0BE4730677DD", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "kcuali blockchain blockchain-an yaa", "messageContextInfo": {"threadId": [], "messageSecret": "h01u9tCpEyQnzfeZCEndEUQhPACmZg8WI57wNWdC8tQ="}}	\N	unknown	1777525811	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qhr54dpdcsndvi	{"id": "3B93F6E9793839ED8020", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "prompt buat blockchain gitu? ga bkalan ssderhana dngan 1 prompt bsa buat blockchain sih, tpi dia bsa bantu proses buat blockchain", "messageContextInfo": {"threadId": [], "messageSecret": "pFZJbsKtRlpB5dLTiYXSJm6BrgwcrN1Fd50PLXxu+1c="}}	\N	unknown	1777525804	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qir54diu6coyum	{"id": "ACB8813B403AFF4F7E6994E59DB5CD94", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Berarti kalo aku prompt itu bisa yang menghasilkan BlockChain technology itu bro?", "messageContextInfo": {"threadId": [], "messageSecret": "bFOSbJthKBTrxxcWR080+wfIrjhWh6rWR3WJtV9UH0s="}}	\N	android	1777525730	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qjr54dmjrtg5zk	{"id": "ACA9D0CE8C54D252AA2D13F4C533FBD9", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Waw", "messageContextInfo": {"threadId": [], "messageSecret": "yPMskUyuv0Ub917oQQqQV/iNSUxjOGFLS/cadV2rwpg="}}	{"stanzaId": "3B2F7A75B53D230FFFAA", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "bisa dngan bantuan manusia, soalnya sdh dipastikan AI susah desain protocol sendiri"}, "statusAttributions": []}	android	1777525701	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qkr54dsk8puhkm	{"id": "3B2F7A75B53D230FFFAA", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "bisa dngan bantuan manusia, soalnya sdh dipastikan AI susah desain protocol sendiri", "messageContextInfo": {"threadId": [], "messageSecret": "FXzqLcYRhyIhO7murVlLZu+pZd5YwBwLJtl9KXY+iZM="}}	\N	unknown	1777525643	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qlr54dy7f1vp0c	{"id": "ACF8DA025B369C1B288651CB3216338D", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Bisa itu dipake buat blockchain kah?", "messageContextInfo": {"threadId": [], "messageSecret": "JaENAcqtYFOOXh+BFLq5lDQWz3R3NveaW+TFixg6zj0="}}	\N	android	1777525415	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qmr54d8xf5meq7	{"id": "ACF3965AFC02738E0EEC3C14BA0ECC19", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Aku make CLAUDE dan itu powerfull menurutku", "messageContextInfo": {"threadId": [], "messageSecret": "NcO4UPuGMHORmoc2RJ2ggmNGSXicTUeWQZcpOTy2qF8="}}	\N	android	1777525405	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qnr54djkqpbf2s	{"id": "ACB37DF7761D8E48EC7F7DBC7B1D999D", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Nahh pertanyaan ku salah satu yang bener bener kepo, Can AI build the Blockchain? Bro", "messageContextInfo": {"threadId": [], "messageSecret": "6fDvg9Wh0WsrBcLs9zPDYxCCu35MEYOPlNSZBOc9UJs="}}	\N	android	1777525386	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qpr54duk1dj4ne	{"id": "3B5496DBB48955BF7FA3", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "karena aku tau indo sberapa jelek sih, belum smpat expose k negara yg lebih jelek dari blockchainnya", "messageContextInfo": {"threadId": [], "messageSecret": "1IPCURb9aAloA9kFJ/uhXFA1Vxy7umK0kROkhXWPWlc="}}	\N	unknown	1777525188	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qqr54db0o571h4	{"id": "3BB8CB7943DC560D109B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "indo paling jelek wkwk, sorry to say", "messageContextInfo": {"threadId": [], "messageSecret": "UiEsQCfWhSsNKYkzrtSUxapFR8oFwQDNhjGZ+m2cMl8="}}	\N	unknown	1777525158	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qrr54d8d6sgmax	{"id": "3BB4A3D895EF1D960E0C", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dah psti US, Europe, kalau d asia hrusnya china, japan, korea, vietnam", "messageContextInfo": {"threadId": [], "messageSecret": "ORwijjFTZjFvi68ShbqrkYw1OSXtKiLQUyF0gsbvGvo="}}	\N	unknown	1777525143	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qsr54dus37olrc	{"id": "ACD1B137AF29DA757E0730B8D3441CCE", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Kalo negara yang sekarang menurut mu ahead in blockchain itu dimana bro?", "messageContextInfo": {"threadId": [], "messageSecret": "5C2e5jHAatGPe+Ny8V642i5H5bcxcua4PpdHd3AYz2E="}}	\N	android	1777525084	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qtr54dxgmqzhj4	{"id": "AC8E23F01D8A4471EAB960267C7D9148", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Okey masuk akal sih", "messageContextInfo": {"threadId": [], "messageSecret": "VHEjLxE2gpHjuRTOPU66cEUM5mfjQlI3iDK8zQ2ii3U="}}	{"stanzaId": "3B86E8C0121711EB6EEE", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "dan prusahaan prusahaan negara maju mostly integrasi AI dan blockchain"}, "statusAttributions": []}	android	1777525019	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffk00qur54dltpyc9mu	{"id": "3B86E8C0121711EB6EEE", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dan prusahaan prusahaan negara maju mostly integrasi AI dan blockchain", "messageContextInfo": {"threadId": [], "messageSecret": "vRtQRWIobpeUa6VQmXI/qKkWraITzcBFDpQbDDfknpI="}}	\N	unknown	1777524473	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00qvr54d0aj3l96q	{"id": "3B34C849DD956187985B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "krena mreka cenderung bet k yg masa depan dari prusahaan prusahaan negara negara maju", "messageContextInfo": {"threadId": [], "messageSecret": "Za6kcPMnf04cNDhtBF1hFv0+Qv4UlqHiTio+PhWdIiI="}}	\N	unknown	1777524463	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00qwr54dakjgm0vd	{"id": "3B443409405914C93231", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "trutama money inflow k prusahaan negara brkmbng kayaknya sangat minim, justru outflow", "messageContextInfo": {"threadId": [], "messageSecret": "oUGVfJMeSvlHbehT72siZfPGUDUpNxXWN60id0eoYJY="}}	\N	unknown	1777524437	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00qxr54db6uc813e	{"id": "3B8A54F9C160F12CC534", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dan investor trutama justru bkalan bnyk yg titik beratkan k aset teknologi macam blockchain dan AI, dibndingkan k bank bank konvensional", "messageContextInfo": {"threadId": [], "messageSecret": "Icrl4W6KWm+JWLGpX92xv0nLVM3YQoi9aSn6tm/BDHM="}}	\N	unknown	1777524402	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00qyr54dtt0xz9tl	{"id": "3BD8D8836CA551D815C9", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "skrg sih kalau liat dari instituti banyak yg infrastrukturnya dah integrasi k blockchain, krena mreka ga mau operasionalnya bsa kganggu krena 1 negara ngeban atau sjenisnya krena mslah geopolitik, jadi mnurutku hrusnya perang tu makin jadi katalis org org buat pakai web3", "messageContextInfo": {"threadId": [], "messageSecret": "R02f2Hsy94ICDtYfwuvVq4n27z+3jqZkqtqI9CddzOk="}}	\N	unknown	1777524301	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00qzr54duxj2cpcs	{"id": "AC0643A69B877999E342230749409754", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Ke project blockchain\\nYang pertama bro", "messageContextInfo": {"threadId": [], "messageSecret": "ZNatYrW+xQJeec7qYs3l8VF3SqxrUnAi7dRGio/I8M4="}}	{"stanzaId": "3B5A4BDCF267C767AF0B", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "yg mau ku make sure tu sisi investor yg kayak gmna? mksdnya apakah investor yg invest k project blockchain atau org yg invest token token yg d blockchain?"}, "statusAttributions": []}	android	1777524088	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r0r54da0tg50ch	{"id": "3B5A4BDCF267C767AF0B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "yg mau ku make sure tu sisi investor yg kayak gmna? mksdnya apakah investor yg invest k project blockchain atau org yg invest token token yg d blockchain?", "messageContextInfo": {"threadId": [], "messageSecret": "R6knggZyWZMdnO9WjfEfuTf3CJF9Rmj9d9PeHBb1UQw="}}	\N	unknown	1777524069	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r1r54dty6bviwe	{"id": "AC4F2DDA44EEB4EADD4A0B64627A7BA2", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Dikoreksi kalo salah ya bro😁", "messageContextInfo": {"threadId": [], "messageSecret": "D4UWYgAgqtEIIr2XIlKEk4w12V2leQjCdFgJQmqnh1w="}}	\N	android	1777523966	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r2r54de2m9rsme	{"id": "AC9E65C048F605F257228B00613A50B2", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Karena aku sempet baca baca katanya israel mau jadi head of blockchain technology nya juga", "messageContextInfo": {"threadId": [], "messageSecret": "7Ve+Fw3ClZPgm+E5PKhP8f8oLwt9hdD4xHIMQy4vJS8="}}	\N	android	1777523952	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rrr54d5tdxhn5t	{"id": "3B15424897430CC8F494", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "iyaa institusi yg tokenize berbeda", "messageContextInfo": {"threadId": [], "messageSecret": "Zhluv1dJUDzZ4UNjGJnLPRgkBspOCk6rd6HYsNZv1CM="}}	\N	unknown	1777520730	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r3r54dx036ugba	{"id": "ACBD5A5BF608CB52CF6B7D825A8DCCAE", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Bro mau tanya, discuss aja @185486836560069 dengan keadaan geopolitik, dan ekonomi nasional serta international saat ini, masih menarik kah dunia blockchain ini dari sisi investor?", "messageContextInfo": {"threadId": [], "messageSecret": "f2Kbjq4CdUIge1CX0o7nImxpNiBx7ecDglguMNNc1rc="}}	{"mentionedJid": ["185486836560069@lid"], "groupMentions": [], "statusAttributions": []}	android	1777523930	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r4r54dg07isvc3	{"id": "3BEC9FB78C69F0654A5B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "okee", "messageContextInfo": {"threadId": [], "messageSecret": "Cmf3eIKpjL+WHPdTOrLyOimYoH7JQKtyV0G7xygBtY4="}}	\N	unknown	1777523909	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r5r54dky6p9f9t	{"id": "AC00DE1D207F200F0A2ECDA8E41A517C", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Kayak ibit dll", "messageContextInfo": {"threadId": [], "messageSecret": "xuTGmo24ieGv4E0rykWs4THSiesqfiUU6pOoYoZWJss="}}	\N	android	1777523849	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r6r54d4f6w2orc	{"id": "AC3D94C03264696976FCABFBBEE17466", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Yg khusus btc", "messageContextInfo": {"threadId": [], "messageSecret": "hvBxnS4HOz6l2MmlyjQOoVl3zY5oU/rtK7Nz1aXKXv0="}}	\N	android	1777523846	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r7r54d3gnkzf49	{"id": "ACD02991CCCE7730B19F4F45967D0000", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Etf vanguard gaada di gotrade", "messageContextInfo": {"threadId": [], "messageSecret": "hCafIa3abO6gTzP0n8BVJFTwR53dcMrvLmqlhLjXKUk="}}	\N	android	1777523841	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r8r54dyt9aq0ew	{"id": "AC011EB3D2CBD03B7ADAC79246FEBF64", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Nah", "messageContextInfo": {"threadId": [], "messageSecret": "nKUx+OdGFnSZ0fStq5wnDpS+2/b+1EabqxRCWHl+hW0="}}	{"stanzaId": "3B34DDCD5A20DECD83DB", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMedJVrGrnznfUDvdpWCxTwId5_ki9vdgCVemzlkPZHonONXjkIk3JOBBjsWihZyW-4m2iXKDOVPil1VbVAxMORo3aLjzWBxW-8iK1QpA?ccb=9-4&oh=01_Q5Aa4QEvi7Zqu6bRUAt5DU7kPC3u7ZIMsMx4M8QL09Yc5Tz15A&oe=6A1A3AB5&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 696, "caption": "even etf vanguard smuanya ad dol", "mediaKey": "KDocQH9ISuKOqwKSd+VSIfU6TvWAy5zAIUzORcpzH3I=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQMedJVrGrnznfUDvdpWCxTwId5_ki9vdgCVemzlkPZHonONXjkIk3JOBBjsWihZyW-4m2iXKDOVPil1VbVAxMORo3aLjzWBxW-8iK1QpA?ccb=9-4&oh=01_Q5Aa4QEvi7Zqu6bRUAt5DU7kPC3u7ZIMsMx4M8QL09Yc5Tz15A&oe=6A1A3AB5&_nc_sid=e6ed6c", "fileLength": {"low": 53918, "high": 0, "unsigned": true}, "fileSha256": "/viQ0FNcXTo2Yr5/t/ptL7rYgF2V3IC0ridbJKvIlbw=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [5344, 17834, 9937, 20801], "scansSidecar": "2r1+bOBI1+KBBAFHopXl9Z5cHGWXo3ZS1HM9UBNDk2YBNasuhvr6Xg==", "fileEncSha256": "h08Hy6oG0UUvgaNPEoj53ZEOh4OatXCeQ8cDid5fcdk=", "mediaKeyTimestamp": {"low": 1777522264, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	android	1777523831	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00r9r54d3se6ef4w	{"id": "ACE2D0A42832B76B2D0471F781D65F1A", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Okey ntar kucoba", "messageContextInfo": {"threadId": [], "messageSecret": "Ml0zAcJ/3PuWRZeBhV2WZlyLv9wotK+IjNvAqM+PSqk="}}	\N	android	1777523830	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00rar54di1j50ygq	{"id": "3B48A727B03A16789978", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "t8tsuuo8R2s55o61wQFwIp0gnaSuQbgVaNqDL0DQIvc=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B34DDCD5A20DECD83DB", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m237/AQPypCTlKRdSJO9QQb4Lrnyzu4u1URQ7kZZqL3n5YyRrlAIAoPVAUtkZyWvd4BYO7cMoWUsth_Gt0dTVFl6CohNjvM1m6qWwiskxdgYGEg?ccb=9-4&oh=01_Q5Aa4QGdItB3BG7fT08aTGlnAlGbMy8Wc9LJHU5Zse-gwiaIJQ&oe=6A1A5C15&_nc_sid=e6ed6c&mms3=true", "width": 2880, "height": 1566, "caption": "even etf vanguard smuanya ad dol", "mediaKey": "n+1zCNb1eQchcBClGhpkPzRt115VO8LwUxtCWZEgCgI=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m237/AQPypCTlKRdSJO9QQb4Lrnyzu4u1URQ7kZZqL3n5YyRrlAIAoPVAUtkZyWvd4BYO7cMoWUsth_Gt0dTVFl6CohNjvM1m6qWwiskxdgYGEg?ccb=9-4&oh=01_Q5Aa4QGdItB3BG7fT08aTGlnAlGbMy8Wc9LJHU5Zse-gwiaIJQ&oe=6A1A5C15&_nc_sid=e6ed6c", "fileLength": {"low": 208410, "high": 0, "unsigned": true}, "fileSha256": "cDcbPOOTNWnGSvu41wL+C8SRvv+/V8ZaiUc84aFAUao=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [21659, 20860, 75039, 90850], "scansSidecar": "LL/AFRwhdsCYN+52CkIWckwW7PqZW4ngE2yFfKa2wYOvN5EkzdNoLw==", "fileEncSha256": "p54rUplVlY6oMjJc4Cu6IRfeySgjO3Ew9YTtVlvM+Ho=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777522265, "high": 0, "unsigned": false}, "midQualityFileSha256": "zyMEZi54O36LhBXQzWT618shck09H8zOVLzcalBH5dQ=", "interactiveAnnotations": []}}}}	\N	unknown	1777522267	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00rbr54dsxdttyc5	{"id": "3B34DDCD5A20DECD83DB", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMedJVrGrnznfUDvdpWCxTwId5_ki9vdgCVemzlkPZHonONXjkIk3JOBBjsWihZyW-4m2iXKDOVPil1VbVAxMORo3aLjzWBxW-8iK1QpA?ccb=9-4&oh=01_Q5Aa4QEvi7Zqu6bRUAt5DU7kPC3u7ZIMsMx4M8QL09Yc5Tz15A&oe=6A1A3AB5&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 696, "caption": "even etf vanguard smuanya ad dol", "mediaKey": "KDocQH9ISuKOqwKSd+VSIfU6TvWAy5zAIUzORcpzH3I=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQMedJVrGrnznfUDvdpWCxTwId5_ki9vdgCVemzlkPZHonONXjkIk3JOBBjsWihZyW-4m2iXKDOVPil1VbVAxMORo3aLjzWBxW-8iK1QpA?ccb=9-4&oh=01_Q5Aa4QEvi7Zqu6bRUAt5DU7kPC3u7ZIMsMx4M8QL09Yc5Tz15A&oe=6A1A3AB5&_nc_sid=e6ed6c", "fileLength": {"low": 53918, "high": 0, "unsigned": true}, "fileSha256": "/viQ0FNcXTo2Yr5/t/ptL7rYgF2V3IC0ridbJKvIlbw=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [5344, 17834, 9937, 20801], "scansSidecar": "2r1+bOBI1+KBBAFHopXl9Z5cHGWXo3ZS1HM9UBNDk2YBNasuhvr6Xg==", "fileEncSha256": "h08Hy6oG0UUvgaNPEoj53ZEOh4OatXCeQ8cDid5fcdk=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777522264, "high": 0, "unsigned": false}, "midQualityFileSha256": "luXt/MpR7hGTe9ZyEESLBOEWUCKEeE99hZwR1hND0KM=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "0zR5c5FczIPUW9xfBGv9PKehchEc/l0ftjgSFY7wjqc="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1777522265	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00rcr54dhekk896s	{"id": "3BEDB2AFF9FAEB843E51", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "ZWHMQ1zDBOi/H25UANmsOq+oshCd5UrmGx+megeK8Gk=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3BA264880EE61792859F", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "185486836560069@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQP-hjIUHRu5n2HnzRgHkBNVaMF6DpZWbWzfcHp-IOZ5NeWvMtm9q4TOTrpGpF8CuFtCRhWBBA2jgC2PhzHOhzigX_Sb1_T6P2fnE0GIDA?ccb=9-4&oh=01_Q5Aa4QED-tFcSOoqxJRBt64-YPhfQaYUB0-4ot_TGEL42fZenw&oe=6A1A5FF5&_nc_sid=e6ed6c&mms3=true", "width": 2878, "height": 1548, "caption": "https://app.paradapp.com/en/solana/dapphub/trending\\n\\ncoba scroll ke paling bawah", "mediaKey": "N4bZ6G302gVafF27tMMts2VKRstr7XB1/oKTBJ16d/8=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m231/AQP-hjIUHRu5n2HnzRgHkBNVaMF6DpZWbWzfcHp-IOZ5NeWvMtm9q4TOTrpGpF8CuFtCRhWBBA2jgC2PhzHOhzigX_Sb1_T6P2fnE0GIDA?ccb=9-4&oh=01_Q5Aa4QED-tFcSOoqxJRBt64-YPhfQaYUB0-4ot_TGEL42fZenw&oe=6A1A5FF5&_nc_sid=e6ed6c", "fileLength": {"low": 208955, "high": 0, "unsigned": true}, "fileSha256": "Xu9H2ABbYa5ITf9BJmqdaPUha7+yVuUGmFIZQR3TCUI=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [21672, 21037, 74625, 91619], "scansSidecar": "dH72MvbmGDhPXOqg4VDrSAmqHFweNnd/rSWb7CRo4R30UFKfy34ubA==", "fileEncSha256": "OH6TT7sQqinv47SLckI4K2pf8dMqVTr4WUAAo3skuTM=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777522202, "high": 0, "unsigned": false}, "midQualityFileSha256": "YBPvHqsxHtvGNc2NSyHLWrQriPIF98hP9Zmvp8U7Elo=", "interactiveAnnotations": []}}}}	\N	unknown	1777522203	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rsr54du3m8ggjq	{"id": "AC1DCC1305E82EAD113EB0D9EB8D9CC8", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Usdc sama usdt bedanya apa? Company nya doang kan ya?", "messageContextInfo": {"threadId": [], "messageSecret": "NDp0bGG6sp/uSaWP5G2NgHR6t//SSFIsqsBsUAQNkhA="}}	\N	android	1777520717	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rtr54dtlb90go7	{"id": "3B281CB52454691D0A4A", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "sma beli saham us, emas, dll smuanya tpi yg tokenized (jadi assetnya di dalam sistem blockchain)", "messageContextInfo": {"threadId": [], "messageSecret": "s23cO1GQ9PAvYezMRTLWkx5Tbya6GRkFqJ6mi3E53Jk="}}	\N	unknown	1777520716	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffl00rdr54d03pvbu5d	{"id": "3BA264880EE61792859F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQPexBXghfjuGdQrBFFkuYPZtfbOFAVLYKrVRxWC4E7SNSL4tDUl-845tyXg9Nxj5DdvICNuGm45AN3Uy2IcQmv8YUMMvnOMHuw3JtbsEA?ccb=9-4&oh=01_Q5Aa4QEyd8OfsKxHQn7T881De_T1NMb2M55nLpFWnFyP2XB-tQ&oe=6A1A51F2&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 688, "caption": "https://app.paradapp.com/en/solana/dapphub/trending\\n\\ncoba scroll ke paling bawah", "mediaKey": "04iYbsbkpEh86TCyAYVznDNCuSE2YYS2ZHYbkbSyMtk=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQPexBXghfjuGdQrBFFkuYPZtfbOFAVLYKrVRxWC4E7SNSL4tDUl-845tyXg9Nxj5DdvICNuGm45AN3Uy2IcQmv8YUMMvnOMHuw3JtbsEA?ccb=9-4&oh=01_Q5Aa4QEyd8OfsKxHQn7T881De_T1NMb2M55nLpFWnFyP2XB-tQ&oe=6A1A51F2&_nc_sid=e6ed6c", "fileLength": {"low": 52872, "high": 0, "unsigned": true}, "fileSha256": "iQJpDHl2io+UyTUOXCvHICWgatWcEviURPwN5oGHvj8=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [5399, 17654, 9436, 20381], "scansSidecar": "wsgaZWRKR/4Cru44oma078kVuJtItHVFBuE3UmFLKfLx7vwsKWvcNg==", "fileEncSha256": "bxT7ePNE64AYKBpaSo4RbOcZMmF7pDD5rxPosZ7tSHQ=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777522200, "high": 0, "unsigned": false}, "midQualityFileSha256": "XoCvaWOy2dy+eBL/Rxza2ah075FQVZGbjW3a1Oz7+H0=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "L/9wi8klq/N35CpD41Tzi/BVc/6Wk64ifXqsLuQjSZc="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1777522201	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rer54dv0y7f09j	{"id": "3BB7FA9202FF43AC4A06", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "dan ini decentralize", "messageContextInfo": {"threadId": [], "messageSecret": "bYYUg5L99CPCRwyZUJim62vW7i1ib62pvah/hnvW0qo="}}	\N	unknown	1777522139	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rfr54dcwiqp754	{"id": "3B100CF00E03B135BC3D", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "hrusnya lebih lengkap dari go trade", "messageContextInfo": {"threadId": [], "messageSecret": "FVMO5/dSnYb1MM85kELK4S8/+WJIEzUri3JmMGuYBb0="}}	\N	unknown	1777522131	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rgr54diptvxrar	{"id": "3B680F9AA4075A52D929", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "belinya jga bsa fraction", "messageContextInfo": {"threadId": [], "messageSecret": "4rb7upHsd0F6yYlZVbwfC1rIHssqcgnt6mo/vpvtTZo="}}	\N	unknown	1777522117	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rhr54d88ytuo9l	{"id": "AC5E859A26227F11BF7A84CD4356B3C3", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Sementara us stock pake gotrade soalnya aku win @185486836560069", "messageContextInfo": {"threadId": [], "messageSecret": "ya3TBmcO7JK617zlGFlk1dPjDOSg+WFDH1vVbftWYkQ="}}	{"mentionedJid": ["185486836560069@lid"], "groupMentions": [], "statusAttributions": []}	android	1777521942	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rir54dyw935ndu	{"id": "ACFBAF5D01F840CE27116B3601D274DA", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Kukira us stock belum bisa yang tokenized", "messageContextInfo": {"threadId": [], "messageSecret": "LDAkmTpv3RTzFl1wSdmaFnv6Q93Mrt09c0AB51aVwL0="}}	\N	android	1777521931	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rjr54dxo9ug734	{"id": "AC042124869958A593EEEC0870F5D188", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Baru tau", "messageContextInfo": {"threadId": [], "messageSecret": "Svo1/x2lTxqIWYCrTWc6nq+PKjyLjpmrqIqb/Cnrgko="}}	\N	android	1777521914	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rkr54dspo05ri8	{"id": "ACEA74305DB1439BE39B9E488A4C84E6", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Ohya", "messageContextInfo": {"threadId": [], "messageSecret": "6Lrw5JAow9UJsdyAhKbUolsWepuWA3qrWNgS4HdGc1A="}}	{"stanzaId": "3B10AE70860B3C5F6AE8", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "yg menarik sih US Stocknya, soalnya bsa trade 24/7"}, "statusAttributions": []}	android	1777521912	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rlr54d8aaxx4k0	{"id": "3B6035023775F31F05E1", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Asik ya, banyak yg bisa di explore wkwkw\\nPelan pelan aku rangkum kedepannya 🤙", "messageContextInfo": {"threadId": [], "messageSecret": "K04/cM3Ns90WuDIjQsOLzbZkcY2uWyRTuUI36ZUlDtM="}}	\N	unknown	1777521102	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rmr54dfmm5829i	{"id": "3BB141CC0D877A228E33", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "jadi ga ada market open atau close lagi d hari lbur", "messageContextInfo": {"threadId": [], "messageSecret": "Lv31W2+4LS9V0yAOAa6r8AwCseV1IYrrZHjT7bwrNmA="}}	\N	unknown	1777520919	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rnr54dbl5ruqfh	{"id": "3B10AE70860B3C5F6AE8", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "yg menarik sih US Stocknya, soalnya bsa trade 24/7", "messageContextInfo": {"threadId": [], "messageSecret": "9G3vsv03sMfT+QCfN8+NKh0dL1BW0iy0lq45/vVK4p8="}}	\N	unknown	1777520896	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00ror54d8d7ebl1k	{"id": "ACD60A6DD33ED0364811855B4723D152", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Ahaaa begitu", "messageContextInfo": {"threadId": [], "messageSecret": "ig/q07z+EdQhPKIAWKetjROFpgYXWdLqb6pji/wEhPg="}}	\N	android	1777520759	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rpr54d5nqgpglq	{"id": "3B12D0D914B6F3F5ABE2", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "kalau d solana banyakan pakai USDC", "messageContextInfo": {"threadId": [], "messageSecret": "0Q8p8gRabr3yIHAf6vxReKF5pXYP/Im0VQGC8rDawK8="}}	\N	unknown	1777520750	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rqr54dr3tznmsp	{"id": "3BEEDE6D6B6CAC7D314C", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "jadi product product yg bsa pakai usdc dan usdt jga bsa berbeda beda", "messageContextInfo": {"threadId": [], "messageSecret": "ffyEaqzEtqRE6SVE7QfTeB7oHOsnF4MhaM5n6bHuxXA="}}	\N	unknown	1777520744	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rur54dfm2y9sba	{"id": "AC45DF392FBD215682BF75BDF67236F4", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Waanjay kerenn keren", "messageContextInfo": {"threadId": [], "messageSecret": "fmdme9Rq72wEGN6xjGpBLxFC13pCV26kHeq/OJgG61s="}}	{"stanzaId": "3BF329CCA717BE30FC21", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "bisa nyimpan usdc dapat bunga dol"}, "statusAttributions": []}	android	1777520705	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rvr54d36caomlo	{"id": "3BF329CCA717BE30FC21", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	185486836560069	\N	conversation	{"conversation": "bisa nyimpan usdc dapat bunga dol", "messageContextInfo": {"threadId": [], "messageSecret": "zsAavtNuQjAggSblskPh2usCXns26ysa8iv/u7pYtxQ="}}	\N	unknown	1777520691	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rwr54d3bmutsvi	{"id": "ACC1AEB7B9E54D19441C27124BD537D5", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Wah menarik", "messageContextInfo": {"threadId": [], "messageSecret": "kbZV3kp3Hvwyc27xDKub1+5r972jMAoLmyiDcQNGzj8="}}	{"stanzaId": "3BD932C757C6AED30367", "quotedType": 0, "participant": "167929614229740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "i see, Jadi awal product kita kan untuk bisa beli bitcoin ya, bahkan langsung simpennya di wallet web3 kita yang which mean bener” kita yg pegang asset kita.\\n\\nSekarang tuh kita juga provide untuk bisa tuker bitcoin kita ke token jaringan blockchain lain kaya Solana, Ethereum gitu brohh"}, "statusAttributions": []}	android	1777520542	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rxr54d2yuatf7p	{"id": "3B00FBAEE2F003A7D64B", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Banyak sih yg pengen di share sebenernnya.. anggep aja ini kenalan awal ajaaa", "messageContextInfo": {"threadId": [], "messageSecret": "iGI66ZJPwRPw5jHkncCsLfQFqYWZKEK15XFSVX5/BB4="}}	\N	unknown	1777520329	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00ryr54dxlkomkya	{"id": "3BD932C757C6AED30367", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "i see, Jadi awal product kita kan untuk bisa beli bitcoin ya, bahkan langsung simpennya di wallet web3 kita yang which mean bener” kita yg pegang asset kita.\\n\\nSekarang tuh kita juga provide untuk bisa tuker bitcoin kita ke token jaringan blockchain lain kaya Solana, Ethereum gitu brohh", "messageContextInfo": {"threadId": [], "messageSecret": "EQ5DAQEjL34HAwFRVtDCsaMMHhibXzw2LJW8eSlshOM="}}	{"stanzaId": "AC03155ADBDDC07B3D2E335FE28D2FCB", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Belum pernah broh \\n\\nKayaknya wkwk"}, "statusAttributions": []}	unknown	1777520243	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00rzr54dkliivmqi	{"id": "AC03155ADBDDC07B3D2E335FE28D2FCB", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Belum pernah broh \\n\\nKayaknya wkwk", "messageContextInfo": {"threadId": [], "messageSecret": "X7K/mGbM/QqC8uc+pwiXnSednKDklqozOgWm4YlrjDY="}}	{"stanzaId": "3B6DF6BBF51A7008F7C1", "quotedType": 0, "participant": "167929614229740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Btw izin nanya nihh..\\nSelain transaction Bitcoin, pernah transaction di jaringan blockchain lain?"}, "statusAttributions": []}	android	1777519898	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffm00s0r54delr0rnse	{"id": "3B6EE0407F58130A8EA8", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "fun fun aja lah yakk ga harus ciyus ciyus banget hehehe", "messageContextInfo": {"threadId": [], "messageSecret": "eF+7TD/c+JVRmBB+AYFstdTv0/rF2yE0fecif8zU39U="}}	\N	unknown	1777519873	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s1r54d08ckgq7o	{"id": "AC307AD3286B990D1E8744046835AC18", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	212154322055172	\N	stickerMessage	{"stickerMessage": {"url": "https://mmg.whatsapp.net/v/t62.15575-24/536851601_1494153965707182_7713511244784247900_n.enc?ccb=11-4&oh=01_Q5Aa4QEawD1znKV725sGydFCMWkKgcGAL0sce1g3WWc1oLFWQw&oe=6A1A55E9&_nc_sid=5e03e0&mms3=true", "width": 64, "height": 64, "isAvatar": false, "isLottie": false, "mediaKey": "iJIw/wvKtLx0tb5pDZzU/ED026Duj5vF36ngVgQZZNk=", "mimetype": "image/webp", "directPath": "/v/t62.15575-24/706704111_2236318123840337_2927531618014164423_n.enc?ccb=11-4&oh=01_Q5Aa4gFPVgzb3jIJZJjKD-C8oDdXNlpMm_qP6Sw_XhjbTiCR3w&oe=6A3B7D4C&_nc_sid=5e03e0", "fileLength": {"low": 361518, "high": 0, "unsigned": true}, "fileSha256": "BcRb4i6UyUf4kovknJFjGLVDyMFcH97RceOaDZC4XAg=", "isAnimated": true, "isAiSticker": false, "fileEncSha256": "J3lTgrSbA7x/tIOfWVhjNfOSdCEXpd60J0xLThSMJbE=", "stickerSentTs": {"low": -596611544, "high": 413, "unsigned": false}, "firstFrameLength": 361106, "firstFrameSidecar": "J9BuVqrQNm6YLA==", "mediaKeyTimestamp": {"low": 1777292768, "high": 0, "unsigned": false}}, "messageContextInfo": {"threadId": [], "messageSecret": "UmCwekpjCPcWyHvN/4qod1yCC7JWM+EfHp9hNXM6JGw="}}	null	android	1777519849	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s2r54dj039do8f	{"id": "3B133EEB06CBD91EB36F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "wkwkwkwk", "messageContextInfo": {"threadId": [], "messageSecret": "kW1rAFuUtgrek99NoaIG6DBTkYoKM8ZjUaDdYOoMQtY="}}	\N	unknown	1777519837	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s3r54do7bcngp7	{"id": "3B46CCD416CB25C71B05", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "pokoknya apapun itu kita harus izinnn", "messageContextInfo": {"threadId": [], "messageSecret": "JoVIEXxtq0uZTccPvzthydDrUP2hFbFGLEPUErZ0Y9M="}}	\N	unknown	1777519834	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s4r54dsdm5jyjl	{"id": "3B8E1AD195747FC86157", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	videoMessage	{"videoMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQND32F5PYfZAsxnx1h5aiW2CgE-ZiS1cgCLWDliM3zGChHmdHA-BpQ15UF4wWxJT9qKoC2-iNuHg9nivmShgX_wW_OgrbECog0HNN0?ccb=9-4&oh=01_Q5Aa4QGASJD6mYYkwSmVx59iolas4uBpvLWfCKCAlesrqfoIUw&oe=6A1A3C0D&_nc_sid=e6ed6c&mms3=true", "width": 196, "height": 266, "seconds": 4, "mediaKey": "jQ4B/CBs3DFOn4aZVl1GZcF/i9CyHR564O1d2IvP5x0=", "mimetype": "video/mp4", "directPath": "/o1/v/t24/f2/m231/AQND32F5PYfZAsxnx1h5aiW2CgE-ZiS1cgCLWDliM3zGChHmdHA-BpQ15UF4wWxJT9qKoC2-iNuHg9nivmShgX_wW_OgrbECog0HNN0?ccb=9-4&oh=01_Q5Aa4QGASJD6mYYkwSmVx59iolas4uBpvLWfCKCAlesrqfoIUw&oe=6A1A3C0D&_nc_sid=e6ed6c", "fileLength": {"low": 239050, "high": 0, "unsigned": true}, "fileSha256": "p3qugCESeWb1zdrWylTSxyvP9Tq9I+ChYtxyJ6hcVv4=", "annotations": [], "contextInfo": {"stanzaId": "AC97C9B7A557ACD69F88F6A076F874CE", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Buset jangan izin izin bro\\nUdh kayak birokrasi aja wkw"}, "statusAttributions": []}, "gifPlayback": true, "fileEncSha256": "7oB5UMPu/1yGCJS6pu3V4/PCSw/KzJQjFN4SZSgfTT8=", "gifAttribution": 1, "processedVideos": [], "mediaKeyTimestamp": {"low": 1777519827, "high": 0, "unsigned": false}, "accessibilityLabel": "Izin GIF", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "riqwvf6y5EjeP2wT1h9G8TXqwop5sNq5tx+bm//2f/4="}}	{"stanzaId": "AC97C9B7A557ACD69F88F6A076F874CE", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Buset jangan izin izin bro\\nUdh kayak birokrasi aja wkw"}, "statusAttributions": []}	unknown	1777519828	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s5r54d371zm67k	{"id": "AC97C9B7A557ACD69F88F6A076F874CE", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Buset jangan izin izin bro\\nUdh kayak birokrasi aja wkw", "messageContextInfo": {"threadId": [], "messageSecret": "YnuGI7SiIObD+19RtArRTKb0BZjE5Vhy1glKDV9Wty4="}}	\N	android	1777519809	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s6r54dk60v8lt7	{"id": "3B6DF6BBF51A7008F7C1", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Btw izin nanya nihh..\\nSelain transaction Bitcoin, pernah transaction di jaringan blockchain lain?", "messageContextInfo": {"threadId": [], "messageSecret": "y9bqJ44+4PksBrfDKUSdi7aKZCkEoKexLV86wxtJEx0="}}	{"stanzaId": "AC82ACDFE9531A4F0B7BDA3F5C317E5D", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Filosofi logonya apa bro kalo boleh tau? @167929614229740"}, "statusAttributions": []}	unknown	1777519638	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s7r54dsf1x7d9g	{"id": "3B198D56CF0658EE125F", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Basically dari filosofi dari logo itu main keywordnya “*parallel*” bro @266266531090456 \\nJadi artinya kita ada di mana mana setiap jaringan blockchain.", "messageContextInfo": {"threadId": [], "messageSecret": "i0XqAR1IGPg9Fo8ldAmfIDhRTffmguUIRFqKR+8cpSw="}}	{"stanzaId": "AC82ACDFE9531A4F0B7BDA3F5C317E5D", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": ["266266531090456@lid"], "groupMentions": [], "quotedMessage": {"conversation": "Filosofi logonya apa bro kalo boleh tau? @167929614229740"}, "statusAttributions": []}	unknown	1777519443	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s8r54d78m4uywy	{"id": "AC82ACDFE9531A4F0B7BDA3F5C317E5D", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Filosofi logonya apa bro kalo boleh tau? @167929614229740", "messageContextInfo": {"threadId": [], "messageSecret": "YHEGnJnfMDTFxomC/aU9qU3F5SErqAgjyNXxuanVDdA="}}	{"mentionedJid": ["167929614229740@lid"], "groupMentions": [], "statusAttributions": []}	android	1777519231	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00s9r54dq03iq05m	{"id": "3B86FC8255E14E12A419", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Udah saat nya kita level up blockchain knowledge kita nih..", "messageContextInfo": {"threadId": [], "messageSecret": "yEmDwiQX59i0YDlMS/syxpn1F0yd+Tea1ETr8mr8lM8="}}	\N	unknown	1777518634	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00sar54dczmc0bos	{"id": "3B8C8A60DB301C6CCEA5", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "Yo’i", "messageContextInfo": {"threadId": [], "messageSecret": "W0YXyY9Ai5ud+U+5I7QD66P5O6oyf91KrjJe/J+g6aE="}}	{"stanzaId": "ACBD8A09C32550C544A1C05194A1F269", "quotedType": 0, "participant": "266266531090456@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Wah ada yang baru nih ya?"}, "statusAttributions": []}	unknown	1777518580	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00sbr54dnli3n2ys	{"id": "ACBD8A09C32550C544A1C05194A1F269", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	266266531090456	\N	conversation	{"conversation": "Wah ada yang baru nih ya?", "messageContextInfo": {"threadId": [], "messageSecret": "JodqyE+fn20TciaaJNBFz3TCtD8X2fLNmbcgMuOrUVI="}}	{"stanzaId": "3B21D3D0F38490BD3AEF", "quotedType": 0, "participant": "167929614229740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 720, "mediaKey": "GscuDHy5uBEIzaLgQVa9bydZELOLZb8AZ07wTCqno7w=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c", "fileLength": {"low": 45905, "high": 0, "unsigned": true}, "fileSha256": "34H7ULVt2BcxgmxkTyhdjjM/0MF/XSkIPpWa4KDuuZU=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [7028, 18305, 7878, 12692], "scansSidecar": "IOKwAWVzIZkhocMQ6S2g2T78ifwPROztags8lE5GkompP2RgTn3A+Q==", "fileEncSha256": "fP5dgzafPxw0BIAkYMqoS4T4MCO71csiC2iiZ5x2pMM=", "mediaKeyTimestamp": {"low": 1777518476, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	android	1777518493	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00scr54d64ud8zf0	{"id": "3B7BB3234F8533F7BB03", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	conversation	{"conversation": "BitVault is Evolving to ParaDapp! 🚀\\n\\nHalo teman-teman semua! Ada kabar besar yang mau aku bagikan hari ini.\\n\\nSeperti yang terlihat di banner baru kita, BitVault resmi berevolusi menjadi Paradapp. Kenapa kita evolusi? Karena kita ingin melangkah lebih jauh untuk eksplorasi  blockchain world bersama.\\n\\nFokus kita sekarang bukan lagi sekadar simpen Bitcoin, tapi bagaimana kita bisa memanfaatkan aset yang kita punya agar lebih produktif—misalnya lewat fitur staking atau swap langsung ke berbagai ekosistem lain dengan cara yang tetap aman.\\n\\nApa yang akan kita bangun di sini?\\n\\n1️⃣ Pusat Edukasi Bersama (Wiki): Aku lagi siapkan Notion Wiki yang akan jadi \\"buku panduan\\" kita untuk belajar segala hal tentang Web3, cara kelola aset, sampai tips keamanan.\\n\\n2️⃣ Weekly Insights: Setiap minggunya, kita akan bedah tren terbaru soal investasi dan teknologi crypto supaya kita semua tetap up-to-date tanpa perlu pusing pantau Twitter seharian.\\n\\n3️⃣ New Experience: Kita sudah bisa mulai intip platform baru kita di: app.paradapp.com\\n\\nTujuan kita tetap sama: Paham sepenuhnya apa yang bisa dilakukan dengan aset blockchain yang kita miliki.\\n\\n⚠️ Penting:\\nSeiring transisi ini, yuk kita tetap waspada. Admin nggak akan pernah chat duluan atau minta private key/isi wallet teman-teman. Selain itu, perlu kita ingat bahwa komunitas ini murni sebagai provider layanan dan sarana edukasi; kita di sini bukan untuk berbagi signal trading atau investment advice yaa.\\n\\nMari kita mulai babak baru ini bareng-bareng! Kalau ada masukan atau pertanyaan soal arah baru kita ini, langsung chit chat disini yaa 🙌", "messageContextInfo": {"threadId": [], "messageSecret": "eW0WRGFiFBpcCyCbiDduuD/2WHBuF8poFqWGD+DxnYQ="}}	{"stanzaId": "3B21D3D0F38490BD3AEF", "quotedType": 0, "participant": "167929614229740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 720, "mediaKey": "GscuDHy5uBEIzaLgQVa9bydZELOLZb8AZ07wTCqno7w=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c", "fileLength": {"low": 45905, "high": 0, "unsigned": true}, "fileSha256": "34H7ULVt2BcxgmxkTyhdjjM/0MF/XSkIPpWa4KDuuZU=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [7028, 18305, 7878, 12692], "scansSidecar": "IOKwAWVzIZkhocMQ6S2g2T78ifwPROztags8lE5GkompP2RgTn3A+Q==", "fileEncSha256": "fP5dgzafPxw0BIAkYMqoS4T4MCO71csiC2iiZ5x2pMM=", "mediaKeyTimestamp": {"low": 1777518476, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	unknown	1777518484	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00sdr54d5ixkrg1i	{"id": "3B1DD28E6FFB63CE1AB4", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "iEbZRiaimE4yn0aDzhbCUMJNqisoEejt78pAOvr4bo0=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B21D3D0F38490BD3AEF", "fromMe": false, "remoteJid": "120363420394299704@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNxeoOh4T-nplWYbKtkAFAs80NE_9USEmXjSjbST55zT9JzW7lhb1kX7LdvD3R0FBfq0WPvByE2ASq7WX7oN3Y2TQM0crACLxrZiJImxA?ccb=9-4&oh=01_Q5Aa4QGRsDH3vwlRXXrmPx2WJOLcmLoSO9H3FL3L6u4qK0nTAw&oe=6A1A4B58&_nc_sid=e6ed6c&mms3=true", "width": 4160, "height": 2340, "mediaKey": "k1RdO66V9BM6CXr5etk25OR3fC4Oend5zqHGtDhCA2I=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQNxeoOh4T-nplWYbKtkAFAs80NE_9USEmXjSjbST55zT9JzW7lhb1kX7LdvD3R0FBfq0WPvByE2ASq7WX7oN3Y2TQM0crACLxrZiJImxA?ccb=9-4&oh=01_Q5Aa4QGRsDH3vwlRXXrmPx2WJOLcmLoSO9H3FL3L6u4qK0nTAw&oe=6A1A4B58&_nc_sid=e6ed6c", "fileLength": {"low": 239212, "high": 0, "unsigned": true}, "fileSha256": "M2KQnhYJ7PSA6j5XflM0yfbmf8lGn/94sMCWf90MNgs=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [49870, 44006, 87057, 58277], "scansSidecar": "H3qQMeueCHKoUXG0aD+VoknUhJvEmjvh4DMrQTs2Fksj0mDFQZQDaA==", "fileEncSha256": "sPp4IuD7MDnjyxGzlQ3AbHrSRgTwhreEbmk5AzSsU3k=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777518478, "high": 0, "unsigned": false}, "midQualityFileSha256": "W6byc/h+i49upb6G9aH0Zk8g7lFC3yDBBTiGrTNf6nQ=", "interactiveAnnotations": []}}}}	\N	unknown	1777518479	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00slr54dxveq5set	{"id": "3EB016B5BF704C389EFFC3", "fromMe": true, "remoteJid": "167929614229740@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/549427749_4236770523302973_89289661049594800_n.enc?ccb=11-4&oh=01_Q5Aa4wEaOhk47QYgyg0U2-vzDEkrb1RXNd1yJH9zS4aQSv28iA&oe=6A5B6006&_nc_sid=5e03e0&mms3=true", "fileName": "ParaHub_Materi.pdf", "mediaKey": "jPrrQ7ToBzcRu/tZkQK4KHz0GBfbSHpj3TL0kxvZEzM=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/549427749_4236770523302973_89289661049594800_n.enc?ccb=11-4&oh=01_Q5Aa4wEaOhk47QYgyg0U2-vzDEkrb1RXNd1yJH9zS4aQSv28iA&oe=6A5B6006&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "WeAFkM4KbjweEgjirBuTftr6DKkLwx6qkUPL2k2thJI=", "mediaKeyTimestamp": {"low": 1781787731, "high": 0, "unsigned": false}}}	null	web	1781787734	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00ser54dhfxkkteq	{"id": "3B21D3D0F38490BD3AEF", "fromMe": false, "remoteJid": "120363420394299704@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 720, "mediaKey": "GscuDHy5uBEIzaLgQVa9bydZELOLZb8AZ07wTCqno7w=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m231/AQOkoYBdb2O6BSosLEOmnWlUNgjgL7ZtqG2wD3GsPDQTixTBLHJ1CjiP7mhPprmKbLCikkG8rlNZBJY5A7G4L4pHlvBPFRMA-ZsGdH8xJQ?ccb=9-4&oh=01_Q5Aa4QEBknQ_Cw8LlRI9UHSOI75hgOHGF3fhqSAV1mSXKf7pQQ&oe=6A1A3064&_nc_sid=e6ed6c", "fileLength": {"low": 45905, "high": 0, "unsigned": true}, "fileSha256": "34H7ULVt2BcxgmxkTyhdjjM/0MF/XSkIPpWa4KDuuZU=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [7028, 18305, 7878, 12692], "scansSidecar": "IOKwAWVzIZkhocMQ6S2g2T78ifwPROztags8lE5GkompP2RgTn3A+Q==", "fileEncSha256": "fP5dgzafPxw0BIAkYMqoS4T4MCO71csiC2iiZ5x2pMM=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777518476, "high": 0, "unsigned": false}, "midQualityFileSha256": "xphl5/gPgzG3U35j1/2SsY4bMj7YdwsD4iIp1CVfBSI=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "tFm3iY53BrQ5nwSz4FBXjG90xfeUtM/gdAQYVeYN+zc="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 3, "statusAttributions": []}	unknown	1777518477	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00sfr54d6ksozxjf	{"id": "A5A15D5511D20A0F0E2149E1CB1356E8", "fromMe": true, "remoteJid": "65842469404740@lid"}	Você	\N	templateButtonReplyMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "cza2Q0J1KOEbJESZZKN9iGxTOJdp+NCddgyttMiRB48="}, "templateButtonReplyMessage": {"selectedId": "DID_NOT_REQUEST_CODE", "contextInfo": {"stanzaId": "FEE3AB02AED0C600D9", "quotedType": 0, "participant": "65842469404740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"templateMessage": {"hydratedTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}, "hydratedFourRowTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}}}, "statusAttributions": []}, "selectedIndex": 1, "selectedDisplayText": "Saya tidak menerima kode"}}	{"stanzaId": "FEE3AB02AED0C600D9", "quotedType": 0, "participant": "65842469404740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"templateMessage": {"hydratedTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}, "hydratedFourRowTemplate": {"hydratedButtons": [], "hydratedFooterText": "Kedaluwarsa dalam 10 menit.", "hydratedContentText": "*4522* adalah kode verifikasi Anda. Demi keamanan, jangan bagikan kode ini."}}}, "statusAttributions": []}	android	1781841347	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffn00sgr54d2igi6nb0	{"id": "FEE3AB02AED0C600D9", "fromMe": false, "remoteJid": "65842469404740@lid"}	65842469404740	\N	placeholderMessage	{"placeholderMessage": {"type": 0}}	\N	desktop	1781841253	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00shr54dqhj9hzvv	{"id": "3EB05BD25E9441CFD3247C", "fromMe": true, "remoteJid": "113739474936038@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/536385013_1920343011981721_3467069621062072652_n.enc?ccb=11-4&oh=01_Q5Aa4wF6pHAn6J3-sjKyh4PH3lUoY6pKcct2pY6O5itXW1dRmg&oe=6A5B501D&_nc_sid=5e03e0&mms3=true", "caption": "hi, this is parahub slide for you to learn!", "fileName": "ParaHub_Materi.pdf", "mediaKey": "CmtXaD66LpsG6XoNSrJ04fsUQQyNubLdrmLeHeN3zQo=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/536385013_1920343011981721_3467069621062072652_n.enc?ccb=11-4&oh=01_Q5Aa4wF6pHAn6J3-sjKyh4PH3lUoY6pKcct2pY6O5itXW1dRmg&oe=6A5B501D&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "rY/kVsVQTbjKZQL9sTBk9G2Q9fe8xNJcDJz3XihikUs=", "mediaKeyTimestamp": {"low": 1781787953, "high": 0, "unsigned": false}}}	null	web	1781787955	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00sir54dj6gx4hxu	{"id": "3EB01D7A0B1BFA633BE42C", "fromMe": true, "remoteJid": "113739474936038@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/597416508_2961618830711741_766455054738242992_n.enc?ccb=11-4&oh=01_Q5Aa4wEW7Pc0_4GLAO50QhIDppL4lTYLUyVMbeaQE8niVvdF7g&oe=6A5B4ABA&_nc_sid=5e03e0&mms3=true", "fileName": "ParaHub_Materi.pdf", "mediaKey": "6nnftgsy7ChRBYpSdI+U/4wfbdo5x27V6NlB0nOeOtA=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/597416508_2961618830711741_766455054738242992_n.enc?ccb=11-4&oh=01_Q5Aa4wEW7Pc0_4GLAO50QhIDppL4lTYLUyVMbeaQE8niVvdF7g&oe=6A5B4ABA&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "uE0kfp7yJQ9SYTDf3JVy5V8w2QGCMYVLGf2ayokGQHM=", "mediaKeyTimestamp": {"low": 1781787811, "high": 0, "unsigned": false}}}	null	web	1781787812	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00sjr54dxd6f6z8k	{"id": "3EB0FDEA917439BCCF7B22", "fromMe": true, "remoteJid": "113739474936038@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/614236614_4755247951375683_3982699048331822573_n.enc?ccb=11-4&oh=01_Q5Aa4wFKip9wxV-xKRVkwtA_91JOM1_Jbvs7yQcniDaTSPFrXw&oe=6A5B46BB&_nc_sid=5e03e0&mms3=true", "fileName": "ParaHub_Materi.pdf", "mediaKey": "PrtFKlqI+c8cCjwBbBaM0imsmDE/YMyDAqYl+Mgv0PY=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/614236614_4755247951375683_3982699048331822573_n.enc?ccb=11-4&oh=01_Q5Aa4wFKip9wxV-xKRVkwtA_91JOM1_Jbvs7yQcniDaTSPFrXw&oe=6A5B46BB&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "x4871oAM2zDTzz/z+Lz7sx5tFNl9LuSLRbPySCeZf4c=", "mediaKeyTimestamp": {"low": 1781787011, "high": 0, "unsigned": false}}}	null	web	1781787014	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00skr54dstyqdneo	{"id": "3EB02DED8AA6F35E4C2D4B", "fromMe": true, "remoteJid": "113739474936038@lid"}	Você	\N	conversation	{"conversation": "hi"}	\N	web	1781784614	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00smr54du5ncs7sz	{"id": "3EB0F2FFF8EA3EFBF49024", "fromMe": true, "remoteJid": "167929614229740@lid"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/659792932_2760588244312920_7258437879331268433_n.enc?ccb=11-4&oh=01_Q5Aa4wEwuD0nL8D8iDUSLTtfZVjB4sACxq1rZwtYk2aAAWRAPw&oe=6A5B67F6&_nc_sid=5e03e0&mms3=true", "fileName": "ParaHub_Materi.pdf", "mediaKey": "rmwekBBqIf9jrZocPLjJZokxrmEMJWMK6rnLR7KOXJM=", "mimetype": "application/pdf", "pageCount": 0, "directPath": "/v/t62.7119-24/659792932_2760588244312920_7258437879331268433_n.enc?ccb=11-4&oh=01_Q5Aa4wEwuD0nL8D8iDUSLTtfZVjB4sACxq1rZwtYk2aAAWRAPw&oe=6A5B67F6&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "fileEncSha256": "H5TewpkRsQO9vXnnLPt/MOX3pnVbKcq+58QR2z2N/AA=", "mediaKeyTimestamp": {"low": 1781787152, "high": 0, "unsigned": false}}}	null	web	1781787155	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00snr54djj07lea2	{"id": "1569165038060490-1", "fromMe": false, "remoteJid": "0@s.whatsapp.net"}	0	\N	interactiveMessage	{"interactiveMessage": {"body": {"text": "*Take control of your chats with lists.*\\n\\nYou can create up to 20 lists—rename or reorganize them to work for you. Easily find the chats you need, when you need them.\\n\\n⭐️ Pro-tip: Create a “New Orders” or “New Customers” list to quickly reply to time sensitive messages."}, "header": {"videoMessage": {"width": 1080, "height": 1080, "caption": "*Take control of your chats with lists.*\\n\\nYou can create up to 20 lists—rename or reorganize them to work for you. Easily find the chats you need, when you need them.\\n\\n⭐️ Pro-tip: Create a “New Orders” or “New Customers” list to quickly reply to time sensitive messages.", "seconds": 21, "mediaKey": "m2Z1cexOEYEQUYZw0CunmVgLBBe0aMh7NczzNE/hgjs=", "mimetype": "video/mp4", "staticUrl": "https://static.whatsapp.net/downloadable?category=PSA&id=1006341001221807188&num=1babf5ef-027a-4df2-95ab-4d00bbb1e421&_nc_cat=1", "fileLength": {"low": 8417934, "high": 0, "unsigned": true}, "fileSha256": "D0wourkG3sC+7BHbHX2WcS8VMvmNwNFXJDjAG0YXVhY=", "annotations": [], "fileEncSha256": "wWWiZdRHkFFMp3xU1xHdXFAi7W5eo11E+htiL7tk+ik=", "processedVideos": [], "interactiveAnnotations": []}, "hasMediaAttachment": true}, "nativeFlowMessage": {"buttons": [{"name": "cta_url", "buttonParamsJson": "{\\"display_text\\":\\"Try now\\",\\"payment_link_preview\\":false,\\"url\\":\\"whatsapp-smb:\\\\/\\\\/biztab\\\\/labels\\",\\"webview_interaction\\":true}"}], "messageParamsJson": ""}}, "messageContextInfo": {"threadId": [], "messageSecret": "NrdYAfZ1OCtCmpMNPVNu72RpfnFsDrRbEta6bmbz7MU="}}	null	desktop	1781769779	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00sor54d2aafx2ne	{"id": "1470088020807147-1", "fromMe": false, "remoteJid": "0@s.whatsapp.net"}	0	\N	interactiveMessage	{"interactiveMessage": {"body": {"text": "*Keep customers engaged with an away message and status!*\\n\\n🕙Out of office or enjoying a well-earned break?\\n\\n✈️ Away messages take the pressure off replying to customers and make sure you never miss a message\\n\\n💬 Just go to settings > business tools > away message 🔛"}, "header": {"videoMessage": {"caption": "*Keep customers engaged with an away message and status!*\\n\\n🕙Out of office or enjoying a well-earned break?\\n\\n✈️ Away messages take the pressure off replying to customers and make sure you never miss a message\\n\\n💬 Just go to settings > business tools > away message 🔛", "seconds": 24, "mediaKey": "h4Dzk6T26r+8Zyfj5dG/qOV9u0/dYhE4/FScVmVz9K4=", "mimetype": "video/mp4", "staticUrl": "https://static.whatsapp.net/downloadable?category=PSA&id=844901550264292170&num=6c800fc5-1cae-4b4a-aa35-a5539b8e3252&_nc_cat=1", "fileLength": {"low": 14471612, "high": 0, "unsigned": true}, "fileSha256": "m6Qr/W144oz1CjKyhVa+lJjcBltniU4gO8xXe96tuQk=", "annotations": [], "fileEncSha256": "6WGzhAaXgAIxXdWkewW0C9fNYuupWCFH306Qhmw7mpo=", "processedVideos": [], "interactiveAnnotations": []}, "hasMediaAttachment": true}, "nativeFlowMessage": {"buttons": [{"name": "cta_url", "buttonParamsJson": "{\\"display_text\\":\\"Try now\\",\\"payment_link_preview\\":false,\\"url\\":\\"whatsapp-smb:\\\\/\\\\/biztab\\\\/away-message\\",\\"webview_interaction\\":true}"}], "messageParamsJson": ""}}, "messageContextInfo": {"threadId": [], "messageSecret": "D3SECnua3qJd36LACF/bYnCyjBb9D1ibCEJyJq5Djug="}}	null	desktop	1781164034	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00spr54dcdx9o4iw	{"id": "1836200367057200-1", "fromMe": false, "remoteJid": "0@s.whatsapp.net"}	0	\N	interactiveMessage	{"interactiveMessage": {"body": {"text": "*Grow your business, just like David!*\\n\\nOne campaign with ads that click to WhatsApp is all it took to gain 400 quality leads for Guitarras David Alcántara 🎸\\n\\nPro tip: start with a catalog item to set up your ad faster! 🚀  "}, "header": {"videoMessage": {"width": 1080, "height": 1080, "caption": "*Grow your business, just like David!*\\n\\nOne campaign with ads that click to WhatsApp is all it took to gain 400 quality leads for Guitarras David Alcántara 🎸\\n\\nPro tip: start with a catalog item to set up your ad faster! 🚀  ", "seconds": 22, "mediaKey": "4ZGsf0Z3nl80os+sjSFx4TGVrRQbkumlL4jYy1asCDA=", "mimetype": "video/mp4", "staticUrl": "https://static.whatsapp.net/downloadable?category=PSA&id=1007357229951369762&num=f2c7de6e-fe06-48c2-bc7f-3c402403d3db&_nc_cat=1", "fileLength": {"low": 14582694, "high": 0, "unsigned": true}, "fileSha256": "8FHRCTikabzj0QJha99U6dL4txD/VsFK2U8tSQKKmAk=", "annotations": [], "fileEncSha256": "qpwp2dUtO9oB29rkMCZCJK39y0+xH3f/ZGFPjnQLRhw=", "processedVideos": [], "interactiveAnnotations": []}, "hasMediaAttachment": true}, "nativeFlowMessage": {"buttons": [{"name": "cta_url", "buttonParamsJson": "{\\"display_text\\":\\"Launch an ad today!\\",\\"payment_link_preview\\":false,\\"url\\":\\"https:\\\\/\\\\/wa.me\\\\/biztab\\\\/advertise?wa_campaign_type=chat_psa\\",\\"webview_interaction\\":true}"}], "messageParamsJson": ""}}, "messageContextInfo": {"threadId": [], "messageSecret": "jw0whTGOt3BtBdVxmZVc0mWtT+ZFdzaYNgOowSeFkSQ="}}	null	desktop	1780322099	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00svr54dyayf2wd7	{"id": "3BE66A954555B7B296CD", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "Tementemen yang lain kalau mau coba bisa langsung d sini aja, kayak calvin, bsa tanya tanya, dan belajar brsama jadinya", "messageContextInfo": {"threadId": [], "messageSecret": "Z8RzQe2risf3sJM6k+OlmHc8dR1ZKcIvZVHkEVydt14="}}	\N	unknown	1780920797	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00swr54dfkyqjhps	{"id": "3A39E8D4637FDE854385", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Hormat diberi komandan🫡😁", "messageContextInfo": {"threadId": [], "messageSecret": "24cF84YO+M39Vm0RgsDseRNL66q1iAWJMF8Rf4DOuNs="}}	\N	ios	1780920646	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00sxr54dqtjss569	{"id": "3BCD81666E5BD654A515", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "wkwkkw", "messageContextInfo": {"threadId": [], "messageSecret": "2hbCtaTFry8BnObJvzkkn8KgAvoDEcT1A1HB9tAo+2o="}}	\N	unknown	1780920606	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00sqr54difmjoet2	{"id": "1484720636734891-1", "fromMe": false, "remoteJid": "0@s.whatsapp.net"}	0	\N	videoMessage	{"videoMessage": {"caption": "*Save private notes in WhatsApp to personalize customer experiences!*\\n\\n📝 Create private notes while you’re in your chat thread\\n\\n👤Or into your customer’s profile for you to see\\n\\n😍 Never forget the small details that can make a big difference to personalizing your customers’ experiences ", "seconds": 25, "mediaKey": "Kbw5/7WbGzY5pkmFbamWcSOmOB64/0+rk9Y1ZHwaASc=", "mimetype": "video/mp4", "staticUrl": "https://static.whatsapp.net/downloadable?category=PSA&id=473167745371341200&num=e71424ef-eb68-4f2d-a625-86325103940b&_nc_cat=1", "fileLength": {"low": 14756290, "high": 0, "unsigned": true}, "fileSha256": "gssi4mOgsii98yxAs7fcsiH1sVxmTccrFCJyIhO31bg=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "fileEncSha256": "NUnSCHBBhI6UKHUaodJb21hD+UU/JybIiqHsEdyAj1U=", "processedVideos": [], "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "Fm+xF19VJX6EN22lBfSBFRMHacguNJv6rz7VxdTuvE8="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	desktop	1779702307	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00srr54dvabi67na	{"id": "3BE7B4EB87EF465C59D2", "fromMe": false, "remoteJid": "120363402874234431@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQNsgKKQERhr1mPEwguShka6dNP86b1gk4bZnv44qFjrXlhupMPNQXLcyGEsei9fY1e5Zy89tFPY1wiDgEPiWnL2FAQRQSufsczM6El73A?ccb=9-4&oh=01_Q5Aa4wEeti79xGWueCyAb0l68JKzKEiIi-RAFmU_gglYIEtUng&oe=6A4C985E&_nc_sid=e6ed6c&mms3=true", "width": 960, "height": 1280, "caption": "Guys.. Lokasi kita ada di lt 2 gedung bagian ini yaa 🙌", "mediaKey": "QJ22xhT+BAfusHPTBEu7KxQTBQytxnqRxPb/bCU1kxo=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQNsgKKQERhr1mPEwguShka6dNP86b1gk4bZnv44qFjrXlhupMPNQXLcyGEsei9fY1e5Zy89tFPY1wiDgEPiWnL2FAQRQSufsczM6El73A?ccb=9-4&oh=01_Q5Aa4wEeti79xGWueCyAb0l68JKzKEiIi-RAFmU_gglYIEtUng&oe=6A4C985E&_nc_sid=e6ed6c", "fileLength": {"low": 173093, "high": 0, "unsigned": true}, "fileSha256": "sjF/wAoEsYOCEhi/xyFUr2R4HfMZj4482rFxKb4wI4A=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [14551, 67960, 49216, 41364], "scansSidecar": "PjeVtpFv7YLp4APS9wygK3vdW4e12OLHW55lmScbi/suQIbvovzC7Q==", "fileEncSha256": "K35TaWnuvcWppX5LEJiKFzvhqXqu5DeTMzsmtD3Misk=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780816006, "high": 0, "unsigned": false}, "accessibilityLabel": "Lokasi lt 2 sini. Naik lantai 2 \\nLetwat sini", "midQualityFileSha256": "REPmPo+ul1w2D7nJCWH8o8zD2yPTNQwCaaw53KmU4qM=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "gdZ1x2DXZ3mHu1yEGrFZ+J0X7yCiZGwIAkWBDAL/BBk="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1780816008	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00ssr54dy0gthul1	{"id": "3B9041D5BF1BED53BFE2", "fromMe": false, "remoteJid": "120363402874234431@g.us"}	167929614229740	\N	protocolMessage	{"protocolMessage": {"key": {"id": "3BCD4DCC49DC41504D84", "fromMe": false, "remoteJid": "120363402874234431@g.us", "participant": "167929614229740@lid"}, "type": 14, "timestampMs": {"low": -2092393204, "high": 414, "unsigned": false}, "editedMessage": {"extendedTextMessage": {"font": 0, "text": "Halo Temen-temen! 👋\\nKita adain meet up seru minggu ini nih!! 🥂\\n\\nYang lagi free, sekalian pengen nongki” gabung yaa\\n\\n*Agenda Kita:*\\n- Discuss & Sharing: Kita bakal ngobrol santai tentang dasar blockchain dan kenapa teknologi desentralisasi ini jadi penting banget di era digital.\\n- ⁠Networking & QnA: Buat kalian yang mau memperluas jaringan atau punya pertanyaan yang selama ini belum terjawab tentang blockchain, bisa langsung datang dan kita bahas bareng yaa!\\n\\n\\n*SAVE THE DATE!*\\n> 📅 7 Juni 2026\\n> ⏰ 16.00 – 18.00 WITA\\n> 📍 Kopi Zeen, Badung\\n\\n*Register Slot Here ⬇︎*\\nhttps://luma.com/b3859fnz", "title": "ParaHub · Luma", "mediaKey": "oNG142VpbhMICll/1TUodsuwDelj3g3jDrZFSUFzS2c=", "textArgb": 0, "description": "ParaHub adalah blockchain onboarding meetup yang dirancang untuk membantu siapa saja memahami dunia blockchain dan Web3 dengan cara yang sederhana dan mudah…", "matchedText": "https://luma.com/b3859fnz", "previewType": 0, "endCardTiles": [], "backgroundArgb": 0, "thumbnailWidth": 800, "thumbnailHeight": 420, "thumbnailSha256": "x6XQN0A0P0Z0mABLZ0ThTUrIniLlsSqeAZlHTyGVQAc=", "mediaKeyTimestamp": {"low": 1780319034, "high": 0, "unsigned": false}, "faviconMMSMetadata": {"mediaKey": "VGAOrQZNYyyL7XnvPTEhRubRaqunrsynD8UJU98BQkw=", "thumbnailSha256": "uxy1nyvhj/nP90yPy1lfRvUi6dGRicX/MD/lrc3gWVo=", "thumbnailEncSha256": "G/RLqjketaEE+Rhesvb5o3Vx7j+k3BoNfS9AxSIEx2I=", "thumbnailDirectPath": "/v/t62.36144-24/580094380_1405375798303818_3114678865138907134_n.enc?ccb=11-4&oh=01_Q5Aa4gF2NnD08VoynEj1Nk1u5SkPMd_VqcoHm620KN2-KV2Amg&oe=6A44EC68&_nc_sid=5e03e0"}, "thumbnailEncSha256": "5aPSqxB2Z+rQHdPT7izsTcM68VMNZHs5ErCTT4Un2eA=", "linkPreviewMetadata": {"fbExperimentId": 0}, "thumbnailDirectPath": "/v/t62.36144-24/710052951_977969464867175_4501440538188870999_n.enc?ccb=11-4&oh=01_Q5Aa4gH6a02yiql-u0pus6NMYf749X8nQv022LTeLcFPwm8dpA&oe=6A44F739&_nc_sid=5e03e0", "inviteLinkGroupTypeV2": 0}}}, "messageContextInfo": {"threadId": [], "messageSecret": "MTvLkT3utQewxP4ufBzcjEzVkKaY1HBduT1ur71TpYw="}}	\N	unknown	1780318718	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00str54dmszt7kjo	{"id": "3B91271B838EDABBA6D3", "fromMe": false, "remoteJid": "120363402874234431@g.us"}	167929614229740	\N	conversation	{"conversation": "BitVault is Evolving to Paradapp! 🚀\\n\\nHalo teman-teman semua! Ada kabar besar yang mau aku bagikan hari ini.\\n\\nSeperti yang terlihat di banner baru kita, BitVault resmi berevolusi menjadi Paradapp. Kenapa kita evolusi? Karena kita ingin melangkah lebih jauh untuk eksplorasi  blockchain world bersama.\\n\\nFokus kita sekarang bukan lagi sekadar simpen Bitcoin, tapi bagaimana kita bisa memanfaatkan aset yang kita punya agar lebih produktif—misalnya lewat fitur staking atau swap langsung ke berbagai ekosistem lain dengan cara yang tetap aman.\\n\\n*Apa yang akan kita bangun di sini?*\\n1️⃣ Pusat Edukasi Bersama (Wiki): Aku lagi siapkan Notion Wiki yang akan jadi \\"buku panduan\\" kita untuk belajar segala hal tentang Web3, cara kelola aset, sampai tips keamanan.\\n\\n2️⃣ Weekly Insights: Setiap minggunya, kita akan bedah tren terbaru soal investasi dan teknologi crypto supaya kita semua tetap up-to-date tanpa perlu pusing pantau Twitter seharian.\\n\\n3️⃣ New Experience: Kita sudah bisa mulai intip platform baru kita di: app.paradapp.com\\n\\nTujuan kita tetap sama: Paham sepenuhnya apa yang bisa dilakukan dengan aset blockchain yang kita miliki.\\n\\n*⚠️ Penting:*\\nSeiring transisi ini, yuk kita tetap waspada. Admin nggak akan pernah chat duluan atau minta private key/isi wallet teman-teman. Selain itu, perlu kita ingat bahwa komunitas ini murni sebagai provider layanan dan sarana edukasi; kita di sini bukan untuk berbagi signal trading atau investment advice yaa.\\n\\nMari kita mulai babak baru ini bareng-bareng! Kalau ada masukan atau pertanyaan soal arah baru kita ini, langsung chit chat disini yaa 🙌", "messageContextInfo": {"threadId": [], "messageSecret": "tSMBvOpZ40/dSBrHC2sZHUKkV5ryTXKK+AhKjvXBM9k="}}	\N	unknown	1777518721	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffo00sur54djlqm3awm	{"id": "3B892B2B88F2E1DB417F", "fromMe": false, "remoteJid": "120363402874234431@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNxeoOh4T-nplWYbKtkAFAs80NE_9USEmXjSjbST55zT9JzW7lhb1kX7LdvD3R0FBfq0WPvByE2ASq7WX7oN3Y2TQM0crACLxrZiJImxA?ccb=9-4&oh=01_Q5Aa4QGRsDH3vwlRXXrmPx2WJOLcmLoSO9H3FL3L6u4qK0nTAw&oe=6A1A4B58&_nc_sid=e6ed6c&mms3=true", "width": 4160, "height": 2340, "mediaKey": "k1RdO66V9BM6CXr5etk25OR3fC4Oend5zqHGtDhCA2I=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQNxeoOh4T-nplWYbKtkAFAs80NE_9USEmXjSjbST55zT9JzW7lhb1kX7LdvD3R0FBfq0WPvByE2ASq7WX7oN3Y2TQM0crACLxrZiJImxA?ccb=9-4&oh=01_Q5Aa4QGRsDH3vwlRXXrmPx2WJOLcmLoSO9H3FL3L6u4qK0nTAw&oe=6A1A4B58&_nc_sid=e6ed6c", "fileLength": {"low": 239212, "high": 0, "unsigned": true}, "fileSha256": "M2KQnhYJ7PSA6j5XflM0yfbmf8lGn/94sMCWf90MNgs=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [49870, 44006, 87057, 58277], "scansSidecar": "H3qQMeueCHKoUXG0aD+VoknUhJvEmjvh4DMrQTs2Fksj0mDFQZQDaA==", "fileEncSha256": "sPp4IuD7MDnjyxGzlQ3AbHrSRgTwhreEbmk5AzSsU3k=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1777518478, "high": 0, "unsigned": false}, "midQualityFileSha256": "W6byc/h+i49upb6G9aH0Zk8g7lFC3yDBBTiGrTNf6nQ=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "yBo7UMSoVXST+X6rTBp4ljp4cN3CcRrMmeFtl8/m4f0="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1777518696	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00syr54dkdozhp0g	{"id": "3B559015EDBF93D28E91", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "thankyou vinn, bsa krena keduanya karena internet atau bnyk yg akses, kta jadi masih relatif early jga jadi server website bsa lebih lambat kalau ada ramai yg akses, nanti bkalan terus ditingkatkan sih seiring jumlah pengguna", "messageContextInfo": {"threadId": [], "messageSecret": "aCIVVY04gPJX7adOizAKvOX1KTIlxalj63dJtUWrQLk="}}	{"stanzaId": "3A1215871FD4C01FDACE", "quotedType": 0, "participant": "253287190290663@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Siappp mantapp Win, sejauh ini Paradapp msih okayy bangett, hnya ad beberapa lag2 sedikit atau mungkin dri jaringan sy juga ni wkwkw"}, "statusAttributions": []}	unknown	1780920605	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00szr54d47g2by6k	{"id": "3A1215871FD4C01FDACE", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Siappp mantapp Win, sejauh ini Paradapp msih okayy bangett, hnya ad beberapa lag2 sedikit atau mungkin dri jaringan sy juga ni wkwkw", "messageContextInfo": {"threadId": [], "messageSecret": "6M1aHpDmOonSrQREhlg9YxE/24rtX+UeqcmyXQlHtfU="}}	{"stanzaId": "3B75AC4FD5259014B585", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "krena di paradapp cuma interface ngambil data dari blockchain aja, sama kayak d phantom wallet jga gitu, dta yang penting di dalam blockchainnya, jadi check di blockchainnya lngsng lebih bagus"}, "statusAttributions": []}	ios	1780920482	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t0r54dzxyfd9ia	{"id": "3B6B1FC8C4A243E881E2", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "tapi di indo bnyk provider ngeblock, dikirain judi kali ya wkwkwk", "messageContextInfo": {"threadId": [], "messageSecret": "q+w7LSSV9ShLgqV4Ill/Ht3KztEvshWICjM0vJ3L50E="}}	\N	unknown	1780920202	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t1r54dnnhfuz9y	{"id": "3B441E7ABE6819EC8F67", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "nah sbnernya aku lebih suka pakai ini https://mempool.space/", "messageContextInfo": {"threadId": [], "messageSecret": "cqHFCXKzPgrEKvQIq2LSzWeB41RgTP3pKEirpgtTEQ0="}}	null	unknown	1780920190	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t2r54d9gf8u5xj	{"id": "3B72A54C35DBA4A3A554", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "bkalan kliatan jumlah bitcoin dll d blockchainny lngsng", "messageContextInfo": {"threadId": [], "messageSecret": "cvbcUE0A3yEXBl9y3p7LeFjDSZkvdDuWwxX+eMhhltQ="}}	\N	unknown	1780920168	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t3r54dho1z66le	{"id": "3B7C4C7B819ACB66073A", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "coba paste aja address bitcoinnya ke sana", "messageContextInfo": {"threadId": [], "messageSecret": "p+QL9qEbkjJ2vXDjuJud6jCEMXE2gbxkgsCwzgZ644E="}}	\N	unknown	1780920152	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t4r54dkpbro8bd	{"id": "3BC947D6B3B0D8FED5D8", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "https://blockstream.info/", "messageContextInfo": {"threadId": [], "messageSecret": "DNRWnu8YEnfnq9efh9Tpq4BecQ8hLkHDIOp1uErP69E="}}	\N	unknown	1780920144	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t5r54dfvm9gmde	{"id": "3B75AC4FD5259014B585", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "krena di paradapp cuma interface ngambil data dari blockchain aja, sama kayak d phantom wallet jga gitu, dta yang penting di dalam blockchainnya, jadi check di blockchainnya lngsng lebih bagus", "messageContextInfo": {"threadId": [], "messageSecret": "EFtpJNjUyHH/bxQkxKLiuXU+uSYx0sKtQO0lo+QA/Yo="}}	\N	unknown	1780920110	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t6r54d2p9odeya	{"id": "3AB7EA8CA95E38149F45", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Ini pke hotspot dri hp sih wkwkwk", "messageContextInfo": {"threadId": [], "messageSecret": "xhOOnHTcrICSxiVEwgjGQDDD+Z/9FBfQNApWCjr+BM0="}}	{"stanzaId": "3B8538BE7013579651EE", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "coba ganti wifinya aja vin, soalnya beberapa provider wifi di indo ngeblock API mempool jadi datanya ga kliatan, yg pnting d dalam blockchain uda confirmed"}, "statusAttributions": []}	ios	1780920088	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t7r54donwr1csc	{"id": "3B8538BE7013579651EE", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "coba ganti wifinya aja vin, soalnya beberapa provider wifi di indo ngeblock API mempool jadi datanya ga kliatan, yg pnting d dalam blockchain uda confirmed", "messageContextInfo": {"threadId": [], "messageSecret": "F5kpbe8mzKPQL8oJG9WhuMz/BX0yh0fwN6nRZmsCNPY="}}	\N	unknown	1780920061	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t8r54dr96g3pgg	{"id": "3A9E9D2295531967FBB1", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/608879267_1905517163461001_42483036143743462_n.enc?ccb=11-4&oh=01_Q5Aa4wEKMh6fsJ5jn3br1qIqBbYp8zBU8Q6Yf3xaZypmIwvEPA&oe=6A4E03FF&_nc_sid=5e03e0&mms3=true", "width": 1200, "height": 1600, "caption": "Win ad problem lgi ni, dri tdi di bagian aset gk muncul aset bitcoin yg kita pegang tu brapa, tpi di phantom udh msuk, hnya di paradapp gk bisa liat, klo usdc tdi bisa liat", "mediaKey": "v5541Z0Xbfc7vPAb6bn6A5d+IMf8GtWsK6O33o5iN3s=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/608879267_1905517163461001_42483036143743462_n.enc?ccb=11-4&oh=01_Q5Aa4wEKMh6fsJ5jn3br1qIqBbYp8zBU8Q6Yf3xaZypmIwvEPA&oe=6A4E03FF&_nc_sid=5e03e0", "fileLength": {"low": 310427, "high": 0, "unsigned": true}, "fileSha256": "XD/3AMhtPLCnto6MCOmp3nm11/KtBEcbe5VWnhEkY1o=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [21160, 93941, 71122, 124202], "scansSidecar": "KBREmfucahf5NB/AqZ0yGfMCD57NrBkdcAufQl16BBUp2157I6GcWg==", "fileEncSha256": "brXCry3Gm24RsiD9rp27QaexIw5UGhyUhK6VvgA0+M4=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780919895, "high": 0, "unsigned": false}, "midQualityFileSha256": "VMQQsmveK1X/AHLNHg1tQf/l4M3Z3j2gFq9BYmOqsyc=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "QOPHsQR0FLikYTtExv7YbHJezEVPZUmxCWjPC0qPw+o="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	ios	1780919951	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00t9r54dy75737ks	{"id": "3ABFF8F7FC03B87ED730", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Meluncurrr🚀", "messageContextInfo": {"threadId": [], "messageSecret": "wKIEwu46+TlpRitAqntYamlCaucxI858Zt+ARc00kY0="}}	{"stanzaId": "3B0D85A44FDF2FA01CF4", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "@253287190290663 dah bsa vin bitcoinnya"}, "statusAttributions": []}	ios	1780918803	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00tar54dw491i78w	{"id": "3B0D85A44FDF2FA01CF4", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "@253287190290663 dah bsa vin bitcoinnya", "messageContextInfo": {"threadId": [], "messageSecret": "z2+pyig8Nc7gCcgFSjLAoPB2+Jk7Zsc7iLO71wbLhGs="}}	{"mentionedJid": ["253287190290663@lid"], "groupMentions": [], "statusAttributions": []}	unknown	1780918784	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00tbr54dpxijznii	{"id": "3B8ED1AAC5335F32A5AA", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "okee wkkww, aman, kalau ada ksulitan baru tanya aja vin", "messageContextInfo": {"threadId": [], "messageSecret": "DFPCeaB1AAcXAPPEwhYXWVTNzoV4obT4W8Msp9Tn4Ks="}}	\N	unknown	1780917547	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00tcr54darfks5bw	{"id": "3A769AC378DA982ECEC4", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Ini lgi ngulik2 paradapp biar bisa gacorr🔥😂", "messageContextInfo": {"threadId": [], "messageSecret": "LlwGy9XL5LVORKVpYBxXpLimvlQ4dgH/anjYtbe0b1w="}}	{"stanzaId": "3B23C1A02A2C2C097582", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "ini uda coba stake belum?"}, "statusAttributions": []}	ios	1780917503	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00tdr54dmol3sp0j	{"id": "3B23C1A02A2C2C097582", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "ini uda coba stake belum?", "messageContextInfo": {"threadId": [], "messageSecret": "VJH99h3dIjANocmaybn5iHvKItqLEySRf+LZfPVTPdk="}}	{"stanzaId": "3A001FE3CECDD51008C5", "quotedType": 0, "participant": "253287190290663@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/552316855_1991338205081758_8803312413181357469_n.enc?ccb=11-4&oh=01_Q5Aa4wG79DRtMDRX-UZ8ZGRJqUx5_-Mp9CYbSGLaAKKD14m-Zw&oe=6A4DFD77&_nc_sid=5e03e0&mms3=true", "width": 1200, "height": 1600, "caption": "Done Win, thanks 🤙🏽", "mediaKey": "RUWxDDL3tD/Vls7/Hr6XzX/LtI4kk6e+iVPcyylo/2Y=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/552316855_1991338205081758_8803312413181357469_n.enc?ccb=11-4&oh=01_Q5Aa4wG79DRtMDRX-UZ8ZGRJqUx5_-Mp9CYbSGLaAKKD14m-Zw&oe=6A4DFD77&_nc_sid=5e03e0", "fileLength": {"low": 440827, "high": 0, "unsigned": true}, "fileSha256": "mpSHmifS+mTiNePeopBplmqbuNm+JumFNgYO6agc0Vc=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [20334, 114885, 148735, 156871], "scansSidecar": "2sswoDuCuHdOsgggWWlRT6iX1fy23aRHadX7avfjPvo9fdnFDMPWWg==", "fileEncSha256": "eJvSqNzCKq0Q4sPHWusoFBtnphQcnH9KQJvfrLRXf94=", "mediaKeyTimestamp": {"low": 1780916799, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}	unknown	1780917288	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00ter54djag2mgl1	{"id": "3BB54326A26EFB63C1F3", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "prnh dnger stacks dll kan, itu dah ga support d phantom mksdnya", "messageContextInfo": {"threadId": [], "messageSecret": "Gkgkl3Wj3xPfexVhOyp9ZF59d0+kb+e8VycbmDWVlAc="}}	\N	unknown	1780917127	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffp00tfr54dofqu5aq6	{"id": "3BC9A41974528092BA41", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "jadi yg simpan bitcoin aja ga bkalan berefek apa apa", "messageContextInfo": {"threadId": [], "messageSecret": "sZcHvgzATYBsuZANgnYPA8huzWsD5UyKBok5nvW4Ahg="}}	\N	unknown	1780917087	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tgr54do9zzas3y	{"id": "3B7BE2017BD13A65FD4E", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	protocolMessage	{"protocolMessage": {"key": {"id": "3B86C0B3FDEB4931C651", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "185486836560069@lid"}, "type": 14, "timestampMs": {"low": -1494276314, "high": 414, "unsigned": false}, "editedMessage": {"extendedTextMessage": {"text": "lagi maintenance sbntr aja vin bitcoinnya biar bsa beli d paradapp, nanti kalau dah bsa, aku kasi tau, terus utk announcement di phantom tu bukan bitcoinnya ga support lagi, jadi ga prlu ngapa ngapain, dia tu updatenya ga support utk layer 2 bitcoin yg kayak bsa pakai simpan nft dll", "contextInfo": {"stanzaId": "3A533C9BC4DF4E8C673F", "quotedType": 0, "participant": "253287190290663@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/564657395_27722352447383444_2038717316474633312_n.enc?ccb=11-4&oh=01_Q5Aa4wGvuTsDtZMrESzfF5ZsqCbY4RwC3J7fASCM81LLuWkAlQ&oe=6A4E1452&_nc_sid=5e03e0&mms3=true", "width": 1600, "height": 1200, "caption": "Mau tnya lgi, ni bitcoin di paradapp ad gangguan yaa jdi gk bisa beli? Sy udh connect semua wallet nya trus refresh tetap sama gk bisa beli", "mediaKey": "jzTHnrOoS6vvu6ouS4417C7qGbxo6BiMi9rzuNFkkLM=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/564657395_27722352447383444_2038717316474633312_n.enc?ccb=11-4&oh=01_Q5Aa4wGvuTsDtZMrESzfF5ZsqCbY4RwC3J7fASCM81LLuWkAlQ&oe=6A4E1452&_nc_sid=5e03e0", "fileLength": {"low": 298202, "high": 0, "unsigned": true}, "fileSha256": "w3qUpknhoIbCz0vqV2zKrCEiSrQNX2DngHVggKJcAh0=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [19813, 75875, 71070, 131442], "scansSidecar": "nImT881W7PeCt2ifdWhFSUkLMlL3EMLvDOoTu09XHHPDyUnRGhmuYw==", "fileEncSha256": "XXfgCFaIH+j+e5waFcBm71icQpRZK8FsR+jMHXoOR8I=", "mediaKeyTimestamp": {"low": 1780916830, "high": 0, "unsigned": false}, "interactiveAnnotations": []}}, "statusAttributions": []}, "previewType": 0, "endCardTiles": [], "inviteLinkGroupTypeV2": 0}}}, "messageContextInfo": {"threadId": [], "messageSecret": "a9qiYyvCCcUS/ADfZ6Ju0GUBLZqkpi+1YVKl58fp4W0="}}	\N	unknown	1780917074	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00thr54d1ksfdvpg	{"id": "3AA41360A718CC59CAA1", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQPuAJAS-N8d54v84RbHhnXYgz9M9GIOWvA1w4aN4fEpvIJCD6O90sWUG40q3EiZ_8fX8IYJuWhVFcwwYgwAmqKl0hMJSvJ_xeeZEfCdsQ?ccb=9-4&oh=01_Q5Aa4wFNbI44KXMrNFZTE7u-P4DazhEtGG1FBHJwkG4xxcKV1g&oe=6A4DFE35&_nc_sid=e6ed6c&mms3=true", "width": 739, "height": 1600, "caption": "Sama ini sy mau tnya yg di lingkaran ini ad update dri phantom, itu hruskah pindahin BTC yg sy hold ini atau gmna yaa? Mohon bantuannya gaess", "mediaKey": "2+8DYtivtFb9PcWlOgwaVlVISfkfWmwejMsVtPbqFUA=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQPuAJAS-N8d54v84RbHhnXYgz9M9GIOWvA1w4aN4fEpvIJCD6O90sWUG40q3EiZ_8fX8IYJuWhVFcwwYgwAmqKl0hMJSvJ_xeeZEfCdsQ?ccb=9-4&oh=01_Q5Aa4wFNbI44KXMrNFZTE7u-P4DazhEtGG1FBHJwkG4xxcKV1g&oe=6A4DFE35&_nc_sid=e6ed6c", "fileLength": {"low": 125101, "high": 0, "unsigned": true}, "fileSha256": "Nt5z52rR8JnM0MQatw2P0QTgAi9PqM7lvaaPVVXReaw=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [10694, 63891, 24872, 25642], "scansSidecar": "u3M/QFYl0jN4JqsZ7XXaC9XNuaMVp6+EvZ7Tkyu6MjmpI9/5gh6AQw==", "fileEncSha256": "7w0gu9ocGHGiT8edCnllTEAIcduxC3uq/2rTaSF0CmM=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780916977, "high": 0, "unsigned": false}, "midQualityFileSha256": "YNOPlaRYEiyI/CuG7i8d+kFVYejmG7C3jHnvfGUKhRg=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "SVyro6ntxYKDlIdZCCDZ2LatqoY2rWnLLA5NRLGOxhM="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	ios	1780916980	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tir54dtncgtims	{"id": "3A533C9BC4DF4E8C673F", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/564657395_27722352447383444_2038717316474633312_n.enc?ccb=11-4&oh=01_Q5Aa4wGvuTsDtZMrESzfF5ZsqCbY4RwC3J7fASCM81LLuWkAlQ&oe=6A4E1452&_nc_sid=5e03e0&mms3=true", "width": 1600, "height": 1200, "caption": "Mau tnya lgi, ni bitcoin di paradapp ad gangguan yaa jdi gk bisa beli? Sy udh connect semua wallet nya trus refresh tetap sama gk bisa beli", "mediaKey": "jzTHnrOoS6vvu6ouS4417C7qGbxo6BiMi9rzuNFkkLM=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/564657395_27722352447383444_2038717316474633312_n.enc?ccb=11-4&oh=01_Q5Aa4wGvuTsDtZMrESzfF5ZsqCbY4RwC3J7fASCM81LLuWkAlQ&oe=6A4E1452&_nc_sid=5e03e0", "fileLength": {"low": 298202, "high": 0, "unsigned": true}, "fileSha256": "w3qUpknhoIbCz0vqV2zKrCEiSrQNX2DngHVggKJcAh0=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [19813, 75875, 71070, 131442], "scansSidecar": "nImT881W7PeCt2ifdWhFSUkLMlL3EMLvDOoTu09XHHPDyUnRGhmuYw==", "fileEncSha256": "XXfgCFaIH+j+e5waFcBm71icQpRZK8FsR+jMHXoOR8I=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780916830, "high": 0, "unsigned": false}, "midQualityFileSha256": "CTKkRIrK5+4M3FI65FtV7e+wp52qVufIFjb8Eucd7f4=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "6/G/b1c39Hpj5xu1TALqwy6axaisUve9Bb7tMKj88CM="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	ios	1780916873	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tjr54dvuc1a35c	{"id": "3A001FE3CECDD51008C5", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/552316855_1991338205081758_8803312413181357469_n.enc?ccb=11-4&oh=01_Q5Aa4wG79DRtMDRX-UZ8ZGRJqUx5_-Mp9CYbSGLaAKKD14m-Zw&oe=6A4DFD77&_nc_sid=5e03e0&mms3=true", "width": 1200, "height": 1600, "caption": "Done Win, thanks 🤙🏽", "mediaKey": "RUWxDDL3tD/Vls7/Hr6XzX/LtI4kk6e+iVPcyylo/2Y=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/552316855_1991338205081758_8803312413181357469_n.enc?ccb=11-4&oh=01_Q5Aa4wG79DRtMDRX-UZ8ZGRJqUx5_-Mp9CYbSGLaAKKD14m-Zw&oe=6A4DFD77&_nc_sid=5e03e0", "fileLength": {"low": 440827, "high": 0, "unsigned": true}, "fileSha256": "mpSHmifS+mTiNePeopBplmqbuNm+JumFNgYO6agc0Vc=", "annotations": [], "contextInfo": {"stanzaId": "3BFA99E1B54B99135E0D", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Hello vin, iyaa bener pakai wallet address solana di phantom, tnggl connect aja"}, "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [20334, 114885, 148735, 156871], "scansSidecar": "2sswoDuCuHdOsgggWWlRT6iX1fy23aRHadX7avfjPvo9fdnFDMPWWg==", "fileEncSha256": "eJvSqNzCKq0Q4sPHWusoFBtnphQcnH9KQJvfrLRXf94=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780916799, "high": 0, "unsigned": false}, "midQualityFileSha256": "cr8uVuLaiq/+zDRlw96DkhK4KoXGslXfmgd48SUtWEA=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "1bk/Vo5kVnABg/k7nF247hAtqDOZgTaKnK6VJ2NqcAY="}}	{"stanzaId": "3BFA99E1B54B99135E0D", "quotedType": 0, "participant": "185486836560069@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Hello vin, iyaa bener pakai wallet address solana di phantom, tnggl connect aja"}, "pairedMediaType": 0, "statusAttributions": []}	ios	1780916822	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tkr54duqq5gze7	{"id": "3B6E2DC6965D0B46CAD4", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "pakai link ini enak sih bsa langsung ada guidencenya jadi smua step https://paradapp.com/en/buy-usdc", "messageContextInfo": {"threadId": [], "messageSecret": "7RIwVKgqVhVytZ0Xh7oUcT4cljgh+rkDwYf1GDPCBi4="}}	null	unknown	1780914135	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tlr54drggj9mzv	{"id": "3BFA99E1B54B99135E0D", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	185486836560069	\N	conversation	{"conversation": "Hello vin, iyaa bener pakai wallet address solana di phantom, tnggl connect aja", "messageContextInfo": {"threadId": [], "messageSecret": "MvoMzc4oB7DRuc5pn7ZnKFYxWyNIY3+xwoDJunYLD+4="}}	\N	unknown	1780913945	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tmr54dwnh7ikhv	{"id": "3AB0AAA31760FDFE5073", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Sore brader, mau tnya ni klo kita mau buy USDC di Paradapp itu wallet address nya yg dri phantom pke dri Solana yaa?", "messageContextInfo": {"threadId": [], "messageSecret": "ayALzgCbQu1tL2ui1JouCeUsXOij4z28ewlKQibw1fw="}}	\N	ios	1780913916	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tnr54d2dujx7fk	{"id": "3BA97052A05BEAE77646", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "DYMkgUw3pwkoetptSqRerUcNi/f57m629H627FDQjxM=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B4C596E32BB69DD8749", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQOzod9S3Pck0mCoy6Q5vbsyRiHFTSOABBtiuzTOdT2ghRZWMO0JE2rW-pfhkJU1uKBJRijDOFXYIQ-Jm0iaDCVyIC-UfpAUZnsoyg6yLQ?ccb=9-4&oh=01_Q5Aa4wGPYQPcyyL87g1czIcQFbV5uzrzJ75QfD_DMtdtGL6vMQ&oe=6A4CC962&_nc_sid=e6ed6c&mms3=true", "width": 4032, "height": 3024, "mediaKey": "D+lL3cBgccIWKOB6iYFRST6ouiiScKHqIgzrzupBqkY=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m234/AQOzod9S3Pck0mCoy6Q5vbsyRiHFTSOABBtiuzTOdT2ghRZWMO0JE2rW-pfhkJU1uKBJRijDOFXYIQ-Jm0iaDCVyIC-UfpAUZnsoyg6yLQ?ccb=9-4&oh=01_Q5Aa4wGPYQPcyyL87g1czIcQFbV5uzrzJ75QfD_DMtdtGL6vMQ&oe=6A4CC962&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 1246630, "high": 0, "unsigned": true}, "fileSha256": "aFlkRspVJPYdJPgKD1NqzCvTI1ndEcliHDW69fPBpiE=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [108029, 127896, 466163, 544540], "scansSidecar": "T0JAuoQNCHVr3w74nxkY5AS5uDiIuFpLsimWZASQi5zU0Lk+AbZeRQ==", "fileEncSha256": "UNJ4p34WlmerRPF0hzptMkg7XEDpnEDveCWORw3PPNg=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827628, "high": 0, "unsigned": false}, "midQualityFileSha256": "AMlWSuZh9pw4lZeOqcfw3MM7csFtf30yLOyq2MFguX8=", "interactiveAnnotations": []}}}}	\N	unknown	1780830247	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tor54dvf91x7gg	{"id": "3B3FFFB8D4C7D67D7626", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "vzW1Xe0vrQ/mex+5e9rs9LRZrIEosSy+02icC45J0zE=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B4E088DAA599E4186E8", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQPmR6qmquaJTGhGLWAKkvmsswIx1vEDLhGmfYAZMVEuT6J0__5mCkGbe7WTduOAfxFrlcaziJEHndlkkzlEsmdvlfVaTdHe2ccaJIGTzA?ccb=9-4&oh=01_Q5Aa4wHb3YbuAg7VjZg21n0stWRIkZdabt0lh2LanyD0UpRG_Q&oe=6A4CA440&_nc_sid=e6ed6c&mms3=true", "width": 3024, "height": 4032, "mediaKey": "gqjNrxSOYN6uLkLzDWGxUKGyN5YQsbJJLBXwUjBNl0o=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQPmR6qmquaJTGhGLWAKkvmsswIx1vEDLhGmfYAZMVEuT6J0__5mCkGbe7WTduOAfxFrlcaziJEHndlkkzlEsmdvlfVaTdHe2ccaJIGTzA?ccb=9-4&oh=01_Q5Aa4wHb3YbuAg7VjZg21n0stWRIkZdabt0lh2LanyD0UpRG_Q&oe=6A4CA440&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 1142837, "high": 0, "unsigned": true}, "fileSha256": "ESG3tF4XdOhfg1C/2JnNv0v0EQVo4fSw+77UZjBWNjU=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [101435, 114206, 419085, 508109], "scansSidecar": "wKGbtCYX/WJLXU7PS0rAzNX595bt5wjt8tbt8ONZljtnG3GQiZcgRg==", "fileEncSha256": "wI0mEmSDdduKW0juHDV8iy7sTYCMhQfhe+HY3nrcE0Q=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827629, "high": 0, "unsigned": false}, "midQualityFileSha256": "SBQ2puFuJq4L+j/qDDp4FUt74vW7UiaFhJ/lo9kptSI=", "interactiveAnnotations": []}}}}	\N	unknown	1780830247	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tpr54dd42jjb4m	{"id": "3B8F78B652B9EAE24F23", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "pWXeHSge3fwcH/HymXPtBnSKI8n4lpqhjnTVX1KRoJw=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B6540FBFF2FC82EBD0A", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQNVfoZvwavoKTxj0D2GDwbAz35gpxHbxj_Q9gDrAxlyABR67pZE6rusiw2fuyeZCRi59rgkh-mA-yW64FTpULwhWfWSJT9JBvu7C1cjnQ?ccb=9-4&oh=01_Q5Aa4wHm8KjunaXZuji3IfpE38JzDcxqPAlIMJ6BJK8ml97Sxw&oe=6A4C9C7C&_nc_sid=e6ed6c&mms3=true", "width": 3024, "height": 4032, "mediaKey": "QCSTC0QfD6jQz/P/WuxJU8IpB0rLH9kj7gpIfrDpIgg=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m238/AQNVfoZvwavoKTxj0D2GDwbAz35gpxHbxj_Q9gDrAxlyABR67pZE6rusiw2fuyeZCRi59rgkh-mA-yW64FTpULwhWfWSJT9JBvu7C1cjnQ?ccb=9-4&oh=01_Q5Aa4wHm8KjunaXZuji3IfpE38JzDcxqPAlIMJ6BJK8ml97Sxw&oe=6A4C9C7C&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 1103096, "high": 0, "unsigned": true}, "fileSha256": "Q82AJ+a0KPgDc0j39335ueTDQOltuPKFp5AgMGWPDus=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [99988, 111873, 403295, 487938], "scansSidecar": "TxysXDeaqR9yxp0zagoFiTGGGQ5Ei2CfG5eQgQw8gf7Vi7lUU9JCrA==", "fileEncSha256": "YgjAi+9iJIgOso5tgW69dTzttVoyziW+QvTx4Vn3qmQ=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827629, "high": 0, "unsigned": false}, "midQualityFileSha256": "WP6MF7EqKjdb0HQYowEM35I1obGntCnqw3DGqwTsGzw=", "interactiveAnnotations": []}}}}	\N	unknown	1780830246	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tqr54dfd0d6f6n	{"id": "3B5B2A34F3A2BE436068", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "p5h3mCqp+1AUAK61Qa8TX4iaPYiNV/AB6tXPyKyyA7I=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B9D02062893AA167EA8", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQNtA4YEICavu7FGCcIv3AJxA0glDGCw4uSY2Ybl8AJ_A-AEPKvZ7OSGaJrBlq2XARz8ybDhE6F8hO8zr9nQ5qtg5SvqVIfxtc1A23nXtw?ccb=9-4&oh=01_Q5Aa4wHUEU0NhH4PccwnHiCUsFVv1jSlDcZS5cL7hzeG5OADQg&oe=6A4CCCC8&_nc_sid=e6ed6c&mms3=true", "width": 4032, "height": 3024, "mediaKey": "XikBhxeuAqCN4ev1KWjl9wRZVDljxj8kU/oc3lGz2u4=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQNtA4YEICavu7FGCcIv3AJxA0glDGCw4uSY2Ybl8AJ_A-AEPKvZ7OSGaJrBlq2XARz8ybDhE6F8hO8zr9nQ5qtg5SvqVIfxtc1A23nXtw?ccb=9-4&oh=01_Q5Aa4wHUEU0NhH4PccwnHiCUsFVv1jSlDcZS5cL7hzeG5OADQg&oe=6A4CCCC8&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 1270828, "high": 0, "unsigned": true}, "fileSha256": "TBS8kZ05OxafP0xmVlyAcph1L8Hl77GzGv8kDwZaQqc=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [107777, 128429, 474437, 560183], "scansSidecar": "efNXd9L7YBTKLIcbPT140hGRmuYa1U5o+l9vqticUz8e31fJzekmOw==", "fileEncSha256": "btKyJiGa7BFHIZeQyNcysLUYrLCfJXbdH7W3CYUyQFE=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827628, "high": 0, "unsigned": false}, "midQualityFileSha256": "Q8KfNxx6Qp1doVWWzBKZPDQiPl8uqJOvDU6Ap1GpWRg=", "interactiveAnnotations": []}}}}	\N	unknown	1780830246	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00trr54dl7d26sg0	{"id": "3B2FC880ED8A1C5C0B36", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	associatedChildMessage	{"messageContextInfo": {"threadId": [], "messageSecret": "RF99aQRQ7otWmZBy5862Qz5pEoiFtOZYHc9QCOAqHPA=", "messageAssociation": {"associationType": 10, "parentMessageKey": {"id": "3B9463BCE738E6A71F98", "fromMe": false, "remoteJid": "120363417652295399@g.us", "participant": "167929614229740@lid"}}}, "associatedChildMessage": {"message": {"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMKCI_xMFR7L-GCcjHa48utDl4wrP40gVKrlUWnamrxtccKcwAWoMAx6k96-F_3kmq8YAzHgc5ug-gsmdPqT-pqLEaXk7cC-JcIfzzobg?ccb=9-4&oh=01_Q5Aa4wHuqaBwx5fY_ixnX0YAwAFehHCJ5Ipz79NH_e9eU02JAg&oe=6A4CB8C8&_nc_sid=e6ed6c&mms3=true", "width": 3024, "height": 4032, "mediaKey": "BEA2DWHl4cRZMyx6gMigmAKHH4cjZmcwUwQ+FXumWVc=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQMKCI_xMFR7L-GCcjHa48utDl4wrP40gVKrlUWnamrxtccKcwAWoMAx6k96-F_3kmq8YAzHgc5ug-gsmdPqT-pqLEaXk7cC-JcIfzzobg?ccb=9-4&oh=01_Q5Aa4wHuqaBwx5fY_ixnX0YAwAFehHCJ5Ipz79NH_e9eU02JAg&oe=6A4CB8C8&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 1123895, "high": 0, "unsigned": true}, "fileSha256": "DfxLJ0e579hR+pZBMuqlwhV77dpPmtNfrTDTlgX8+To=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 4, "statusAttributions": []}, "scanLengths": [101619, 113898, 411782, 496594], "scansSidecar": "tHWKJvqZFi2NqH+Sc65MudQwPEw9bYsIBqno1i/VqMRcO1cI/bUcgA==", "fileEncSha256": "yi+fWW1mGm9ioC00TPpMqNY8RF5Qui6pcSQqRY8pUEs=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827630, "high": 0, "unsigned": false}, "midQualityFileSha256": "NJGlm0RuuTpeJsCKY5VxkXyk/8QgxuDZnEERIMpx0rQ=", "interactiveAnnotations": []}}}}	\N	unknown	1780830245	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffq00tsr54dbdoov4kf	{"id": "3B4C596E32BB69DD8749", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQMKBH_d2qFcNal4FvX58TeCfO7WvAYvMDdwo6_ZL4u4CnYORH4mJg3ktyqvWGLxubMiOaIU0KR3shdJerkNSF8um0hqpPGtWt0MYUSMTg?ccb=9-4&oh=01_Q5Aa4wEpNcvm0sJh6vEe7QqFLhn6_uOlMk_0q_d2NdWm1WGH7w&oe=6A4CB0E8&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 960, "mediaKey": "SP0wvEpsDYQ7qdNVL85SJLasko1QA21C471pzwxBZq0=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m235/AQMKBH_d2qFcNal4FvX58TeCfO7WvAYvMDdwo6_ZL4u4CnYORH4mJg3ktyqvWGLxubMiOaIU0KR3shdJerkNSF8um0hqpPGtWt0MYUSMTg?ccb=9-4&oh=01_Q5Aa4wEpNcvm0sJh6vEe7QqFLhn6_uOlMk_0q_d2NdWm1WGH7w&oe=6A4CB0E8&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 173200, "high": 0, "unsigned": true}, "fileSha256": "BX2hfjMva0Y2OGbKNN78zuxf95LqB45kglaWhFoVGHo=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [13596, 59631, 36281, 63690], "scansSidecar": "7oEWHw0VOxZjYlGu1jGC5x2XI03ZV8SGZ1tZogCwwkZfoC2cZx8uow==", "fileEncSha256": "hL3NyqtGqsGJSaNyp7Z851dFz6zKwmQAknQ1O2vZ0yk=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827625, "high": 0, "unsigned": false}, "midQualityFileSha256": "gozYKRQZ/hqK0X8MXqSIsBEr8HBbE9pwzlLnDdMV7CA=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "7KV69+f5uBP/oz48Xgn/4r6TUV7a7aW9NEfl87pCt1s="}}	{"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}	unknown	1780830245	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00ttr54dsxq751uk	{"id": "3B4E088DAA599E4186E8", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQM4Fz3fDN8vE8Gijkll95ykFImV4WMCQFXzGzfG6MwSduF6Lyk-tVF0jq8J8XXWjHX7kBPdcfzArOnJz4hUOhcJOIIoIB9X7-10sYrEfQ?ccb=9-4&oh=01_Q5Aa4wF2Z_PYTvMFn1snVAga1RD5KaOoY1rCA13OnDkqu4Fm7A&oe=6A4CC6A7&_nc_sid=e6ed6c&mms3=true", "width": 960, "height": 1280, "mediaKey": "ef5JFauNnXUpj+wxNVsHDnAd0MNCihqmoo19RFBm0t4=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m234/AQM4Fz3fDN8vE8Gijkll95ykFImV4WMCQFXzGzfG6MwSduF6Lyk-tVF0jq8J8XXWjHX7kBPdcfzArOnJz4hUOhcJOIIoIB9X7-10sYrEfQ?ccb=9-4&oh=01_Q5Aa4wF2Z_PYTvMFn1snVAga1RD5KaOoY1rCA13OnDkqu4Fm7A&oe=6A4CC6A7&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 155989, "high": 0, "unsigned": true}, "fileSha256": "H5ncZxOafmQnFN50q7UDI+oXs9xvO6gQrwGpIO6hmG0=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [12945, 54571, 31511, 56960], "scansSidecar": "kDieLZdI0PLCms2crD2Krc0a4Kkr/5TwOKSfsfS/dXzfhDZlCYrBzg==", "fileEncSha256": "MIdS/SFuPJVaaHmvPYW0MxlVXSAQAn0UUgeyW/bgheE=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827625, "high": 0, "unsigned": false}, "midQualityFileSha256": "XMO8fJJBG7cskS8saZQ7RuJQEHSC/xWhaSJaPS/wOCw=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "ArlZbpdAEanSdLlmGkgNj6xI+bV+EpZ0u1VGddkF0wQ="}}	{"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}	unknown	1780830245	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00tur54d1z959rtv	{"id": "3B6540FBFF2FC82EBD0A", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMqKpmgQoVf1tCYQGf8n2G_LtNsxY2T3d2v1i9UD08Tg_s1WTaKy8SbK_3oLDBVJCy6wWkKpWDHjColyUNe3xTCH-IYDWv01SKH878bqQ?ccb=9-4&oh=01_Q5Aa4wFaDX8IIMVpnimHJpZ1snqysra43jSq5ATZ6d7gk6jUfw&oe=6A4CBA73&_nc_sid=e6ed6c&mms3=true", "width": 960, "height": 1280, "mediaKey": "EuHVzG2jQz6VcUUZZs0TnhBsiI98jFdyaxI0OGzMUGU=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQMqKpmgQoVf1tCYQGf8n2G_LtNsxY2T3d2v1i9UD08Tg_s1WTaKy8SbK_3oLDBVJCy6wWkKpWDHjColyUNe3xTCH-IYDWv01SKH878bqQ?ccb=9-4&oh=01_Q5Aa4wFaDX8IIMVpnimHJpZ1snqysra43jSq5ATZ6d7gk6jUfw&oe=6A4CBA73&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 153125, "high": 0, "unsigned": true}, "fileSha256": "GMcS3vhFVgVxMnKAQrhjn6yMncVS7mi0Qt5HKHqJDIc=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [12871, 53235, 30781, 56236], "scansSidecar": "mSI5RIZdogLRVehf25C5IpNMYRxCogE9EvixgblQRdCnpQ9DON+l7g==", "fileEncSha256": "PDCcnt0SY+VcCcNB/vxYnlv44cEUlNu8vP8lv3FqBQ8=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827625, "high": 0, "unsigned": false}, "midQualityFileSha256": "MpUwnObKeNkcr1R7kAMDpGeRPQDJEYEZ4nOwoDriupk=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "n+xxbOMfiwyVAhrzGL/9zic5li8Q+lQb8pjmkMDQneU="}}	{"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}	unknown	1780830244	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00tvr54dqj17cfh4	{"id": "3B9D02062893AA167EA8", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQOYC3vMBtQ0HEluj1B7jgaLh2NlhsAB_ayV_bWHR0HpiceFKMpwsgEOPdjoXKqe7IxV8qM3g8O1vjZcQmyLe1EqwBsbw8ixRNKQ4jqAtA?ccb=9-4&oh=01_Q5Aa4wFutGSjBHjg21DLiulex_686VjxT8nb1ZZV0lqc_GLqBw&oe=6A4CC4B3&_nc_sid=e6ed6c&mms3=true", "width": 1280, "height": 960, "mediaKey": "eKDTnzEvHxKewiR9QFcYgIGxpqIPrIjAXLUH/xs7aE4=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQOYC3vMBtQ0HEluj1B7jgaLh2NlhsAB_ayV_bWHR0HpiceFKMpwsgEOPdjoXKqe7IxV8qM3g8O1vjZcQmyLe1EqwBsbw8ixRNKQ4jqAtA?ccb=9-4&oh=01_Q5Aa4wFutGSjBHjg21DLiulex_686VjxT8nb1ZZV0lqc_GLqBw&oe=6A4CC4B3&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 173599, "high": 0, "unsigned": true}, "fileSha256": "a/XzIMNmwyzK/BYJ8YyCpdTMDXoM6Ude93M4o/qkSFc=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [13468, 59344, 36344, 64441], "scansSidecar": "TJKl9Ni3yr0565xfJhH7nmNwlCQAjgB382xs+N2uWbRdkUjJECVt6g==", "fileEncSha256": "IoQzBZFIJm/ApIsJjshnsXaC/NtMky1Xe6CvbUpLkZo=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827625, "high": 0, "unsigned": false}, "midQualityFileSha256": "JgPzh8UQslxf0XdR3NEzh/iM3nvXcPD+6vIWU5WI/aM=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "tfTo+pqqVkF9/v2y04Tg5S6qm2KeEOc+G4bEmEg/hmQ="}}	{"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}	unknown	1780830244	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00twr54djfdg86hp	{"id": "3B9463BCE738E6A71F98", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQM8xNzFJMUUdmDWFQcKB4dBvrLQc2Jc4741wdxwWt1W6RZudbc3vIgZ7OQQ4ba-u0UiHubc4DXqVSuYJ81hexofkWtH9UXV-5B0_BRC_g?ccb=9-4&oh=01_Q5Aa4wEmlOOxq7-htL_pfoqlGr53AbR-Cz3OwOZ9f0GO09gWmQ&oe=6A4CCD73&_nc_sid=e6ed6c&mms3=true", "width": 960, "height": 1280, "mediaKey": "VF4mrnDA+CMs7qxVjxhckOm/218JgkN1MtJbK9+MYUU=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m234/AQM8xNzFJMUUdmDWFQcKB4dBvrLQc2Jc4741wdxwWt1W6RZudbc3vIgZ7OQQ4ba-u0UiHubc4DXqVSuYJ81hexofkWtH9UXV-5B0_BRC_g?ccb=9-4&oh=01_Q5Aa4wEmlOOxq7-htL_pfoqlGr53AbR-Cz3OwOZ9f0GO09gWmQ&oe=6A4CCD73&_nc_sid=e6ed6c&_nc_hot=1780830242", "fileLength": {"low": 156289, "high": 0, "unsigned": true}, "fileSha256": "U+of3nuogClBG4wy71SmBUlDF6Zy3L0Owi8VOqoGNpI=", "annotations": [], "contextInfo": {"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}, "scanLengths": [12989, 54851, 31570, 56877], "scansSidecar": "tSdxKp74o2/fp51e+XwcdhpstNQbsUMSpL37XpHfjoL6Z4JG159pYA==", "fileEncSha256": "yz/Aha2GMBWeXInuU+YBS+RGIoOnB6JPeNImwV6ZWn0=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780827625, "high": 0, "unsigned": false}, "midQualityFileSha256": "H9t27n8VtHkCqPJ95m+j05k19g9+zLhq0vUyF2JGnQA=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "XKOq58hrMEBhA+PCWylc5Fg3VrRb/27UwLOPdKpxevU="}}	{"isForwarded": true, "mentionedJid": [], "forwardOrigin": 0, "groupMentions": [], "forwardingScore": 1, "pairedMediaType": 3, "statusAttributions": []}	unknown	1780830243	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00txr54dqq2wa29i	{"id": "AC8F78C6A3DC5A7F1C9325963CB771FD", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	266266531090456	\N	conversation	{"conversation": "Keren👍", "messageContextInfo": {"threadId": [], "messageSecret": "cjpeY7dgeBfxDasw4JCriirZk1GvWGSaPGt+iWTAi/c="}}	{"stanzaId": "AC3B2DA1A2BA4EA4F1FF083078FED921", "quotedType": 0, "participant": "112395133432025@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/666041787_2124526084785676_8749243534176923180_n.enc?ccb=11-4&oh=01_Q5Aa4wGSed2eFgVlNhwrHDHb_MHTvbEdaCHz2Y6lX_zpm6rhUg&oe=6A4CB3D1&_nc_sid=5e03e0&mms3=true", "caption": "Materi ParaHub", "fileName": "ParaHub.pdf", "mediaKey": "roGd02dMrhfi443Xt4pKjeu0DX999jbvREFYTbVGWZw=", "mimetype": "application/pdf", "pageCount": 31, "directPath": "/v/t62.7119-24/666041787_2124526084785676_8749243534176923180_n.enc?ccb=11-4&oh=01_Q5Aa4wGSed2eFgVlNhwrHDHb_MHTvbEdaCHz2Y6lX_zpm6rhUg&oe=6A4CB3D1&_nc_sid=5e03e0", "fileLength": {"low": 10579722, "high": 0, "unsigned": true}, "fileSha256": "nOC1PZ23a04GKdEC/ginVsmqfCxssS8QMPRQSoqxkfA=", "fileEncSha256": "tPhniXxEWyBBzFDLwaV0TMDvrISsYCQ1Ir3S2+wMTns=", "mediaKeyTimestamp": {"low": 1780811813, "high": 0, "unsigned": false}}}, "statusAttributions": []}	android	1780824838	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00tyr54dzyd3o5t2	{"id": "AC3B2DA1A2BA4EA4F1FF083078FED921", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	112395133432025	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/666041787_2124526084785676_8749243534176923180_n.enc?ccb=11-4&oh=01_Q5Aa4wGSed2eFgVlNhwrHDHb_MHTvbEdaCHz2Y6lX_zpm6rhUg&oe=6A4CB3D1&_nc_sid=5e03e0&mms3=true", "caption": "Materi ParaHub", "fileName": "ParaHub.pdf", "mediaKey": "roGd02dMrhfi443Xt4pKjeu0DX999jbvREFYTbVGWZw=", "mimetype": "application/pdf", "pageCount": 31, "directPath": "/v/t62.7119-24/666041787_2124526084785676_8749243534176923180_n.enc?ccb=11-4&oh=01_Q5Aa4wGSed2eFgVlNhwrHDHb_MHTvbEdaCHz2Y6lX_zpm6rhUg&oe=6A4CB3D1&_nc_sid=5e03e0", "fileLength": {"low": 10579722, "high": 0, "unsigned": true}, "fileSha256": "nOC1PZ23a04GKdEC/ginVsmqfCxssS8QMPRQSoqxkfA=", "fileEncSha256": "tPhniXxEWyBBzFDLwaV0TMDvrISsYCQ1Ir3S2+wMTns=", "thumbnailWidth": 480, "thumbnailHeight": 270, "thumbnailSha256": "SdVS96SdzMSgdH2O3D8/qOyE6K1v44F0eSbrv/pjKfk=", "mediaKeyTimestamp": {"low": 1780811813, "high": 0, "unsigned": false}, "thumbnailEncSha256": "n+tgMgcVg+LATTkQEc1bHT4h5sLY//x2Mji3wnTFsWI=", "thumbnailDirectPath": "/v/t62.36145-24/717192809_1307040261104488_398137453712554170_n.enc?ccb=11-4&oh=01_Q5Aa4wFZ-X8rjmYy2dUgTrE6ds2pZjfYS0Ft8K-j2i1Mr35Ezg&oe=6A4CB505&_nc_sid=5e03e0"}, "messageContextInfo": {"threadId": [], "messageSecret": "mLfpnV1+2Ex/LCSZvRi6rG/E5/+jVIOYybNHwFVsmS8="}}	null	android	1780823243	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00tzr54dkqblif9b	{"id": "3BB5684A965577DB2956", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	imageMessage	{"imageMessage": {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQNsgKKQERhr1mPEwguShka6dNP86b1gk4bZnv44qFjrXlhupMPNQXLcyGEsei9fY1e5Zy89tFPY1wiDgEPiWnL2FAQRQSufsczM6El73A?ccb=9-4&oh=01_Q5Aa4wEeti79xGWueCyAb0l68JKzKEiIi-RAFmU_gglYIEtUng&oe=6A4C985E&_nc_sid=e6ed6c&mms3=true", "width": 960, "height": 1280, "caption": "Guys.. Lokasi kita ada di lt 2 gedung bagian ini yaa 🙌", "mediaKey": "QJ22xhT+BAfusHPTBEu7KxQTBQytxnqRxPb/bCU1kxo=", "mimetype": "image/jpeg", "directPath": "/o1/v/t24/f2/m269/AQNsgKKQERhr1mPEwguShka6dNP86b1gk4bZnv44qFjrXlhupMPNQXLcyGEsei9fY1e5Zy89tFPY1wiDgEPiWnL2FAQRQSufsczM6El73A?ccb=9-4&oh=01_Q5Aa4wEeti79xGWueCyAb0l68JKzKEiIi-RAFmU_gglYIEtUng&oe=6A4C985E&_nc_sid=e6ed6c&_nc_hot=1780816136", "fileLength": {"low": 173093, "high": 0, "unsigned": true}, "fileSha256": "sjF/wAoEsYOCEhi/xyFUr2R4HfMZj4482rFxKb4wI4A=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}, "scanLengths": [14551, 67960, 49216, 41364], "scansSidecar": "PjeVtpFv7YLp4APS9wygK3vdW4e12OLHW55lmScbi/suQIbvovzC7Q==", "fileEncSha256": "K35TaWnuvcWppX5LEJiKFzvhqXqu5DeTMzsmtD3Misk=", "imageSourceType": 0, "mediaKeyTimestamp": {"low": 1780816006, "high": 0, "unsigned": false}, "accessibilityLabel": "Lokasi lt 2 sini. Naik lantai 2 \\nLetwat sini", "midQualityFileSha256": "REPmPo+ul1w2D7nJCWH8o8zD2yPTNQwCaaw53KmU4qM=", "interactiveAnnotations": []}, "messageContextInfo": {"threadId": [], "messageSecret": "RCSzKAeuaJPer6rV3t48D7EMfIzOpnGmM3SkZZTX6t4="}}	{"mentionedJid": [], "groupMentions": [], "pairedMediaType": 0, "statusAttributions": []}	unknown	1780816137	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u0r54dp7egylpk	{"id": "3ADE6446EF77457963AD", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	253287190290663	\N	conversation	{"conversation": "Gasss ready🚀", "messageContextInfo": {"threadId": [], "messageSecret": "GtDB30Q3qCRLN+RVYnR7O8npEwhsPCjsbTHUTwBrTGM="}}	{"stanzaId": "3BE6E6B7E8D51ED69D52", "quotedType": 0, "participant": "167929614229740@lid", "mentionedJid": [], "groupMentions": [], "quotedMessage": {"conversation": "Hello Guys.. ready for this meet up?"}, "statusAttributions": []}	ios	1780813474	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u1r54d749o6vfc	{"id": "3B241115E9307F00C56B", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	conversation	{"conversation": "kita update info lanjut nanti yaa.. see you there 🙌", "messageContextInfo": {"threadId": [], "messageSecret": "LpbC2idfedXIRFdDHLXQuqanEXAnxdrBtgcF2zX03ps="}}	\N	unknown	1780808074	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u2r54d49ipgb3j	{"id": "3BE6E6B7E8D51ED69D52", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	conversation	{"conversation": "Hello Guys.. ready for this meet up?", "messageContextInfo": {"threadId": [], "messageSecret": "Ky5klsjfssNtVXws1KiTeYLv+SgNCUsQtpJUDGdX8qo="}}	\N	unknown	1780808007	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u3r54da0lhtxeu	{"id": "3BF74A962DCF00DF51A6", "fromMe": false, "remoteJid": "120363417652295399@g.us"}	167929614229740	\N	conversation	{"conversation": "Halo Temen-temen! 👋\\nKita adain meet up seru minggu ini nih!! 🥂\\n\\nYang lagi free, sekalian pengen nongki” gabung yaa\\n\\n*Agenda Kita:*\\n- Discuss & Sharing: Kita bakal ngobrol santai tentang dasar blockchain dan kenapa teknologi desentralisasi ini jadi penting banget di era digital.\\n- ⁠Networking & QnA: Buat kalian yang mau memperluas jaringan atau punya pertanyaan yang selama ini belum terjawab tentang blockchain, bisa langsung datang dan kita bahas bareng yaa!\\n\\n\\n*SAVE THE DATE!*\\n> 📅 7 Juni 2026\\n> ⏰ 16.00 – 18.00 WITA\\n> 📍 Kopi Zeen, Badung\\n\\n*Register Slot Here ⬇︎*\\nhttps://luma.com/b3859fnz", "messageContextInfo": {"threadId": [], "messageSecret": "Lt5ftlt5zoVFOlBMgeVyhKz6Jn/tngTElT398m98ElI="}}	null	unknown	1780319208	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u4r54dsvv64399	{"id": "AC8D5A1ECFE69DAB698B784394F4920E", "fromMe": false, "remoteJid": "276183644156050@lid"}	276183644156050	\N	conversation	{"conversation": "Lince", "messageContextInfo": {"threadId": [], "messageSecret": "LPVmooOMHbg68j//CbfTtaopEcsKJlplGPdHAL3hHxg="}}	\N	android	1780457518	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u5r54dob7u88hc	{"id": "AC12A069EF709F49ADE4402DF068E044", "fromMe": false, "remoteJid": "276183644156050@lid"}	276183644156050	\N	conversation	{"conversation": "Tamo minta norek \\nIni dgan lknce", "messageContextInfo": {"threadId": [], "messageSecret": "rz2jdFm8jtZd72GJ3vKc0gSOyLCmI9t7M148yJCy470="}}	\N	android	1780457516	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnw5ffr00u6r54d3wpcmrw4	{"id": "A5D62883021546B310BA6A60C7132525", "fromMe": true, "remoteJid": "276183644156050@lid"}	Você	\N	conversation	{"conversation": "Mohon maaf, ini siapa ya?", "messageContextInfo": {"threadId": [], "messageSecret": "LByGMUSbjkbXemtfylDp2Z+42qbj34Ce8Z7Jqz4smWo="}}	\N	android	1779711952	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqnw5ffs00u7r54dncwldxxu	{"id": "AC492B38AE685DE1E934FB5F51B0F490", "fromMe": false, "remoteJid": "276183644156050@lid"}	276183644156050	\N	conversation	{"conversation": "P", "messageContextInfo": {"threadId": [], "messageSecret": "Ls4JejkwHzaeMXKU8iJp6VslbKq6B9p7XSChrEc4nTo="}}	\N	android	1779711903	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmqnwcser00uer54d9ljent20	{"id": "3EB0556F7245E625B84CC1", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/613014737_1023664516668821_9180289090608776506_n.enc?ccb=11-4&oh=01_Q5Aa4wFZHCNkZQI-JLabEoFa4z1Y0xsRV7Pl3B9wtzBqUgtRUA&oe=6A5F6C84&_nc_sid=5e03e0&mms3=true", "caption": "Production cluster fully operational! 🎉", "fileName": "ParaHub_Materi.pdf", "mediaKey": "9WO8+0jCvNkA+K7zHhcd1DSJJQjKNw09F1RG2CmW5/g=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/613014737_1023664516668821_9180289090608776506_n.enc?ccb=11-4&oh=01_Q5Aa4wFZHCNkZQI-JLabEoFa4z1Y0xsRV7Pl3B9wtzBqUgtRUA&oe=6A5F6C84&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781880215, "high": 0, "unsigned": false}}, "fileEncSha256": "D0EQt3azFk3uGn542/TzSTp/nw9c85yQEFBhC2C8HkA=", "mediaKeyTimestamp": {"low": 1782053014, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781880215, "high": 0, "unsigned": false}}	web	1782053015	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqnx8kgk00ukr54dvmf4p0l8	{"id": "3EB0D557132F80C5615999", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/564520364_1940973059919986_6373582246104580709_n.enc?ccb=11-4&oh=01_Q5Aa4wFRvEEo8Rik3hK5k_8_d9jDseNOdjHiviFKJl3UNYlp6Q&oe=6A5F7AFE&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "ParaHub_Materi.pdf", "mediaKey": "s4bULfQkpFJ/zSstZhfCN5It3QIgSBEFGDJZtjWg1XI=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/564520364_1940973059919986_6373582246104580709_n.enc?ccb=11-4&oh=01_Q5Aa4wFRvEEo8Rik3hK5k_8_d9jDseNOdjHiviFKJl3UNYlp6Q&oe=6A5F7AFE&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781881698, "high": 0, "unsigned": false}}, "fileEncSha256": "3OZb2M1ylOqxibMsDIENYl/bKav6Vm7aH52MNsJTpLI=", "mediaKeyTimestamp": {"low": 1782054498, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781881698, "high": 0, "unsigned": false}}	web	1782054498	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqnxeogp00utr54dmzlho5at	{"id": "3EB0A67380DF0E055D91F9", "fromMe": true, "remoteJid": "6285117722465@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/726934328_854200660663077_3058352438482880468_n.enc?ccb=11-4&oh=01_Q5Aa4wFS2wKnXx7oKk1EI5jRKh2oYr1UGGnCB5euPxHt_Ils9g&oe=6A5F639C&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "ParaHub_Materi.pdf", "mediaKey": "qrcqcK6PRg7PU/fHcj+rAByoGvFUUAftFmbg9MFI7XY=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/726934328_854200660663077_3058352438482880468_n.enc?ccb=11-4&oh=01_Q5Aa4wFS2wKnXx7oKk1EI5jRKh2oYr1UGGnCB5euPxHt_Ils9g&oe=6A5F639C&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781881983, "high": 0, "unsigned": false}}, "fileEncSha256": "dug5ncPASWeklRpGkrOTu+vmOvp3uIPxJPakCgGgU6E=", "mediaKeyTimestamp": {"low": 1782054782, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781881983, "high": 0, "unsigned": false}}	web	1782054783	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqnxkyrh00uzr54d0b6huwvs	{"id": "3EB0CDD3A525BE5DF39B2F", "fromMe": true, "remoteJid": "6287860202653@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/597702202_2205163756996819_480603665338273542_n.enc?ccb=11-4&oh=01_Q5Aa4wHVZ_6fqxh_nHRv6SoB1jTHlyObzMAV_KJ49sxWQiykjA&oe=6A5F74E5&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "ParaHub_Materi.pdf", "mediaKey": "sKfKGdnOkCpLFWtpaie3gpxt/yqqW602yj3shhfW0ZU=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/597702202_2205163756996819_480603665338273542_n.enc?ccb=11-4&oh=01_Q5Aa4wHVZ_6fqxh_nHRv6SoB1jTHlyObzMAV_KJ49sxWQiykjA&oe=6A5F74E5&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781882276, "high": 0, "unsigned": false}}, "fileEncSha256": "u4uPuH1rILOui+8pCKb3rFw9ZlxVM1Af9QyvMLSROik=", "mediaKeyTimestamp": {"low": 1782055075, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781882276, "high": 0, "unsigned": false}}	web	1782055076	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqnxy8x800v7r54d484fnl57	{"id": "3EB090C7C1ACB736037DEE", "fromMe": true, "remoteJid": "6282247973243@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/670775447_1711014643425236_1587467834795752685_n.enc?ccb=11-4&oh=01_Q5Aa4wES94lM2hbYDUG8NCXJlDlNIvOhWBoyCBSfQ5wBDFlVPQ&oe=6A5F7C1F&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "ParaHub_Materi.pdf", "mediaKey": "dF+VN+LORJXKdfC50CNh0Nf2sTCJ1AxJDp5ZdX9ve4c=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/670775447_1711014643425236_1587467834795752685_n.enc?ccb=11-4&oh=01_Q5Aa4wES94lM2hbYDUG8NCXJlDlNIvOhWBoyCBSfQ5wBDFlVPQ&oe=6A5F7C1F&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781882895, "high": 0, "unsigned": false}}, "fileEncSha256": "EIK7HaEOPIrUtQ0gNKT9JMoG440GnnsTJKetSpGh/Ss=", "mediaKeyTimestamp": {"low": 1782055695, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781882895, "high": 0, "unsigned": false}}	web	1782055695	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqp3j7ff00vwr54dh73o1ncu	{"id": "3EB0515E5A748370064AF3", "fromMe": true, "remoteJid": "6285738102839@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/668786286_1521994759415603_2988346250899270619_n.enc?ccb=11-4&oh=01_Q5Aa4wF-OsD_Kb2F7kCDPUkthKuIVntsRJ-nhA7tLEcgaOIltA&oe=6A608C2F&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "ParaHub_Materi.pdf", "mediaKey": "KWXfycG7iDm1dBOq9W01cu1soYzOyQ6k2BSNvDbiOgU=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/668786286_1521994759415603_2988346250899270619_n.enc?ccb=11-4&oh=01_Q5Aa4wF-OsD_Kb2F7kCDPUkthKuIVntsRJ-nhA7tLEcgaOIltA&oe=6A608C2F&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781952737, "high": 0, "unsigned": false}}, "fileEncSha256": "ZXwZ/qjUONMgciVO7w1BvOZhhisT/9/wVMb7EQtOzEI=", "mediaKeyTimestamp": {"low": 1782125537, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1781952737, "high": 0, "unsigned": false}}	web	1782125537	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqdyo2w00wmr54dpvdpc4w2	{"id": "3EB0A96821F2D4CB23FB99", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/555767012_1385026673438136_2972548546834116007_n.enc?ccb=11-4&oh=01_Q5Aa4wGyfS5P40eU0Hxdvre9pSXKIgiBAw_3QnwfENqXLRqmUw&oe=6A61B061&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "Blockchain Onboarding by ParaHub.pdf", "mediaKey": "qKeGK9rcOaRvsY9Zs60t85chvqfT5AovfHt9TVNn2WE=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/555767012_1385026673438136_2972548546834116007_n.enc?ccb=11-4&oh=01_Q5Aa4wGyfS5P40eU0Hxdvre9pSXKIgiBAw_3QnwfENqXLRqmUw&oe=6A61B061&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782030723, "high": 0, "unsigned": false}}, "fileEncSha256": "F3hrYFNQaJkL6xCqo4aLmCxE3tjEKYySgrkJoHBw7XY=", "mediaKeyTimestamp": {"low": 1782203523, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782030723, "high": 0, "unsigned": false}}	web	1782203523	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqe8is400wqr54dp8miv7al	{"id": "3EB0BBAF7E5A6F2FDFB7FF", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/565946997_938386055881791_2421622395273758774_n.enc?ccb=11-4&oh=01_Q5Aa4wFcYJYo4vFcsNAvTVz8627SwxwOP_3VZpdKgsg8YI030A&oe=6A61B941&_nc_sid=5e03e0&mms3=true", "caption": "Halo, Pasha Renaisan!\\n\\nTerima kasih telah mengakses materi onboarding blockchain dari ParaHub.\\n\\nBerikut adalah materi \\"Memahami Blockchain dari Dasar\\" yang Kamu minta.\\n\\nMateri ini dirancang untuk membantu Kamu memahami konsep blockchain dengan bahasa yang sederhana dan mudah dipahami, sehingga lebih mudah dipahami oleh siapa saja yang baru memulai.\\n\\nSemoga materi ini dapat menjadi langkah awal yang bermanfaat dalam perjalanan Kamu mengenal dunia blockchain.", "fileName": "Blockchain Onboarding by ParaHub.pdf", "mediaKey": "q3pupZqbGSxYp8do2PImYwZRNqbu2/+cDXuLfZ6rgCs=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/565946997_938386055881791_2421622395273758774_n.enc?ccb=11-4&oh=01_Q5Aa4wFcYJYo4vFcsNAvTVz8627SwxwOP_3VZpdKgsg8YI030A&oe=6A61B941&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782031183, "high": 0, "unsigned": false}}, "fileEncSha256": "Lo73l5yqWDLf492UNGW83RdTv8YCICVBsxCDVi+sXHM=", "mediaKeyTimestamp": {"low": 1782203982, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782031183, "high": 0, "unsigned": false}}	web	1782203983	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqb7xpg00wer54dcxp77ljw	{"id": "3EB0D9340B225D1441E6B6", "fromMe": false, "remoteJid": "112395133432025@lid", "participant": "", "remoteJidAlt": "6282247973243@s.whatsapp.net", "addressingMode": "lid"}	Adi	\N	conversation	{"conversation": "ajg luh", "messageContextInfo": {"threadId": [], "messageSecret": "NE42YM/GiZ2yymr/yrg1JEZaZwFkG8FvFOKvYmfN4K0=", "limitSharingV2": {"trigger": 0, "initiatedByMe": false}, "deviceListMetadata": {"senderKeyHash": "zQjoC9QHtth7Ew==", "senderTimestamp": {"low": 1781651887, "high": 0, "unsigned": true}, "recipientKeyHash": "DbPdH+y2GvEQcg==", "senderKeyIndexes": [], "senderAccountType": 0, "recipientTimestamp": {"low": 1782052602, "high": 0, "unsigned": true}, "receiverAccountType": 0, "recipientKeyIndexes": []}, "deviceListMetadataVersion": 2}}	\N	web	1782198917	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmqqga3dr00wwr54d2n58recd	{"id": "3EB0193929E365E7935721", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/729340582_839796362291133_4383964067016752233_n.enc?ccb=11-4&oh=01_Q5Aa4wERVa3ne1QhCJhNWJN557HLjdtSPaICOl_i53DLsHOjZw&oe=6A61BCD5&_nc_sid=5e03e0&mms3=true", "caption": "Halo, pasha!\\n\\nTerima kasih telah mengakses materi onboarding blockchain dari ParaHub.\\n\\nBerikut adalah materi \\"Memahami Blockchain dari Dasar\\" yang Kamu minta.\\n\\nMateri ini dirancang untuk membantu Kamu memahami konsep blockchain dengan bahasa yang sederhana dan mudah dipahami, sehingga lebih mudah dipahami oleh siapa saja yang baru memulai.\\n\\nSemoga materi ini dapat menjadi langkah awal yang bermanfaat dalam perjalanan Kamu mengenal dunia blockchain.", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "UOslhUXAW1ccKQ5dzFMnxyTxmwNX+NjJS6njiz7lzzk=", "mimetype": "false", "directPath": "/v/t62.7119-24/729340582_839796362291133_4383964067016752233_n.enc?ccb=11-4&oh=01_Q5Aa4wERVa3ne1QhCJhNWJN557HLjdtSPaICOl_i53DLsHOjZw&oe=6A61BCD5&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782034615, "high": 0, "unsigned": false}}, "fileEncSha256": "cXXzcL3UiGrGTm9f1Bhjg/h5PgygeTy4BVJGLpzSktw=", "mediaKeyTimestamp": {"low": 1782207415, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782034615, "high": 0, "unsigned": false}}	web	1782207415	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqhe2js00x2r54ddmfn2221	{"id": "3EB09AB6CCA0679CBDD3CA", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/561295709_1582459903595426_5357876400022524346_n.enc?ccb=11-4&oh=01_Q5Aa4wE3kJDnuNbOHX3sS5h6Mdqrz7uDkbYTwN2-ycjOFyC_eA&oe=6A61BE98&_nc_sid=5e03e0&mms3=true", "caption": "Halo, Pasha!\\n\\nTerima kasih telah mengakses materi onboarding blockchain dari ParaHub.\\n\\nBerikut adalah materi \\"Memahami Blockchain dari Dasar\\" yang Kamu minta.\\n\\nMateri ini dirancang untuk membantu Kamu memahami konsep blockchain dengan bahasa yang sederhana dan mudah dipahami, sehingga lebih mudah dipahami oleh siapa saja yang baru memulai.\\n\\nSemoga materi ini dapat menjadi langkah awal yang bermanfaat dalam perjalanan Kamu mengenal dunia blockchain.", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "2Cq2HJWB5GJVNZrGsJloo9KSitkvn7kBIFKAkeOCX7k=", "mimetype": "false", "directPath": "/v/t62.7119-24/561295709_1582459903595426_5357876400022524346_n.enc?ccb=11-4&oh=01_Q5Aa4wE3kJDnuNbOHX3sS5h6Mdqrz7uDkbYTwN2-ycjOFyC_eA&oe=6A61BE98&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036480, "high": 0, "unsigned": false}}, "fileEncSha256": "3vuRTM5y1tSGe98Y2B7LgqsO8VDX4OVxTT80G6wjikA=", "mediaKeyTimestamp": {"low": 1782209280, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036480, "high": 0, "unsigned": false}}	web	1782209280	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqhf96c00xar54dbxc534cb	{"id": "3EB033EE0CF793AD6EB30B", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/561589583_36426195183695348_2328532568930318607_n.enc?ccb=11-4&oh=01_Q5Aa4wF4p9FvGOoxY7dGmT5ryO9PtDFrOrpD-UNv5x8wyLpsjw&oe=6A61D461&_nc_sid=5e03e0&mms3=true", "caption": "Hello, Pasha Renaisan!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from the Ground Up\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "nLW4ZRGHQk2timPGc/6UNFL2J4uz+6solzEYFuxGKPs=", "mimetype": "false", "directPath": "/v/t62.7119-24/561589583_36426195183695348_2328532568930318607_n.enc?ccb=11-4&oh=01_Q5Aa4wF4p9FvGOoxY7dGmT5ryO9PtDFrOrpD-UNv5x8wyLpsjw&oe=6A61D461&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036536, "high": 0, "unsigned": false}}, "fileEncSha256": "ZS4j5AVqHReD0JigFrVKuJ5g9TC8bxbA7yyTgcDV8wI=", "mediaKeyTimestamp": {"low": 1782209335, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036536, "high": 0, "unsigned": false}}	web	1782209336	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqhfwzg00xgr54d9kb2wxav	{"id": "3EB0D8ECF5A22A8120A0FF", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/616112062_888083173662818_3027672130549094567_n.enc?ccb=11-4&oh=01_Q5Aa4wHRsN3C4n-6Zy-KBZzlpFGBOOqJEttH6veoG6SBw-5fHA&oe=6A61D872&_nc_sid=5e03e0&mms3=true", "caption": "Halo, Pasha Renaisan!\\n\\nTerima kasih telah mengakses materi onboarding blockchain dari ParaHub.\\n\\nBerikut adalah materi \\"Memahami Blockchain dari Dasar\\" yang Kamu minta.\\n\\nMateri ini dirancang untuk membantu Kamu memahami konsep blockchain dengan bahasa yang sederhana dan mudah dipahami, sehingga lebih mudah dipahami oleh siapa saja yang baru memulai.\\n\\nSemoga materi ini dapat menjadi langkah awal yang bermanfaat dalam perjalanan Kamu mengenal dunia blockchain.", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "GL6Ge+BxkFWd53yu8o/ta+7UqRthGsRtjObyFwFaa/s=", "mimetype": "false", "directPath": "/v/t62.7119-24/616112062_888083173662818_3027672130549094567_n.enc?ccb=11-4&oh=01_Q5Aa4wHRsN3C4n-6Zy-KBZzlpFGBOOqJEttH6veoG6SBw-5fHA&oe=6A61D872&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036566, "high": 0, "unsigned": false}}, "fileEncSha256": "k0yGFcskGLK9P0yRLdZp71CqV1nPdYhSkT2YGWDt/ck=", "mediaKeyTimestamp": {"low": 1782209366, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782036566, "high": 0, "unsigned": false}}	web	1782209366	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqhpahw00xmr54dn8gb59mu	{"id": "3EB0A6BB06088EFCB698AE", "fromMe": true, "remoteJid": "6282247973243@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/669660638_1373974491305358_4342003820520316464_n.enc?ccb=11-4&oh=01_Q5Aa4wGSt21-5y6rP2Ch5LIqsmTmzs1M-zFsxkh71GkbL1fobQ&oe=6A61C40B&_nc_sid=5e03e0&mms3=true", "caption": "Hello, adistra!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from the Ground Up\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "wYa4Bs1u5CqkOXTOJKtnFojEeQFlQR9qYcO2Y8kM4iI=", "mimetype": "false", "directPath": "/v/t62.7119-24/669660638_1373974491305358_4342003820520316464_n.enc?ccb=11-4&oh=01_Q5Aa4wGSt21-5y6rP2Ch5LIqsmTmzs1M-zFsxkh71GkbL1fobQ&oe=6A61C40B&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782037004, "high": 0, "unsigned": false}}, "fileEncSha256": "ifuPTCiXJ1VwXcgNaDbPd0IwH4RlcU6muGHyRmVfBm0=", "mediaKeyTimestamp": {"low": 1782209804, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782037004, "high": 0, "unsigned": false}}	web	1782209804	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqqhwed800xqr54dm0iajgsb	{"id": "3EB07777D38BC83D18D3F7", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/616452338_902543379538496_6343775693151379489_n.enc?ccb=11-4&oh=01_Q5Aa4wEAle4ehV9ih-oOBJyqtJdaowCac70xTI6AGT10-fmhNw&oe=6A61BC5A&_nc_sid=5e03e0&mms3=true", "caption": "Hello, pasha!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "Sq6ul4dquCDhIxwupwzELbMZMS7JMec4ebgndNPxg3I=", "mimetype": "false", "directPath": "/v/t62.7119-24/616452338_902543379538496_6343775693151379489_n.enc?ccb=11-4&oh=01_Q5Aa4wEAle4ehV9ih-oOBJyqtJdaowCac70xTI6AGT10-fmhNw&oe=6A61BC5A&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782037335, "high": 0, "unsigned": false}}, "fileEncSha256": "RwzDK+5Yb5eUv//tr0ps5ldH0lIDBHxLLEMM65AAmeA=", "mediaKeyTimestamp": {"low": 1782210135, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782037335, "high": 0, "unsigned": false}}	web	1782210135	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqrw8ps800yqr54dugr703lb	{"id": "3EB0D14B47213EDCEF01A4", "fromMe": true, "remoteJid": "6287860202653@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/562481276_912569691876401_2844542195968333755_n.enc?ccb=11-4&oh=01_Q5Aa4wF5SYmMNxQVSsPndZpBuVYu8jiBbxCsH9k1sOLR8hmSOQ&oe=6A63310C&_nc_sid=5e03e0&mms3=true", "caption": "Hello, kelwin shen!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub", "mediaKey": "tBRQOInbOgYJFRk1Vox5/B+nUn3BtQ4O9wmbosl73h8=", "mimetype": "false", "directPath": "/v/t62.7119-24/562481276_912569691876401_2844542195968333755_n.enc?ccb=11-4&oh=01_Q5Aa4wF5SYmMNxQVSsPndZpBuVYu8jiBbxCsH9k1sOLR8hmSOQ&oe=6A63310C&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782121891, "high": 0, "unsigned": false}}, "fileEncSha256": "8yEicRfMx0paDM5LYVVU9L4twNzBWP40mfZCrpSos88=", "mediaKeyTimestamp": {"low": 1782294691, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782121891, "high": 0, "unsigned": false}}	web	1782294691	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqsu8fyl00zgr54dfxf3p0i1	{"id": "3EB08C53D9B6890BF62046", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/555344909_1492549758853376_2280750453397999085_n.enc?ccb=11-4&oh=01_Q5Aa4wEakv6E35SFF0LEd_vaHeO3u-zZqQ0oNOyMBOlM4fKUPw&oe=6A63ED1A&_nc_sid=5e03e0&mms3=true", "caption": "Hello, Pasha R!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "Mkvc+CcSB348pxLgbBecAwXfIb4xC2zkTjAqU0iyOK0=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/555344909_1492549758853376_2280750453397999085_n.enc?ccb=11-4&oh=01_Q5Aa4wEakv6E35SFF0LEd_vaHeO3u-zZqQ0oNOyMBOlM4fKUPw&oe=6A63ED1A&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782178984, "high": 0, "unsigned": false}}, "fileEncSha256": "14GrVc+94WuqBgpVeAteFp24RpCY3NCq6v9d+6LQBro=", "mediaKeyTimestamp": {"low": 1782351784, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782178984, "high": 0, "unsigned": false}}	web	1782351784	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqsvvn9u00zpr54d4jk9scqy	{"id": "3EB0889BB3DC0789D85941", "fromMe": true, "remoteJid": "6282146077890@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/729813464_27865491563034213_1464836856752599532_n.enc?ccb=11-4&oh=01_Q5Aa4wHFDOOGZaKSDbfEcs04a6my4Jj6zSf3vDUY5yei0M_1UA&oe=6A640500&_nc_sid=5e03e0&mms3=true", "caption": "Hello, Fajar Tapa!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "B+fzZ5Z9Z98GnbJzJPe9Zzovc1O2clnvcMC97w78ANo=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/729813464_27865491563034213_1464836856752599532_n.enc?ccb=11-4&oh=01_Q5Aa4wHFDOOGZaKSDbfEcs04a6my4Jj6zSf3vDUY5yei0M_1UA&oe=6A640500&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782181746, "high": 0, "unsigned": false}}, "fileEncSha256": "fMJOUW2LUvDqTxp9SvpRja1flIF3xOHZ0bR3o5RaQnY=", "mediaKeyTimestamp": {"low": 1782354545, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782181746, "high": 0, "unsigned": false}}	web	1782354546	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmqulmcx8010jr54d6fydazw3	{"id": "E3A304111209D08359", "fromMe": false, "remoteJid": "164124021502171@lid", "participant": "", "remoteJidAlt": "62881082489258@s.whatsapp.net", "addressingMode": "lid"}	\N	\N	templateMessage	{"templateMessage": {"templateId": "842108848756023", "contextInfo": {"mentionedJid": [], "groupMentions": [], "dataSharingContext": {"parameters": [{"key": "data_sharing_encrypted_token_disclosed", "stringData": "AQIfnq0SnANtK4KosmXFRUF459b5bxxoc0gd7YTWInZbkIXz5J3pS5NnOvt/yUTfEJ4J5qZbpWGixETOWj6Av4gnYwZZ73NVE5rtdqi1NC7q3S3gXUhra+O1uMp6JFdjirAiTWbOD5+0dfTODFpnrxUTklNieyHL6DlmzY37P25RHiOpDxLppHqx78sXty0n47kU0p8itrIhp0Y="}, {"key": "data_sharing_encrypted_token_undisclosed", "stringData": "AQI0f5kahZq+4qpRodrwmaddy5tMElA2s952KvMbBFaq2EGXTXa9+eo91vbsr4FLKM/hsmABxFQTJuaDagUf5gI9wd4ANWLmATrpw6hWO4XV/sbaEJr8XX6/zNgLhiiCs0+4eaVJZIpzHNM8G4eNw3lhxDA2QtLryjCbkFT0u/johUfoel4tUCxo35mOf3Q/03zTLe1DPOTX2Lc="}], "dataSharingFlags": 0, "showMmDisclosure": false}, "statusAttributions": []}, "hydratedTemplate": {"templateId": "842108848756023", "imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/613331876_1958229478463169_4683720869026783577_n.enc?ccb=11-4&oh=01_Q5Aa4wFysrwxE6edBqirSa59olfe4o1_LahnssAFzC6YcJAa2A&oe=6A632E36&_nc_sid=5e03e0&mms3=true", "width": 1600, "height": 1600, "mediaKey": "D3Dekrf3QLzK4n9tDjRmO2oTg8jz2p9ojHMKk2CDfzM=", "mimetype": "image/jpeg", "directPath": "/v/t62.7118-24/613331876_1958229478463169_4683720869026783577_n.enc?ccb=11-4&oh=01_Q5Aa4wFysrwxE6edBqirSa59olfe4o1_LahnssAFzC6YcJAa2A&oe=6A632E36&_nc_sid=5e03e0", "fileLength": {"low": 228576, "high": 0, "unsigned": true}, "fileSha256": "p2TotEzpyyMQh6+mMuQOx9QIY4mMwLrxayGVImKKqyg=", "annotations": [], "contextInfo": {"mentionedJid": [], "groupMentions": [], "statusAttributions": []}, "scanLengths": [], "fileEncSha256": "CLiRl5XIKpjcU9mbsSqSYZ4yNDJphvhsxQAGTg1Wqv4=", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAFA3PEY8MlBGQUZaVVBfeMiCeG5uePWvuZHI////////////////////////////////////////////////////2wBDAVVaWnhpeOuCguv/////////////////////////////////////////////////////////////////////////wAARCABIAEgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwBAARyeaXaPUfnTaAK3MQxS4pQKcE96TYWI8+xx644pcU9ehUc0u3mpUu5bjbYYqlugoKkdRT3JDDnHHrQmWyGyaz9q9+g+QjooorczEpwpop4oYIcKjL5qVjuBye1RlmxkKBis3ruaLQcCoj96PMJGAabl8jpzQQxI+UDnrS0HdjzhhycUhYIpA6+op3GOKY4x1qVBA5MZRSUVuZi04U2nbh/dpSbQJD8E/dx+NKUCj52PPoKYCewI/Gl34Zd3qfesn3saIQ47MwH0pW4PDEke2f5UjEvGxVycdQRSuxjEYXpU38gBfu9qaxzSykLL7EZNNcEjKj61aktBNDDRSUVoSPooopiDNBYggr1FSeWMA7jyOwpNvu3/AHzUtopXI2lZlKhQueuKVZioAKhsdKfsz3b/AL5o2D1b/vmotG1h3ZCWZm3HrQHYAjPWpfJG0ncRj1GKgqrJi1FopKKoRLRRRTEJScUUUDDj3pPxNFFIBKSiigYUUUUAf//Z", "thumbnailSha256": "gD08XkWGN5g1JMHLVQ1/E5fL3a4h6UgSoqrPzmsltS0=", "mediaKeyTimestamp": {"low": 1782296638, "high": 0, "unsigned": false}, "thumbnailEncSha256": "kRUZ27vf5FLo2f5WOC548zHcoOlFgQ9CAH8/9YjQ5tY=", "thumbnailDirectPath": "/v/t62.35850-24/729569804_961863270213196_7639099236629022456_n.enc?ccb=11-4&oh=01_Q5Aa4wGHNEjOaBVst0jkzf2iB2zEyQfelz6BROb1bJZyHUFXPw&oe=6A632044&_nc_sid=5e03e0", "interactiveAnnotations": []}, "hydratedButtons": [{"index": 0, "quickReplyButton": {"id": "Info Detail!", "displayText": "Info Detail!"}}, {"index": 1, "quickReplyButton": {"id": "Klaim Promo!", "displayText": "Klaim Promo!"}}, {"index": 2, "quickReplyButton": {"id": "Jadwalkan Demo Fitur!", "displayText": "Jadwalkan Demo Fitur!"}}], "hydratedContentText": "Halo Kak 👋\\n\\n*Mau bisnis lebih produktif tanpa tambah effort?*\\nSekarang saat yang tepat!\\n\\n🔥 _*PROMO QONTAK BIG SALE*_ 🔥\\n*Diskon hingga 50%*\\n*Mulai dari Rp200rb/user*\\n\\nDengan Qontak, tim bisa:\\n✔️ Respon customer lebih cepat\\n✔️ Auto response 24 jam\\n✔️ Follow up prospek otomatis\\n✔️ Kelola chat dari berbagai channel dalam 1 platform\\n✔️ Tingkatkan closing lebih maksimal\\n\\n*Promo hanya berlaku sampai akhir Juni*.\\nBoleh saya bantu info detail promonya, Kak?\\n\\nAini\\n+62 813-8502-5327"}}, "messageContextInfo": {"threadId": [], "deviceListMetadata": {"recipientKeyHash": "DbPdH+y2GvEQcg==", "senderKeyIndexes": [], "recipientTimestamp": {"low": 1782052602, "high": 0, "unsigned": true}, "recipientKeyIndexes": []}, "deviceListMetadataVersion": 2}}	{"mentionedJid": [], "groupMentions": [], "dataSharingContext": {"parameters": [{"key": "data_sharing_encrypted_token_disclosed", "stringData": "AQIfnq0SnANtK4KosmXFRUF459b5bxxoc0gd7YTWInZbkIXz5J3pS5NnOvt/yUTfEJ4J5qZbpWGixETOWj6Av4gnYwZZ73NVE5rtdqi1NC7q3S3gXUhra+O1uMp6JFdjirAiTWbOD5+0dfTODFpnrxUTklNieyHL6DlmzY37P25RHiOpDxLppHqx78sXty0n47kU0p8itrIhp0Y="}, {"key": "data_sharing_encrypted_token_undisclosed", "stringData": "AQI0f5kahZq+4qpRodrwmaddy5tMElA2s952KvMbBFaq2EGXTXa9+eo91vbsr4FLKM/hsmABxFQTJuaDagUf5gI9wd4ANWLmATrpw6hWO4XV/sbaEJr8XX6/zNgLhiiCs0+4eaVJZIpzHNM8G4eNw3lhxDA2QtLryjCbkFT0u/johUfoel4tUCxo35mOf3Q/03zTLe1DPOTX2Lc="}], "dataSharingFlags": 0, "showMmDisclosure": false}, "statusAttributions": []}	desktop	1782458250	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmr68gral013br54dt04vuxv8	{"id": "3EB0FA7861A1C2C5DD4F9A", "fromMe": true, "remoteJid": "6281338772338@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/736973147_1572093301168940_4158209927847923739_n.enc?ccb=11-4&oh=01_Q5Aa4wEyHA3QdkGl898uyOXRTXfY0nQYFDwZ5B1mDyWbX4l3Gg&oe=6A705884&_nc_sid=5e03e0&mms3=true", "caption": "Hello, diva!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "ShWjKjzZ3ygx/AVSDxZ+mf2Czc69yQ/Ivn2uPTsy2nY=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/736973147_1572093301168940_4158209927847923739_n.enc?ccb=11-4&oh=01_Q5Aa4wEyHA3QdkGl898uyOXRTXfY0nQYFDwZ5B1mDyWbX4l3Gg&oe=6A705884&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782988948, "high": 0, "unsigned": false}}, "fileEncSha256": "Zt+PoYURig4hMsm8Oqc5nWyrlBKaA12F6nDfOe3NOro=", "mediaKeyTimestamp": {"low": 1783161747, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1782988948, "high": 0, "unsigned": false}}	web	1783161748	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmr92vsjy014yr54drufab14p	{"id": "3B6E57FC561B4400274B", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "kok masuk lagii", "messageContextInfo": {"threadId": [], "messageSecret": "Qnw2xvP0Cyhqtu9ayW+tK2Wu6auxT9YDyRpxVZRiEI0="}}	\N	unknown	1783333771	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92vu3c0154r54djfx5afoo	{"id": "3B72007FD583E5C68AAC", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "ngentottt", "messageContextInfo": {"threadId": [], "messageSecret": "BacVB4WMmIXzS24iI3agP8Sh2GRzdSpQvX0SCD28Jjo="}}	\N	unknown	1783333773	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92vztd015ar54dm1f7deml	{"id": "3B679D2BEE9B11905D33", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "BYE!", "messageContextInfo": {"threadId": [], "messageSecret": "2g+KtcPSMlE5+6fNDDIyUe7nNethtO3bUCtEYlETUU0="}}	\N	unknown	1783333780	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92wlep015gr54dkv6084p6	{"id": "3EB0B33057DCB6A829F70C", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "113739474936038@lid", "addressingMode": "lid", "participantAlt": "6281239990810@s.whatsapp.net"}	Pasha Renaisan	\N	conversation	{"conversation": "kamu kemarin tak liat di tkj sama cosplay zoro", "messageContextInfo": {"threadId": [], "messageSecret": "340BqREQ9WykSab6+d7Fu69Ffoy3yBF9yfU2dC+wzC0="}, "senderKeyDistributionMessage": {"groupId": "120363409068752753@g.us", "axolotlSenderKeyDistributionMessage": "Mwjx7vh6EAAaIMLrWPeCyIcrkcg1N7sdTU6apn4EAfgVf6gpmUvRnBnzIiEFyfCgAKxq9RnfOxL6IqzXcK9av6IkFdgMXrKIE0a62HA="}}	\N	web	1783333808	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92wtgg015mr54dya2inby2	{"id": "3EB083FEF15700299015F5", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "113739474936038@lid", "addressingMode": "lid", "participantAlt": "6281239990810@s.whatsapp.net"}	Pasha Renaisan	\N	conversation	{"conversation": "kamu selingkuh mulu", "messageContextInfo": {"threadId": [], "messageSecret": "2U5LHK/S2uyjmHJuid/urkfx+hB6V4PVlGqcTAVEYlQ="}}	\N	web	1783333819	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr91jij2014ar54dro0vl9nm	{"id": "3B1389BCA14C0141E660", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "185486836560069@lid", "addressingMode": "lid", "participantAlt": "6287860202653@s.whatsapp.net"}	Kelwin Shen	\N	conversation	{"conversation": "Hello", "messageContextInfo": {"threadId": [], "messageSecret": "SnH4vUHtbsAyw0QiNg6JdNdhGObqql+ZowvJn4dqayU="}, "senderKeyDistributionMessage": {"groupId": "120363409068752753@g.us", "axolotlSenderKeyDistributionMessage": "MwjVwoOvARAAGiBdfRq5e8DOoZC3MljAFFYQnt3lfM340X07cEz/cwJgpCIhBQq8baJxFvT3MPPw0gh5dWJQ3xckpFTnEgO6ZoflXYMh"}}	\N	unknown	1783331518	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92uyql014gr54d7z93r8l2	{"id": "3BC0F412F29CBA526EAE", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "group apa ni", "messageContextInfo": {"threadId": [], "messageSecret": "ZcMYPPKN/ic0Mk7RXTFXT9sA5vEgoXnncgzoaKSaieU="}, "senderKeyDistributionMessage": {"groupId": "120363409068752753@g.us", "axolotlSenderKeyDistributionMessage": "MwiG9J2kBBAAGiDWbLZBKnUrXGGjJ2r2XivP77p13VOdZbyXP8MafL6ctiIhBdq5pbCOic9vf8/RqSoIsO17EtWmTrfO2Q/HgABe64BQ"}}	\N	unknown	1783333732	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92v1m9014mr54dtijox232	{"id": "3B20F7334561C4812F27", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "nyocot", "messageContextInfo": {"threadId": [], "messageSecret": "VPH9I537TkDP0xrJnJtBWNfVUO/z/pUpy7V/O8BLlVY="}}	\N	unknown	1783333736	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr92vojp014sr54deu5hey8z	{"id": "3BDD96C9754946FCA5B4", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "bajingan", "messageContextInfo": {"threadId": [], "messageSecret": "GGiVsc6bQnw4Zy1X8W483GDukJKsFEDBMd93sDuG37c="}, "senderKeyDistributionMessage": {"groupId": "120363409068752753@g.us", "axolotlSenderKeyDistributionMessage": "MwjR3vfpAxAAGiAdLSxcTSI3j6nPusdEE5vzjD3++7keBaIXwvpImoSLfiIhBYGF0LQD+9BUX/6nYr4lro/qePsaU4Tdu86fVjzk7O1I"}}	\N	unknown	1783333766	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr93zkq4016mr54dkla5fadi	{"id": "3EB0161925755BF2818C37", "fromMe": true, "remoteJid": "167929614229740@lid", "participant": "", "remoteJidAlt": "6285117722465@s.whatsapp.net", "addressingMode": "lid"}	Paradapp	\N	conversation	{"conversation": "Halo! Selamat datang di grup kami. Senang bisa bergabung dengan Anda!"}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "statusAttributions": [], "ephemeralSettingTimestamp": {"low": 1783162825, "high": 0, "unsigned": false}}	web	1783335627	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	SERVER_ACK
cmr93z9uk016gr54drezozixq	{"id": "3BE7BDBC72D4D9F25083", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "bye", "messageContextInfo": {"threadId": [], "messageSecret": "H04gqXHiGAGdR9/Ju2T5RMr87lXXUghq0GJslI8webM="}}	\N	unknown	1783335613	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr93zlxr016sr54dkcw7g434	{"id": "3EB010809B46CF8D606092", "fromMe": true, "remoteJid": "167929614229740@lid", "participant": "", "remoteJidAlt": "6285117722465@s.whatsapp.net", "addressingMode": "lid"}	Paradapp	\N	conversation	{"conversation": "Halo! Selamat datang di grup kami. Senang bisa bergabung dengan Anda!"}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "statusAttributions": [], "ephemeralSettingTimestamp": {"low": 1783162827, "high": 0, "unsigned": false}}	web	1783335628	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	SERVER_ACK
cmr941h15016yr54dj4v0jo8l	{"id": "3EB096C2E956F1EBBC5A9A", "fromMe": true, "remoteJid": "112395133432025@lid", "participant": "", "remoteJidAlt": "6282247973243@s.whatsapp.net", "addressingMode": "lid"}	Paradapp	\N	conversation	{"conversation": "Halo! Selamat datang di grup kami. Senang bisa bergabung dengan Anda!"}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "statusAttributions": [], "ephemeralSettingTimestamp": {"low": 1783162914, "high": 0, "unsigned": false}}	web	1783335715	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	SERVER_ACK
cmr93yw92015sr54dl1wqr14g	{"id": "3BEAAFD87AAF3DA9F55C", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "JIR", "messageContextInfo": {"threadId": [], "messageSecret": "nCVQf8QY5jDqIP9i0AynvAH1VyCpb6+1O/0J3+wEhJ4="}, "senderKeyDistributionMessage": {"groupId": "120363409068752753@g.us", "axolotlSenderKeyDistributionMessage": "Mwjjzv2cBRAAGiAH24fYK9yBk0Pp1RBEL4Alr8rIIkvcQwSFlXcXcOU3hCIhBSiZNaOb1gaOFOajyJrHpmkRxVKkdSPNvtQJ3/oXbFxz"}}	\N	unknown	1783335595	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr93z24r015yr54dyefilgco	{"id": "3BD89D95317E91435617", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "kok join lagi anjirrr", "messageContextInfo": {"threadId": [], "messageSecret": "HsTebINRMlAjY/0aqJUc6wHMm21dP9aurI/O+znn4LY="}}	\N	unknown	1783335603	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr93z85r0164r54dv253gfp5	{"id": "3BEBBDECDCE56DDE23BA", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "di hack ci", "messageContextInfo": {"threadId": [], "messageSecret": "+cmgqXE32ZSThqYBJJYlXWSFDzbS9Cf3XLZc6M87nvI="}}	\N	unknown	1783335611	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr93z8of016ar54dp0tgv1v7	{"id": "3B5071FCD504E934CC5B", "fromMe": false, "remoteJid": "120363409068752753@g.us", "participant": "167929614229740@lid", "addressingMode": "lid", "participantAlt": "6285117722465@s.whatsapp.net"}	Eka	\N	conversation	{"conversation": "fak", "messageContextInfo": {"threadId": [], "messageSecret": "uZQLbe40KlY9gu8vx7xmpRPlWnDmJoc6I0BC/HhTlZs="}}	\N	unknown	1783335611	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	READ
cmr95ll09017ar54dluoosvca	{"id": "A52A438152A631417D51CB7DD157DDD7", "fromMe": true, "remoteJid": "112395133432025@lid", "participant": "", "remoteJidAlt": "6282247973243@s.whatsapp.net", "addressingMode": "lid"}	Paradapp	\N	conversation	{"conversation": "Follow this link to join my WhatsApp group: https://chat.whatsapp.com/E2GkkF61CjDE7qMmiUnfhX?s=sh&p=a&ilr=0&amv=2"}	\N	android	1783338333	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	SERVER_ACK
cmr9v8cgo017kr54d1zk7w112	{"id": "3B0D9F4CBB584A1BB0D7", "fromMe": false, "remoteJid": "167929614229740@lid", "participant": "", "remoteJidAlt": "6285117722465@s.whatsapp.net", "addressingMode": "lid"}	Eka	\N	conversation	{"conversation": "HALAH NYOCOT", "messageContextInfo": {"threadId": [], "messageSecret": "8ex6iqSvK0Uq9iRL6NRNRqjK5GdfqS17laNbeu3Hswo=", "deviceListMetadata": {"senderKeyHash": "Iy30+rGmlEcgXA==", "senderTimestamp": {"low": 1775799722, "high": 0, "unsigned": true}, "recipientKeyHash": "pz50cDEB2nDfrA==", "senderKeyIndexes": [], "recipientTimestamp": {"low": 1783331230, "high": 0, "unsigned": true}, "recipientKeyIndexes": []}, "deviceListMetadataVersion": 2}}	\N	unknown	1783381386	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	DELIVERY_ACK
cmrn7wzpd01a2r54dtydibq71	{"id": "3EB04019AB07459F3FE740", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/534838922_1015057981432556_7194926176959943473_n.enc?ccb=11-4&oh=01_Q5Aa5AEhqV27YeuZ1_v0bTYYxlMcu8_SoNtyIxJlMhr9QIe4QA&oe=6A7FFD0E&_nc_sid=5e03e0&mms3=true", "caption": "Hello, Pasha Renaisan!\\n\\nThank you for accessing the blockchain onboarding materials from ParaHub.\\n\\nHere is the \\"Understanding Blockchain from Basic\\" guide you requested.\\n\\nThis material is designed to help you grasp blockchain concepts in simple, everyday language, making it easy for anyone just starting out.\\n\\nWe hope this guide serves as a helpful first step in your journey into the world of blockchain!", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "TDLZT5BQBOgsxOx8PUpurrfG4bOQMj51rZg9JJFuQMs=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/534838922_1015057981432556_7194926176959943473_n.enc?ccb=11-4&oh=01_Q5Aa5AEhqV27YeuZ1_v0bTYYxlMcu8_SoNtyIxJlMhr9QIe4QA&oe=6A7FFD0E&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1784015951, "high": 0, "unsigned": false}}, "fileEncSha256": "I8RzEPMavbxjA+q/+e0MRcKnRjkwHXkPimyjgfI/930=", "mediaKeyTimestamp": {"low": 1784188750, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1784015951, "high": 0, "unsigned": false}}	web	1784188751	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cms9xhck40001of4cmdtgmkuy	{"id": "3EB0751612AD81DF3D3726", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/571615869_2266768544148978_6669779500789943712_n.enc?ccb=11-4&oh=01_Q5Aa5AEqrBaszRRLmAIk3yvCryBTYufUVVTI5VLL2fYL4VFZZQ&oe=6A94FF14&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "PAoRZ/S0QFreTdaKhVFJadktO6BliHmNIQffJzZmCRY=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/571615869_2266768544148978_6669779500789943712_n.enc?ccb=11-4&oh=01_Q5Aa5AEqrBaszRRLmAIk3yvCryBTYufUVVTI5VLL2fYL4VFZZQ&oe=6A94FF14&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1785389146, "high": 0, "unsigned": false}}, "fileEncSha256": "KjrVl8/ik1bhS5BEJEIIt7PvRR9z67dzQakl4SlIqaQ=", "mediaKeyTimestamp": {"low": 1785561946, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1785389146, "high": 0, "unsigned": false}}	web	1785561946	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmsk40y7l002bof4c8zq4ts78	{"id": "3EB0F95BD35E0599E6A206", "fromMe": true, "remoteJid": "6281338772338@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/702564254_1703847167568539_7241606369566053542_n.enc?ccb=11-4&oh=01_Q5Aa5QG5gNTd73hh4Q29hjVHMes6PAXy3FgRHjSNRyfCSEIAuA&oe=6A9E3F97&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "gEa+C3Dhalz0X8I2LJs0N+66a69euhLGDCq3HBMG72A=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/702564254_1703847167568539_7241606369566053542_n.enc?ccb=11-4&oh=01_Q5Aa5QG5gNTd73hh4Q29hjVHMes6PAXy3FgRHjSNRyfCSEIAuA&oe=6A9E3F97&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786004799, "high": 0, "unsigned": false}}, "fileEncSha256": "KwneNiHOWGN17NR87nQlIj8yTF1D0Ec2meOlQ3xyZrI=", "mediaKeyTimestamp": {"low": 1786177599, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786004799, "high": 0, "unsigned": false}}	web	1786177599	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmskp3ht8002lof4cf4ze4fl9	{"id": "3EB02809839442E43B1383", "fromMe": true, "remoteJid": "6281239990810@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/640387973_1070778112552045_6344356909076422268_n.enc?ccb=11-4&oh=01_Q5Aa5QGPcwK9XLADju0hTLfaiiLnJK7llRA1vfcuodH41QTxqg&oe=6A9EE1B3&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "81dSZQaNmCHXnfCOyqGkFNVjcsKVyCVvAiEQBHiJw6M=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/640387973_1070778112552045_6344356909076422268_n.enc?ccb=11-4&oh=01_Q5Aa5QGPcwK9XLADju0hTLfaiiLnJK7llRA1vfcuodH41QTxqg&oe=6A9EE1B3&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786040191, "high": 0, "unsigned": false}}, "fileEncSha256": "3f0rlSY5ONzS6e5EImlEIS1LZocmBU1bvkltjfFnnpY=", "mediaKeyTimestamp": {"low": 1786212991, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786040191, "high": 0, "unsigned": false}}	web	1786212991	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
cmskpgpcy002uof4cpj21ot3p	{"id": "3EB05328A3550F085BE988", "fromMe": true, "remoteJid": "6282146504913@s.whatsapp.net"}	Você	\N	documentMessage	{"documentMessage": {"url": "https://mmg.whatsapp.net/v/t62.7119-24/541737411_2121510311911927_5404882699764445054_n.enc?ccb=11-4&oh=01_Q5Aa5QHrp1YQK_Nu0aOwMOWUEqWWfov4mhIuW7NZFf9xcZGobw&oe=6A9EEB05&_nc_sid=5e03e0&mms3=true", "caption": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀", "fileName": "Blockchain Onboarding By ParaHub.pdf", "mediaKey": "WPtB38VgFYQglcIkEog9LnAkIhyUkn3ftKe8jPpCGMw=", "mimetype": "application/pdf", "directPath": "/v/t62.7119-24/541737411_2121510311911927_5404882699764445054_n.enc?ccb=11-4&oh=01_Q5Aa5QHrp1YQK_Nu0aOwMOWUEqWWfov4mhIuW7NZFf9xcZGobw&oe=6A9EEB05&_nc_sid=5e03e0", "fileLength": {"low": 10567963, "high": 0, "unsigned": true}, "fileSha256": "ZZ32oCrEqTilZwwB9fJUvjcnA7XnCNdWS5LdPv0aC1Y=", "contextInfo": {"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786040806, "high": 0, "unsigned": false}}, "fileEncSha256": "2HeJLT2XOPH6lO9jyY5TfnKjYcfk4OisnzCIflu1Sfs=", "mediaKeyTimestamp": {"low": 1786213606, "high": 0, "unsigned": false}}}	{"mentionedJid": [], "groupMentions": [], "disappearingMode": {"initiator": 0}, "ephemeralSettingTimestamp": {"low": 1786040806, "high": 0, "unsigned": false}}	web	1786213606	\N	\N	\N	\N	\N	23d8699a-16ab-4406-9e59-9c374964b83c	\N	\N	PENDING
\.


--
-- Data for Name: MessageUpdate; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."MessageUpdate" (id, "keyId", "remoteJid", "fromMe", participant, "pollUpdates", status, "messageId", "instanceId") FROM stdin;
cmqnwctkl00ugr54dx22uviya	3EB0556F7245E625B84CC1	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqnwcser00uer54d9ljent20	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnwgmze00uir54dcrzd3z56	3EB0556F7245E625B84CC1	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqnwcser00uer54d9ljent20	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnx8lpb00umr54dgs8qcml8	3EB0D557132F80C5615999	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqnx8kgk00ukr54dvmf4p0l8	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxdzl200uor54dwg9qy9t8	3EB0556F7245E625B84CC1	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqnwcser00uer54d9ljent20	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxdzld00uqr54dx1ugjmp2	3EB0D557132F80C5615999	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqnx8kgk00ukr54dvmf4p0l8	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxeppq00uvr54d278hktgd	3EB0A67380DF0E055D91F9	167929614229740@lid	t	\N	\N	DELIVERY_ACK	cmqnxeogp00utr54dmzlho5at	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxh7oh00uxr54dlrqg8tjw	3EB0A67380DF0E055D91F9	167929614229740:5@lid	t	\N	\N	DELIVERY_ACK	cmqnxeogp00utr54dmzlho5at	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxkzre00v1r54dere7r5dz	3EB0CDD3A525BE5DF39B2F	185486836560069:27@lid	t	\N	\N	DELIVERY_ACK	cmqnxkyrh00uzr54d0b6huwvs	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxl05b00v3r54dnu4lnynk	3EB0CDD3A525BE5DF39B2F	185486836560069@lid	t	\N	\N	DELIVERY_ACK	cmqnxkyrh00uzr54d0b6huwvs	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxl17g00v5r54do54h2p6i	3EB0CDD3A525BE5DF39B2F	185486836560069:27@lid	t	\N	\N	READ	cmqnxkyrh00uzr54d0b6huwvs	23d8699a-16ab-4406-9e59-9c374964b83c
cmqnxyaey00v9r54dmsto1cyw	3EB090C7C1ACB736037DEE	112395133432025@lid	t	\N	\N	DELIVERY_ACK	cmqnxy8x800v7r54d484fnl57	23d8699a-16ab-4406-9e59-9c374964b83c
cmqny7cxh00vbr54detrjq2d3	3EB0CDD3A525BE5DF39B2F	185486836560069:27@lid	t	\N	\N	DELIVERY_ACK	cmqnxkyrh00uzr54d0b6huwvs	23d8699a-16ab-4406-9e59-9c374964b83c
cmqny9s2g00vdr54d86qufos3	3EB0D557132F80C5615999	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqnx8kgk00ukr54dvmf4p0l8	23d8699a-16ab-4406-9e59-9c374964b83c
cmqny9sb500vfr54dvyl2b3bw	3EB0A67380DF0E055D91F9	167929614229740@lid	t	\N	\N	SERVER_ACK	cmqnxeogp00utr54dmzlho5at	23d8699a-16ab-4406-9e59-9c374964b83c
cmqny9slm00vhr54dpgn2zl19	3EB0CDD3A525BE5DF39B2F	185486836560069@lid	t	\N	\N	SERVER_ACK	cmqnxkyrh00uzr54d0b6huwvs	23d8699a-16ab-4406-9e59-9c374964b83c
cmqny9st500vjr54don7imjqm	3EB090C7C1ACB736037DEE	112395133432025@lid	t	\N	\N	SERVER_ACK	cmqnxy8x800v7r54d484fnl57	23d8699a-16ab-4406-9e59-9c374964b83c
cmqp3j8rn00vyr54d84msrjjk	3EB0515E5A748370064AF3	203023255101512:75@lid	t	\N	\N	DELIVERY_ACK	cmqp3j7ff00vwr54dh73o1ncu	23d8699a-16ab-4406-9e59-9c374964b83c
cmqp3j8vm00w0r54d9dw83pzi	3EB0515E5A748370064AF3	203023255101512@lid	t	\N	\N	DELIVERY_ACK	cmqp3j7ff00vwr54dh73o1ncu	23d8699a-16ab-4406-9e59-9c374964b83c
cmqp3vcew00w2r54d8omfn6dw	3EB0515E5A748370064AF3	203023255101512@lid	t	\N	\N	SERVER_ACK	cmqp3j7ff00vwr54dh73o1ncu	23d8699a-16ab-4406-9e59-9c374964b83c
cmqq6tw5w00wcr54dgfj6wcy1	3EB090C7C1ACB736037DEE	112395133432025:38@lid	t	\N	\N	DELIVERY_ACK	cmqnxy8x800v7r54d484fnl57	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqdyp5g00wor54dnou3lp8y	3EB0A96821F2D4CB23FB99	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqqdyo2w00wmr54dpvdpc4w2	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqe8j8x00wsr54dedbolphb	3EB0BBAF7E5A6F2FDFB7FF	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqqe8is400wqr54dp8miv7al	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqe8lhc00wur54d9scehhlt	3EB0BBAF7E5A6F2FDFB7FF	113739474936038@lid	t	\N	\N	READ	cmqqe8is400wqr54dp8miv7al	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqga3w100wyr54dgjud72xm	3EB0193929E365E7935721	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqqga3dr00wwr54d2n58recd	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqga5vo00x0r54d7ku49eva	3EB0193929E365E7935721	113739474936038@lid	t	\N	\N	READ	cmqqga3dr00wwr54d2n58recd	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhe32i00x4r54duvuwqcqg	3EB09AB6CCA0679CBDD3CA	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqqhe2js00x2r54ddmfn2221	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhe3wn00x6r54dzo69u359	3EB09AB6CCA0679CBDD3CA	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqqhe2js00x2r54ddmfn2221	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhed0100x8r54dkwj2a8x4	3EB09AB6CCA0679CBDD3CA	113739474936038@lid	t	\N	\N	READ	cmqqhe2js00x2r54ddmfn2221	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhf9nb00xcr54d5ba38vsz	3EB033EE0CF793AD6EB30B	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqqhf96c00xar54dbxc534cb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhfb1g00xer54ds2pq9l5x	3EB033EE0CF793AD6EB30B	113739474936038@lid	t	\N	\N	READ	cmqqhf96c00xar54dbxc534cb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhfxf400xir54dqql2f5sb	3EB0D8ECF5A22A8120A0FF	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqqhfwzg00xgr54d9kb2wxav	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhj1rx00xkr54dzrz4st6d	3EB0D8ECF5A22A8120A0FF	113739474936038@lid	t	\N	\N	READ	cmqqhfwzg00xgr54d9kb2wxav	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhpayy00xor54di65kr8ds	3EB0A6BB06088EFCB698AE	112395133432025@lid	t	\N	\N	DELIVERY_ACK	cmqqhpahw00xmr54dn8gb59mu	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhwesk00xsr54dxkcq6qtp	3EB07777D38BC83D18D3F7	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqqhwed800xqr54dm0iajgsb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqhwlav00xur54dbiwr43lf	3EB07777D38BC83D18D3F7	113739474936038@lid	t	\N	\N	READ	cmqqhwed800xqr54dm0iajgsb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqold3v00xwr54df7b3xv7x	3EB0A96821F2D4CB23FB99	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqdyo2w00wmr54dpvdpc4w2	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolep200xyr54dy8v2y1pe	3EB0BBAF7E5A6F2FDFB7FF	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqe8is400wqr54dp8miv7al	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolgyd00y0r54dp6xbeycx	3EB0193929E365E7935721	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqga3dr00wwr54d2n58recd	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolhwv00y2r54dmxfshevy	3EB09AB6CCA0679CBDD3CA	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqhe2js00x2r54ddmfn2221	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolj4600y4r54de4hke1pv	3EB033EE0CF793AD6EB30B	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqhf96c00xar54dbxc534cb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolk5300y6r54d3bantklx	3EB0D8ECF5A22A8120A0FF	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqhfwzg00xgr54d9kb2wxav	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqolksn00y8r54d25fgg5yj	3EB0A6BB06088EFCB698AE	112395133432025@lid	t	\N	\N	SERVER_ACK	cmqqhpahw00xmr54dn8gb59mu	23d8699a-16ab-4406-9e59-9c374964b83c
cmqqollbn00yar54ddh4qmskh	3EB07777D38BC83D18D3F7	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqqhwed800xqr54dm0iajgsb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqrw8qab00ysr54dufl5g2mi	3EB0D14B47213EDCEF01A4	185486836560069@lid	t	\N	\N	DELIVERY_ACK	cmqrw8ps800yqr54dugr703lb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqrw8rxs00yur54dweskraqx	3EB0D14B47213EDCEF01A4	185486836560069:27@lid	t	\N	\N	READ	cmqrw8ps800yqr54dugr703lb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqs9eoi400z4r54d1h1vxwhz	3EB0D14B47213EDCEF01A4	185486836560069@lid	t	\N	\N	SERVER_ACK	cmqrw8ps800yqr54dugr703lb	23d8699a-16ab-4406-9e59-9c374964b83c
cmqsu8gmg00zir54drk2bbyku	3EB08C53D9B6890BF62046	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmqsu8fyl00zgr54dfxf3p0i1	23d8699a-16ab-4406-9e59-9c374964b83c
cmqsu8k4900zkr54d3aky74kg	3EB08C53D9B6890BF62046	113739474936038@lid	t	\N	\N	READ	cmqsu8fyl00zgr54dfxf3p0i1	23d8699a-16ab-4406-9e59-9c374964b83c
cmqsudh3700zmr54d724rlr8u	3EB08C53D9B6890BF62046	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmqsu8fyl00zgr54dfxf3p0i1	23d8699a-16ab-4406-9e59-9c374964b83c
cmqsvvomf00zrr54dwk3duook	3EB0889BB3DC0789D85941	139397676712143@lid	t	\N	\N	DELIVERY_ACK	cmqsvvn9u00zpr54d4jk9scqy	23d8699a-16ab-4406-9e59-9c374964b83c
cmqt8q9jy00ztr54dtkylf4nq	3EB08C53D9B6890BF62046	113739474936038@lid	t	\N	\N	SERVER_ACK	cmqsu8fyl00zgr54dfxf3p0i1	23d8699a-16ab-4406-9e59-9c374964b83c
cmqt8q9l900zvr54d9tw29f62	3EB0889BB3DC0789D85941	139397676712143@lid	t	\N	\N	SERVER_ACK	cmqsvvn9u00zpr54d4jk9scqy	23d8699a-16ab-4406-9e59-9c374964b83c
cmqteeu390101r54dh1p7i7i9	3EB0D9340B225D1441E6B6	112395133432025@lid	f	\N	\N	READ	cmqqb7xpg00wer54dcxp77ljw	23d8699a-16ab-4406-9e59-9c374964b83c
cmqtf6foo0103r54doxootc0d	3EB0889BB3DC0789D85941	139397676712143:19@lid	t	\N	\N	DELIVERY_ACK	cmqsvvn9u00zpr54d4jk9scqy	23d8699a-16ab-4406-9e59-9c374964b83c
cmr68gted013dr54d0q2y2w6l	3EB0FA7861A1C2C5DD4F9A	163513716719703@lid	t	\N	\N	DELIVERY_ACK	cmr68gral013br54dt04vuxv8	23d8699a-16ab-4406-9e59-9c374964b83c
cmr68rmqd013fr54ddg9f1cbq	3EB0FA7861A1C2C5DD4F9A	163513716719703@lid	t	\N	\N	DELIVERY_ACK	cmr68gral013br54dt04vuxv8	23d8699a-16ab-4406-9e59-9c374964b83c
cmr768jkb013pr54djvfm0b05	3EB0FA7861A1C2C5DD4F9A	163513716719703@lid	t	\N	\N	SERVER_ACK	cmr68gral013br54dt04vuxv8	23d8699a-16ab-4406-9e59-9c374964b83c
cmr93zl1c016qr54dmjww18m6	3EB0161925755BF2818C37	167929614229740@lid	t	\N	\N	DELIVERY_ACK	cmr93zkq4016mr54dkla5fadi	23d8699a-16ab-4406-9e59-9c374964b83c
cmr93zm7m016wr54d4u6ybah8	3EB010809B46CF8D606092	167929614229740@lid	t	\N	\N	DELIVERY_ACK	cmr93zlxr016sr54dkcw7g434	23d8699a-16ab-4406-9e59-9c374964b83c
cmr941hbs0172r54dic78l69o	3EB096C2E956F1EBBC5A9A	112395133432025:38@lid	t	\N	\N	DELIVERY_ACK	cmr941h15016yr54dj4v0jo8l	23d8699a-16ab-4406-9e59-9c374964b83c
cmr941nl70174r54dkuurgney	3EB010809B46CF8D606092	167929614229740:5@lid	t	\N	\N	DELIVERY_ACK	cmr93zlxr016sr54dkcw7g434	23d8699a-16ab-4406-9e59-9c374964b83c
cmr941nlc0176r54d0es02snx	3EB0161925755BF2818C37	167929614229740:5@lid	t	\N	\N	DELIVERY_ACK	cmr93zkq4016mr54dkla5fadi	23d8699a-16ab-4406-9e59-9c374964b83c
cmr945ft60178r54dhieyjzqd	3EB096C2E956F1EBBC5A9A	112395133432025:38@lid	t	\N	\N	DELIVERY_ACK	cmr941h15016yr54dj4v0jo8l	23d8699a-16ab-4406-9e59-9c374964b83c
cmr95lldc017er54dz3ox3xvt	A52A438152A631417D51CB7DD157DDD7	112395133432025@lid	t	\N	\N	DELIVERY_ACK	cmr95ll09017ar54dluoosvca	23d8699a-16ab-4406-9e59-9c374964b83c
cmrn7x05301a4r54dqqtmb8v6	3EB04019AB07459F3FE740	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmrn7wzpd01a2r54dtydibq71	23d8699a-16ab-4406-9e59-9c374964b83c
cmrn7z3ub01a6r54dbi3ztf51	3EB04019AB07459F3FE740	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmrn7wzpd01a2r54dtydibq71	23d8699a-16ab-4406-9e59-9c374964b83c
cmrn801i701a8r54d73bog4m9	3EB04019AB07459F3FE740	113739474936038@lid	t	\N	\N	READ	cmrn7wzpd01a2r54dtydibq71	23d8699a-16ab-4406-9e59-9c374964b83c
cmrn9tbkw01aar54dgphwogww	3EB04019AB07459F3FE740	113739474936038@lid	t	\N	\N	SERVER_ACK	cmrn7wzpd01a2r54dtydibq71	23d8699a-16ab-4406-9e59-9c374964b83c
cmrncftpz01agr54dtji7ebdz	3EB04019AB07459F3FE740	113739474936038:83@lid	t	\N	\N	DELIVERY_ACK	cmrn7wzpd01a2r54dtydibq71	23d8699a-16ab-4406-9e59-9c374964b83c
cmrrlkm8v01bir54dykc2c2y4	3EB0FA7861A1C2C5DD4F9A	163513716719703:88@lid	t	\N	\N	DELIVERY_ACK	cmr68gral013br54dt04vuxv8	23d8699a-16ab-4406-9e59-9c374964b83c
cms9xhd430003of4c2y8h61wm	3EB0751612AD81DF3D3726	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cms9xhck40001of4cmdtgmkuy	23d8699a-16ab-4406-9e59-9c374964b83c
cms9xhf5i0005of4cdoovqtem	3EB0751612AD81DF3D3726	113739474936038:84@lid	t	\N	\N	DELIVERY_ACK	cms9xhck40001of4cmdtgmkuy	23d8699a-16ab-4406-9e59-9c374964b83c
cms9xhi3q0007of4ccczy5djy	3EB0751612AD81DF3D3726	113739474936038@lid	t	\N	\N	READ	cms9xhck40001of4cmdtgmkuy	23d8699a-16ab-4406-9e59-9c374964b83c
cmsa2e7ob0001of4cqahw4bj2	3EB0751612AD81DF3D3726	113739474936038@lid	t	\N	\N	SERVER_ACK	cms9xhck40001of4cmdtgmkuy	23d8699a-16ab-4406-9e59-9c374964b83c
cmsk410e3002dof4cj79unt2c	3EB0F95BD35E0599E6A206	163513716719703@lid	t	\N	\N	DELIVERY_ACK	cmsk40y7l002bof4c8zq4ts78	23d8699a-16ab-4406-9e59-9c374964b83c
cmskozzwj002jof4cn8eowwrw	3EB0F95BD35E0599E6A206	163513716719703@lid	t	\N	\N	SERVER_ACK	cmsk40y7l002bof4c8zq4ts78	23d8699a-16ab-4406-9e59-9c374964b83c
cmskp3iea002nof4cbat0rlei	3EB02809839442E43B1383	113739474936038@lid	t	\N	\N	DELIVERY_ACK	cmskp3ht8002lof4cf4ze4fl9	23d8699a-16ab-4406-9e59-9c374964b83c
cmskp3jbl002pof4cro07hgyd	3EB02809839442E43B1383	113739474936038@lid	t	\N	\N	READ	cmskp3ht8002lof4cf4ze4fl9	23d8699a-16ab-4406-9e59-9c374964b83c
cmskpf69t002rof4cc3l1sr91	3EB02809839442E43B1383	113739474936038:84@lid	t	\N	\N	DELIVERY_ACK	cmskp3ht8002lof4cf4ze4fl9	23d8699a-16ab-4406-9e59-9c374964b83c
cmskpgqja002wof4cvf1a9rmq	3EB05328A3550F085BE988	115839730770167@lid	t	\N	\N	DELIVERY_ACK	cmskpgpcy002uof4cpj21ot3p	23d8699a-16ab-4406-9e59-9c374964b83c
cmskpjcjv002yof4cqb83w0e6	3EB05328A3550F085BE988	115839730770167:56@lid	t	\N	\N	DELIVERY_ACK	cmskpgpcy002uof4cpj21ot3p	23d8699a-16ab-4406-9e59-9c374964b83c
cmskuzzz00030of4cb30ibesi	3EB02809839442E43B1383	113739474936038@lid	t	\N	\N	SERVER_ACK	cmskp3ht8002lof4cf4ze4fl9	23d8699a-16ab-4406-9e59-9c374964b83c
cmskv00m50032of4clo1fr04d	3EB05328A3550F085BE988	115839730770167@lid	t	\N	\N	SERVER_ACK	cmskpgpcy002uof4cpj21ot3p	23d8699a-16ab-4406-9e59-9c374964b83c
cmsmodzz9003cof4cmpiihlod	3EB05328A3550F085BE988	115839730770167:51@lid	t	\N	\N	DELIVERY_ACK	cmskpgpcy002uof4cpj21ot3p	23d8699a-16ab-4406-9e59-9c374964b83c
cmssvdyuz004sof4c1t7d11cz	3EB0F95BD35E0599E6A206	163513716719703:88@lid	t	\N	\N	DELIVERY_ACK	cmsk40y7l002bof4c8zq4ts78	23d8699a-16ab-4406-9e59-9c374964b83c
\.


--
-- Data for Name: N8n; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."N8n" (id, enabled, description, "webhookUrl", "basicAuthUser", "basicAuthPass", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "splitMessages", "timePerChar", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: N8nSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."N8nSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "splitMessages", "timePerChar", "createdAt", "updatedAt", "n8nIdFallback", "instanceId") FROM stdin;
\.


--
-- Data for Name: Nats; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Nats" (id, enabled, events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: OpenaiBot; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."OpenaiBot" (id, "assistantId", model, "systemMessages", "assistantMessages", "userMessages", "maxTokens", expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "triggerType", "triggerOperator", "triggerValue", "createdAt", "updatedAt", "openaiCredsId", "instanceId", enabled, "botType", description, "functionUrl", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: OpenaiCreds; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."OpenaiCreds" (id, "apiKey", "createdAt", "updatedAt", "instanceId", name) FROM stdin;
\.


--
-- Data for Name: OpenaiSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."OpenaiSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "debounceTime", "ignoreJids", "createdAt", "updatedAt", "openaiCredsId", "openaiIdFallback", "instanceId", "speechToText", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: Proxy; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Proxy" (id, enabled, host, port, protocol, username, password, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: Pusher; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Pusher" (id, enabled, "appId", key, secret, cluster, "useTLS", events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: Rabbitmq; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Rabbitmq" (id, enabled, events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Session" (id, "sessionId", creds, "createdAt") FROM stdin;
cmqnw2w3y0003r54dnan90on8	23d8699a-16ab-4406-9e59-9c374964b83c	"{\\"noiseKey\\":{\\"private\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"SEIYsLiBTzz7xb/95SXt8TjyMhNWNXrrfbMgVPKpjFA=\\"},\\"public\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"Ig/i5fllP8zEfISflSt9FJ8zeGC+5qnYZnz19dDxbWo=\\"}},\\"pairingEphemeralKeyPair\\":{\\"private\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"wKiWNcXH10KZf3OTCrwhb6t/VYfobaowhidmNT8yv2I=\\"},\\"public\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"sTA/K/INe99kfq5rGN0yC76pFHKP6yHIZp68X4JQVzU=\\"}},\\"signedIdentityKey\\":{\\"private\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"SFgFGXhLfBpJIhz/uDl0PVKl+vA/6novLr9iuXgJOFY=\\"},\\"public\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"P/qSJdsr7FsNZN7uNFZh3HN/pdh4lyKjYWCebel6wFw=\\"}},\\"signedPreKey\\":{\\"keyPair\\":{\\"private\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"GOztpre7bB02hXLI3uOiGtg4B8m/Y61Ok7CJaz8yH3w=\\"},\\"public\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"S+So2qI+G++phNQLGT2lCWvZCfZkSYc6cUhNdT+K8R4=\\"}},\\"signature\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"NFVIuwbV/wVnsLlP+moRh/WnoTG3ZueknWFVdJnHJD844VBrs5MLFX3rpxpFRZjY5J7BUnTY/9v1FdgpWqYujQ==\\"},\\"keyId\\":1},\\"registrationId\\":27,\\"advSecretKey\\":\\"S999q6u/vJ2YtH4oe5PwxF9jPbPmXkKAT18O92WKeUM=\\",\\"processedHistoryMessages\\":[{\\"key\\":{\\"remoteJid\\":\\"6281337887161@s.whatsapp.net\\",\\"fromMe\\":false,\\"id\\":\\"A5F5CD5D824247979112930B26CD97EF\\",\\"participant\\":\\"\\",\\"addressingMode\\":\\"pn\\"},\\"messageTimestamp\\":1782052608},{\\"key\\":{\\"remoteJid\\":\\"6281337887161@s.whatsapp.net\\",\\"fromMe\\":false,\\"id\\":\\"A577DD2E3E951D813C2423BC4CF2B473\\",\\"participant\\":\\"\\",\\"addressingMode\\":\\"pn\\"},\\"messageTimestamp\\":1782052608},{\\"key\\":{\\"remoteJid\\":\\"6281337887161@s.whatsapp.net\\",\\"fromMe\\":false,\\"id\\":\\"A586E0452F31BFB76D0EBE45DB44FF46\\",\\"participant\\":\\"\\",\\"addressingMode\\":\\"pn\\"},\\"messageTimestamp\\":1782052608},{\\"key\\":{\\"remoteJid\\":\\"6281337887161@s.whatsapp.net\\",\\"fromMe\\":false,\\"id\\":\\"A52ED7DC940ABF2086EE6F5F67C81B4A\\",\\"participant\\":\\"\\",\\"addressingMode\\":\\"pn\\"},\\"messageTimestamp\\":1782052609},{\\"key\\":{\\"remoteJid\\":\\"6281337887161@s.whatsapp.net\\",\\"fromMe\\":false,\\"id\\":\\"A5DB1BDA68E43BB8D886A0AAEFD64092\\",\\"participant\\":\\"\\",\\"addressingMode\\":\\"pn\\"},\\"messageTimestamp\\":1782052612}],\\"nextPreKeyId\\":813,\\"firstUnuploadedPreKeyId\\":813,\\"accountSyncCounter\\":1,\\"accountSettings\\":{\\"unarchiveChats\\":false},\\"registered\\":false,\\"account\\":{\\"details\\":\\"COzNj8YDEPrt39EGGAEgACgA\\",\\"accountSignatureKey\\":\\"L7CYQhfY46+58vYX/FLfuOmSc9aUKeosADzx7VB66zo=\\",\\"accountSignature\\":\\"SMmguck+L0+BksetrDpFLHjrsQU5ZCnKZ8iDmPThgrpJFB4I38c81dxZwrXZGIzD2SjpO99+KWLokZ+uHtX9AQ==\\",\\"deviceSignature\\":\\"LI3AuYY4ySxwZYyI1M7A+ga3+iN3w8oEWahHtmjMMt5vWVFHE8qT4tj8/dVHM02F2fhBJECIE5S1kw7KVH1Qjw==\\"},\\"me\\":{\\"id\\":\\"6281337887161:5@s.whatsapp.net\\",\\"name\\":\\"Paradapp\\",\\"lid\\":\\"150109325156451:5@lid\\"},\\"signalIdentities\\":[{\\"identifier\\":{\\"name\\":\\"150109325156451:5@lid\\",\\"deviceId\\":0},\\"identifierKey\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"BS+wmEIX2OOvufL2F/xS37jpknPWlCnqLAA88e1Qeus6\\"}}],\\"platform\\":\\"smba\\",\\"routingInfo\\":{\\"type\\":\\"Buffer\\",\\"data\\":\\"CAIIBQgI\\"},\\"lastAccountSyncTimestamp\\":1786636660,\\"myAppStateKeyId\\":\\"AAAAAENG\\"}"	2026-06-21 14:35:55.535
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Setting" (id, "rejectCall", "msgCall", "groupsIgnore", "alwaysOnline", "readMessages", "readStatus", "syncFullHistory", "createdAt", "updatedAt", "instanceId", "wavoipToken") FROM stdin;
cmqnw2vzs0001r54d9wkwlqz1	f		f	f	f	f	f	2026-06-21 14:35:55.384	2026-06-21 14:35:55.384	23d8699a-16ab-4406-9e59-9c374964b83c	
\.


--
-- Data for Name: Sqs; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Sqs" (id, enabled, events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: Template; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Template" (id, "templateId", name, template, "createdAt", "updatedAt", "instanceId", "webhookUrl") FROM stdin;
\.


--
-- Data for Name: Typebot; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Typebot" (id, enabled, url, typebot, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "createdAt", "updatedAt", "triggerType", "triggerOperator", "triggerValue", "instanceId", "debounceTime", "ignoreJids", description, "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: TypebotSetting; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."TypebotSetting" (id, expire, "keywordFinish", "delayMessage", "unknownMessage", "listeningFromMe", "stopBotFromMe", "keepOpen", "createdAt", "updatedAt", "instanceId", "debounceTime", "typebotIdFallback", "ignoreJids", "splitMessages", "timePerChar") FROM stdin;
\.


--
-- Data for Name: Webhook; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Webhook" (id, url, enabled, events, "webhookByEvents", "webhookBase64", "createdAt", "updatedAt", "instanceId", headers) FROM stdin;
\.


--
-- Data for Name: Websocket; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution."Websocket" (id, enabled, events, "createdAt", "updatedAt", "instanceId") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: evolution; Owner: paradapp_user
--

COPY evolution._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
0ef7e99e-382c-48d9-bd46-1ac061deb1ff	1af30cbbccd90152fbb1b99a458978e42428a792b822b4b5f9c9c7fffbf7264f	2026-06-21 14:35:44.801284+00	20240819154941_add_context_to_integration_session	\N	\N	2026-06-21 14:35:44.798374+00	1
aa620bc6-bc01-4f94-b146-797b407c3bcf	7507eff6b49fad53cdd0b3ace500f529597dfa1a8987afbb9807968a8ee8ef49	2026-06-21 14:35:44.551499+00	20240609181238_init	\N	\N	2026-06-21 14:35:44.42365+00	1
04c33861-e2fa-47d5-948d-75969510b160	8c2a595975dc2f6dee831983304996e25c37014c48291576e7c8044078bfde32	2026-06-21 14:35:44.660099+00	20240722173259_add_name_column_to_openai_creds	\N	\N	2026-06-21 14:35:44.654067+00	1
e1793ec3-0fe0-4e42-bd5e-b087dd6566d6	914eeefb9eba0dacdbcb7cdbe47567abd957543d6f27c39db4eec6a40c864008	2026-06-21 14:35:44.556731+00	20240610144159_create_column_profile_name_instance	\N	\N	2026-06-21 14:35:44.552221+00	1
44b951bf-445e-4420-9c33-41ec15b5f6e2	50d6920345af06dbd5086959784b7e2b4d163a5b555ff1029e5f81678a454444	2026-06-21 14:35:44.560438+00	20240611125754_create_columns_whitelabel_chatwoot	\N	\N	2026-06-21 14:35:44.557473+00	1
077b2806-1920-42db-b535-d569dda42161	c29ccc88930138c50091712466f3f97bff48f6a0f486dcec5b19dc08c3612973	2026-06-21 14:35:44.71145+00	20240729180347_modify_typebot_session_status_openai_typebot_table	\N	\N	2026-06-21 14:35:44.696256+00	1
c1a32aa2-3361-418d-b9d0-e6cf909601ac	b90c49299ed812fb46b71a4f0b9f818b7fc7109c52b1aff227a107236839d93c	2026-06-21 14:35:44.564041+00	20240611202817_create_columns_debounce_time_typebot	\N	\N	2026-06-21 14:35:44.561241+00	1
415f9b70-60bb-42dc-bb51-80a066cc0adc	20b3c04d93799c25fa8b2d0a85d10f9280e915a5d7519542492ed85ff082a3c0	2026-06-21 14:35:44.663431+00	20240722173518_add_name_column_to_openai_creds	\N	\N	2026-06-21 14:35:44.660742+00	1
dc036465-2c5d-4225-a57a-c6f4d68752d3	01303057a037f5dc28272ac513b60d5a75be71d1bf727e671ca538db3268fa2e	2026-06-21 14:35:44.567022+00	20240712144948_add_business_id_column_to_instances	\N	\N	2026-06-21 14:35:44.564606+00	1
db410176-2397-409a-ba91-1149b42a998e	34235c250eb1f088c285489ad690b4c045680f1638076436cdc66de0ea382cc2	2026-06-21 14:35:44.582374+00	20240712150256_create_templates_table	\N	\N	2026-06-21 14:35:44.567645+00	1
c5ecc92d-8bb4-4ee3-906d-2e0ed45ed828	0ba192ba428c9ab5a9b31d1f7d73603ee47b6192e2f8c590f6d93ade0dbdbccf	2026-06-21 14:35:44.586596+00	20240712155950_adjusts_in_templates_table	\N	\N	2026-06-21 14:35:44.583024+00	1
65b275be-474d-4b71-b01f-ea9003104c59	7ffb91b84cb7aa17b1f488d580626144cd557ccdfaec6654515545401d1938af	2026-06-21 14:35:44.66894+00	20240723152648_adjusts_in_column_openai_creds	\N	\N	2026-06-21 14:35:44.664026+00	1
7df05db5-cfd7-48ad-bb77-a7c92c192630	426256b73f7ea52538dc91a890179c841325a9c387cf02885b81971d582af830	2026-06-21 14:35:44.591746+00	20240712162206_remove_templates_table	\N	\N	2026-06-21 14:35:44.587359+00	1
88db91aa-5d8b-49a8-9110-be33b72c4fd3	3496739609829e80daf733baecd3d3e4e279bf318a99adc1ca3aa1c76f893b2f	2026-06-21 14:35:44.59651+00	20240712223655_column_fallback_typebot	\N	\N	2026-06-21 14:35:44.592401+00	1
2f43795d-0fe2-4a8a-9a11-de3323b24c88	c8627bad5d72ee4ef774ed32c95a2524517b0c60c49fa67cd4ba9dff7cbdde3b	2026-06-21 14:35:44.757157+00	20240811021156_add_chat_name_column	\N	\N	2026-06-21 14:35:44.753176+00	1
868f2ec4-a159-4be8-9f4a-2d21cb38785e	bea48f697c0c5db52ade4a3f26c1321e3f5611c80ea50384baa54e58c6b3a79e	2026-06-21 14:35:44.599804+00	20240712230631_column_ignore_jids_typebot	\N	\N	2026-06-21 14:35:44.597215+00	1
4ae12a72-98c8-48fd-a389-047637f9e9ad	3056f8f1335e8933e4098f005e33cd4821190be2eb76520c0d01e2e13cf6e073	2026-06-21 14:35:44.672215+00	20240723200254_add_webhookurl_on_message	\N	\N	2026-06-21 14:35:44.669571+00	1
d692702a-8512-4f39-9814-8370de7ffe3f	1bac56740af5d2d6512b29e7a6e0721d69b2a290400f6660b92b6f2d8b30cd6e	2026-06-21 14:35:44.613788+00	20240713184337_add_media_table	\N	\N	2026-06-21 14:35:44.600448+00	1
32502022-725a-4791-a763-437011ea8126	bdd992b253321ca9a9556e30fea5e7760556cb8e80140aec34066301b55dc675	2026-06-21 14:35:44.649604+00	20240718121437_add_openai_tables	\N	\N	2026-06-21 14:35:44.614543+00	1
34ff0458-1e1c-45f3-bd7b-7cebed5b99d0	961a8627684fe1e4c7123565db3d16db30768df41881342032f9a2df16145eaf	2026-06-21 14:35:44.740356+00	20240730152156_create_dify_tables	\N	\N	2026-06-21 14:35:44.712193+00	1
7121201f-5651-4883-aee8-ad1d47e22ab7	8147ec0cc86ac30ea1be05d461559ba5064273a3fcb3227af71ddcd895f5aebe	2026-06-21 14:35:44.653374+00	20240718123923_adjusts_openai_tables	\N	\N	2026-06-21 14:35:44.650365+00	1
1be2305a-9cc5-4d33-90e8-859d915ace93	9d6c9b4ffe51483a851f6507f7aefd2fb34f54a7c28961856e3230fda4f87022	2026-06-21 14:35:44.685388+00	20240725184147_create_template_table	\N	\N	2026-06-21 14:35:44.67282+00	1
a0fa4bd1-5846-4182-867b-ce30f6763e76	94e2edb21107895c77b24402f41cd020c7f74dbb39b9a95664a45e62e2582be9	2026-06-21 14:35:44.689188+00	20240725202651_add_webhook_url_template_table	\N	\N	2026-06-21 14:35:44.686076+00	1
356653a9-a179-4bc4-92ca-a628e3d49d38	d0da588e4204c50bde2e41a615b9301afca072991033545b6f4e3e34e088db87	2026-06-21 14:35:44.692659+00	20240725221646_modify_token_instance_table	\N	\N	2026-06-21 14:35:44.689863+00	1
dca0afac-9f9d-42b9-bb46-0463f31a0461	b56b053451d564ff6282078fad4fc7bff4aa71e3b0b8d00bf219da4ed1bc4c86	2026-06-21 14:35:44.744525+00	20240801193907_add_column_speech_to_text_openai_setting_table	\N	\N	2026-06-21 14:35:44.741253+00	1
3da11be7-fc06-4659-939a-d6bb621f29dc	a80f5c27cd80d088ea69153f8d6f4879406770ffa5a7fd50b28da82bd020322e	2026-06-21 14:35:44.6956+00	20240729115127_modify_trigger_type_openai_typebot_table	\N	\N	2026-06-21 14:35:44.693338+00	1
f6fff8da-c823-4a92-a0b2-36e413c4e602	428a9148f2a29f773e0c9813149e6d07bf51765e018652aeac0be2141a722b67	2026-06-21 14:35:44.772761+00	20240814173033_add_ignore_jids_chatwoot	\N	\N	2026-06-21 14:35:44.769874+00	1
96161510-ea19-49e8-b9f2-7da174bbcd95	2b963cbc826ea024f9a643af2d5d9fcea06717c90ec9bacb255d3836efa06aea	2026-06-21 14:35:44.749146+00	20240803163908_add_column_description_on_integrations_table	\N	\N	2026-06-21 14:35:44.745296+00	1
3c07f434-985e-4533-aae4-f4a4e21960e1	ee44f0420384d55de6d252fffb8f2cfa88479e5811e14cfe975d8edfcc6957e0	2026-06-21 14:35:44.763486+00	20240811183328_add_unique_index_for_remoted_jid_and_instance_in_contacts	\N	\N	2026-06-21 14:35:44.757856+00	1
f4745cf4-f22f-4d8d-8f53-c4f05c4a3192	4d2dd947ebb7515c7c278472a10ebab6d5f41a5ef60e15df717a05d457d5d2aa	2026-06-21 14:35:44.752459+00	20240808210239_add_column_function_url_openaibot_table	\N	\N	2026-06-21 14:35:44.7498+00	1
8d4b4149-1d33-4bb9-a231-ca1b422506e9	29c330029a48aaee63567e63c4f4e57b7c1f5344162b11fbf61a4dc194547861	2026-06-21 14:35:44.769155+00	20240813003116_make_label_unique_for_instance	\N	\N	2026-06-21 14:35:44.764197+00	1
5214fbb4-8a0b-4340-8197-e297d8d61e53	bc5cd1c7fb4df72e88cb4856c9c49ea340284c9d8f389fe558008a921494ed82	2026-06-21 14:35:44.797433+00	20240817110155_add_trigger_type_advanced	\N	\N	2026-06-21 14:35:44.794289+00	1
bbe48416-5028-4d69-899c-6cf5ec81d4c6	e1eb8997ac99fd555b8a9241c817b97fa5614124922b4e6b3cb1751e9e2199c7	2026-06-21 14:35:44.793527+00	20240814202359_integrations_unification	\N	\N	2026-06-21 14:35:44.773595+00	1
9aac9e71-b3c2-4926-8ea2-7b82e5a48d63	a363a9ebc5bb526e504c4e6f71ed7702a5b6d317db6a9981f36c4560f9147fba	2026-06-21 14:35:44.806383+00	20240821120816_bot_id_integration_session	\N	\N	2026-06-21 14:35:44.802026+00	1
4ea608c1-3d3c-4784-9e16-ffb48f3c8cd2	e31947e6c709ee3a62504980ae9ab1ffbfd9faf0cf9ac389cfd6435734c49902	2026-06-21 14:35:44.824199+00	20240821171327_add_generic_bot_table	\N	\N	2026-06-21 14:35:44.807181+00	1
70856fc5-a64c-4637-82ad-826eb418bc7c	18dde8e48c49a97f33f5b789ccd919326253c26d43af72c77f6b13d4285ffba8	2026-06-21 14:35:44.847635+00	20240821194524_add_flowise_table	\N	\N	2026-06-21 14:35:44.825191+00	1
56d9489c-0365-466d-9f3e-01767d09f002	0148a09e0e5eedafe5c5169c6351201a5c70ebaa853456693d75a7b82a851dbe	2026-06-21 14:35:44.852449+00	20240824161333_add_type_on_integration_sessions	\N	\N	2026-06-21 14:35:44.848713+00	1
a7499db0-2c2a-423c-ba88-fa86e3a8fc27	710e7ee3aabf07aa6ee9bf2865c09f75d461efa5724dd83f5a6f324ea1e5e47c	2026-06-21 14:35:44.880553+00	20240825130616_change_to_evolution_bot	\N	\N	2026-06-21 14:35:44.853868+00	1
a67122e1-95e7-4d7b-afe6-ec7a8b503451	0a6034359b1cf68820e829d31402032eed0f77586fb1ee590a98f5a6c3e15847	2026-06-21 14:35:45.04734+00	20250514232744_add_n8n_table	\N	\N	2026-06-21 14:35:45.024571+00	1
e16cea35-8ade-4a7a-bd60-12820c6c6649	d03a8a31df36eb0a07e80cd2a149b6d826e69bb2cb21fbe69943ae5ffba672ad	2026-06-21 14:35:44.893157+00	20240828140837_add_is_on_whatsapp_table	\N	\N	2026-06-21 14:35:44.881518+00	1
494b6a86-7934-46b2-878f-b42d7bebd7f8	e927e00343b622bee7dab1b9b5c9fdd95007bfaf9d705ec52db9ecb05fb3d078	2026-06-21 14:35:44.897454+00	20240828141556_remove_name_column_from_on_whatsapp_table	\N	\N	2026-06-21 14:35:44.894062+00	1
f7cc8d21-3aad-4c4e-9a67-a395008ea242	cf00d8ef2c28cf94aea51e7e2a80ddd65474a4f6c1113abc65dea6cc194c1a57	2026-06-21 14:35:44.914173+00	20240830193533_changed_table_case	\N	\N	2026-06-21 14:35:44.89826+00	1
e6ccf5e2-f631-4d41-9177-9d43d488f722	f9ddf352b22e52a1f466d40df95da7bd6f4bf51310c07911d9c990f720e1fe81	2026-06-21 14:35:45.073501+00	20250515211815_add_evoai_table	\N	\N	2026-06-21 14:35:45.048418+00	1
31c13e13-98fa-420e-98fc-cbe1bc2d25fa	1cc60b9c38db62b694f753e2ee4c155e95c66815b5800f6ddb6f7cddec23b1ad	2026-06-21 14:35:44.927228+00	20240906202019_add_headers_on_webhook_config	\N	\N	2026-06-21 14:35:44.914985+00	1
7c38075d-312a-4102-b094-467604c1a0e2	7dff7227c1e013127210ab4f77b91dc24eae14bcd07f21fb27aaa2fa82b23865	2026-06-21 14:35:44.934383+00	20241001180457_add_message_status	\N	\N	2026-06-21 14:35:44.928496+00	1
c1bb021f-c13a-40c1-a7f8-e8c475c6f54d	07449acbac59175f82670f34664c1dcea4d34f9a1710f19bd3396e26868db09e	2026-06-21 14:35:44.948939+00	20241006130306_alter_status_on_message_table	\N	\N	2026-06-21 14:35:44.93575+00	1
1880419b-814e-46e4-9877-39956b64ed6a	7a03627d41844a016b28b4194e36eea0e52cd24be0061535fecba4ccbd0e72f4	2026-06-21 14:35:45.079752+00	20250516012152_remove_unique_atribute_for_file_name_in_media	\N	\N	2026-06-21 14:35:45.074682+00	1
3bd53878-bc08-4b70-90ce-a809e6424c29	7e9a7c45f05285e9fea38ccfa4266790a099107605299d81c309e689c06494ef	2026-06-21 14:35:44.954735+00	20241007164026_add_unread_messages_on_chat_table	\N	\N	2026-06-21 14:35:44.950279+00	1
be6e923a-22f6-4927-9c0a-36a2f44a10ce	7e3e4686eb8009cbf0f71e8606a442b1c2862673dbc654b3f36f39a36efcb586	2026-06-21 14:35:44.971042+00	20241011085129_create_pusher_table	\N	\N	2026-06-21 14:35:44.95626+00	1
9ef01ae6-e3d3-4562-aa1b-454c08d3af24	270e1e51c7b9d24c0e68708ad167cb5748d591fd194ad422486574a0e83c0b79	2026-06-21 14:35:44.978343+00	20241011100803_split_messages_and_time_per_char_integrations	\N	\N	2026-06-21 14:35:44.971781+00	1
eefe399b-9eb0-4842-8704-57aeba29ca6e	3fca4961d4e7fa8e1a99e3ec6b072d235bec706b7463ab699887be1084e3b656	2026-06-21 14:35:45.087928+00	20250612155048_add_coluns_trypebot_tables	\N	\N	2026-06-21 14:35:45.08172+00	1
1e8c4478-d1d0-4895-a50b-1a4a02109f1e	e82282df963a32556a9c8cd5fd908dd5810d4c35f0d7765ab9e844ebad1106a2	2026-06-21 14:35:45.004595+00	20241017144950_create_index	\N	\N	2026-06-21 14:35:44.979027+00	1
0d56f11c-e87f-4250-9993-6064d269fa4c	668e44d3cd8caafa8f60f89805e9f80587c1c69b4d52a21dfc79f4b615125b1c	2026-06-21 14:35:45.010477+00	20250116001415_add_wavoip_token_to_settings_table	\N	\N	2026-06-21 14:35:45.006441+00	1
6c75288d-c5a4-44f2-ba5e-8a2f1643ca23	17983175f27c61a0ee6aaa42c94d665cabb7e904ee91c33f867c657512210e1a	2026-06-21 14:35:45.023634+00	20250225180031_add_nats_integration	\N	\N	2026-06-21 14:35:45.011493+00	1
832db734-1112-4926-9e5c-9ab4054bc452	36a19fe7711b98d02b450aedb2de8802b5e2e635a1e530cbc42f1d184e89bec3	2026-06-21 14:35:45.093488+00	20250613143000_add_lid_column_to_is_onwhatsapp	\N	\N	2026-06-21 14:35:45.088807+00	1
5c9eb3c3-0713-4464-b610-45ae71d89883	2b9d50b837a154ee3a74284c130b21fbe10ecddc1159cb29dac74c4ba4cb6a5f	2026-06-21 14:35:45.107974+00	20250918182355_add_kafka_integration	\N	\N	2026-06-21 14:35:45.094501+00	1
ba3dacea-de60-4ff6-aad2-91c0d32c0045	84053d218d69e85953f7533bbfced9171e762c02c88ab944aaaa75b17f18e161	2026-06-21 14:35:45.117281+00	20251122003044_add_chat_instance_remotejid_unique	\N	\N	2026-06-21 14:35:45.108848+00	1
\.


--
-- Data for Name: Dapp; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."Dapp" (id, name, description, url, "logoPath", "favoriteCount", "createdAt", network, description_idn) FROM stdin;
3	SentX	An NFT marketplace on Hedera where users can discover, buy, sell, and launch digital collectible collections.	https://sentx.io	sentx-1773182423909.png	2	2026-03-14 09:40:30.868+00	HEDERA	Pasar NFT di Hedera tempat pengguna dapat menemukan, membeli, menjual, dan meluncurkan koleksi digital.
2	SaucerSwap	The premier AMM and decentralized exchange on Hedera, enabling seamless token swaps, liquidity provision, and yield generation with fast finality and low fees.	https://www.saucerswap.finance/	saucerswap-1773182237765.png	4	2026-03-14 09:40:11.537+00	HEDERA	AMM dan bursa terdesentralisasi utama di Hedera, memungkinkan pertukaran token, penyediaan likuiditas, dan penghasilan imbal hasil yang mulus dengan finalitas cepat dan biaya rendah.
1	Kabila	An all-in-one Web3 platform on Hedera that enables creators and communities to create, launch, and manage tokens and NFTs.	https://kabila.app/	kabila-1773181958059.png	3	2026-03-14 09:39:46.671+00	HEDERA	Platform Web3 lengkap di Hedera yang memungkinkan pencipta dan komunitas untuk membuat, meluncurkan, dan mengelola token serta NFT.
4	Bonzo Finance	A decentralized lending and borrowing protocol on Hedera that enables users to supply assets, borrow against collateral, and earn yield in DeFi.	https://bonzo.finance	bonzo-finance-1773182531556.png	7	2026-03-14 09:40:48.758+00	HEDERA	Protokol peminjaman terdesentralisasi di Hedera yang memungkinkan pengguna menyetor aset, meminjam dengan jaminan, dan mendapatkan imbal hasil di DeFi.
8	Meteora	A next-generation liquidity protocol on Solana enabling efficient token swaps, dynamic liquidity provision, and optimized yield strategies.	https://www.meteora.ag/	meteora-1777540805047.png	1	2026-04-30 09:20:05.392+00	SOLANA	Protokol likuiditas generasi berikutnya di Solana yang memungkinkan pertukaran token yang efisien, penyediaan likuiditas dinamis, dan strategi imbal hasil yang dioptimalkan.
9	Solana Stake	A staking solution on Solana enabling users to earn rewards through standard staking, liquid staking, and stablecoin staking in a unified experience.	solana-stake	solana-stake-1777561623640.png	6	2026-04-30 15:07:05.515+00	SOLANA	Solusi staking di Solana yang memungkinkan pengguna untuk mendapatkan imbal hasil melalui staking standar, liquid staking, dan staking stablecoin dalam satu pengalaman terpadu.
11	US Stocks	Access, buy, and trade tokenized U.S. stocks and ETFs on-chain with 24/7 market availability and DeFi integration.	solana-tokenized-stocks	us-stocks-1777564183479.png	5	2026-04-30 15:49:45.262+00	SOLANA	Akses, beli, dan perdagangkan saham dan ETF AS yang ditokenisasi secara on-chain dengan ketersediaan pasar 24/7 dan integrasi DeFi.
7	MetaDAO	A decentralized launchpad and governance platform enabling projects to raise capital and operate through market-driven decision making.	https://www.metadao.fi/	metadao-1777540620012.png	1	2026-04-30 09:17:00.39+00	SOLANA	Platform launchpad dan tata kelola terdesentralisasi yang memungkinkan proyek untuk mengumpulkan modal dan beroperasi melalui pengambilan keputusan berbasis pasar.
6	Magic Eden	A leading multi-chain NFT marketplace enabling users to discover, trade, and create digital assets with fast transactions and low fees.	https://magiceden.io/	magic-eden-1777539583151.png	1	2026-04-30 08:59:44.437+00	SOLANA	Pasar NFT multi-chain terkemuka yang memungkinkan pengguna untuk menemukan, memperdagangkan, dan membuat aset digital dengan transaksi cepat dan biaya rendah.
10	Solana Swap	A token swap platform on Solana enabling seamless trading, optimal price discovery, and efficient access to liquidity across the ecosystem.	solana-swap	solana-swap-1777562123112.png	5	2026-04-30 15:14:35.833+00	SOLANA	Platform pertukaran token di Solana yang memungkinkan perdagangan yang mulus, penemuan harga yang optimal, dan akses efisien ke likuiditas di seluruh ekosistem.
12	BETA	A tokenized portfolio asset providing diversified exposure to global equities, commodities, digital assets, and cash within a single on-chain investment product.	beta-global-index	beta-1778512066480.png	4	2026-05-11 15:07:46.927+00	SOLANA	Aset portofolio yang ditokenisasi untuk memberikan eksposur terdiversifikasi pada ekuitas global, komoditas, aset digital, dan uang tunai dalam satu produk investasi on-chain.
\.


--
-- Data for Name: DappFeature; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."DappFeature" (id, title, description, "dappId", description_idn, title_idn) FROM stdin;
89	NFT Marketplace	Users can explore, buy, and sell NFTs across various collections through a marketplace that supports listings, offers, auctions, and asset management tools.	3	Pengguna dapat menjelajahi, membeli, dan menjual NFT di berbagai koleksi melalui pasar yang mendukung pendaftaran, penawaran, lelang, dan alat manajemen aset.	Pasar NFT
90	Non-Custodial Trading	SentX operates in a non-custodial model where NFTs and funds remain in users wallets, enabling peer-to-peer transactions while maintaining full control of digital assets.	3	SentX beroperasi dalam model non-kustodian di mana NFT dan dana tetap berada di dompet pengguna, memungkinkan transaksi peer-to-peer sambil mempertahankan kendali penuh atas aset digital.	Perdagangan Non-Kustodian
91	NFT Launchpad for Creators	Creators can launch NFT collections through built-in tools that support minting, whitelisting, and project launches, helping projects distribute NFTs directly to their communities.	3	Pencipta dapat meluncurkan koleksi NFT melalui alat bawaan yang mendukung pencetakan (minting), whitelisting, dan peluncuran proyek, membantu proyek mendistribusikan NFT langsung ke komunitas mereka.	Launchpad NFT untuk Pencipta
92	Concentrated Liquidity (V2)	SaucerSwap V2 introduces concentrated liquidity, allowing liquidity providers to allocate capital within specific price ranges. This significantly improves capital efficiency and enables deeper liquidity for traders.	2	SaucerSwap V2 memperkenalkan likuiditas terkonsentrasi, yang memungkinkan penyedia likuiditas untuk mengalokasikan modal dalam rentang harga tertentu. Ini secara signifikan meningkatkan efisiensi modal dan memungkinkan likuiditas yang lebih dalam bagi pedagang.	Likuiditas Terkonsentrasi (V2)
93	Fair and Secure Trading	Built on Hedera’s asynchronous Byzantine Fault Tolerant (aBFT) consensus, SaucerSwap helps reduce risks such as front-running and MEV (Maximal Extractable Value), creating a more transparent and fair trading environment.	2	Dibangun di atas konsensus asynchronous Byzantine Fault Tolerant (aBFT) Hedera, SaucerSwap membantu mengurangi risiko seperti front-running dan MEV (Maximal Extractable Value), menciptakan lingkungan perdagangan yang lebih transparant dan adil.	Perdagangan yang Adil dan Aman
94	Single-Sided Staking	Users can stake the native SAUCE token in the Infinity Pool to earn a share of protocol fees without needing to provide liquidity pairs, allowing them to generate yield without exposure to impermanent loss.	2	Pengguna dapat melakukan staking token asli SAUCE di Infinity Pool untuk mendapatkan bagian dari biaya protokol tanpa perlu menyediakan pasangan likuiditas, memungkinkan mereka menghasilkan imbal hasil tanpa risiko impermanent loss.	Staking Satu Sisi
95	NFT Creation and Launch Tools	Kabila provides simple tools that allow creators and brands to easily create, launch, and manage NFT collections without requiring technical knowledge.	1	Kabila menyediakan alat sederhana yang memungkinkan pencipta dan merek untuk dengan mudah membuat, meluncurkan, dan mengelola koleksi NFT tanpa memerlukan pengetahuan teknis.	Alat Pembuatan dan Peluncuran NFT
96	NFT Marketplace	Users can buy, sell, and trade NFTs within the Kabila ecosystem, providing a dedicated marketplace for digital collectibles built on the Hedera network.	1	Pengguna dapat membeli, menjual, dan memperdagangkan NFT dalam ekosistem Kabila, menyediakan pasar khusus untuk koleksi digital yang dibangun di jaringan Hedera.	Pasar NFT
97	Tokenized Communities (Plazas)	Kabila enables creators to build token-gated community spaces where members can access exclusive content, events, and interactions.	1	Kabila memungkinkan pencipta untuk membangun ruang komunitas yang dipagari token (token-gated) di mana anggota dapat mengakses konten, acara, dan interaksi eksklusif.	Komunitas Ter-tokenisasi (Plaza)
86	Decentralized Lending & Borrowing	Users can supply crypto assets to liquidity pools to earn interest or borrow assets by depositing collateral, enabling open and permissionless credit markets on the Hedera network.	4	Pengguna dapat menyetor aset kripto ke kolam likuiditas untuk mendapatkan bunga atau meminjam aset dengan menyetorkan jaminan, memungkinkan pasar kredit terbuka dan tanpa izin di jaringan Hedera.	Peminjaman Terdesentralisasi
87	Liquidity Pools & Yield Opportunities	Assets deposited into Bonzo liquidity pools generate yield for lenders while providing available liquidity for borrowers across the Hedera DeFi ecosystem.	4	Aset yang disetorkan ke dalam kolam likuiditas Bonzo menghasilkan imbal hasil bagi pemberi pinjaman sekaligus menyediakan likuiditas bagi peminjam di seluruh ekosistem DeFi Hedera.	Kolam Likuiditas & Peluang Imbal Hasil
88	Advanced DeFi Tools	Bonzo Finance supports advanced DeFi functionality such as flash loans and automated liquidation mechanisms, enabling more complex trading strategies and helping maintain the health of lending markets.	4	Bonzo Finance mendukung fungsionalitas DeFi canggih seperti flash loans dan mekanisme likuidasi otomatis, memungkinkan strategi perdagangan yang lebih kompleks dan membantu menjaga kesehatan pasar peminjaman.	Alat DeFi Canggih
98	NFT Trading & Discovery	Magic Eden enables users to explore, buy, and sell NFTs across various categories, offering a smooth marketplace experience with intuitive browsing and collection discovery.	6	Magic Eden memungkinkan pengguna untuk menjelajahi, membeli, dan menjual NFT di berbagai kategori, menawarkan pengalaman pasar yang lancar dengan penelusuran intuitif dan penemuan koleksi.	Perdagangan & Penemuan NFT
99	Creator Launchpad & Minting	The platform provides tools for creators to mint and launch NFT collections, lowering the barrier to entry and supporting project growth within the Web3 ecosystem.	6	Platform ini menyediakan alat bagi para pencipta untuk mencetak dan meluncurkan koleksi NFT, menurunkan hambatan masuk dan mendukung pertumbuhan proyek dalam ekosistem Web3.	Launchpad Pencipta & Pencetakan (Minting)
100	Multi-Chain Support & Low Fees	Magic Eden supports multiple blockchain networks and is known for its low transaction costs, enabling efficient trading and broader accessibility for users.	6	Magic Eden mendukung berbagai jaringan blockchain dan dikenal dengan biaya transaksinya yang rendah, memungkinkan perdagangan yang efisien dan aksesibilitas yang lebih luas bagi pengguna.	Dukungan Multi-Chain & Biaya Rendah
101	Fair Launch Fundraising	MetaDAO allows projects to raise capital through open token sales where anyone can participate at the same price, eliminating private deals and improving transparency.	7	MetaDAO memungkinkan proyek untuk mengumpulkan modal melalui penjualan token terbuka di mana siapa pun dapat berpartisipasi dengan harga yang sama, menghilangkan kesepakatan pribadi dan meningkatkan transparansi.	Penggalangan Dana Peluncuran yang Adil (Fair Launch)
102	Futarchy-Based Governance	Instead of traditional voting, MetaDAO uses decision markets where participants trade on outcomes, allowing market signals to determine whether proposals create value.	7	Alih-alih pemungutan suara tradisional, MetaDAO menggunakan pasar keputusan di mana peserta berdagang berdasarkan hasil, memungkinkan sinyal pasar untuk menentukan apakah proposal menciptakan nilai.	Tata Kelola Berbasis Futarki
103	Market-Governed Treasury	Funds raised are managed through a system where spending, token issuance, and major decisions require approval via market mechanisms, aligning long-term incentives between teams and the community.	7	Dana yang terkumpul dikelola melalui sistem di mana pengeluaran, penerbitan token, dan keputusan besar memerlukan persetujuan melalui mekanisme pasar, menyelaraskan insentif jangka panjang antara tim dan komunitas.	Perbendaharaan yang Diatur Pasar
104	Dynamic Liquidity Market Maker (DLMM)	Meteora’s DLMM pools allow liquidity to be concentrated around active price ranges, improving capital efficiency and reducing slippage for traders while increasing returns for liquidity providers.	8	Pool DLMM Meteora memungkinkan likuiditas terkonsentrasi di sekitar rentang harga aktif, meningkatkan efisiensi modal dan mengurangi slippage bagi pedagang sekaligus meningkatkan keuntungan bagi penyedia likuiditas.	Dynamic Liquidity Market Maker (DLMM)
105	Yield Optimization & Dynamic Vaults	The protocol offers automated vault strategies that actively rebalance liquidity across opportunities, helping users maximize yield while minimizing manual management.	8	Protokol ini menawarkan strategi vault otomatis yang secara aktif menyeimbangkan kembali likuiditas di berbagai peluang, membantu pengguna memaksimalkan imbal hasil sambil meminimalkan manajemen manual.	Optimalisasi Imbal Hasil & Vault Dinamis
106	High-Performance Trading on Solana	Built on Solana, Meteora enables fast, low-cost transactions with deep liquidity, providing a seamless trading experience for both retail and advanced DeFi users.	8	Dibangun di atas Solana, Meteora memungkinkan transaksi cepat berbiaya rendah dengan likuiditas yang dalam, memberikan pengalaman perdagangan yang mulus bagi pengguna DeFi ritel maupun tingkat lanjut.	Perdagangan Performa Tinggi di Solana
107	Stake SOL	Stake SOL to earn rewards directly from the network through a secure and reliable staking mechanism, allowing users to participate in network validation while generating consistent returns.	9	Lakukan stake SOL untuk mendapatkan imbal hasil langsung dari jaringan melalui mekanisme staking yang aman dan andal, memungkinkan pengguna untuk berpartisipasi dalam validasi jaringan sambil menghasilkan keuntungan yang konsisten.	Stake SOL
108	Stake Liquid SOL	Participate in liquid staking to earn rewards while maintaining the ability to use assets across DeFi applications.	9	Berpartisipasi dalam liquid staking untuk mendapatkan imbal hasil sambil mempertahankan kemampuan untuk menggunakan aset di berbagai aplikasi DeFi.	Stake Liquid SOL
109	Stake Stablecoin	Access stablecoin-based staking strategies to generate additional and more stable returns.	9	Akses strategi staking berbasis stablecoin untuk menghasilkan keuntungan tambahan yang lebih stabil.	Stake Stablecoin
113	Token Swapping	Easily swap tokens across the Solana ecosystem with optimized execution to ensure efficient trades and competitive pricing.	10	Tukar token dengan mudah di seluruh ekosistem Solana dengan eksekusi yang dioptimalkan untuk memastikan perdagangan yang efisien dan harga yang kompetitif.	Pertukaran Token
114	Smart Price Optimization	Trades are executed by accessing multiple liquidity sources to minimize slippage and achieve the best available rates.	10	Perdagangan dieksekusi dengan mengakses berbagai sumber likuiditas untuk meminimalkan slippage dan mencapai tingkat harga terbaik yang tersedia.	Optimasi Harga Cerdas
115	Advanced Trading Options	Access additional trading features such as limit orders and automated strategies, providing greater control and flexibility for managing trades.	10	Akses fitur perdagangan tambahan seperti limit order dan strategi otomatis, memberikan kontrol dan fleksibilitas yang lebih besar untuk mengelola perdagangan.	Opsi Perdagangan Lanjutan
116	Tokenized Stocks & ETFs (1:1 Backing)	Access blockchain-based representations of real-world stocks and ETFs, fully backed to ensure accurate price exposure to traditional markets.	11	Akses representasi berbasis blockchain dari saham dan ETF dunia nyata, didukung penuh untuk memastikan eksposur harga yang akurat ke pasar tradisional.	Saham & ETF yang Ditokenisasi (Dukungan 1:1)
117	24/7 Market Access	Trade tokenized equities anytime without being limited by traditional stock market hours, enabling continuous global access.	11	Perdagangkan ekuitas yang ditokenisasi kapan saja tanpa dibatasi oleh jam buka pasar saham tradisional, memungkinkan akses global yang berkelanjutan.	Akses Pasar 24/7
118	Indeks Stock Option	Access diversified exposure to multiple stocks through index-based tokenized options, enabling easier portfolio diversification.	11	Akses eksposur yang terdiversifikasi ke berbagai saham melalui opsi tokenisasi berbasis indeks, memungkinkan diversifikasi portofolio yang lebih mudah.	Opsi Saham Indeks
119	Diversified Multi-Asset Portfolio	Gain exposure to a curated basket of global equities, commodities, digital assets, and cash reserves within a single tokenized asset, reducing concentration risk while simplifying portfolio management.	12	Dapatkan eksposur ke keranjang kurasi yang berisi ekuitas global, komoditas, aset digital, dan cadangan kas dalam satu aset yang ditokenisasi, mengurangi risiko konsentrasi sekaligus menyederhanakan manajemen portofolio.	Portofolio Multi-Aset yang Terdiversifikasi
120	Tokenized Equity & Commodity Exposure	Access tokenized U.S. equities, global market indices, and commodities such as gold directly on-chain, enabling participation in traditional financial markets through blockchain infrastructure.	12	Akses ekuitas AS yang ditokenisasi, indeks pasar global, dan komoditas seperti emas secara langsung secara on-chain, memungkinkan partisipasi dalam pasar keuangan tradisional melalui infrastruktur blockchain.	Eksposur Ekuitas & Komoditas yang Ditokenisasi
121	Integrated Digital Asset Allocation	Benefit from structured exposure to digital assets such as Bitcoin alongside traditional markets, creating a balanced portfolio designed for both growth potential and resilience.	12	Manfaatkan eksposur terstruktur ke aset digital seperti Bitcoin bersama pasar tradisional, menciptakan portofolio seimbang yang dirancang untuk potensi pertumbuhan dan ketahanan.	Alokasi Aset Digital yang Terintegrasi
122	Structured Portfolio Allocation (Epoch 1)	Access a transparent 7-asset portfolio allocation designed to balance growth, stability, liquidity, and diversification across traditional and digital assets. The portfolio consists of 30% VT for global equities exposure, 15% SPY for U.S. market exposure, 10% QQQ for technology-focused growth, 5% IEMG for emerging markets, 15% GLD for gold exposure as an inflation hedge, 15% cbBTC for digital asset exposure, and 10% USDC as a cash reserve and liquidity buffer.	12	Akses alokasi portofolio 7 aset yang transparan dan dirancang untuk menyeimbangkan pertumbuhan, stabilitas, likuiditas, dan diversifikasi di seluruh aset tradisional dan digital. Portofolio terdiri dari 30% VT untuk eksposur ekuitas global, 15% SPY untuk eksposur pasar AS, 10% QQQ untuk pertumbuhan yang berfokus pada teknologi, 5% IEMG untuk pasar negara berkembang, 15% GLD untuk eksposur emas sebagai lindung nilai inflasi, 15% cbBTC untuk eksposur aset digital, dan 10% USDC sebagai cadangan kas dan penyangga likuiditas.	Alokasi Portofolio Terstruktur (Epoch 1)
\.


--
-- Data for Name: DappSection; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."DappSection" (id, title, description, "dappId", description_idn, title_idn) FROM stdin;
30	What is Bonzo Finance?	Bonzo Finance is a decentralized lending and borrowing protocol on the Hedera network that allows users to supply crypto assets to earn yield or borrow assets by providing collateral. The protocol enables permissionless lending markets through liquidity pools where users can deposit assets such as HBAR and stablecoins to earn interest, while borrowers can access liquidity without relying on centralized intermediaries, creating an open and efficient decentralized credit market.	4	Bonzo Finance adalah protokol peminjaman terdesentralisasi di jaringan Hedera yang memungkinkan pengguna menyetor aset kripto untuk mendapatkan imbal hasil atau meminjam aset dengan menyediakan jaminan. Protokol ini memungkinkan pasar peminjaman tanpa izin melalui kolam likuiditas di mana pengguna dapat menyetor aset seperti HBAR dan stablecoin untuk mendapatkan bunga, sementara peminjam dapat mengakses likuiditas tanpa bergantung pada perantara terpusat, menciptakan pasar kredit terdesentralisasi yang terbuka dan efisien.	Apa itu Bonzo Finance?
31	What is SentX?	SentX is a non-custodial NFT marketplace built on the Hedera network that allows users to discover, buy, sell, and manage digital collectibles. The platform connects creators and collectors through a peer-to-peer marketplace where NFTs can be traded directly from users’ wallets while maintaining full ownership of assets. In addition to trading, SentX also provides tools for creators to launch and manage NFT projects within the Hedera ecosystem.	3	SentX adalah pasar NFT non-kustodian yang dibangun di jaringan Hedera yang memungkinkan pengguna untuk menemukan, membeli, menjual, dan mengelola koleksi digital. Platform ini menghubungkan pencipta dan kolektor melalui pasar peer-to-peer di mana NFT dapat diperdagangkan langsung dari dompet pengguna sambil tetap mempertahankan kepemilikan penuh atas aset. Selain perdagangan, SentX juga menyediakan alat bagi pencipta untuk meluncurkan dan mengelola proyek NFT dalam ekosistem Hedera.	Apa itu SentX?
32	What is SaucerSwap?	SaucerSwap is a decentralized exchange (DEX) and liquidity platform built on the Hedera network that allows users to swap tokens, provide liquidity, and earn yield through decentralized finance (DeFi). Using an automated market maker (AMM) model, it enables permissionless trading without centralized intermediaries, allowing users to maintain full control of their assets. The platform supports fast transactions and low fees, creating a smooth and efficient trading experience within the Hedera ecosystem.	2	SaucerSwap adalah bursa terdesentralisasi (DEX) dan platform likuiditas yang dibangun di jaringan Hedera yang memungkinkan pengguna untuk menukar token, menyediakan likuiditas, dan mendapatkan imbal hasil melalui decentralized finance (DeFi). Menggunakan model automated market maker (AMM), platform ini memungkinkan perdagangan tanpa izin tanpa perantara terpusat, sehingga pengguna dapat mempertahankan kendali penuh atas aset mereka. Platform ini mendukung transaksi cepat dan biaya rendah, menciptakan pengalaman perdagangan yang lancar dan efisien dalam ekosistem Hedera.	Apa itu SaucerSwap?
33	What is Kabila?	Kabila is an all-in-one Web3 platform built on the Hedera network that provides tools for creators, brands, and communities to create, launch, and manage digital assets such as tokens and NFTs. The platform allows users to mint NFT collections, launch tokenized projects, and distribute digital assets directly to their communities. It simplifies the process of building and managing Web3 projects while enabling creators to engage their audiences and maintain ownership of their digital assets.	1	Kabila adalah platform Web3 lengkap yang dibangun di jaringan Hedera yang menyediakan alat bagi pencipta, merek, dan komunitas untuk membuat, meluncurkan, dan mengelola aset digital seperti token dan NFT. Platform ini memungkinkan pengguna untuk mencetak koleksi NFT, meluncurkan proyek yang ter-tokenisasi, dan mendistribusikan aset digital secara langsung ke komunitas mereka. Ini menyederhanakan proses pembangunan dan pengelolaan proyek Web3 sambil memungkinkan pencipta untuk melibatkan audiens mereka dan mempertahankan kepemilikan atas aset digital mereka.	Apa itu Kabila?
34	What is Magic Eden?	Magic Eden is a decentralized NFT marketplace that allows users to buy, sell, mint, and explore digital assets across multiple blockchain networks, including Solana, Ethereum, and others. Originally built on Solana, it leverages high-speed transactions and low fees to provide a seamless trading experience, while expanding into a multi-chain platform that aggregates liquidity and supports a wide range of NFT ecosystems. Designed for both creators and collectors, Magic Eden offers an accessible and efficient gateway into digital ownership and Web3 culture.	6	Magic Eden adalah pasar NFT terdesentralisasi yang memungkinkan pengguna untuk membeli, menjual, mencetak (mint), dan menjelajahi aset digital di berbagai jaringan blockchain, termasuk Solana, Ethereum, dan lainnya. Awalnya dibangun di Solana, platform ini memanfaatkan transaksi berkecepatan tinggi dan biaya rendah untuk memberikan pengalaman perdagangan yang mulus, sambil berkembang menjadi platform multi-chain yang mengagregasi likuiditas dan mendukung berbagai ekosistem NFT. Dirancang untuk pencipta dan kolektor, Magic Eden menawarkan gerbang yang mudah diakses dan efisien menuju kepemilikan digital dan budaya Web3.	Apa itu Magic Eden?
35	What is MetaDAO?	MetaDAO is a fundraising and governance platform that enables projects to launch tokens through a fair, community-driven model while operating under a unique system called futarchy, where decisions are made through market mechanisms rather than traditional voting. Projects raise capital directly from users via token sales, and treasury management, token issuance, and strategic decisions are governed by prediction markets, aligning incentives between founders and token holders while increasing transparency and reducing the risk of misaligned interests.	7	MetaDAO adalah platform penggalangan dana dan tata kelola yang memungkinkan proyek untuk meluncurkan token melalui model yang adil dan digerakkan oleh komunitas sambil beroperasi di bawah sistem unik yang disebut futarki, di mana keputusan dibuat melalui mekanisme pasar daripada pemungutan suara tradisional. Proyek mengumpulkan modal langsung dari pengguna melalui penjualan token, dan manajemen perbendaharaan, penerbitan token, serta keputusan strategis diatur oleh pasar prediksi, menyelaraskan insentif antara pendiri dan pemegang token sekaligus meningkatkan transparansi dan mengurangi risiko benturan kepentingan.	Apa itu MetaDAO?
36	What is Meteora?	Meteora is a decentralized exchange (DEX) and liquidity protocol built on the Solana blockchain that focuses on optimizing how liquidity is deployed and utilized across DeFi. It introduces dynamic liquidity mechanisms such as DLMM (Dynamic Liquidity Market Maker) pools and automated vault strategies to improve capital efficiency, reduce slippage, and enhance yield generation for users. By acting as a core liquidity layer within the Solana ecosystem, Meteora enables seamless trading, deeper liquidity, and more sustainable DeFi participation.	8	Meteora adalah bursa terdesentralisasi (DEX) dan protokol likuiditas yang dibangun di atas blockchain Solana yang berfokus pada pengoptimalan bagaimana likuiditas diterapkan dan dimanfaatkan di seluruh DeFi. Meteora memperkenalkan mekanisme likuiditas dinamis seperti pool DLMM (Dynamic Liquidity Market Maker) dan strategi vault otomatis untuk meningkatkan efisiensi modal, mengurangi slippage, dan meningkatkan perolehan imbal hasil bagi pengguna. Dengan bertindak sebagai lapisan likuiditas inti dalam ekosistem Solana, Meteora memungkinkan perdagangan yang mulus, likuiditas yang lebih dalam, dan partisipasi DeFi yang lebih berkelanjutan.	Apa itu Meteora?
37	What is Solana Stake?	Solana Stake is a staking experience powered by the Marinade protocol, enabling users to access multiple staking strategies in one place. Users can choose between standard SOL staking for direct rewards, liquid staking for flexibility within DeFi, or stablecoin staking to generate additional yield, creating a more flexible and capital-efficient way to participate in staking and on-chain yield generation.	9	Solana Stake adalah pengalaman staking yang didukung oleh protokol Marinade, memungkinkan pengguna untuk mengakses berbagai strategi staking di satu tempat. Pengguna dapat memilih antara staking SOL standar untuk imbal hasil langsung, liquid staking untuk fleksibilitas dalam DeFi, atau staking stablecoin untuk menghasilkan imbal hasil tambahan, menciptakan cara yang lebih fleksibel dan efisien secara modal untuk berpartisipasi dalam staking dan perolehan imbal hasil on-chain.	Apa itu Solana Stake?
39	What is Swap?	Swap is a trading experience powered by the Jupiter protocol, enabling users to swap tokens by sourcing liquidity from multiple platforms to find the best available prices. Instead of relying on a single exchange, it aggregates liquidity from various Solana-based DEXs, optimizing execution, reducing slippage, and improving overall trading efficiency while maintaining fast and low-cost transactions.	10	Swap adalah pengalaman perdagangan yang didukung oleh protokol Jupiter, memungkinkan pengguna untuk menukar token dengan mengambil sumber likuiditas dari berbagai platform untuk menemukan harga terbaik yang tersedia. Alih-alih mengandalkan satu bursa, ini mengagregasi likuiditas dari berbagai DEX berbasis Solana, mengoptimalkan eksekusi, mengurangi slippage, dan meningkatkan efisiensi perdagangan secara keseluruhan sambil mempertahankan transaksi yang cepat dan berbiaya rendah.	Apa itu Swap?
40	What is US Stock?	US Stocks is a trading feature, integrated with xStocks and Ondo, enabling users to access tokenized versions of real-world equities and ETFs directly on-chain. Each asset represents exposure to publicly traded securities backed 1:1 by underlying holdings, allowing users to trade, transfer, and utilize stocks in a decentralized environment while benefiting from continuous market access and seamless integration with DeFi.	11	US Stocks adalah fitur perdagangan yang terintegrasi dengan xStocks dan Ondo, memungkinkan pengguna untuk mengakses versi tokenisasi dari ekuitas dan ETF dunia nyata langsung secara on-chain. Setiap aset mewakili eksposur ke sekuritas yang diperdagangkan secara publik yang didukung 1:1 oleh aset dasar, memungkinkan pengguna untuk memperdagangkan, mentransfer, dan memanfaatkan saham dalam lingkungan terdesentralisasi sambil mendapatkan manfaat dari akses pasar yang berkelanjutan dan integrasi yang mulus dengan DeFi.	Apa itu US Stock?
41	What is BETA?	BETA is a tokenized portfolio asset designed to simplify long-term wealth preservation and diversified investing through a single on-chain token. Instead of manually managing multiple assets, platforms, and jurisdictions, users can hold or mint $BETA to gain exposure to a structured basket of tokenized equities, commodities, digital assets, and cash allocations. Built on Solana and accessible through Paradapp, BETA automates portfolio construction and asset allocation into a seamless experience while maintaining transparency, liquidity, and clear portfolio composition. The portfolio is structured to balance long-term growth, stability, inflation protection, and liquidity, allowing users to access diversification investment through a simplified and accessible system.	12	BETA adalah aset portofolio yang ditokenisasi untuk menyederhanakan penyimpanan kekayaan jangka panjang dan investasi yang terdiversifikasi melalui satu token on-chain. Alih-alih mengelola berbagai aset, platform, dan yurisdiksi secara manual, pengguna dapat menyimpan atau mencetak $BETA untuk mendapatkan eksposur ke dalam keranjang terstruktur yang berisi alokasi ekuitas, komoditas, aset digital, dan uang tunai yang ditokenisasi. Dibangun di Solana dan dapat diakses melalui Paradapp, BETA mengotomatiskan pembentukan portofolio dan alokasi aset menjadi pengalaman yang mulus dengan tetap menjaga transparansi, likuiditas, dan komposisi portofolio yang jelas. Portofolio ini disusun untuk menyeimbangkan pertumbuhan jangka panjang, stabilitas, perlindungan inflasi, dan likuiditas, yang memungkinkan pengguna untuk mengakses investasi diversifikasi melalui sistem yang disederhanakan dan dapat diakses.	Apa itu BETA?
\.


--
-- Data for Name: IdrxAccount; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."IdrxAccount" ("walletAddress", "idrxApiKey", "idrxApiSecret", "kycOnboardingAddress", "createdAt", "updatedAt", email, "idrxEmail") FROM stdin;
FghAY44kjdGg6XNvY4CjtcMhzvssA9d9Ts9m5Eh9mLGT	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-16 12:05:59.478068+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
bc1q7eu84v58kxj0r9u72vmjze7wlrnsdg5n79uv2r	50189053ce19c3cd	a2f20561df61d32c02862ea997ace7f2c90069eb90c2d293def0cfb9c45b2437	DD54engwg1BmZ92vN2U9YfLNqeshGkyGzoQS4isaSbPh	2026-08-16 15:28:38.841794+00	2026-09-15 15:59:11.136679+00	creativebountyteam@gmail.com	creativebountyteam+idrx_1789487950@gmail.com
bc1qqme3nlke95y0x07pusklmd8jje6ugldta9en42	50189053ce19c3cd	a2f20561df61d32c02862ea997ace7f2c90069eb90c2d293def0cfb9c45b2437	DD54engwg1BmZ92vN2U9YfLNqeshGkyGzoQS4isaSbPh	2026-08-16 16:30:26.288123+00	2026-09-15 15:59:11.136679+00	creativebountyteam@gmail.com	creativebountyteam+idrx_1789487950@gmail.com
9M8qqccQEYdgDbr3Vb4k1VrwV8DrN41EwEA7odg6E7bU	62f2a423984d2b9e	d9ee5297417cbf9f8ee2853915ab01eca3d0e8a37c4b1cd6217a864fc277c8e7	6h1UosiJScHTNRaUMP5wfa8gTsg4vx9XzPBVy6fqtZNk	2026-08-16 15:10:44.415201+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+11@gmail.com	pasha.renaisan+11@gmail.com
15JweJFKZktfBaApBKKUX5AgCkyURBZRXSnWgBSLV4TwBMQY	bbbf4878ea4f99f2	20cbbd75b88b6c0f3c0e3d1abf8de8aae70bc50dc0a0daa680d5db4417825b8b	6HXsMuH5WBSC5GeidSwDPTw5CEkA3bjHx5VPLYW6YwYQ	2026-08-17 05:13:20.984956+00	2026-09-15 15:55:22.991093+00	kelwinwithshen@gmail.com	kelwinwithshen@gmail.com
bc1qkv4d63d0u7r8uz9tpthg3474393v3dxguxk7d5	1e790e1d2932bc92	caef767ccd55694d698516ba6bad5db6e657e6e5afae4c2b8f09f045220bbf6c	4frRoyHGyyC59anawJkjk2Bwm1Buj1aM4aVCKZ79Lcpz	2026-08-23 22:06:55.657681+00	2026-09-15 15:55:22.991093+00	paramadhika@gmail.com	paramadhika@gmail.com
4kVyvpTmJbC548pFK9Y95GpE7NhgCuz2rPXFNzSMRL68	c06e52e5c5d7d90d	b4ef5ea1f8b5fb76e712d038d6795e88850c0e77c7bd3229ee21bcfd24ce258d	BSy8nbfpBNZ7dV9SWFMnpBWeErHuuKyPb7uZnz737efy	2026-08-24 13:26:13.896761+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+76@gmail.com	pasha.renaisan+76@gmail.com
BMHXwv1xZNkL57mfF6EhzmYuh5R6S4gkmzEdS2Mkk85K	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-25 13:41:07.579603+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
Ea9wFfm8pdGvvQvQrTUmV5WHuYFdzxacqhoNzqr4o4mS	2c2242a91e8a90cd	d68db325e960659515296a84f13101701f1912c4def267f38d7ccb1498db6a3c	H3Zbit9pSesQNaqVA3FspDV5Nco3qc3CRHk8oStu6CJ5	2026-08-26 10:55:14.525327+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+30@gmail.com	pasha.renaisan+30@gmail.com
bc1qjjc4gv80kqjm5xc0qnk9yhe3mhtee2avehau33	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-26 12:04:34.228028+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
4P94wGza7ypZd9zrjsx8PygX7YZjmScSpVPAQpgAvFcQ	918963bf0e196f6f	8fab915945612b410d20b41829a3b69942562fc730f11c674ebd641ac181b7f5	4QfGct1ReN2sp6kuRKHLu251kTMngDrXZkJwssnX1Czo	2026-08-26 12:26:08.156613+00	2026-09-15 15:55:22.991093+00	adihariselasa@gmail.com	adihariselasa@gmail.com
bc1qs6d5gwmgfh5ek878daxv9za02rjztvjcpn29ns	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-27 05:02:07.111747+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
bc1qdk08y6cdut0x5h300us6a4xwdvl5aav69md248	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-08-27 05:03:40.090717+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
zAhhYG5tcU8nqB64dPaRYqvqwCp1PZpoEK1oHLsiPH4	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-27 13:11:18.561576+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	68fbe41b7bff768c	6a813e5202bd7a160d6ce0853986d6b5a81a3dfba17ddd75d456869fde3f3a91	Fi7qcNGASn7iuH7n96XZ2FV42X9wiY9Qk9xSCYNcYraP	2026-08-27 13:14:54.291467+00	2026-09-15 15:55:22.991093+00	ftapamahendra@gmail.com	ftapamahendra@gmail.com
bc1qclfskzr0snpeytn29hvepz8jflre7tqkhp0sg5	ef9feeb734f94640		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-28 16:19:35.113528+00	2026-09-15 15:55:22.991093+00	pasha.renaisan@gmail.com	pasha.renaisan@gmail.com
J576U6Fazq9j4fGx3x6y5j4vUaZJup9rarnbmY1nR8q7	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-09-01 01:14:04.343259+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	b2e9bbddf1ef3b4a		hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1	2026-08-28 17:46:51.03637+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
bc1q09rpkqchl0yulen7wupf5uu05uk63wwx79pcfc	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-09-01 02:59:07.697901+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
44KcbsbZPPqxSNhtyWC7o8JbBvEvC2o4nDA4Ad9BoFWC	bbbf4878ea4f99f2	20cbbd75b88b6c0f3c0e3d1abf8de8aae70bc50dc0a0daa680d5db4417825b8b	6HXsMuH5WBSC5GeidSwDPTw5CEkA3bjHx5VPLYW6YwYQ	2026-09-01 04:19:49.005655+00	2026-09-15 15:55:22.991093+00	kelwinwithshen@gmail.com	kelwinwithshen@gmail.com
87JyDsMpP9TmajXRTtC7MEMKF2tf2hFvVJGto9qmzQMt	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-09-01 15:48:04.93841+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
14rrwEnCnkfpWZzditUL7SJQNixqPyEAiQLjJJjsLP2tSoSF	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-09-02 12:52:13.081132+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
0xE3B910c931117EAe35684D2af78e69240031C69f	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-09-02 17:12:09.652366+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	92b90484b6d12792	9b5d0c5f58645591f25c023ff7a18cf35ae0d1ad2586bc646b3d5b29ee5d81b9	DUpJJRfME1uGCKa1GAvvSRXt2UWstcfK5ioBGbgz4Wb	2026-09-10 04:30:18.884028+00	2026-09-15 15:55:22.991093+00	gedeekaputra31@gmail.com	gedeekaputra31@gmail.com
4zzdvjNgVwSPxiYf8nC9bVRX1GmkDSz3GoGF6j7uM4y4	4296f4f660bc65ca	8642266455d5453d54dcef4bb845c13ee06c407cc7126ff3df92b8c1e0e7363e	5Euxxr4KLLMXLC6gNCpyEv3xhZLnpQAzihHp5R6PaDcw	2026-09-14 13:54:05.537798+00	2026-09-15 15:55:22.991093+00	kelwinwithshen+1@gmail.com	kelwinwithshen+1@gmail.com
6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-08-16 12:00:47.76997+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	b2e9bbddf1ef3b4a	dd79c2ee0631c5440cd61ae5a23eb17e62b043081a0a15d1f8369945fca9b49b	6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd	2026-01-01 00:00:00+00	2026-09-15 15:55:22.991093+00	pasha.renaisan+24@gmail.com	pasha.renaisan+24@gmail.com
5TZy4gdeCQqUjPhqTANpZYeiVJnbXwhWyVjhoG553EbP	bbbf4878ea4f99f2	20cbbd75b88b6c0f3c0e3d1abf8de8aae70bc50dc0a0daa680d5db4417825b8b	6HXsMuH5WBSC5GeidSwDPTw5CEkA3bjHx5VPLYW6YwYQ	2026-09-15 16:00:51.366874+00	2026-09-15 16:00:51.366874+00	kelwinwithshen@gmail.com	kelwinwithshen@gmail.com
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."Transaction" (id, type, status, "tokenAmount", "tokenType", "idrAmount", "walletAddress", "paymentDetails", "txHash", "cexTxId", "refAddress", "refAmount", "xenditTxId", "createdAt", "updatedAt", "networkEnv", network, "refTxHash") FROM stdin;
cmnzwjisu0003pn014jmjnbr9	DEPOSIT	COMPLETED	65	HBAR	100000	0x7D28743A0354942AD797d7194E24d12bd8588B84	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1776248582.672846634	422953	\N	\N	pr-2af35a69-9365-4519-80df-1cecc1e3f822	2026-04-15 10:22:58.542+00	2026-04-15 10:23:29.05+00	TESTNET	HEDERA	\N
cmnzf6lkh0001t901ed6mndwj	DEPOSIT	COMPLETED	65	HBAR	100000	0xf0a37a7b419a63fc4075eb173525b820b5b5391e	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1776220462.236380753	415834	\N	\N	pr-71c7b528-03f0-4cca-96d5-c42c6ee6531e	2026-04-15 02:17:02.129+00	2026-04-15 02:34:37.315+00	TESTNET	HEDERA	\N
cmo05w9ph0000mn01uroray1k	DEPOSIT	COMPLETED	0.0035	ETH	150000	0x32f1f016B155279F881B077bD81F364A490d9680	{"method": "QRIS", "qrString": "some-random-qr-string"}	0xa5ecd66e93c4420c0b860cb8cd77c89319a09fdb12a4c83334b2c5a80871608e	2800241	\N	\N	pr-0d3d202b-0df8-45b1-b33b-cfa7f9f3745f	2026-04-15 14:44:49.83+00	2026-04-15 14:45:12.987+00	TESTNET	ETHEREUM	\N
cmnz4n46n0000r201d2be8ugn	DEPOSIT	COMPLETED	0.0033	ETH	150000	0x914EffCbd43c570ec5d59e8a3918b80439e6cb86	{"method": "QRIS", "qrString": "some-random-qr-string"}	0x0fea7fc202ad2a6f0f4ccd06760fc8e6a296d29fb038dc163689c828d46ca142	2654071	\N	\N	pr-e6a1a56a-ad95-4df0-af93-1a8093a9334b	2026-04-14 21:21:56.976+00	2026-04-14 21:22:16.042+00	TESTNET	ETHEREUM	\N
cmn6bn57l000blv019lzfzihg	DEPOSIT	COMPLETED	0.0022	ETH	100000	0x4Df6b2c7d70b4C832293b3f570675075087bD7e5	{"method": "QRIS", "qrString": "some-random-qr-string"}	0x3af1e2062f52fb551784ad43dffb56a01cef4541499df30a7a420aa22d4f09f6	13834162	\N	\N	pr-e5ed81e0-2d91-4366-9e04-aa0721b45614	2026-03-25 17:32:36.513+00	2026-03-25 17:32:50.442+00	TESTNET	ETHEREUM	\N
cmn2asag5000fk201qx7b20ka	DEPOSIT	COMPLETED	0.0037	ETH	150000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "some-random-qr-string"}	0xbacfe008b9a0da8b25951ca78b62969121e8bfb1a35b10caa3fddbb53edff18e	12752670	\N	\N	pr-11f21ed9-d8d9-470d-99d9-b7c7c7798186	2026-03-22 21:57:32.261+00	2026-03-22 21:57:50.61+00	TESTNET	ETHEREUM	\N
cmn2a6awf000ek2011keq9imo	DEPOSIT	COMPLETED	0.0023	ETH	100000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "some-random-qr-string"}	0x95b65735fe71505311e96cf39752b5d898e24af2ab044b780bcc7280d3b4cf2e	12749220	\N	\N	pr-663d926f-d06f-41df-8c10-5f92bf162c9c	2026-03-22 21:40:26.416+00	2026-03-22 21:40:40.408+00	TESTNET	ETHEREUM	\N
cmn3mvd250000oj01wigu2jf4	WITHDRAWAL	COMPLETED	0.003	ETH	103848	0x851B807752b4eb83f4A9FD3275376bc8018CE73A	{"method": "ID_BCA", "accountNumber": "1234567890", "paradappAddress": "0xF31E175f92bb9b45B1F25E0d7d93AfeAA4577dC4", "accountHolderName": "DUMMY**USER"}	0x0cbc5c0b4853332cf47b99b1ae6bee3a994ff49eae406eb7902af74760731edc	13197761	\N	\N	disb-6828c046-1baf-42df-87f1-6d0a3ce6dcb1	2026-03-23 20:23:37.182+00	2026-03-23 20:34:45.159+00	TESTNET	ETHEREUM	\N
cmn3d2i7b000hk2014ra3he06	DEPOSIT	COMPLETED	0.0076	ETH	300000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "some-random-qr-string"}	0x14469c2ead91ba03b466941cf500ed4512e2e9e06d367da18072ab24b049094e	13061400	\N	\N	pr-6605c4b9-cc90-4323-9f04-c1a02f55378f	2026-03-23 15:49:14.279+00	2026-03-23 15:49:28.05+00	TESTNET	ETHEREUM	\N
cmn3cjyum000gk201ri1h4w3n	DEPOSIT	COMPLETED	82	HBAR	150000	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774280117.851932188	2208617	\N	\N	pr-71e0d48c-9aa3-4d55-9942-11ad8fbc89af	2026-03-23 15:34:49.39+00	2026-03-23 15:35:33.034+00	TESTNET	HEDERA	\N
cmnzfhxv70002t9016rhvzsps	DEPOSIT	COMPLETED	99	HBAR	150000	0x0000000000000000000000000000000000840ce7	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1776220462.236380753	415961	\N	\N	pr-81bc1c1c-b913-4782-81ae-c41e753b268b	2026-04-15 02:25:51.283+00	2026-04-15 02:34:37.327+00	TESTNET	HEDERA	\N
cmo1wi98r0000lp018ivuz1tv	DEPOSIT	COMPLETED	93	HBAR	150000	0x0000000000000000000000000000000000840ce7	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1776369451.625343093	475318	\N	\N	pr-64c02023-51c2-499f-bf8a-41b2b84f4e35	2026-04-16 19:57:31.851+00	2026-04-16 19:57:42.446+00	TESTNET	HEDERA	\N
cmn3fjlmb000jk201u2i0yqgy	DEPOSIT	COMPLETED	0.0077	ETH	300000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "some-random-qr-string"}	0x8fc9444c3d68b8e4d81fb7b8cd272bddb0e3e90ddddf6435af3931906d959011	13105924	\N	\N	pr-04c13cdd-40fe-4471-81ba-185dfa49dbcb	2026-03-23 16:58:31.092+00	2026-03-23 16:58:49.244+00	TESTNET	ETHEREUM	\N
cmn3g66yl000kk201yau354k2	WITHDRAWAL	COMPLETED	0.007	ETH	247890	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "ID_BCA", "accountNumber": "033819281", "paradappAddress": "0xF31E175f92bb9b45B1F25E0d7d93AfeAA4577dC4", "accountHolderName": "DUMMY**USER"}	\N	13116290	\N	\N	disb-a579a4f8-7c54-41a5-ac6c-892e53d3f5ea	2026-03-23 17:16:05.181+00	2026-03-23 17:19:04.441+00	TESTNET	ETHEREUM	\N
cmn7hy0bj000glv01xa1hqosy	DEPOSIT	COMPLETED	0.0022	ETH	100000	0x7B101024838708D2043b28E499f484166a8122cb	{"method": "VA", "vaNumber": "381659999065652", "channelCode": "BCA"}	0xf42871cb6840c615f006a74857998f9c1e6c9dc3b3651f9e08bff97438706602	14058832	\N	\N	pr-4fec1774-e372-4983-9c8a-9e6aa19470dc	2026-03-26 13:16:47.263+00	2026-03-26 13:17:02.973+00	TESTNET	ETHEREUM	\N
cmnf76bku000dre013yn9qtk4	DEPOSIT	COMPLETED	56	HBAR	100000	0xca73918ebeaf4dccff703e3e7cb2f5b1591a20ae	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774996647.783886365	2487144	\N	\N	pr-2ac35445-af27-4ad7-ab5b-ed14d8831cf8	2026-03-31 22:37:28.734+00	2026-03-31 22:37:42.595+00	TESTNET	HEDERA	\N
cmng6wpmf000fre0120elcsn8	DEPOSIT	COMPLETED	55	HBAR	100000	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1775056686.182820504	7336	\N	\N	pr-30a7f4d4-1159-4db8-ad55-06259f97de05	2026-04-01 15:17:46.551+00	2026-04-01 15:18:15.028+00	TESTNET	HEDERA	\N
cmni6lpwn000hre01533z05fd	DEPOSIT	COMPLETED	185	HBAR	300000	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	{"method": "VA", "vaNumber": "381659999961967", "channelCode": "BCA"}	0.0.7066149@1775177087.200646940	58652	\N	\N	pr-5373f203-de9d-4e9d-bf9a-8279c7870e04	2026-04-03 00:44:46.055+00	2026-04-03 00:44:55.221+00	TESTNET	HEDERA	\N
cmmumaui60000pg0129l5rnex	DEPOSIT	COMPLETED	49	HBAR	100000	0x851B807752b4eb83f4A9FD3275376bc8018CE73A	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1773752300.689459498	1990769	\N	\N	pr-39e588dc-e5e0-4c58-a053-55d0ed08942b	2026-03-17 12:57:44.43+00	2026-03-17 12:58:31.28+00	TESTNET	HEDERA	\N
cmn7fjzq5000dlv01zebkg94p	DEPOSIT	COMPLETED	52	HBAR	100000	0x19375c62875e1236ae9c667ae3613d8d0a0ce1d0	{"method": "VA", "vaNumber": "381659999484326", "channelCode": "BCA"}	0.0.7066149@1774526994.924204957	2316468	\N	\N	pr-5f949e9a-e9e3-4500-96f5-f27c208d3caa	2026-03-26 12:09:54.077+00	2026-03-26 12:10:11.842+00	TESTNET	HEDERA	\N
cmmuty02j0001pg01z7wwu3p4	DEPOSIT	COMPLETED	47	HBAR	100000	0x851B807752b4eb83f4A9FD3275376bc8018CE73A	{"method": "VA", "vaNumber": "8930999909943477", "channelCode": "BNI"}	0.0.7066149@1773765138.814251380	1999377	\N	\N	pr-0c090aaf-9eea-43fa-8461-88f7fadc02c1	2026-03-17 16:31:42.043+00	2026-03-17 16:32:29.927+00	TESTNET	HEDERA	\N
cmn90s9u90000re014nq1kmss	DEPOSIT	COMPLETED	314	HBAR	500000	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774623119.835867109	2351868	\N	\N	pr-1a682608-8841-4353-8193-cf6e33300555	2026-03-27 14:51:58.545+00	2026-03-27 14:52:17.68+00	TESTNET	HEDERA	\N
cmmz1aovn0002l0012imm383j	DEPOSIT	COMPLETED	85	HBAR	150000	0x7Eeacf2FC7452EaC8CdadEa86c53f866DaB90b69	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774019554.195282008	2112409	\N	\N	pr-b429086f-f923-4a27-a727-52cf2b2875b1	2026-03-20 15:08:36.083+00	2026-03-20 15:12:45.31+00	TESTNET	HEDERA	\N
cmn0kwsui0000k201aodggjt2	DEPOSIT	COMPLETED	53	HBAR	100000	0x851B807752b4eb83f4A9FD3275376bc8018CE73A	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774112727.905152707	2137926	\N	\N	pr-26887cba-35c3-478c-95a6-2974e6fb9a7d	2026-03-21 17:05:26.538+00	2026-03-21 17:05:36.612+00	TESTNET	HEDERA	\N
cmn24akev000ak201ni5jomkr	DEPOSIT	COMPLETED	120	HBAR	200000	0x4Df6b2c7d70b4C832293b3f570675075087bD7e5	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774205800.967737929	2168126	\N	\N	pr-11f349bc-ed2b-496c-bacb-23d6f33e4f8d	2026-03-22 18:55:47.671+00	2026-03-22 18:56:53.151+00	TESTNET	HEDERA	\N
cmn27bynp000bk2013vpcfeda	DEPOSIT	COMPLETED	120	HBAR	200000	0x4Df6b2c7d70b4C832293b3f570675075087bD7e5	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774210853.707293487	2169881	\N	\N	pr-7c93ba97-014e-4e01-b5d7-407696ea206b	2026-03-22 20:20:51.637+00	2026-03-22 20:21:09.361+00	TESTNET	HEDERA	\N
cmn27qr1q000ck2011o9c8qvh	DEPOSIT	COMPLETED	88	HBAR	150000	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774211566.328234424	2170138	\N	\N	pr-cfcc9038-8664-420d-8d0c-cdbe3284d337	2026-03-22 20:32:21.614+00	2026-03-22 20:32:59.616+00	TESTNET	HEDERA	\N
cmn283nt8000dk201w6e1n568	DEPOSIT	COMPLETED	88	HBAR	150000	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774212169.451560576	2170352	\N	\N	pr-907dce51-9370-4c68-bb7b-40f8fac45a2e	2026-03-22 20:42:23.948+00	2026-03-22 20:42:59.767+00	TESTNET	HEDERA	\N
cmng15fzf000ere013uvfhjyl	DEPOSIT	COMPLETED	55	HBAR	100000	0xca73918ebeaf4dccff703e3e7cb2f5b1591a20ae	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1775046999.398739732	1466	\N	\N	pr-938aec5b-c366-4cdb-8720-f0660c57a46f	2026-04-01 12:36:36.268+00	2026-04-01 12:36:53.247+00	TESTNET	HEDERA	\N
cmn3pi2pz0000lr01bkibur52	DEPOSIT	COMPLETED	113	HBAR	200000	0x30A2AC9d570927B79aF58321B79c3c0688711d8b	{"method": "VA", "vaNumber": "381659999662998", "channelCode": "BCA"}	0.0.7066149@1774302530.931136911	2220869	\N	\N	pr-f50a4aa2-5289-4cec-9171-e7c7aa671051	2026-03-23 21:37:16.103+00	2026-03-23 21:49:01.545+00	TESTNET	HEDERA	\N
cmn3oxasx0000lu01ix4hss5p	DEPOSIT	COMPLETED	84	HBAR	150000	0xca73918ebeaf4dccff703e3e7cb2f5b1591a20ae	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774302530.931136911	2220540	\N	\N	pr-73f140cb-031f-46c6-b45b-4c2c0e2a6a33	2026-03-23 21:21:06.801+00	2026-03-23 21:49:01.557+00	TESTNET	HEDERA	\N
cmn567zoh0007lv01hrybgp8z	DEPOSIT	COMPLETED	52	HBAR	100000	0x00000000000000000000000000000000007ed025	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774390382.997610748	2263325	\N	\N	pr-fa3f8632-90f9-4f44-b265-4a376d5501c0	2026-03-24 22:13:05.249+00	2026-03-24 22:13:14.603+00	TESTNET	HEDERA	\N
cmn76fz5d000clv01en2hiffn	DEPOSIT	COMPLETED	86	HBAR	150000	0xca73918ebeaf4dccff703e3e7cb2f5b1591a20ae	{"method": "QRIS", "qrString": "some-random-qr-string"}	0.0.7066149@1774511699.127331972	2311098	\N	\N	pr-0b38a292-8390-4d29-ba29-9060c8c469f6	2026-03-26 07:54:50.162+00	2026-03-26 07:55:11.541+00	TESTNET	HEDERA	\N
cmn8olyod000ilv01x3atibus	WITHDRAWAL	COMPLETED	100	HBAR	148695	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	{"method": "ID_BCA", "accountNumber": "12121212121", "paradappAddress": "0.0.7066149", "accountHolderName": "DUMMY**USER"}	0.0.4660021-1774602667-205592338	2342712	\N	\N	disb-289ae838-4928-4a8f-8fe2-8b4da8de7be4	2026-03-27 09:11:08.749+00	2026-03-27 10:29:28.788+00	TESTNET	HEDERA	\N
cmn8qgb2u000slv017zt9ly9s	DEPOSIT	COMPLETED	117	HBAR	200000	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	{"method": "VA", "vaNumber": "889089999961967", "channelCode": "MANDIRI"}	0.0.7066149@1774605764.284690094	2343827	\N	\N	pr-3aca7ca9-fc5a-4f49-8ab5-ad10873893ca	2026-03-27 10:02:44.118+00	2026-03-27 10:02:55.968+00	TESTNET	HEDERA	\N
cmn8qk61g000tlv01gcxxjene	WITHDRAWAL	COMPLETED	100	HBAR	147422	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	{"method": "ID_BCA", "accountNumber": "12121212", "paradappAddress": "0.0.7066149", "accountHolderName": "DUMMY**USER"}	0.0.4660021-1774605946-415987128	2343927	\N	\N	disb-ad2d13dc-2a94-45ae-97b1-e8f19fbc74a3	2026-03-27 10:05:44.213+00	2026-03-27 10:29:28.854+00	TESTNET	HEDERA	\N
cmn8p7z37000jlv01v6gmdpt3	WITHDRAWAL	COMPLETED	62	HBAR	88929	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	{"method": "ID_BCA", "accountNumber": "1212121212", "paradappAddress": "0.0.7066149", "accountHolderName": "DUMMY**USER"}	0.0.4660021-1774603695-192414608	2343180	\N	\N	disb-d638fca3-3d13-469d-8b37-23f5393cee75	2026-03-27 09:28:15.716+00	2026-03-27 10:29:28.722+00	TESTNET	HEDERA	\N
cmnzgithf0000pn01vesjdw5i	WITHDRAWAL	COMPLETED	80	HBAR	112132	0xf0a37a7b419a63fc4075eb173525b820b5b5391e	{"method": "ID_BCA", "accountNumber": "123", "paradappAddress": "0.0.7066149", "accountHolderName": "DUMMY**USER"}	0.0.8555429-1776221674-056642540	416366	\N	\N	disb-62d3a82d-1f35-4b90-8d12-e1404f3204ed	2026-04-15 02:54:31.876+00	2026-04-15 02:55:16.107+00	TESTNET	HEDERA	\N
cmo1wsl5b0000qm01xfq3fhee	WITHDRAWAL	COMPLETED	92.99881684	HBAR	139451	0x0000000000000000000000000000000000840ce7	{"method": "ID_BCA", "accountNumber": "1234567890", "paradappAddress": "0.0.7066149", "accountHolderName": "DUMMY**USER"}	0.0.8654055-1776369932-314918891	475740	\N	\N	disb-845d7f91-69d5-42d2-8ff2-2ccbce920796	2026-04-16 20:05:33.839+00	2026-04-16 20:06:07.161+00	TESTNET	HEDERA	\N
cmodfl56c0000m501v2u4w5gj	DEPOSIT	COMPLETED	0.09761235	SOL	150000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525feTbELRinthWkg4nrPE48yxyK630499B1"}	4mqeS3hsLeVqqCWdwbZkgPYs4UhwAzVLAfRGqG71ECRAGqGrkTrSqtu9TZrA1iDEqXn3LnNhTqMUminJAgcDCouk	16994375105	\N	\N	pr-92b5251e-e0b0-47dd-95e6-6f0011bb1299	2026-04-24 21:37:07.188+00	2026-04-24 22:13:11.892+00	MAINNET	SOLANA	\N
cm9tufj220000k1r6u069xr6l_migrated	DEPOSIT	COMPLETED	0.000323	BTC	550000	bc1qnunvj96qx03sx072qe233dtwcjgsjnnweem3mx	{"method": "VA", "vaNumber": "8930250131251511", "channelCode": "BNI"}	760000f16ebbab2b94ec2d37c1d66034afc278ddb450cf2f43f9d67e04aa1751	41836612580	\N	\N	pr-72964c76-aac1-4363-8e26-0a3e1f931c00	2025-04-23 11:21:23.259+00	2025-04-24 14:29:34.315+00	MAINNET	BITCOIN	\N
cmbdck2850002k17xkljltu4b_migrated	WITHDRAWAL	COMPLETED	0.000257	BTC	375489	bc1qxz6x4j4680q8p39mp3jzer08hvun3hefszra09	{"method": "ID_BCA", "accountNumber": "7445116700", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "K***IN"}	16e7071aec11c1137dda94f55bd8807989340b4d10b185af982353293ba28353	44067177645	\N	\N	disb-c5a41d47-3c43-4e67-8f32-aeb4c8b246ce	2025-06-01 07:36:07.494+00	2025-06-01 07:41:50.257+00	MAINNET	BITCOIN	\N
cmodikhqo0000mh01ljgu6v6f	DEPOSIT	COMPLETED	16.758144	USDC	300000	44KcbsbZPPqxSNhtyWC7o8JbBvEvC2o4nDA4Ad9BoFWC	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054063000005802ID5908BitVault6006BADUNG61058036162290525MCX3tF9JqDV2dPk5pKtuX2Evm63040D38"}	5s6bYcRjN58BAGPzQji8YQD8qdMqKrUHqbcuqVPTh4RG8dAUVNxfVVit54ByRVmnXZPxzcHrwZAV3cUNXE34n77b	1472718029	\N	\N	pr-cb48f4cc-c93c-407f-87f3-b2586cec10e6	2026-04-24 23:00:35.664+00	2026-04-24 23:26:17.578+00	MAINNET	SOLANA	\N
cmp3r4a6z000nmj01tgjqge79	DEPOSIT	COMPLETED	0.00067301	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250137355518", "channelCode": "BNI"}	1a5f768722f69c2e2650dc3c4a69d4cda0270826cdab49981714c9d785ccc9c6	61737646185	\N	\N	pr-9bda7565-dee0-471d-b138-8be5667d213c	2026-05-13 07:41:56.507+00	2026-05-13 08:00:09.541+00	MAINNET	BITCOIN	\N
cmpjn54dg0004mq01kfna5jsh	DEPOSIT	COMPLETED	56.642438	USDC	1000000	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	{"method": "VA", "vaNumber": "88908298425266872", "channelCode": "MANDIRI"}	4JquJPy56V6mKskpvjjzWyXXugDWkQZhpaBJXBftqSYpeDgqRAypiXPAzgp24goRH6vyzqFmCEi5cB9wNDe2BZwH	1517976939	\N	\N	pr-dff8a0d3-754a-428f-bdc3-56618c9073cc	2026-05-24 10:34:55.972+00	2026-05-24 10:36:34.594+00	MAINNET	SOLANA	\N
cmpjsijsc0006mq01mut090ki	DEPOSIT	COMPLETED	1129.568438	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294808211174", "channelCode": "PERMATA"}	2Q334hFg4xW6iFasfMtsdbW86CLDsKC5uWCvPVB3qjsvg6uuYbgNmCimrTZYdMDU99hJv3fGGoTsvxPCmoNfc4mm	1518125060	\N	\N	pr-b590cdcf-889a-4027-a3aa-fc2521aab8f1	2026-05-24 13:05:20.557+00	2026-05-24 13:06:36.59+00	MAINNET	SOLANA	\N
cmozk6v760006nv01k8d1l1wj	DEPOSIT	COMPLETED	2.409580499	SOL	4000000	G8vkKtPzQfm8dTVnFcgFis5LgRHqwCk2bT29731sXU6D	{"method": "VA", "vaNumber": "8930250121001111", "channelCode": "BNI"}	5w5rb3VfQgoKPumw6CpnMqjrNeQweQkfTxKhuM2taB5Dpj8K9y5YTKaa4psKxWcyNDE8S2zMKFUGHYpyidsazW1y	17057079318	\N	\N	pr-10609412-b39a-433c-85cc-44875e75eab5	2026-05-10 09:16:55.027+00	2026-05-10 09:19:48.103+00	MAINNET	SOLANA	\N
cmqpw4lpz0011l301zuq9u7id	WITHDRAWAL	COMPLETED	99.468623	USDC	1751958	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "I Gede Eka Laksmana Putra"}	4RT8n3dnj5qkiHsmqAPx3R9k1nPDp7UN8SApwZX1dAh8ffeEg9LUKkFKxCJemyyzhXBZWFGAzCWsjdQLMHwBQa7J	1564455289	\N	\N	disb-caf0e082-f1ef-4727-aec4-8c3667c6edd4	2026-06-23 00:12:47.736+00	2026-06-23 00:15:27.638+00	MAINNET	SOLANA	\N
cmozyzjd80000k001gz7oacap	DEPOSIT	COMPLETED	0.007150799999412	ETH	300000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054063000005802ID5908BitVault6006BADUNG610580361622905254xaRi8J2BiT3ssMwufkZgvLZT6304922D"}	0xcb198f0a8be97c78c898302cc23540b0563a3c9a5e1f07f68ad6485dc65522a3	717556	\N	\N	pr-8c3c6070-872b-4bc9-be14-b2d2f23f36c0	2026-05-10 16:11:07.34+00	2026-05-10 16:11:24.858+00	TESTNET	ETHEREUM	\N
cmpza9ft20000p601doj3mx08	DEPOSIT	COMPLETED	13.257759	USDC	250000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062500005802ID5908BitVault6006BADUNG61058036162290525HbnUxmVeFGDdjRbJQiDyqCyr56304D1A2"}	51E4P6fzq3KQa8j9ooXK1EK4paEEQmKRxhAo7YG3R7WXnzLkRLhioMyzBhGuQFLuYHsAq2CahoRSPdiq3oJgdWN7	1535222528	\N	\N	pr-9296e400-903f-4e8c-a3dc-05b60649a26c	2026-06-04 09:18:41.223+00	2026-06-04 09:26:47.571+00	MAINNET	SOLANA	\N
cmp6re0j5000omj01xv9spzj2	DEPOSIT	COMPLETED	0.3066865	SOL	500000	C4gLLpuAFKEavuU85RzMFyTuBEabm5LcXjQyeJrqL1LM	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525bXifcHSrjsKennsSqADfLoVn8630433F4"}	443aF3ce7SLKeHHAN6q2bJo4qM12Xc3pd6tPCyx2fcG8ABdobfLZDMr1eUdL85kgm56DyZULYaSJDSGWpvUZRjHf	562901	\N	\N	pr-f16fad8f-ee3b-40e6-a675-5fe79b70715e	2026-05-15 10:12:49.073+00	2026-05-15 10:13:04.421+00	TESTNET	SOLANA	\N
cmp16fi1g0004k001wuodb02p	DEPOSIT	COMPLETED	0.024033899999139	ETH	1000000	0xD2fBf40ec6bC4916657c03584a5BBec48C56f603	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG6105803616229052599Wd2hAT673eHvwGBT3Qu2pEU63041B10"}	0x4c7299a4b1803c546c6bb9db72f6d129b24108745518e6ac84e0ee6c2c7735c6	898798	\N	\N	pr-feade2fe-8dae-431e-bf8b-c53ff9ca9aa2	2026-05-11 12:27:15.604+00	2026-05-11 12:27:41.515+00	TESTNET	ETHEREUM	\N
cmr8y1nvm001bl301097904fx	WITHDRAWAL	COMPLETED	114	USDC	2014769	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "i gede eka laksmana putra"}	Tcd3P461NKspgpp6avc5uTXfkxya6U35UYaqMGP5Cxhu8BT3KUXFh9HMAqQaFq4VQinWfk5jhjCCYAJ4erRJfrJ	1585295789	\N	\N	disb-99ce9ca7-2ec0-4187-a1e0-1b75fe56f9c2	2026-07-06 08:14:07.138+00	2026-07-06 08:16:36.079+00	MAINNET	SOLANA	\N
cmpf6q7yu0001ru01h9tktcd1	DEPOSIT	COMPLETED	89.609437	USDC	1600000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "VA", "vaNumber": "7293294805272453", "channelCode": "PERMATA"}	3zFpYgxxYCoBdRcvFv7eUSoJRgaGJTPn6qX4Lbo8C726XRkwh56BHAPe8K7fco4bGxyUqS8vXXeraky4bbp8KEh8	1512929428	\N	\N	pr-edae8585-2748-42a0-99b9-a2843c042854	2026-05-21 07:44:22.231+00	2026-05-21 07:45:41.995+00	MAINNET	SOLANA	\N
cmpc08iri0012mj01hrs3sv5o	DEPOSIT	COMPLETED	111.587447	USDC	2000000	EoMqYMQGxxA9ogQgdxumKqVJHEMR9QjadKTo1SX3ui9X	{"method": "VA", "vaNumber": "8930250136443713", "channelCode": "BNI"}	33RyL28tVd26fj1qEitVsMr9ttLbritXyxFDXi1a6vvxzVfHXeMFabLoKG1jMGAh4g1sfsSeNL2jMfJTQVJBkfAh	1509238788	\N	\N	pr-ca349bdd-a32a-4ca7-8881-2fa11afc5490	2026-05-19 02:19:20.19+00	2026-05-19 02:20:46.882+00	MAINNET	SOLANA	\N
cmq53eg600000ql01xci8ahrw	DEPOSIT	COMPLETED	7.749745	USDC	150000	GPMQYaRd39L4i986Uc8pSN45njDDL65nr4D4BRtKCu2T	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525NJfcgi7GDNimnJnErtvuLebZk6304CD3E"}	5aTrUu6yCAtGiN21cQ4frT9SLpQV5eEvmxDaEonHRqvv2iM68LPfCCjBRvnGAeWyNJ8DaWT8srWhqwEiundGBsbC	1542463387	\N	\N	pr-dc6f2148-1787-44fc-aa58-1e214dcc7a52	2026-06-08 10:53:14.713+00	2026-06-08 10:54:40.158+00	MAINNET	SOLANA	\N
cmqkpmsws000vl301ezlecvzq	WITHDRAWAL	COMPLETED	20.286706	USDC	354781	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	{"method": "ID_BCA", "accountNumber": "7445116700", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "kelwin"}	VXu9dXExgbkkd53ZTqiMwg5N4UpWs8Vzztd3M32Jz7Je2DvMJV11gR1dcap32anBBBZCuSfrrpqEVwUFVJmb6MN	1559443480	\N	\N	disb-2c374749-9208-4e00-a69f-6784f0bda35a	2026-06-19 09:12:08.668+00	2026-06-19 09:15:26.602+00	MAINNET	SOLANA	\N
cmryy4c3e001jl301zflfa3gg	DEPOSIT	COMPLETED	10.645687	USDC	200000	6BXWFQo1zdysPBZFyDaUjLC4Myy2oFDjMx1LZNkTYYYH	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525WX8DQusER2t8XTWwJ43yPnYLc63046EFA"}	2ZTZodfRy4FWcXL4hkw9Zggxa3mnLJTouo5YXHRLU9KZftCCGGYyVzg9Dn8fxs9b8Ct7EyC1uftk21h29JmQYqw2	1610703832	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	0.026614	pr-adb72b73-198c-446a-8032-ce8c6a56c00b	2026-07-24 12:58:12.41+00	2026-07-24 12:59:56.209+00	MAINNET	SOLANA	2ZTZodfRy4FWcXL4hkw9Zggxa3mnLJTouo5YXHRLU9KZftCCGGYyVzg9Dn8fxs9b8Ct7EyC1uftk21h29JmQYqw2
cmpjpval10005mq014o0k8oc9	DEPOSIT	COMPLETED	1129.568437	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294801167746", "channelCode": "PERMATA"}	3zVRVKjokwTesMDLCW5zc1bqTiUByryEZcfDBYn5fNCciydq7jtmnDKGKhi8mb6HST1NRYhdDrRq76ijbWwNWfNQ	1518056677	\N	\N	pr-99e6e507-2f63-4c10-9049-661c17016d2d	2026-05-24 11:51:16.31+00	2026-05-24 11:52:30.3+00	MAINNET	SOLANA	\N
cmozmj8gr0000k001w1o335b5	DEPOSIT	COMPLETED	0.603389499	SOL	1000000	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525m4EyUYkReoKvHcNWvNNnjCSMi63047C06"}	5jHRuJZniD3CirASxEi3XTZJuudWUnqne3E5n22mdCpVkCLNXAf44vWckuvB1zmeXBg6LPCsmwxKSqEme52sevjA	223217	\N	\N	pr-76b9c8c6-d244-4b49-8170-4832af4540f3	2026-05-10 10:22:31.324+00	2026-05-10 10:22:43.075+00	TESTNET	SOLANA	\N
cmonty4ua000jnl01hr5nav3h	DEPOSIT	COMPLETED	36.662456	USDC	635000	3w4XXxkdFSVtYbXQD9uPAoRJJopGDWxYLpetRKSnrF9p	{"method": "VA", "vaNumber": "88908298468058865", "channelCode": "MANDIRI"}	616B1CE1PdyM3m7nXpEtRf72H9m9J3RE86KsAQP8gYuEmfLRBu36vPZAx74cuQ2JbZBoLGaTpcFHpwBCsKhE23rv	1482987840	\N	\N	pr-3ca6571b-cce0-40b1-8367-267573115777	2026-05-02 04:16:49.666+00	2026-05-02 05:00:54.826+00	MAINNET	SOLANA	\N
cmqq9vux10012l301m3e6wax4	WITHDRAWAL	COMPLETED	26.177173	USDC	460165	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "pasha renaisan"}	4i3PLsDkYUsuuk5kDTWBfPkP6RUnfzxEDuR183Tvc6hSZS7hw8HSTc4w3ZL5nBwA9muGf1917mFqJgPE1kmUqjMa	1564875356	\N	\N	disb-caccd459-9c92-4332-8bef-5e53a5429c3a	2026-06-23 06:37:54.374+00	2026-06-23 06:40:26.924+00	MAINNET	SOLANA	\N
cmoyb98iv0001nv01phozgdoa	DEPOSIT	COMPLETED	0.00138449	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525SY1wBdW22BhRh1s12BmeZi36i630471F2"}	1c0cd6ade3d14cc32234e073e782419d8ac8b3e5e3832c9dcd2121232ca7c871	61596804092	\N	\N	pr-498571d1-7a5c-48d1-a358-95f72ea45e86	2026-05-09 12:19:02.887+00	2026-05-09 14:59:49.048+00	MAINNET	BITCOIN	\N
cmp0edueg0001k0015j4n6d8q	DEPOSIT	COMPLETED	2.9590305	SOL	5000000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "VA", "vaNumber": "8930250121364847", "channelCode": "BNI"}	dyWi1STi3DQb3XSi7KvqsTZGdQquvKr7oxSBVPL2i9wbdDnaX6EejeFbkZd71UisDxbLqY6qrSPRWcNAETxLg6A	17061634236	\N	\N	pr-a71b6bd3-5598-40e8-91b5-771bc4613e96	2026-05-10 23:22:09.065+00	2026-05-10 23:25:47.183+00	MAINNET	SOLANA	\N
cmq54ni8d0000pf01e2rz3nz5	DEPOSIT	COMPLETED	0.00014093	BTC	200000	bc1q7eu84v58kxj0r9u72vmjze7wlrnsdg5n79uv2r	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525rtEDfxDEu8U5XZkhHPXV2zGyi63043053"}	2209f9589fb58bfcf136ea8c219ddebe0109ed5570d983acfb24d064aded0c68	63017255631	\N	\N	pr-4422b949-4e94-4e32-82c9-b95ae01a6b7a	2026-06-08 11:28:16.91+00	2026-06-08 11:51:49.215+00	MAINNET	BITCOIN	\N
cmrjj651o001cl301va5yhe63	WITHDRAWAL	COMPLETED	85.526216	USDC	1524699	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "pasha renaisan"}	WSjuXtZ8tx7PrFj2qwDrVkVtCoUnVhdt6QM6Jy6mPMMwQ4QFyd7k8iZdg9nqJwuWke7jtRGKaDeREk5sw9SNUXL	1595440341	\N	\N	disb-93eec6af-d410-45e4-a531-739a46c99e22	2026-07-13 18:03:09.708+00	2026-07-13 21:09:41.984+00	MAINNET	SOLANA	\N
cmqu34cs10014l3012zoqzt75	DEPOSIT	COMPLETED	0.0008828	BTC	1000000	bc1q7325a45uk2p2m642786l3hjgfl702nvgdvqnfe	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525QdZdA1FXs9UuZoxQE6TwbRPX663049134"}	2452e648a8275f0af12828d888f685b193b30e11cb19c14c12178e53f66928d0	63794781852	\N	\N	pr-0ba24dd5-7859-4da2-8000-a70e1b945d46	2026-06-25 22:39:38.161+00	2026-06-25 22:44:42.106+00	MAINNET	BITCOIN	\N
cmq83pvmn0000l3011od7frpw	DEPOSIT	COMPLETED	0.00042326	BTC	500000	bc1qdhcq4dcyv7w4xsxzs2dgwf6jw0k6v60ztdhf9l	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525eeg8BLXVJwx6CCSJuQU5qDYEQ630476E9"}	5a920d7293ff1c4bd1f1b4ff3e833827fb525fe5fcb24f854cf4cb9a3ba48241	63147479357	\N	\N	pr-bb75abf8-c010-4475-bae7-d5de3165dbaa	2026-06-10 13:25:26.495+00	2026-06-10 13:37:58.977+00	MAINNET	BITCOIN	\N
1959feb0-b13b-4ccf-b969-c4085c41a749	DEPOSIT	COMPLETED	0.004131119447196	ETH	150000	0x565F164BA785E93557305Db172e29fC4E08c899a	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525CUAk3mnn2csfQNHkqv3Px4Zph6304E908"}	0x098bf975873be57b1acd783a97a35963b04d8d907bcf172d4a16b007e1f24c64	16792659	\N	\N	pr-a2afe44a-b571-4e9f-84c8-b5d307f90276	2026-07-30 15:06:53.426+00	2026-07-30 15:07:02.717+00	TESTNET	ETHEREUM	\N
cmryyfbt6001kl301ja05p44a	DEPOSIT	COMPLETED	0.00039438	BTC	500000	bc1qnmgrlpn2htngd0n6ggq43ekvp6dv7mwcwzlkwj	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG610580361622905251RodtJYguqUvyU3H2GHNcrkvJ63040928"}	f11c6c37853ef0381831f3d295cfc07541eb15e3a6786f7200853b3b2c93137e	64830788387	\N	\N	pr-f73443d1-71f7-4dcb-b6b2-5e4bfdd244ea	2026-07-24 13:06:45.258+00	2026-07-24 13:10:08.507+00	MAINNET	BITCOIN	\N
cmqlzcf13000wl3019j0ly20p	DEPOSIT	COMPLETED	6.262619	USDC	120000	65mufTpBd7ktPBBTP3Jhg9kgGjSxWKUnLgYY5L5j4wp4	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525Jptimbdcpev7nYCPcFaMgxzQw6304DDDA"}	w9P1HXtsREAQ3MohhrogjdTxaHNYUJup3f24ou7cRJKWE9uziYADk2hWtxjqFYxYgjwzoatTAFSRhU8yMwNNtCB	1560740953	\N	\N	pr-734b5a0d-5b2d-4488-8210-7a2766ea05d9	2026-06-20 06:31:46.455+00	2026-06-20 06:32:42.45+00	MAINNET	SOLANA	\N
cmozmkjoz0001k001ly86oofj	WITHDRAWAL	COMPLETED	0.336533985	SOL	536569	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Eka Laksmana"}	5d7Yn1ayF4Efrh7ViGonGxUVx6cFQcmTNtMu2Aa34MMXstQbQavzybggdutbn6mV7PykEYbjqeM7JZkP2jeJ6Ehq	223244	\N	\N	\N	2026-05-10 10:23:32.531+00	2026-05-10 10:23:56.321+00	TESTNET	SOLANA	\N
cmq5593n80001pf01dbn621ef	DEPOSIT	COMPLETED	0.00014093	BTC	200000	bc1qfc5a5sve79cvqrvky7mdccd7q6uq0xd0mnhc7l	{"method": "VA", "vaNumber": "8930250120086189", "channelCode": "BNI"}	f2796a91ec8818cf054916d036c2a1b1e99fcdb918417df83022056ddd07daea	63018297581	\N	\N	pr-4ef61dca-65ea-4403-b276-e12e5d48540d	2026-06-08 11:45:04.436+00	2026-06-08 11:51:49.221+00	MAINNET	BITCOIN	\N
bcd19531-0323-4ac0-a275-413cc85dc818	DEPOSIT	COMPLETED	8.5014299999	DOT	120000	14zRcrEEghsNF5msJ2HirCLnBTVtYVsLWCaXbWHfaZfdm77L	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525jWLqzWivb336V6Zch7F2FQX9k630456F9"}	0xe9eb6ba9a73b58dbde505d3d212bf0298dd0d47bd6ac95ff3a4e6350b66920e3	6158797061	\N	\N	pr-c3f4c637-3989-4a25-ab96-0be2e86eacdb	2026-07-29 16:34:38.983+00	2026-07-29 18:33:28.296+00	MAINNET	POLKADOT	\N
cmq1xyylm000no601w5keooy9	DEPOSIT	COMPLETED	0.00173195	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525U3s23qiQsbxCYS2q4fysAUEM96304DD97"}	18dae129b1e91ff3489d844d181c03690da9ff5b8d5aaf9b72b8d0c25687c8fc	62877040946	\N	\N	pr-b9b027f2-a867-46ee-9961-f0dbc19dc06d	2026-06-06 05:57:55.499+00	2026-06-06 11:18:05.515+00	MAINNET	BITCOIN	\N
cmqqb6vuz0013l301wq31u4qy	DEPOSIT	COMPLETED	0.00084284	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525VNfqYbfHackkYoapxm97xCN6c63047AC9"}	bf51e6a288a6ed41aa64fc524e68f2e9b15665051c38bdd013dcb68fde263151	63638055022	\N	\N	pr-2d45ad01-e661-436c-8a7d-94440ad075e6	2026-06-23 07:14:28.427+00	2026-06-23 07:18:22.698+00	MAINNET	BITCOIN	\N
cmrkiqgmc001dl30155pd5sxc	DEPOSIT	COMPLETED	6.200092	USDC	120000	BQnyCdHLjMopEHKaXvSbJCG2BSz1EEVTUQqD8g9WKg8P	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525SM8mtLnA6psDFFjCEpPSVRrqD6304804C"}	46q6E3w8odfgZRjCFH2muAR5txY5yN6ebVePL9TpSsrMF5CUoB5gacziLYctrJeLJzkyBJbDXifUYqLXeJdjWg1a	1596399450	\N	\N	pr-3bbed65f-e306-4800-a558-6e1f3e3d6065	2026-07-14 10:38:44.388+00	2026-07-14 10:39:32.62+00	MAINNET	SOLANA	\N
cmozcj5k50002nv01ubu212mx	DEPOSIT	COMPLETED	0.0689245	SOL	115000	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061150005802ID5908BitVault6006BADUNG610580361622905254fr83fR7EXN8kmCPu8sRtQoRc6304FA35"}	4NvetESXkgeW2mhisacJB45HEsWFWzfTzjJh8bAmAKGrKEamcdPdJWQg3VnxvXAahCzFnZEht42JMzNxijHi1rt2	214070	\N	\N	pr-bee12dc6-f043-4383-b481-fa609255182d	2026-05-10 05:42:31.397+00	2026-05-10 05:42:59.221+00	TESTNET	SOLANA	\N
cmfuicr6e0002k1a3ja4sm102_migrated	DEPOSIT	COMPLETED	0.001169	BTC	2300000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298441367599", "channelCode": "MANDIRI"}	053cc62fbb34b602ac5790a879ee1f33d0af9c1b16e3092480ffb386a526ac92	48979603666	\N	\N	pr-1835e542-2716-4c03-92b7-ac46277c5056	2025-09-22 02:29:18.614+00	2025-09-22 05:58:09.928+00	MAINNET	BITCOIN	\N
cmpxjkm740000ob01n0fv4csy	WITHDRAWAL	COMPLETED	99	USDC	1758018	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "I GEDE EKA LAKSMANA PUTRA"}	3dhg85KWk7oeCmCXd4DPAWbaCTsNJJt8TF5ewnxQBGR1aWUj5gfHE4Nq93H1fNY3UkeWVTMMLkcoxg4zuTazqmxm	1533418866	\N	\N	disb-4d71b343-6342-4007-b9e5-968b992a54f0	2026-06-03 04:03:46.912+00	2026-06-03 09:15:41.645+00	MAINNET	SOLANA	\N
cmp7oyoxh000qmj016jq0lrru	DEPOSIT	COMPLETED	1123.57442	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294816361584", "channelCode": "PERMATA"}	38Vccfi5sgUrLHC6KqJyYgGMYZc56TSB5bSGTzPece7MiyGeYFvJF7iC5aEHz1JFFxzCSVsH7SchiNgX7ACEzYDb	1504612254	\N	\N	pr-15deeb48-ef4b-44ca-bb80-87d29b8465cc	2026-05-16 01:52:41.141+00	2026-05-16 01:53:47.244+00	MAINNET	SOLANA	\N
cmqxex1l30015l301x4upw76r	DEPOSIT	COMPLETED	54.474116	USDC	1000000	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	{"method": "VA", "vaNumber": "88908298481522445", "channelCode": "MANDIRI"}	3ALSqza5FamyLEY5AcnMM4daDD62GkgmbLeXv9rvWLTEmvnk5gnHvvpMyzftmmXqHXUUcnKkSQaiQhiF8be8PwZv	1573064801	\N	\N	pr-52af6313-c10e-466e-95d9-bd37f7713cff	2026-06-28 06:33:10.984+00	2026-06-28 06:34:47.53+00	MAINNET	SOLANA	\N
cmqal39p40001l301jj0pr4y1	WITHDRAWAL	COMPLETED	149.67228	USDC	2651564	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Pasha Renaisan"}	5h9aMpT1LnnJ4cgMpocy9DWUneFny1ber6FQVGAtvgqES6dHwa1A7gVubX2FtmHtAtWKrzLuyhUgci1iCcYFLmwh	1548709717	\N	\N	disb-38212045-70f8-45ee-8d73-846e50216b7a	2026-06-12 07:07:17.08+00	2026-06-12 07:11:20.939+00	MAINNET	SOLANA	\N
cmqd29g1f0007l301hmvztdvz	DEPOSIT	COMPLETED	27.012129	USDC	500000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525aThFZwt5QzxW3tKDmeM8bmC8K630471F2"}	23nfx6j4Q1aahQ7GYEQJehs6mf9fcdy9xE8n4uSYRzVWjx33cYNKn3tPfVwrj2N3k52aEXnJ3hGbuPmhndU3eAoM	1551257413	\N	\N	pr-33506536-2c8e-4d7a-948a-f6ffaca0165c	2026-06-14 00:43:31.06+00	2026-06-14 00:45:00.044+00	MAINNET	SOLANA	\N
cmq0x62uk0008o601w0i3ufb9	DEPOSIT	COMPLETED	8.133497	USDC	150000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525YS6wbQQHawp1QuHqFbUxkr8vn6304E13E"}	8cN1KJMcffnJP5YagQZg4uGwiuiiRAnJ447NHATrqAyzoPHfBjJHo3KAUso5KqATSjayfY7TGiaLuwYbrGKfWKr	162812	\N	\N	pr-fbbff202-aa91-4cb9-9c4d-fc93f8518778	2026-06-05 12:47:41.804+00	2026-06-05 12:50:43.856+00	TESTNET	SOLANA	\N
cmq1y2vx3000oo601iovw3q75	DEPOSIT	COMPLETED	0.00085283	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525jXEWMWz9YepaW1CzN5qmMudXc63042F72"}	5740a141813a1d30092c24c0a7809c467c5b14fa79a9dc8fd8a5a68c3d227717	62877308007	\N	\N	pr-53d231e8-ae4d-4040-ae69-33e76b426598	2026-06-06 06:00:58.648+00	2026-06-06 11:18:05.522+00	MAINNET	BITCOIN	\N
cmp9vbkwh000rmj01acccq5ud	DEPOSIT	COMPLETED	1125.572439	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294815734176", "channelCode": "PERMATA"}	5ZKZqc4HXTXdxzYyGWCnVzL4n5xRvXRaku8T5WD5ZmDzVn29QfwxEgQ3ZbiG1dEVSvuBgsLimkCeQMWNxBDweJE7	1506666191	\N	\N	pr-1fd82083-8cb5-4e35-94f3-b39861f4d631	2026-05-17 14:26:12.497+00	2026-05-17 14:27:33.06+00	MAINNET	SOLANA	\N
cmozmr0ne0002k0011t4mqv2z	DEPOSIT	COMPLETED	3.0179725	SOL	5000000	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540750000005802ID5908BitVault6006BADUNG61058036162290525BvNppBxdw6Qp8exDo1TSyuiUU63044D12"}	LonERqigDreRFuJgiQQGnkrjmEDPvZus77v2BBQBLcXmFy8Sg1tX4tfRvJsCqZ8xLpmN1a8BvapfKmiVU9B8QwX	223408	\N	\N	pr-426643ca-41f8-4546-9018-f17d79995a2b	2026-05-10 10:28:34.442+00	2026-05-10 10:28:43.264+00	TESTNET	SOLANA	\N
cmpzhro0k0000s201sq5vinn3	DEPOSIT	COMPLETED	0.115588529	SOL	150000	FghAY44kjdGg6XNvY4CjtcMhzvssA9d9Ts9m5Eh9mLGT	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525VXZfz8DwAJsEJnXH86mRJm5Jb63042410"}	4FQKhUCaMTeZvEZbXtDyGRwyEy59Fk5sZLb6tNdMaYi32aTGVRdWVo1Wunbvjnk6jt5PFeAsMqrP9HJ889KBXQSG	83426	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	0.000288971	pr-c956f784-469a-4e5f-bd53-0b043955defd	2026-06-04 12:48:48.98+00	2026-06-04 12:48:59.72+00	TESTNET	SOLANA	s9nu2Cvv2AHkXYi4eyMxUuePMHMEp7g5UNwHJ4J23Sj8KJJxSqMfD7xKfmYqRLvXgWhd4T7YUBpwwELnmYnoYph
cmq69k6nt0004pf01x2hwrxul	WITHDRAWAL	COMPLETED	92	USDC	1641286	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "i gede eka laksmana putra"}	27xQE3ho51zGfqAcCkWnAfdpbmJtWKweJRGdup5cGU2Q1erZXNkW8xeHSys3iEE2UHqUkhUSE2yUBTNdrEi1mKhv	1543949181	\N	\N	disb-12bdbb64-c9d0-4dd9-adb5-0a6d96ea4d14	2026-06-09 06:33:26.201+00	2026-06-09 10:34:19.3+00	MAINNET	SOLANA	\N
cmosmihon000nnl01go80fnaf	DEPOSIT	COMPLETED	0.00347021	BTC	5000000	bc1qu08q2f5ktr2qyk6fq0evnf6vrtv5kqyfl5974e	{"method": "VA", "vaNumber": "88908298415609054", "channelCode": "MANDIRI"}	9ea60f9285387565240cfd84c127abecf0552fefab5499ee841b38d8dfee5b8e	61430632932	\N	\N	pr-826fadc9-aa82-4071-9359-1f2af4a5aedc	2026-05-05 12:47:33.383+00	2026-05-05 13:34:08.043+00	MAINNET	BITCOIN	\N
cmp1jsv7b0009k001fx02q2rs	DEPOSIT	COMPLETED	0.2887045	SOL	500000	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525GF8ZsKRFSwgV6bxTe45tX2LVW6304131D"}	3zzJ8bSjrNMp3b7zYWQuoeD7e9BeFo1xHKR4me3GWPeK6aXAeN3PL8LJ6kGUjysq73uhRYonQTG5DEfW2g7eqFrm	337752	\N	\N	pr-b69408b4-f4bf-47a4-aa43-7d734b652a66	2026-05-11 18:41:34.199+00	2026-05-11 18:41:46.788+00	TESTNET	SOLANA	\N
cmqyrqtta0016l301b9f0cxlz	DEPOSIT	COMPLETED	27.007016	USDC	500000	4wBsuuCvfTHmWSDRTwng6kBB69yo1cKSuAjnY6DgoqDL	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG610580361622905251k9iZjib9bTugCTjyU1qYThxE63049D67"}	3RvH4kdJnUL1G3atXhF48EqKsY4Hw8SjdQgXJ3K9wa1ykZk3fYJrru695LEZuVqSYiUhvx3GKnAfwuDedJDTjG9e	1574467194	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.067517	pr-e06cf899-333b-45e0-8746-d904ee5f9fee	2026-06-29 05:20:02.158+00	2026-06-29 05:20:53.876+00	MAINNET	SOLANA	3RvH4kdJnUL1G3atXhF48EqKsY4Hw8SjdQgXJ3K9wa1ykZk3fYJrru695LEZuVqSYiUhvx3GKnAfwuDedJDTjG9e
cmozcw5oq0003nv01e0vlnko2	DEPOSIT	COMPLETED	0.071921499	SOL	120000	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525E948PwppSZY6vs1whiuEtjVZU6304CB48"}	3WKDfMxPSui2SKvNME5jWhkzkrt5AZiSSfcZLQuDiJcMijiNyE6t4TsQjccQzyCvNAxh663z4dom1P3FDRCPPQzq	214284	\N	\N	pr-404433cd-674d-4aea-824a-c8f4f9f62c30	2026-05-10 05:52:38.09+00	2026-05-10 05:52:59.33+00	TESTNET	SOLANA	\N
cmpstmbkc000nmq01hs5gkrvv	DEPOSIT	COMPLETED	0.00034943	BTC	500000	bc1qdhcq4dcyv7w4xsxzs2dgwf6jw0k6v60ztdhf9l	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525wqbsuKsfMqq78MP2ZXkmUVWDU630434C6"}	fe8ff6020c835587a458c1b8947bc9904632e13a8b087597ef9f2b9dbded6820	62401124937	\N	\N	pr-541ffcac-38e3-4121-a194-f7e86a2b7dae	2026-05-30 20:46:11.724+00	2026-05-30 21:10:43.614+00	MAINNET	BITCOIN	\N
cmronczs6001el301b53tc26z	DEPOSIT	COMPLETED	0.00170307	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG610580361622905257ySy4WnoNw64dx8HpzwQYvPWv6304B467"}	c73187f8e9d1d91fa1ffcd845c8cac45f759430846d39a54fe447883179e9635	64614798912	\N	\N	pr-6b5bcae2-d1bb-4313-bdd1-4c4ada4f25d7	2026-07-17 07:59:18.822+00	2026-07-17 08:13:09.918+00	MAINNET	BITCOIN	\N
cmqd2uyv90008l301yqmqi9x7	DEPOSIT	COMPLETED	10.612216	USDC	200000	8zp7EfHhrd1L18UsWkx1z2GCLjdhDn5mzgMyA1BFJhAK	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525y8qYpJQLck4sY9S1AH1Za12Ki630454E8"}	5ZdtXKCX8ad8euScE9nUatLg4z9wX41Nut1eWQjq7Z6hwdj3sazaJcApiQcKRepvKAyxQgdLmTCnbeTYRaZQNa7C	1551270927	C4gLLpuAFKEavuU85RzMFyTuBEabm5LcXjQyeJrqL1LM	0.02653	pr-953b6866-5076-4463-9335-061d886319cf	2026-06-14 01:00:15.238+00	2026-06-14 01:01:50.605+00	MAINNET	SOLANA	5ZdtXKCX8ad8euScE9nUatLg4z9wX41Nut1eWQjq7Z6hwdj3sazaJcApiQcKRepvKAyxQgdLmTCnbeTYRaZQNa7C
cmq0y4qw50009o6012nxgwpmb	DEPOSIT	COMPLETED	6.499213	USDC	120000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525g9nsFbq1RP3NVSsXNB4P1q6Xh6304E7B0"}	47T5uA222h8KvQN7sp7WzTWZtKMCCm9wMqKeWgjujz6qzjHnYEMPo4WWCbFAA7ZybdmPRhTCjrc6TYS4pqKL76Zu	165683	\N	\N	pr-f53034a4-cd35-4cfa-8437-244b6ca696a7	2026-06-05 13:14:39.269+00	2026-06-05 13:14:58.934+00	TESTNET	SOLANA	\N
cmpfaqgc40000pv01nt2ijrbq	DEPOSIT	COMPLETED	11.658298	USDC	200000	6KnPswERjjoScJLxf22Yp1MKoiRbC2ZXMW8HJT9MjULT	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525UNy2TqGtzzbDr5UJDed2b2uEr6304BBAF"}	3mawNgVYpeBBDowsbygyaRF8NTUBSzgfJthYwShaMJ9XeenvdLdrLDLhmRhTMPgERmnWz55W14bdbzgkXc5THxDx	1513228842	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	0.029145	pr-6c4aa035-0f73-4b07-bffa-b2354c27c99f	2026-05-21 09:36:31.54+00	2026-05-21 11:53:53.84+00	MAINNET	SOLANA	\N
cmp1juicr000ak001zqscgoz5	WITHDRAWAL	COMPLETED	1	SOL	1671185	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "ID_BCA", "accountNumber": "0986567211", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Kolamaru"}	LEiSFhdx4oZ2aLPiAST7YKr8ACRkmXJq1aiTtzq9dXjfx2MKH85vSD8vt8Nao5T29ZcmvqAQYbUoDDYfNrtAka4	337855	\N	\N	\N	2026-05-11 18:42:50.86+00	2026-05-11 18:43:20.826+00	TESTNET	SOLANA	\N
cmogx29p20009qp0173t5fve9	DEPOSIT	COMPLETED	0.00217847	BTC	3000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540730000005802ID5908BitVault6006BADUNG61058036162290525nob1A5TgAnbVn7kmbGwhS96nG630408CC"}	9d0cdcbc20ac154709429913a0b355463d4956716977f9831751a841b69db28f	61101702186	\N	\N	pr-71986c8b-0655-4079-adbb-b9aa7a8e47d9	2026-04-27 08:09:38.198+00	2026-04-27 08:19:02.242+00	MAINNET	BITCOIN	\N
cmosmoqu9000onl01j8uph86j	DEPOSIT	COMPLETED	0.00346761	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294805347238", "channelCode": "PERMATA"}	7ca99cc5356538291a5bec3a8fd1ca7d1d0a22b9bffd5eb2d65861dd945d0660	61430741657	\N	\N	pr-552af631-33f2-47a1-a1fd-222efe91d887	2026-05-05 12:52:25.186+00	2026-05-05 13:34:08.049+00	MAINNET	BITCOIN	\N
cmpaq1j4r000smj0142t6s94u	DEPOSIT	COMPLETED	37.661446	USDC	682000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054066820005802ID5908BitVault6006BADUNG610580361622905259WrcFb3GdstJCgg4zN8tBn5pc63049164"}	3MWDNG9YocdDhj5WPaWnW918PbPKvUmrYdy5qr8uwznscmYz61YBCsoiMXytgRK2zLeHvUP8iT97QFSAByZ9KBi9	1507633019	\N	\N	pr-e4321ed5-331b-4b1c-9348-e89dc2e08854	2026-05-18 04:46:11.739+00	2026-05-18 04:48:08.951+00	MAINNET	SOLANA	\N
cmozf3fpo0004nv010azcuuys	WITHDRAWAL	COMPLETED	0.069795971	SOL	108867	HK31BJKAiMQmK6f3rtJBAMRaDUhERaroGcs38GQGRDVm	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Eka Laksmana"}	qsL2cdCoRZ3RJc76SmvBnzNsQQTRLATD2cp6oHbAN3eAEwrKNy6UkJkjus6imHxw4V8qE6XGwyETvrTxErtKT5X	215652	\N	\N	disb-5cc4121b-f207-4184-8690-4ba07d8baf38	2026-05-10 06:54:16.906+00	2026-05-10 06:54:47.318+00	TESTNET	SOLANA	\N
cmgnhg4tv0002k180ppef0irg_migrated	DEPOSIT	COMPLETED	0.005262	BTC	10000000	bc1qnmgrlpn2htngd0n6ggq43ekvp6dv7mwcwzlkwj	{"method": "VA", "vaNumber": "13282277369647121", "channelCode": "BRI"}	d1ea1af83e51fc72e5396e83855aa4c2afcfd2fffd391776ca3315c252b6e806	49989460016	\N	\N	pr-a3a87343-cbbc-4f5e-a1ec-58a6b1e2cb76	2025-10-12 09:09:15.763+00	2025-10-12 09:47:54.81+00	MAINNET	BITCOIN	\N
cmifwfnnh0003k1imoi88ml1t_migrated	DEPOSIT	COMPLETED	0.003357	BTC	5000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298497462874", "channelCode": "MANDIRI"}	9d2bc1477725a8dea0d1a2d3663ff5b3170280f924d6e81b1c12a792cbe9e603	52895452127	\N	\N	pr-4d3e35b1-6d7a-4e11-94ed-3334b224a4bd	2025-11-26 11:06:03.005+00	2025-11-26 11:18:13.211+00	MAINNET	BITCOIN	\N
cmhh5ep920000k1gd8pw2rlt5_migrated	DEPOSIT	COMPLETED	0.00051	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525dUbxTMAGLlpibQgwutUs9OdPb630481CD", "channelCode": "QRIS"}	8ec0d392dfbb46ad7e0bdfb961a2a21a4d3a029dc226381342f06b920b081c94	51156416886	\N	\N	pr-8e1817b6-8105-482d-ac5b-60cea57349e2	2025-11-02 03:25:18.806+00	2025-11-02 06:28:04.878+00	MAINNET	BITCOIN	\N
cmrqeybgb001fl301o0jaytws	DEPOSIT	COMPLETED	0.00039828	BTC	500000	bc1qkv4d63d0u7r8uz9tpthg3474393v3dxguxk7d5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525jjSurRcnngZsv4NyEro2W4Z6c630417CE"}	0db2c21ab3399d01b4f5b3365a1286509b690b65b9eccb59fa09f1e7988d87e5	64649668637	\N	\N	pr-f89d65bd-e8e5-4369-9639-ee391a97cd3e	2026-07-18 13:39:29.531+00	2026-07-18 13:44:39.28+00	MAINNET	BITCOIN	\N
cmpzkrg540000o601evq4wgnh	DEPOSIT	COMPLETED	0.00421425	BTC	5000000	bc1qu08q2f5ktr2qyk6fq0evnf6vrtv5kqyfl5974e	{"method": "VA", "vaNumber": "8930250129636291", "channelCode": "BNI"}	94ad95d5434cacc159233ab00995b4edc63fcaf3b7a492d6b1d038a340c83640	62691900405	\N	\N	pr-4054b641-e957-48e3-9dc5-7450c3b9eba6	2026-06-04 14:12:37.625+00	2026-06-04 14:21:26.515+00	MAINNET	BITCOIN	\N
cmqaxfrny0003l301o02j3om3	DEPOSIT	COMPLETED	0.00040328	BTC	500000	bc1qdhcq4dcyv7w4xsxzs2dgwf6jw0k6v60ztdhf9l	{"method": "VA", "vaNumber": "8930250123372559", "channelCode": "BNI"}	60f1c495e3cb148cab471451b30e7cd85553ace1bee942f9a180aa56493c27de	63246514401	\N	\N	pr-577c097e-5e22-41b7-8811-d0467c96ed89	2026-06-12 12:52:55.63+00	2026-06-12 13:30:20.978+00	MAINNET	BITCOIN	\N
cmoe7phd80004la01u466f06v	DEPOSIT	COMPLETED	11.348748	USDC	205000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062050005802ID5908BitVault6006BADUNG610580361622905252YYDcqw8JCqquLBLPz1FFm83z63043CF2"}	4xbemK2wLpTN5JT7v9RwPoV1e499qM9yhgH2YEtzdDDjhL3L5QW1J6Dgg9zJ1zti3hnphy8aRFTEDNRuFyKpz7AD	1473338608	\N	\N	pr-2c412d6f-39e7-4efa-912a-a4819b862181	2026-04-25 10:44:18.86+00	2026-04-25 11:08:57.475+00	MAINNET	SOLANA	\N
cmoe7q2uf0005la01ore0kizp	DEPOSIT	COMPLETED	0.07766045	SOL	120000	51tsDJ2rbNhEF6Mo589uRXyeTTtTSX5kLZSUxhurL45s	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG610580361622905255NuTxy8DDfCbBHuWnQNQ3aots63040F5B"}	4toVvW6r6jm9mi47DM6tzb9VFxEtLmTT63Cuhsic1go3AYkDHvbtA5UeTip7VP2SCETNr8oubAi18pZDQ7Crix5L	16995316621	\N	\N	pr-9d94d769-48ee-425f-91c3-84057cc0b06f	2026-04-25 10:44:46.696+00	2026-04-25 11:08:54.097+00	MAINNET	SOLANA	\N
cmoeb0jz70000mh01jkyera32	DEPOSIT	COMPLETED	0.077910916	SOL	120000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG610580361622905254rrxzFfVJpHdtsgQUxuR3kZA56304AC48"}	28C4rYfrJ3yWziGZQLhAMs1kMAPPuFURDwUTLbKUMrRHKq574hwDotAT8bq2sgKHJbiNHiD52zX3evRhQWXhorc4	16995444179	\N	\N	pr-e9a4d724-f3de-4301-90b7-173e88094548	2026-04-25 12:16:54.306+00	2026-04-25 12:42:52.907+00	MAINNET	SOLANA	\N
cmqyrubde0017l3018v7gcl1f	DEPOSIT	COMPLETED	26.994286	USDC	500000	4wBsuuCvfTHmWSDRTwng6kBB69yo1cKSuAjnY6DgoqDL	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525fihu7pgWu1rGLpprf7kFwzSXC63042C0C"}	5nJY2774L2otCv4Za9TGTMkQg3Kcw4uzyHsqGeFovyGc6LFzRsxECKp2X6coNDJ69moBknoM1VwpPKDxAfo7bScX	1574470493	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.067485	pr-8cfc9145-4c64-4b68-99bd-17eff3416154	2026-06-29 05:22:44.883+00	2026-06-29 05:23:48.931+00	MAINNET	SOLANA	5nJY2774L2otCv4Za9TGTMkQg3Kcw4uzyHsqGeFovyGc6LFzRsxECKp2X6coNDJ69moBknoM1VwpPKDxAfo7bScX
1dbc0a5b-20bf-43d2-b56b-6605abf22579	DEPOSIT	COMPLETED	0.089903499	SOL	120000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525FfH2GtAgSdTJuLK9zjyzTjYyt63045F34"}	5Fx9y7XT3j1ASEoqoTGdEiofyifP4DEwMjq3QxpkGYmq2G6ugFeMpNsAEyBzVGuMjxoqsQnKYXSM11EPPPDZq3dM	3586458	\N	\N	pr-fdf7deff-066d-409b-977e-a1cf5787de7c	2026-08-01 09:15:11.604+00	2026-08-01 09:15:23.031+00	TESTNET	SOLANA	\N
cmpaq5buk000tmj01120lntqh	DEPOSIT	COMPLETED	342.356446	USDC	6142269	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540761422695802ID5908BitVault6006BADUNG61058036162290525AwhdyRLf6xzABN6xGaQ8UM4zg63046B3C"}	2FenJrTEMYkbrXKaJ2HQuYH8paK1NChfFcLUxabaDbAjojhS1SirLu4zPe6mYs5DD8334C7wUtDtQpRty9vdpdAz	1507635061	\N	\N	pr-701c4fe7-b9f5-4222-b30e-8675350c8272	2026-05-18 04:49:08.923+00	2026-05-18 04:50:08.962+00	MAINNET	SOLANA	\N
cmpqpkei1000cmq014okd5une	DEPOSIT	COMPLETED	110.588463	USDC	2000000	8pX62tfQVDSushgJvuEZvmpeS9Uxa549EaD9JTqm5Dyu	{"method": "VA", "vaNumber": "8930250128906538", "channelCode": "BNI"}	Yr7ine1KT6NzWLQhGMm6KoFbSH1yqxHxPgRchh9fbUz5H37v4Acm5YTdMuREGZ7JNpu3brxRGuzB7TeGB4ydKiq	1525670356	\N	\N	pr-384d3cb7-1a39-405a-8d56-68465f86f7f4	2026-05-29 09:17:11.401+00	2026-05-29 09:22:02.34+00	MAINNET	SOLANA	\N
cmegs7ix40000k1uj4f1c6zag_migrated	DEPOSIT	COMPLETED	0.000559	BTC	1100000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "VA", "vaNumber": "88908298493949214", "channelCode": "MANDIRI"}	a83aae32d5c44fa7db8efee3b240edaa2c153e59985960f62b4cb48a4ee55c6e	47581864143	\N	\N	pr-5f07e01f-9f53-409a-9875-9f6388986f65	2025-08-18 07:16:41.992+00	2025-08-18 07:36:17.085+00	MAINNET	BITCOIN	\N
cmbbx6ib6000ck1xd0gwzjzpi_migrated	DEPOSIT	COMPLETED	0.000558	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250136977210", "channelCode": "BNI"}	7f17240687cec1ff4c6b38a6397df50b21092abebf48b07a5868248c977d7256	44033661149	\N	\N	pr-756a4635-7d3a-4f27-9726-bc9491ee83fd	2025-05-31 07:37:54.738+00	2025-05-31 07:46:14.801+00	MAINNET	BITCOIN	\N
cmcf2ol2n0007k1bj8bd5fx0g_migrated	WITHDRAWAL	COMPLETED	0.002006	BTC	3425849	bc1qwc6e6kw8qgutzkwwys43mjpmrf3cmjr7swwnvd	{"method": "ID_BCA", "accountNumber": "7670720955", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I G*** E** L*****NA P***"}	374586a59879cbc49554179630f0d2d3f407076b70731d30ac6d8e3deff8bd11	45357855922	\N	\N	disb-efc03256-faa7-4960-bbcf-6f9aa432dfea	2025-06-27 17:14:57.071+00	2025-06-27 21:42:46.393+00	MAINNET	BITCOIN	\N
cmd41iymb0002k1jqy42b0cwg_migrated	DEPOSIT	COMPLETED	0.002539	BTC	5000000	bc1qg8s7ypf4vtagsvrqcpspns4l9ef09m2fjeu7ax	{"method": "VA", "vaNumber": "8930250133136340", "channelCode": "BNI"}	2eef6dcc3216015474e77965058a98c4313ebb4c43aa9238dcdd97d75ca24b43	46036468487	\N	\N	pr-e3b10859-a19a-4dbc-aab3-730014ce2b73	2025-07-15 04:36:49.475+00	2025-07-15 04:54:35.898+00	MAINNET	BITCOIN	\N
cmpfhxelt0000l10107wrol7b	DEPOSIT	COMPLETED	6.992442	USDC	115000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061150005802ID5908BitVault6006BADUNG61058036162290525BPPXU4QXTEXGMSrBXav7G8FwF630477E8"}	4GEv5qPvP6WEGm2P3wDC9eQuNcnXdHrme4gZbiVuZUfvVhZMxyxDtCLefZdqGLXt1juNGHvksPbqJLY9LWgQ3rKk	886324	\N	\N	pr-77218198-f4e5-4249-81c4-7e6582eab13e	2026-05-21 12:57:53.201+00	2026-05-21 12:58:08.182+00	TESTNET	SOLANA	\N
cmpfhxfmx0001l101wgua6e7t	DEPOSIT	COMPLETED	6.992442	USDC	120000	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525foSX21GTuBqR1KffoiE2DJEa96304773F"}	4GEv5qPvP6WEGm2P3wDC9eQuNcnXdHrme4gZbiVuZUfvVhZMxyxDtCLefZdqGLXt1juNGHvksPbqJLY9LWgQ3rKk	886323	\N	\N	pr-fc812a95-1461-4e0d-b772-bcb0158bf3ea	2026-05-21 12:57:54.538+00	2026-05-21 12:58:10.468+00	TESTNET	SOLANA	\N
cmb7m0ouf000ak1xd78c2gerz_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1q0zem4xfgqn8wz4gmhnsmcrrqtv5jzzsw00nz50	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG610580361622905255FrV9Mx73o3sL2Q5wME3EdHcO630491C9", "channelCode": "QRIS"}	a4236e6007878b0deaa7e32c7f2bf03c7b0b061968fdfabdb5b1917f1c2f6aa9	43841491367	\N	\N	pr-b3e98721-f107-4eff-bbd6-29a8783f1134	2025-05-28 07:14:22.791+00	2025-05-28 07:29:57.599+00	MAINNET	BITCOIN	\N
cmegtrdai0000k1ck0g4oocwb_migrated	DEPOSIT	COMPLETED	0.00051	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250138075445", "channelCode": "BNI"}	5f44b8d706017012ae7a2d92e8835ad377631fa89acbdf31bf652494bebf112d	47583072237	\N	\N	pr-6d3612de-23ca-42b0-b72b-289355db6d2f	2025-08-18 08:00:07.435+00	2025-08-18 08:11:31.991+00	MAINNET	BITCOIN	\N
cmczttbc10000k1fofbw1gyxy_migrated	DEPOSIT	COMPLETED	0.00049	BTC	1000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298402129848", "channelCode": "MANDIRI"}	fab257fe4044fc927467e7f728d0ba71ad66a4dfe021fe3096ead535c32859e9	45896901786	\N	\N	pr-1375d8ec-55f8-4175-a2c9-1abf47eb17a6	2025-07-12 05:49:50.88+00	2025-07-12 05:54:41.543+00	MAINNET	BITCOIN	\N
cmcaz8vht0003k1bj4j946smp_migrated	DEPOSIT	COMPLETED	0.000549	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525rFlFWobaoOrDZihdwziPY8Bro63045131", "channelCode": "QRIS"}	a9adef513e4242f53f0cc34a9f75075f4e55b17a8520711e88f6d411944a1f80	45238100422	\N	\N	pr-4a2da39e-4be6-4f9f-92d6-89eb945f0894	2025-06-24 20:27:40.528+00	2025-06-24 21:54:46.059+00	MAINNET	BITCOIN	\N
cmoh32b9s000aqp01ww09ddqm	DEPOSIT	COMPLETED	0.00144403	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525BS5LzL46XDwJCz94HktBkZGR66304963A"}	ac3ed5709bd611e0c1a4278d9cb109ed7f9447556cbfcb61b76b32ffac664363	61105391063	\N	\N	pr-b94ffe05-73bc-4d2f-8ce2-a9085401f774	2026-04-27 10:57:37.936+00	2026-04-27 11:17:13.966+00	MAINNET	BITCOIN	\N
cmpxqat910003ob01ph0l376i	DEPOSIT	COMPLETED	121.378	HBAR	200000	0xDce48c400939f48549A9B468e3c28025ffD4F987	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525s6NceLf4ekzjrCLapEzPjctaq63041521"}	0.0.8555429@1780470741.456787602	1077060	\N	\N	pr-8fc52909-a614-4df4-8f71-cc1520a46b76	2026-06-03 07:12:06.806+00	2026-06-03 07:12:35.195+00	TESTNET	HEDERA	\N
cmc7remlf0003k1njd9r2egv5_migrated	DEPOSIT	COMPLETED	0.000281	BTC	499000	bc1qyuznapyjtzcpq8mj6afdpkua5xghy5z0v6nckw	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054064990005802ID5908BitVault6006BADUNG61058036162290525i2zJ87XxmZ4nhItv1AlzcRsOG63041DDD", "channelCode": "QRIS"}	250450e23234b6564fcee2999e248e9f7e52c412be9a190d5b8dca66d9e15752	45087236024	\N	\N	pr-81274526-9825-445b-bdd0-9be23f09bd63	2025-06-22 14:24:53.475+00	2025-06-22 14:57:59.727+00	MAINNET	BITCOIN	\N
cmbu5a9oy000ik1au8yhz5lbj_migrated	DEPOSIT	COMPLETED	0.004611	BTC	8000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "8930250125347238", "channelCode": "BNI"}	8c250a3cbe1dc5b920fe945050a3f1b02697f96d796ae9466fb41153e98abac8	44624831959	\N	\N	pr-6ad4c19a-e117-418b-82f7-70e80faf86fe	2025-06-13 01:44:38.29+00	2025-06-13 04:28:02.801+00	MAINNET	BITCOIN	\N
cmfus7u780003k1exez2fuvno_migrated	DEPOSIT	COMPLETED	0.000766	BTC	1500000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "VA", "vaNumber": "8930250132717493", "channelCode": "BNI"}	2d8bd2877f4d8273e7047ac751afdb29c105db39687629e9df7a78212e9d9511	48989287819	\N	\N	pr-1a9d4366-c49f-421e-9ef5-5877fb25fce9	2025-09-22 07:05:25.412+00	2025-09-22 07:31:01.059+00	MAINNET	BITCOIN	\N
cmd5opt1d0006k1jq61d3qgrg_migrated	DEPOSIT	COMPLETED	0.000156	BTC	350000	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054063500005802ID5908BitVault6006BADUNG61058036162290525ABV0rJ9rj7XeKCI7LH4LjFm8I6304D018", "channelCode": "QRIS"}	1b79c6b2b93234f5d55d3e4c4db36be6d0efa02b90a080f031f89ee2da252414	46094669151	\N	\N	pr-95fdef27-992a-4123-8dd2-f9ef5f99badc	2025-07-16 08:13:46.177+00	2025-07-16 08:15:21.305+00	MAINNET	BITCOIN	\N
cmcmuxexs0001k1rqthjbdz3v_migrated	WITHDRAWAL	COMPLETED	0.004	BTC	6933325	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "ID_BCA", "accountNumber": "4350614155", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "K**EK T*** W******RI"}	edcf8b88144bd882dbf9c8ce2f8a28e7fee70ebef3f8c720846ae564c8c13b9f	45546562577	\N	\N	disb-3ed8c8e8-f342-4037-9a21-be26aa165558	2025-07-03 04:00:01.502+00	2025-07-03 04:03:33.278+00	MAINNET	BITCOIN	\N
cmde12x8w0001k11mm1fgpjjw_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1qgx3wps4pefksr5v9fj7w9mpadf7g5jcnx5g56x	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525KTYX0XVoCGfUx3dLsyijCDgwc6304B426", "channelCode": "QRIS"}	c903293d1f27ea16f94ea8ab54971d58fdfe3643713a05009ac15ab4f194c5e9	46357270716	\N	\N	pr-03496c2c-d679-4349-aaf4-955b9d69c0c6	2025-07-22 04:22:02.961+00	2025-07-22 04:30:19.011+00	MAINNET	BITCOIN	\N
cmdin84xd0000k1t9m2kisrvu_migrated	DEPOSIT	COMPLETED	0.0005	BTC	999000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "VA", "vaNumber": "88908298490680017", "channelCode": "MANDIRI"}	560c4a98fd2c6ae5417c2c3a44e177bb232088a408999c7a21cbdc2f382d1215	46521542898	\N	\N	pr-1c3e01cf-f626-4176-bf3a-e542fb67031d	2025-07-25 09:53:02.449+00	2025-07-25 10:03:09.188+00	MAINNET	BITCOIN	\N
cmaqo5swi0000k14t70jv4kgk_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525s7zQ77PZO9AqgVyAv8Sg441736304E91D", "channelCode": "QRIS"}	b753a3649e940d1bf658f562b5a1cda799da8f321d5850c65805fdac3d3cbd19	43102423217	\N	\N	pr-dc2deccc-bbcf-4546-89b5-2609efb43437	2025-05-16 10:42:15.57+00	2025-05-16 12:13:50.461+00	MAINNET	BITCOIN	\N
cmhk79tvq0001k19ljmbeo5km_migrated	DEPOSIT	COMPLETED	0.001101	BTC	2000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298497288300", "channelCode": "MANDIRI"}	7f49894d575dfd236b363cd2087b1c11377c14110608f3054e7f905d5971cb59	51279562532	\N	\N	pr-42c9d36a-9cbb-4c86-b899-562213170172	2025-11-04 06:40:49.286+00	2025-11-04 06:52:53.391+00	MAINNET	BITCOIN	\N
cmam4ttse0003k1qgo7xk585t_migrated	DEPOSIT	COMPLETED	0.000843	BTC	1500000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "VA", "vaNumber": "8930250126832605", "channelCode": "BNI"}	6bc99c70b81cabe54dda5c4281339e3e8fbf361af78de9205818416f57c55811	42904729769	\N	\N	pr-3fb85e80-c595-4301-961a-1b86fbc22b9c	2025-05-13 06:29:59.439+00	2025-05-13 06:33:41.049+00	MAINNET	BITCOIN	\N
cmbd9zk5a0001k17x2n8utzdg_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qeqynq89y5pa4hztz6dm8utn5jwpsdjp0cpp527	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525kNNgwKQUY5USOq6NtzhCQicFX63044309", "channelCode": "QRIS"}	045aa9fb31fec8a1caa35940f2ad20c95870adcd22439ec2a532c469e7121349	44065911068	\N	\N	pr-0b9137c2-d7ab-4e6d-a4e1-82ef248001fb	2025-06-01 06:24:11.711+00	2025-06-01 06:57:10.23+00	MAINNET	BITCOIN	\N
cmamgr6tr0007k1qgaofn753e_migrated	DEPOSIT	COMPLETED	0.003345	BTC	6000000	bc1qmz8suzqrqsg3evut6hd46vwraqy533a4c46dyc	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540760000005802ID5908BitVault6006BADUNG61058036162290525NQF6CrPjO1NRgByGC0V2FSriO6304BBC2", "channelCode": "QRIS"}	950191b095f78ed2dcbf786b352cbb58545745565414c2e5ef0cf765ab2f658a	42915490706	\N	\N	pr-8971c0fa-8deb-4fb6-bdfc-856b4d9883cf	2025-05-13 12:03:51.76+00	2025-05-13 12:22:42.648+00	MAINNET	BITCOIN	\N
cmam55sje0004k1qgrf3tlvmk_migrated	DEPOSIT	COMPLETED	0.003394	BTC	6000000	bc1qvfugxzfm0kh0u9z5ewyr06pstdgt8pgxqrnh6h	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540760000005802ID5908BitVault6006BADUNG61058036162290525pe9n3RKsN47BKpB2PzNHQgT2a6304F441", "channelCode": "QRIS"}	1c14989670c2a490e7882b07644fef9e0bb55fe4bde4d3934ea7376eafdd63c1	42904930171	\N	\N	pr-16a7a6a5-383a-4b5d-bc7f-68c7d886b706	2025-05-13 06:39:17.69+00	2025-05-13 07:12:21.159+00	MAINNET	BITCOIN	\N
cmbkzqmld0005k1auyyub4p0n_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1qktchyjj0vtus5uy4sl8fhrh489gudej06lgm20	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525QFAGuZW4lvmTi2SAhH0t0fGX46304E758", "channelCode": "QRIS"}	6a1b3503663a85df6b181eaa9f55f79119234ac2e3e020c5d71e07bc6d52137f	44341180136	\N	\N	pr-df83017d-f7ee-4fb8-b295-16407a6a5521	2025-06-06 15:59:28.225+00	2025-06-06 16:14:15.451+00	MAINNET	BITCOIN	\N
cmbbvzyqp000bk1xd0ixreux1_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525LGIXQzt8IohGJzhE7fxEXf0w86304676C", "channelCode": "QRIS"}	8fd792302e1870d7391eaf32888750588f24e0ed5291b2a7a73c43900afb18e8	44033151105	\N	\N	pr-383644d9-6892-4d4c-8844-0b35005de707	2025-05-31 07:04:49.825+00	2025-05-31 07:14:14.67+00	MAINNET	BITCOIN	\N
cmb1qydzt0004k1xddbedkmeq_migrated	DEPOSIT	COMPLETED	0.001085	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298450611995", "channelCode": "MANDIRI"}	9a1aea345d8df306a6b45222c6de0fa5fe1cfbb1de1289a24b3bfdd79bb4b773	43636957419	\N	\N	pr-43f330d7-e6ba-4978-a5f6-94b01e1e1f0a	2025-05-24 04:45:56.441+00	2025-05-24 05:12:30.72+00	MAINNET	BITCOIN	\N
cmcnk0s7y0000k18obduobho1_migrated	DEPOSIT	COMPLETED	0.000252	BTC	499000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298437802860", "channelCode": "MANDIRI"}	372000f710c8d7e53239e402fc1799d3e22d0ed96644052aef3af1d4850bae9d	45571564016	\N	\N	pr-7f837136-b4e9-49e5-89dc-c34cf27c9930	2025-07-03 15:42:29.085+00	2025-07-03 15:47:53.705+00	MAINNET	BITCOIN	\N
cm9sddseu0001k1joob57kxww_migrated	DEPOSIT	COMPLETED	0.00127	BTC	2000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250123747613", "channelCode": "BNI"}	d7cf49c8576d754b6a977c2ae8d8289b9ed4a8f92b023355348d69b418bfb3d4	41766559993	\N	\N	pr-cdba674a-5d74-4fe2-b794-9b2b7fd7a20f	2025-04-22 10:36:22.423+00	2025-04-22 11:59:16.453+00	MAINNET	BITCOIN	\N
cm9se4nt10001k13c8uakvpjp_migrated	DEPOSIT	COMPLETED	0.00063	BTC	1000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "88908298493669550", "channelCode": "MANDIRI"}	b2dcbbbed5148e19492373c353c1f89c7548b0349155adc7df44446197d9f2bc	41766643570	\N	\N	pr-fb14efe0-80db-45cf-b78a-b04a7b60c311	2025-04-22 10:57:16.166+00	2025-04-22 11:59:16.633+00	MAINNET	BITCOIN	\N
cmbqgrqc3000dk1autppbmlyd_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1qx9f2j80m0c6ygmkdrp3yrg3umfevqv4d72s2e3	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525cvz12ssBYkclbVT5cUnfRN13M63040AB6", "channelCode": "QRIS"}	0c207ea7cb59d9144f35bc0e47ffa835b880228e6875610ad8f9c8197c4056b2	44477085547	\N	\N	pr-3427a2a2-0b7f-4805-8fd8-b08c1a3be9b5	2025-06-10 11:55:04.083+00	2025-06-10 12:01:06.82+00	MAINNET	BITCOIN	\N
cmbu7esw1000kk1auvjwvvrce_migrated	DEPOSIT	COMPLETED	0.009225	BTC	16000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294800297800", "channelCode": "PERMATA"}	231745ec9fbed223075892f23eb06b47f70d7ad8af9a060ac698e577a170eddf	44629403626	\N	\N	pr-49c2dea8-eb45-4d4b-bfe7-1be72c9c3f1d	2025-06-13 02:44:09.025+00	2025-06-13 02:52:11.443+00	MAINNET	BITCOIN	\N
cmc8t8pw80005k1nja6lppcsl_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1q8rlzw9e3rknus637a27fhpuqrswxra87a58uwg	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525OfrUPuokgOqZ4OD9gQQ0sd9GY6304BAC5", "channelCode": "QRIS"}	9f2ee63f9c57c5ba035f75b50542e39b07e8b1f3ad41b924fbbc78dbf405dd20	45141201219	\N	\N	pr-f6c4c951-1bf9-4bf2-9e92-9eb0b8b866a2	2025-06-23 08:04:03.225+00	2025-06-23 08:25:09.287+00	MAINNET	BITCOIN	\N
cm9wcpb8t0002k1gaweq7207j_migrated	DEPOSIT	COMPLETED	0.000291	BTC	499000	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "VA", "vaNumber": "8930250136395699", "channelCode": "BNI"}	d9f2f9e323c3d2d4e67b987c7864859e48f1ca17c6f8512eb2792f7d98d05f5d	41936251984	\N	\N	pr-ce826501-b3e5-47e3-bce7-23229122427f	2025-04-25 05:28:25.133+00	2025-04-25 05:58:57.38+00	MAINNET	BITCOIN	\N
cm9wl1gkh0004k1gavfgdfruw_migrated	DEPOSIT	COMPLETED	0.000101	BTC	199000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298436054691", "channelCode": "MANDIRI"}	67ce661372471c4831a86cba5830f1b31d7c8cae48716f8ca3945d1cdf8a63cb	41941436648	\N	\N	pr-98c9a285-33df-4765-8370-cf4e837c0d46	2025-04-25 09:21:48.833+00	2025-04-25 09:59:18.135+00	MAINNET	BITCOIN	\N
cm9y38x6i0000k1kac8w9kneg_migrated	WITHDRAWAL	COMPLETED	0.0002	BTC	273910	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "ID_BCA", "accountNumber": "3801167622", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "N**LY J***NI"}	007aaadd437fdd43b25ede2e57ce211a22874acc5cda6f8ff75e873934cea91f	41994769910	\N	\N	disb-614ed955-c1ec-4b16-8220-9d4c858c5e23	2025-04-26 10:39:16.218+00	2025-04-26 10:57:08.155+00	MAINNET	BITCOIN	\N
cm9wxu3gi0005k1ga2157hcze_migrated	DEPOSIT	COMPLETED	0.000585	BTC	999000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298408849320", "channelCode": "MANDIRI"}	5b58d276ecca9632c90995a3975b10b8ee197cd6cd169c69df3eb21c79dfec5e	41961807288	\N	\N	pr-a34bf12b-3217-4d14-b812-2864f11c5ab0	2025-04-25 15:20:00.259+00	2025-04-25 15:31:19.336+00	MAINNET	BITCOIN	\N
cm9wxz3ph0006k1gai8v8qg0v_migrated	DEPOSIT	COMPLETED	0.000585	BTC	999000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298466036130", "channelCode": "MANDIRI"}	5b4da6c65318c5d032e97debfe0a2db5066342949818b84014277a16934ec73c	41962106962	\N	\N	pr-63e6b3f1-1fc0-4b39-a245-199061d97759	2025-04-25 15:23:53.861+00	2025-04-25 15:31:19.5+00	MAINNET	BITCOIN	\N
cm9zv8r0j0002k1ka3rwtybj0_migrated	DEPOSIT	COMPLETED	0.000101	BTC	199000	bc1qpt382saq65e3dzsj00z8lr42laf0mep2x0nlgg	{"method": "VA", "vaNumber": "13282277368383765", "channelCode": "BRI"}	408ded4fa606a595cd4d999da91bfc4589855583851b772df36211b5ab683ac4	42036853043	\N	\N	pr-1ceb755a-cd22-4535-b4d9-263f28aab7db	2025-04-27 16:30:43.651+00	2025-04-27 17:04:54.425+00	MAINNET	BITCOIN	\N
cma5w1hnk0001k1l95sexy60p_migrated	DEPOSIT	COMPLETED	9.5e-05	BTC	199000	bc1qaruxj9f05dfqyl5hfpg6zf9ce8nyzq8npa9lhq	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525EkBnPjYniSMpcb3xXFUpRrz7j63045364", "channelCode": "QRIS"}	e6e4fd91ab361e18d685f7a9c98646e2878db3131eda6ca56f17992137a1eea0	42237416044	\N	\N	pr-72edeacb-ce9a-4eb7-85a7-e3de1ba386d1	2025-05-01 21:39:41.6+00	2025-05-01 22:20:01.19+00	MAINNET	BITCOIN	\N
cma69r91h0000k14h76a6ptx5_migrated	DEPOSIT	COMPLETED	0.000585	BTC	999000	bc1qnunvj96qx03sx072qe233dtwcjgsjnnweem3mx	{"method": "VA", "vaNumber": "8930250125888336", "channelCode": "BNI"}	83fa381d946a49fa0cac19007ad77ac6ff1d9c7887fcdb84efade6f56bf93c14	42252358704	\N	\N	pr-e082eda3-68d4-48ef-996f-26fbf8ed421c	2025-05-02 04:03:38.5+00	2025-05-02 04:06:02.383+00	MAINNET	BITCOIN	\N
cmg0xlj0j0001k1od47j0bsk3_migrated	DEPOSIT	COMPLETED	0.00052	BTC	1000000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250122363300", "channelCode": "BNI"}	5c67036e95ff573ae21eb562cfc30dece966714ca0a02e477adbebcf2bdbe767	49188484166	\N	\N	pr-65866087-4c5c-41fa-ad70-12ad9fb74702	2025-09-26 14:22:39.236+00	2025-09-26 17:07:45.987+00	MAINNET	BITCOIN	\N
cma6nqyfu0001k14hvqldatrt_migrated	DEPOSIT	COMPLETED	9.5e-05	BTC	199000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525IWIEpAdOkH4DYIfzR5swGxuUa6304E85A", "channelCode": "QRIS"}	d56ffafb21f1e8ca68ad901acba1af59e43545b90769bfc11fdab29764d104a4	42265129904	\N	\N	pr-818af823-35ea-4f52-8596-86640a6fd5be	2025-05-02 10:35:19.386+00	2025-05-02 11:08:05.823+00	MAINNET	BITCOIN	\N
cmaiev8y00006k1grwcjkeg7f_migrated	DEPOSIT	COMPLETED	0.0085	BTC	15000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294803404431", "channelCode": "PERMATA"}	714ad3ef79a74602d8724be700a79fde5423388a7caf26297a4a8e47e0cca1bd	42726475554	\N	\N	pr-49ce08a1-ab22-495c-88e8-c76737af833a	2025-05-10 15:59:57.192+00	2025-05-10 16:57:35.989+00	MAINNET	BITCOIN	\N
cmaif5vrm0007k1grh7w6k6yf_migrated	DEPOSIT	COMPLETED	0.005658	BTC	10000000	bc1qu08q2f5ktr2qyk6fq0evnf6vrtv5kqyfl5974e	{"method": "VA", "vaNumber": "7293294801364847", "channelCode": "PERMATA"}	714ad3ef79a74602d8724be700a79fde5423388a7caf26297a4a8e47e0cca1bd	42726757266	\N	\N	pr-24ef1d5d-fa71-4480-a847-dec8ec03f163	2025-05-10 16:08:13.33+00	2025-05-10 16:57:55.974+00	MAINNET	BITCOIN	\N
cmbcc0ts6000dk1xdpu2wwq1f_migrated	DEPOSIT	COMPLETED	0.000377	BTC	700000	bc1q498vacwfvvfqgjhjgg3dnkf3xl5m5m92u5kly0	{"method": "VA", "vaNumber": "7293294804534587", "channelCode": "PERMATA"}	c7a1d3017a28a2cf2dbab5c0c08da130a7d3598ccf2f381c7dedbb1d87f9ffbc	44044084255	\N	\N	pr-35f91712-26d2-42de-a46f-036293dacdc1	2025-05-31 14:33:23.91+00	2025-05-31 14:40:16.82+00	MAINNET	BITCOIN	\N
cmaj6aoxn0000k159czed8nl5_migrated	DEPOSIT	COMPLETED	0.002797	BTC	5000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540750000005802ID5908BitVault6006BADUNG61058036162290525edYOwI1jFlFGAW0GvXaRZRm8Y63045051", "channelCode": "QRIS"}	8ff0f5c0ea685274e3d9217608e71c649fe15b59a49681de094e94e317fc9790	42760832218	\N	\N	pr-4c4cd547-2f60-4d40-981a-7aab4a77ef10	2025-05-11 04:47:47.387+00	2025-05-11 04:56:38.393+00	MAINNET	BITCOIN	\N
cmbdq1njr0000k15ajyb737u6_migrated	DEPOSIT	COMPLETED	0.000437	BTC	800000	bc1q498vacwfvvfqgjhjgg3dnkf3xl5m5m92u5kly0	{"method": "VA", "vaNumber": "7293294818479973", "channelCode": "PERMATA"}	8385f2a6ec48cea2628d1be2c211172bd9144be371db7a0817ced0a923b6a9f3	44076477168	\N	\N	pr-799ee06b-5743-40ff-87fc-441674722f51	2025-06-01 13:53:43.288+00	2025-06-01 13:56:34.167+00	MAINNET	BITCOIN	\N
cmajg05ig0001k1596haayb7x_migrated	DEPOSIT	COMPLETED	0.011224	BTC	20000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "8930250128383765", "channelCode": "BNI"}	7b162fffa633a0a1420179cb9f262eb26981dae2af73b2ebfac7e5932d50dbe8	42769540438	\N	\N	pr-906fe418-6e18-4e9f-a873-9feb6d4569db	2025-05-11 09:19:31.815+00	2025-05-11 09:45:19.37+00	MAINNET	BITCOIN	\N
cmb1r40xx0005k1xdqso0m3bg_migrated	DEPOSIT	COMPLETED	0.001192	BTC	2200000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298430993864", "channelCode": "MANDIRI"}	9a1aea345d8df306a6b45222c6de0fa5fe1cfbb1de1289a24b3bfdd79bb4b773	43637028427	\N	\N	pr-835506bd-e49d-4dc8-9284-8b06433cf065	2025-05-24 04:50:19.461+00	2025-05-24 05:11:50.731+00	MAINNET	BITCOIN	\N
cmds85c2h0000k1vseufjvdir_migrated	DEPOSIT	COMPLETED	0.00049	BTC	1000000	bc1qx9f2j80m0c6ygmkdrp3yrg3umfevqv4d72s2e3	{"method": "VA", "vaNumber": "8930250128211174", "channelCode": "BNI"}	abe69903015aee98da7efc49f5c7c8b3c76958eecef5b180c0f84fbb526bd9b9	46800037627	\N	\N	pr-26e87067-8e31-4ca4-89ea-329849e5a94e	2025-08-01 02:48:39.257+00	2025-08-01 02:57:59.971+00	MAINNET	BITCOIN	\N
cmdvf1xmf0000k1xacgsdm8ik_migrated	DEPOSIT	COMPLETED	0.00051	BTC	1000000	bc1qxsd86pqe7np3h3tp5emeecwlfqn9va4tsa6cyj	{"method": "VA", "vaNumber": "8930250121308402", "channelCode": "BNI"}	1806b7a7ac491f03bbaa31edbc616f66224e6b090b2d4bce74a9c20e847b83fa	46920193342	\N	\N	pr-0cc843f1-6648-4a57-9b5b-3e0f7e219858	2025-08-03 08:25:16.407+00	2025-08-03 08:41:06.657+00	MAINNET	BITCOIN	\N
cmbqgxt2z000ek1aut2knv4tg_migrated	DEPOSIT	COMPLETED	0.003266	BTC	6000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "8930250125461517", "channelCode": "BNI"}	394af7662e00746e91eb4feaf67b001d31097f392524a2c7d61b0826879b67d1	44477227140	\N	\N	pr-e51d0e5a-c687-44b4-87e8-45d1e91fd266	2025-06-10 11:59:47.579+00	2025-06-10 12:49:17.131+00	MAINNET	BITCOIN	\N
cmaconuip0003k1ec6tnslkfi_migrated	DEPOSIT	COMPLETED	9.5e-05	BTC	199000	bc1qx3zt6xscmkfaxel9wesuw0h85pgq7m9djle3xa	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525lKRpuoq1dxNWW3wQish2AbQk363047621", "channelCode": "QRIS"}	f4f863c0701c420fc65fb6b099a96c6fb6e73f3dffd0a202662e57ee4cd2b85b	42485193487	\N	\N	pr-a6522fb4-652b-49e7-a2e1-1a6c16621cc4	2025-05-06 15:47:31.01+00	2025-05-06 19:05:09.408+00	MAINNET	BITCOIN	\N
cmc4v5nmi0000k1t5qogeiais_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1pmrry4psjcuarxc4cjuxhdfz5xx8lute65hyt7263a6sn703ehdlqepyhkx	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525huQPITXx3jxSdQeThiRUtg3Ih63049313", "channelCode": "QRIS"}	169d1bd567b0e538054436876b936d56e8e647fa2684b204678e803dc56a24e2	44980652988	\N	\N	pr-287ceddb-efb6-4a92-99fd-f0484613faab	2025-06-20 13:46:34.841+00	2025-06-20 14:33:57.061+00	MAINNET	BITCOIN	\N
cmbu9njw2000lk1auev80991j_migrated	DEPOSIT	COMPLETED	0.003295	BTC	5800000	bc1qu08q2f5ktr2qyk6fq0evnf6vrtv5kqyfl5974e	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540758000005802ID5908BitVault6006BADUNG610580361622905256TsvlypAoXO5DiaLWEAWr83LG630492FD", "channelCode": "QRIS"}	440884cb3a2c9569a9b4ae2dd03165fda1981933c6c7eff8949593f900967d50	44632190860	\N	\N	pr-ce9af276-a998-4abd-9836-f082d660576e	2025-06-13 03:46:56.498+00	2025-06-13 04:28:02.782+00	MAINNET	BITCOIN	\N
cmagvyw4m0001k1gr6nn1k9hc_migrated	DEPOSIT	COMPLETED	0.002845	BTC	5000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "VA", "vaNumber": "13282277360297800", "channelCode": "BRI"}	60213f5bcafb3e64318ae4d3e31843331fa1e0a90e6c63d91863b6dc3896f09c	42677522329	\N	\N	pr-a70b5e44-0458-4765-ae00-edcb145cc2e9	2025-05-09 14:23:08.326+00	2025-05-09 23:37:52.888+00	MAINNET	BITCOIN	\N
cmagxtnmu0002k1grb04nd5zt_migrated	DEPOSIT	COMPLETED	8.7e-05	BTC	199000	bc1q6hcy0efjlcmtag895r77kvwsgzyw7zkslhm3fr	{"method": "VA", "vaNumber": "8930250138479973", "channelCode": "BNI"}	fd810232511364bb4b7cef08c899f118936fec243bc9a9ea0c34ba2d8d67f80c	42682752531	\N	\N	pr-6131f64e-3757-4c1d-8742-1302d7152373	2025-05-09 15:15:03.271+00	2025-05-09 23:37:52.907+00	MAINNET	BITCOIN	\N
cmg04udrt0001k16vldjjrvfc_migrated	DEPOSIT	COMPLETED	0.002638	BTC	5000000	bc1qx5hxcwphj8rf7lr9zemwwpwsr44reynmuxmzah	{"method": "VA", "vaNumber": "8930250126152136", "channelCode": "BNI"}	57d1c83d641f9ebc7893cf87c74da019449570c8bdfc43569c7d5e9fdfcab1ae	49164912436	\N	\N	pr-1b5243ab-5250-49dc-852b-b44bd9199e15	2025-09-26 00:57:43.482+00	2025-09-26 02:40:53.524+00	MAINNET	BITCOIN	\N
cmahz3u4f0004k1gr8sewwzv6_migrated	DEPOSIT	COMPLETED	0.000863	BTC	1561871	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540715618715802ID5908BitVault6006BADUNG61058036162290525kOh6O5bRcX1hSM40DTHktRi27630440AC", "channelCode": "QRIS"}	9f08a9932d4f7c37d4c550967b748c679db342359434c8bf92832c43aa603bf6	42712846448	\N	\N	pr-9216645b-32cf-4679-92e1-345cdd750f9b	2025-05-10 08:38:44.032+00	2025-05-10 09:13:15.197+00	MAINNET	BITCOIN	\N
cmahymf1z0003k1grvihs4a60_migrated	DEPOSIT	COMPLETED	0.007677	BTC	13663033	bc1qnf4300290altrdy84hzhk4xe7dhturukkm6wu3	{"method": "VA", "vaNumber": "13282277366832605", "channelCode": "BRI"}	74b4210a5bd917f86b614907b753ce9f32b41644b96239cc754b4f562a7a24a8	42712564460	\N	\N	pr-9ea07c54-e2e5-4041-8892-f27dca079b51	2025-05-10 08:25:11.351+00	2025-05-10 09:13:15.216+00	MAINNET	BITCOIN	\N
cmb2209ky0006k1xd8ga62fi5_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG610580361622905250ZF1WuZqoabPpmwd7zDWVil8X63042FC6", "channelCode": "QRIS"}	97bbf393aafa5118f254717b544a408e0a9fb10a8ecd7a018edab186c537f1da	43644595351	\N	\N	pr-bb5cfc14-8bac-410e-9147-f4a309b154b6	2025-05-24 09:55:19.81+00	2025-05-24 10:30:31.926+00	MAINNET	BITCOIN	\N
cmc6c0c9f0000k1njzgzmwawr_migrated	WITHDRAWAL	COMPLETED	0.001	BTC	1660825	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "ID_BCA", "accountNumber": "4350614155", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "K**EK T*** W******RI"}	bd46fbd7743c95285a62ef0e34f0c82519956c9ded0ee89f8dde4b8f4c032fcb	45026162073	\N	\N	disb-50b8f126-dc9c-409e-a444-bc3a7dab0ab7	2025-06-21 14:26:06.482+00	2025-06-21 14:33:46.158+00	MAINNET	BITCOIN	\N
cmawvhyfw0004k1ftaor7bi93_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1qf0xn8ucm7vd3ezw7ymhaef4zms6vjkxv720tzw	{"method": "VA", "vaNumber": "88908298499446631", "channelCode": "MANDIRI"}	55f8c8e9df968d41b37ff09902ee1578d06b03d7cd7134103bb588cb534952d6	43366725669	\N	\N	pr-2f3aa691-9295-436c-ac01-8ea15770c436	2025-05-20 18:54:16.988+00	2025-05-20 19:01:21.684+00	MAINNET	BITCOIN	\N
cmbxnek93000qk1auh65mpc6j_migrated	DEPOSIT	COMPLETED	0.000835	BTC	1500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540715000005802ID5908BitVault6006BADUNG61058036162290525XHbD1WH7TOJdSYFnMVmHXr1xH6304032B", "channelCode": "QRIS"}	10738aa9ba9b6587b75f9cfdbcb3261cd1d7f3f64c37be6517474cc4aff5bdb0	44731780008	\N	\N	pr-317e3b96-1914-41d7-bef5-93d54844d439	2025-06-15 12:35:10.215+00	2025-06-15 12:46:23.853+00	MAINNET	BITCOIN	\N
cmd2qi4iu0001k1gvxy0vuvwz_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1q8tx3ttdm6wnvw6g8ddg7ejsn9fgnwe7ymgvj6l	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525s3KnDifc2YF2GWM4w0JeSiHV0630432CA", "channelCode": "QRIS"}	a2296c1bfc237043a4ed68143e7246566c0727d7fe1fb4d849ff7d3967c5d4c0	46002054890	\N	\N	pr-7c7b4796-5be5-425b-a908-9d2258558d8d	2025-07-14 06:40:28.518+00	2025-07-14 16:52:28.807+00	MAINNET	BITCOIN	\N
cmbdth3xg0002k15akgasscw2_migrated	DEPOSIT	COMPLETED	0.001114	BTC	2000000	bc1qwc6e6kw8qgutzkwwys43mjpmrf3cmjr7swwnvd	{"method": "VA", "vaNumber": "8930250129852659", "channelCode": "BNI"}	714c2a23aab8ac43b490b875537fb0bb7ebf075b6550eee0dd412a4865134e70	44079501908	\N	\N	pr-e846070c-fd76-4616-9f3a-6eba9aa0fe60	2025-06-01 15:29:43.204+00	2025-06-01 17:20:55.911+00	MAINNET	BITCOIN	\N
cmazhlkup0000k1xdtga5dfnp_migrated	DEPOSIT	COMPLETED	0.000518	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250138021381", "channelCode": "BNI"}	55a2ad0bb824f6a7d2bc6330bbae0c0664dc9a95387b1e5f92aed8382ce18e16	43531322095	\N	\N	pr-9b9d209c-17ec-4b49-afbd-e98f3aa91e8a	2025-05-22 14:48:29.905+00	2025-05-22 17:27:23.275+00	MAINNET	BITCOIN	\N
cmbd0rwhq000ek1xdksoq53j0_migrated	DEPOSIT	COMPLETED	0.00083	BTC	1500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540715000005802ID5908BitVault6006BADUNG61058036162290525SlW32K0uaHO80RHFOk8h4Sd1e6304B1EA", "channelCode": "QRIS"}	c84a9fafb624cf12b43ba8f3a56ed588e468538deffb7a92c9e4c6c24812786f	44060970131	\N	\N	pr-f3208030-ecd5-45cc-9703-e013ae59ad4c	2025-06-01 02:06:17.917+00	2025-06-01 02:27:00.515+00	MAINNET	BITCOIN	\N
cmcpz9wpv0001k1dt6vxghgg9_migrated	DEPOSIT	COMPLETED	0.000756	BTC	1380000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "88908298487983980", "channelCode": "MANDIRI"}	45721ee7c134a0bcd7bd1f0d66c65326432f3b5296b88e82098570391279ba88	45629337450	\N	\N	pr-6213edac-f48e-4f9b-b836-949eea595736	2025-07-05 08:25:01.412+00	2025-07-05 09:05:22.438+00	MAINNET	BITCOIN	\N
cmbpwow1k0008k1au0walhm5i_migrated	DEPOSIT	COMPLETED	0.000529	BTC	1000000	bc1qxsd86pqe7np3h3tp5emeecwlfqn9va4tsa6cyj	{"method": "VA", "vaNumber": "13282277379725701", "channelCode": "BRI"}	d2b5b892b70fd78c3abd919d7e52d0d227ccf5416d7a3edc9e2561abc6175f03	44463639823	\N	\N	pr-c303ad16-1e87-4b7b-ab05-978318e19f67	2025-06-10 02:32:59.192+00	2025-06-10 02:45:31.548+00	MAINNET	BITCOIN	\N
cmc8vrppd0000k1bjm9hc65wj_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1pafn9nellkdrgp7vdru92w9erzrm3q0dwe568nu9tpg5seuz5sq5qwm6nfn	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525IXg80OAJEsqgviEaOAe5a62Lk630445B9", "channelCode": "QRIS"}	894faf9802560dfbdade942ed60c672674db493478b53149b109f5ca3afebb9f	45142821011	\N	\N	pr-0cf020d5-c7aa-413d-a4fb-b9d31b652ff8	2025-06-23 09:14:48.673+00	2025-06-23 09:31:25.969+00	MAINNET	BITCOIN	\N
cmbv0ik4q000mk1aui22mzxcy_migrated	DEPOSIT	COMPLETED	0.001405	BTC	2500000	bc1qmz8suzqrqsg3evut6hd46vwraqy533a4c46dyc	{"method": "VA", "vaNumber": "88908298495455455", "channelCode": "MANDIRI"}	d7c530ea957a7d87834235b3c7b9679711d6b8d50867db8f645cc329e00a66b0	44668873247	\N	\N	pr-3b759a7f-091e-41b7-ad44-f9eb308f4268	2025-06-13 16:18:53.162+00	2025-06-13 16:23:29.256+00	MAINNET	BITCOIN	\N
cmbqncrls000fk1auy2k06dpe_migrated	DEPOSIT	COMPLETED	0.002746	BTC	5000000	bc1qvfugxzfm0kh0u9z5ewyr06pstdgt8pgxqrnh6h	{"method": "VA", "vaNumber": "8930250124316790", "channelCode": "BNI"}	5c713347f0cc98f0f3008a3b87a3588bc5efe4ff721bd4dd7466a02ff6c0e5a6	44485319586	\N	\N	pr-34083582-32b2-429b-8b92-714a90814233	2025-06-10 14:59:23.2+00	2025-06-10 15:42:48.388+00	MAINNET	BITCOIN	\N
cmcb3xjkp0004k1bj2qz46kpa_migrated	DEPOSIT	COMPLETED	0.000549	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525n57MGpKdbiVXwKBfYP5VCPCtO63041ECD", "channelCode": "QRIS"}	56da7579c433820b7483b9969c41c05b88b0ad0a6d7a22efc980a54c41d23ba7	45240812261	\N	\N	pr-f3b33280-47ef-4b6e-b516-4723140bc97d	2025-06-24 22:38:49.946+00	2025-06-24 23:06:26.756+00	MAINNET	BITCOIN	\N
cmd47a46x0003k1jqe5fn6xi5_migrated	DEPOSIT	COMPLETED	0.000234	BTC	499000	bc1qqsdcgnwvmj2y97hn85v7ylh2k47rz3eecaqxsv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054064990005802ID5908BitVault6006BADUNG61058036162290525jEbXRHeaVTW2OyExyo1phTD2W63042E46", "channelCode": "QRIS"}	750b49a513e570df20cec19b674d482fbe8ae4b020c486b6e8c90cdbf08b0b5b	46042201569	\N	\N	pr-bdf99849-1f56-40eb-adc4-b36138e92e1b	2025-07-15 07:17:54.488+00	2025-07-15 07:39:27.355+00	MAINNET	BITCOIN	\N
cmdeftoou0002k11mbzce77no_migrated	DEPOSIT	COMPLETED	0.000283	BTC	600000	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054066000005802ID5908BitVault6006BADUNG61058036162290525EWnd1CM9RZljJoye90iVFjRYk630457A4", "channelCode": "QRIS"}	e17278cdd91b749ce38ebd630cdd550a9ba3eede8cd592dd8c992c80b8604115	46373544530	\N	\N	pr-4abbbb04-19e5-45dd-ab3e-247146f36f28	2025-07-22 11:14:46.206+00	2025-07-22 11:49:22.76+00	MAINNET	BITCOIN	\N
cmddeigpo0001k1ihwrn7ig0x_migrated	DEPOSIT	COMPLETED	0.001003	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298412139097", "channelCode": "MANDIRI"}	b4f16039a12f492af972a74b9e5c230eb6010801b969eb0d5bc44e6d9fd1c1d7	46334295262	\N	\N	pr-b6c22948-da7c-4ee5-8da1-cbe65bcfcd37	2025-07-21 17:50:16.86+00	2025-07-21 19:18:57.534+00	MAINNET	BITCOIN	\N
cmdse5brw0001k1vsgex012wg_migrated	WITHDRAWAL	COMPLETED	0.0004	BTC	717759	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "ID_BNI", "accountNumber": "1773254709", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I P*** K**IN T*** S"}	167b4c440e65fcc6d9d05140c5f7ebacd7282a6ddb5a83dd6bfd694987f81290	46805611075	\N	\N	disb-936dbbed-489a-48c8-aa73-1b9fa2c7153a	2025-08-01 05:36:36.561+00	2025-08-01 05:44:31.668+00	MAINNET	BITCOIN	\N
cmb6i4xn30007k1xd1jo8qoee_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525RLPMMMrK2mpi146ZxiPur3bK663043113", "channelCode": "QRIS"}	1e2506a028c63c085cf374bbd30b46610071158ed569e15e5f9f22adda8be3e9	43796769612	\N	\N	pr-4b8e1e26-07e9-42ef-9d43-e2c84ce01a22	2025-05-27 12:37:56.175+00	2025-05-27 12:41:12.369+00	MAINNET	BITCOIN	\N
cmarugqoe0004k14t4853wjwz_migrated	DEPOSIT	COMPLETED	0.002814000000000001	BTC	5000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540750000005802ID5908BitVault6006BADUNG61058036162290525zwzk0akqELXVEhbRlvHZn8rjo6304F388", "channelCode": "QRIS"}	3ac74e1008806712dfc74faf6a80eb60dcb2eddad23b8643eb4fd89d9be06fd5	43148634942	\N	\N	pr-ce6b5684-1489-4942-965c-8243b3b70428	2025-05-17 06:26:29.774+00	2025-05-17 06:30:34.143+00	MAINNET	BITCOIN	\N
cmbgclfuu0000k1gphq8son3h_migrated	WITHDRAWAL	COMPLETED	0.006748	BTC	11434323	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "ID_BNI", "accountNumber": "0881528979", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "S*** M*** R**NA K***LA C****NI"}	234b87aafacaf48070411358346ec1785d43ba9757d64d2675efa71082121587	44169976432	\N	\N	disb-eafa5822-7eeb-4d7e-b37c-d0cf1be7bdfd	2025-06-03 10:00:30.342+00	2025-06-03 10:27:39.901+00	MAINNET	BITCOIN	\N
cmcxbidc00001k104aya0vxzd_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1qx3zt6xscmkfaxel9wesuw0h85pgq7m9djle3xa	{"method": "VA", "vaNumber": "88908298455091642", "channelCode": "MANDIRI"}	35ae23e87c566ac875def2867472d4e323b6f6e4cb6f55b5fc36c0bb5a15e9c1	45797605724	\N	\N	pr-942e7950-0de4-4354-b2dc-240ea7e93dd6	2025-07-10 11:41:54.816+00	2025-07-10 11:53:29.409+00	MAINNET	BITCOIN	\N
cmb0ahlxn0001k1xdna53iusc_migrated	DEPOSIT	COMPLETED	0.010703	BTC	20000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "8930250121022774", "channelCode": "BNI"}	aa8f18df4d2f55dc69ee74b75baaeb0d46c0bb46fbafbe584ee8f0943e54b6f6	43564162077	\N	\N	pr-3e9fa198-dda5-46e3-b939-c4d1ee873546	2025-05-23 04:17:13.547+00	2025-05-23 04:34:25.569+00	MAINNET	BITCOIN	\N
cmbd40c9f000fk1xdpfngm48j_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525iID0ihV7Eq0JtB7MER6ittAtj630450A2", "channelCode": "QRIS"}	5dcf828bd93dec24091c42b43149870f28317370d8a59c10f116a19108b3edc6	44063035266	\N	\N	pr-f5930528-d104-41ec-8764-73ffed2ded06	2025-06-01 03:36:50.452+00	2025-06-01 04:02:01.213+00	MAINNET	BITCOIN	\N
cmbpxkv580009k1aubzlj1j53_migrated	DEPOSIT	COMPLETED	0.000529	BTC	999000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG61058036162290525W8O6MBIoSINXREfYlf7EILoMS630466CF", "channelCode": "QRIS"}	eec44e85e7b03d723fd9a59329e6b333f5bd97830661866850ce61593e21e176	44464172712	\N	\N	pr-0946f739-f336-48f8-a0bd-11e38e3065f7	2025-06-10 02:57:51.02+00	2025-06-10 03:00:11.663+00	MAINNET	BITCOIN	\N
cmc172ntl000rk1au9us51qkg_migrated	DEPOSIT	COMPLETED	0.000549	BTC	1000000	bc1qx9f2j80m0c6ygmkdrp3yrg3umfevqv4d72s2e3	{"method": "VA", "vaNumber": "8930250127120784", "channelCode": "BNI"}	611c078da5fef47698a62a8a36cc43035a416e5e93a80c7d81a9c95f8e18a712	44867257362	\N	\N	pr-11c18d60-f93f-4da0-a1ff-fd527be97a8b	2025-06-18 00:09:05.817+00	2025-06-18 00:15:36.879+00	MAINNET	BITCOIN	\N
cmddeq4rb0002k1ihmkvhzujs_migrated	DEPOSIT	COMPLETED	0.001003	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298411459527", "channelCode": "MANDIRI"}	0ab9ecfb6c279605797039a84d3b4c12005bbb538ed8cdbbb1a003f8bf526316	46334598656	\N	\N	pr-d7480fdc-cdc0-49b0-a247-3c7787d311e9	2025-07-21 17:56:14.616+00	2025-07-21 19:18:57.555+00	MAINNET	BITCOIN	\N
cmc8w3t380001k1bjisuwzwps_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1q9pxt0ac8eecay9cs8qedtfdk6lg0lgg49xjvtq	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525bsoNJFkCcOvoWplkkNgGzLzVU6304D4DF", "channelCode": "QRIS"}	f4924c2217400c6ff3e0cb2cdb0c6d35fa2a266faa896816e241b9c022090130	45143050439	\N	\N	pr-91dfaf97-3f84-4980-b8ef-6dfcfaaa6a87	2025-06-23 09:24:12.932+00	2025-06-23 09:31:25.987+00	MAINNET	BITCOIN	\N
cmc77o09f0001k1njpcei5gu2_migrated	DEPOSIT	COMPLETED	0.001141	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298478020307", "channelCode": "MANDIRI"}	9ffcd18870bd059cd01d0c20362421b6eefd8efe052b9b7a9fd48c524d2db3d8	45067560643	\N	\N	pr-0a48aaf2-d7ca-4670-8fd6-9c2e4f56a75b	2025-06-22 05:12:18.771+00	2025-06-22 05:20:44.233+00	MAINNET	BITCOIN	\N
cmclp305j0000k1asy9tnvfce_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1qqsdcgnwvmj2y97hn85v7ylh2k47rz3eecaqxsv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525tQriora3RYWXquqT1PGsiJCGc63046D6D", "channelCode": "QRIS"}	866154e6007477186c450e09f69a657f6a8f7dfc35b2bf45047687c20ab39d5f	45508830513	\N	\N	pr-687edb68-2569-40ae-adf9-fba17a2da408	2025-07-02 08:28:38.407+00	2025-07-02 08:37:59.008+00	MAINNET	BITCOIN	\N
cmd411yfl0000k1jqm92kg1vh_migrated	DEPOSIT	COMPLETED	0.005085	BTC	10000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294806832605", "channelCode": "PERMATA"}	ff2886c1f24e47f11aac45c795fae29ac1d2dfd2ddfc67cf90bef235f2b5ae71	46035977454	\N	\N	pr-20279758-372d-4fbe-aac3-1ac7cbb4c885	2025-07-15 04:23:36.081+00	2025-07-15 04:39:35.746+00	MAINNET	BITCOIN	\N
cmdit1qc90001k1t96rrniuob_migrated	DEPOSIT	COMPLETED	0.0005	BTC	999000	bc1qcm2xewftxlq9gnkr4vztd4glk5l993e9mjh5sq	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG61058036162290525hTiDBSZzfdF4b1fSZCJldbzGQ6304CEF2", "channelCode": "QRIS"}	46481f0a9bf2ef9b840a9b86383c3d591af4ac22677c11254924d9f8a4154062	46527201438	\N	\N	pr-3e277c99-4f9f-47c9-9df1-5d31c947ad3d	2025-07-25 12:36:01.304+00	2025-07-25 14:15:31.248+00	MAINNET	BITCOIN	\N
cmdg03sw20000k16ofhm2qk8o_migrated	DEPOSIT	COMPLETED	0.00049	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250121167746", "channelCode": "BNI"}	079434e4244fda911c79fde8348f144083da55b828ea0088821ee337d549bbbb	46422593227	\N	\N	pr-7a202d23-fb00-410f-98d2-4e8740d5174c	2025-07-23 13:30:16.706+00	2025-07-23 13:38:32.577+00	MAINNET	BITCOIN	\N
cmcmpe1xa0000k1rqniuxo8ti_migrated	DEPOSIT	COMPLETED	0.000539	BTC	1000000	bc1qx9f2j80m0c6ygmkdrp3yrg3umfevqv4d72s2e3	{"method": "VA", "vaNumber": "8930250136361584", "channelCode": "BNI"}	3f8821e37f44b555d293e24d472a9c7a91821530f60159513f4272ee866ae769	45543590569	\N	\N	pr-37488fc6-d524-493b-893e-f837e27b5df6	2025-07-03 01:25:00.094+00	2025-07-03 01:42:01.825+00	MAINNET	BITCOIN	\N
cmasbgzo30005k14t0uxo1bnz_migrated	DEPOSIT	COMPLETED	0.000558	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250126567520", "channelCode": "BNI"}	11c6efa5706a51ea06a357eb1108e4853af0b54b51306047e0b6098072c3516f	43164987376	\N	\N	pr-5788a2f9-e436-4c57-be85-0ba6e0c66c60	2025-05-17 14:22:34.899+00	2025-05-17 18:55:55.201+00	MAINNET	BITCOIN	\N
cmcyd0d8g0000k15c7885cqtk_migrated	DEPOSIT	COMPLETED	0.000746	BTC	1500000	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540715000005802ID5908BitVault6006BADUNG61058036162290525h1qUCm9AQznneFGEqjO6qfbai63047318", "channelCode": "QRIS"}	56e9e8ffd737f05fc560539f0d80fd63d1e66bf2f9dec49420da808e6c6e2171	45845201245	\N	\N	pr-4f3cac54-1844-46f4-8459-1b74462ccd3e	2025-07-11 05:11:40.288+00	2025-07-11 06:38:33.389+00	MAINNET	BITCOIN	\N
cmpv925p50003mi0113afeol2	DEPOSIT	COMPLETED	0.00383724	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294815491640", "channelCode": "PERMATA"}	586d1cc904a54a4241fd2ff052467b0c834c06e1a572b5bdac477b1f5f46fd18	62450776236	\N	\N	pr-f908ca2f-e75e-4722-8403-a5f3fbc5d14d	2026-06-01 13:33:57.209+00	2026-06-01 13:37:40.123+00	MAINNET	BITCOIN	\N
cmbd8qvfp0000k116a6c07wq3_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qxz6x4j4680q8p39mp3jzer08hvun3hefszra09	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525iuYhcssC5K70MZ1hB3qxre4Tl63049D81", "channelCode": "QRIS"}	fe49963d0a329f24ad4065f4c9aa56942696a12b6394908a8733c0f6dfdcf1dc	44065308404	\N	\N	pr-402f29d4-77b2-4548-b6a9-84706a21bcaa	2025-06-01 05:49:26.821+00	2025-06-01 05:55:25.483+00	MAINNET	BITCOIN	\N
cmc1ug9f3000sk1auztsfzk4p_migrated	DEPOSIT	COMPLETED	0.000559	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250129072516", "channelCode": "BNI"}	a149f1283f5cc0b5e034eaead8b8efcc7c178946f3a38197fd3733719a3fcb5c	44883339509	\N	\N	pr-d7d735a8-5e8b-4946-bd85-d05375aa6b01	2025-06-18 11:03:31.502+00	2025-06-18 12:23:33.386+00	MAINNET	BITCOIN	\N
cmb0ngs9d0002k1xdh5xhv0st_migrated	WITHDRAWAL	COMPLETED	0.0002	BTC	305751	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "ID_BCA", "accountNumber": "7670720955", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I G*** E** L*****NA P***"}	6a0b30a0f5f8871774aafdf498b2562275f195648848333c6bbf38f10b7dab9e	43577392592	\N	\N	disb-799ad0af-9ed4-4498-b731-8d85ce9ef977	2025-05-23 10:20:30.097+00	2025-05-23 11:36:27.051+00	MAINNET	BITCOIN	\N
cmb6pe51z0009k1xdg3afpmss_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1qcw9j0kq3gc7n24xsd2cahy6qpa5f52mrkwxcpz	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG610580361622905257MEl4Ry9kC64wlUcO44Q6zzvr6304F0DD", "channelCode": "QRIS"}	a69df67d07d34ce227b910fdc6e476c874ea8694514a24ca9d50654f58ac6e4b	43812027150	\N	\N	pr-501c33ec-4996-47bb-a52a-ba4ab7652d0e	2025-05-27 16:01:02.999+00	2025-05-27 18:23:33.882+00	MAINNET	BITCOIN	\N
cmb6pe3yp0008k1xdfvi7xtye_migrated	DEPOSIT	COMPLETED	7.9e-05	BTC	199000	bc1qrulnukd4xd6egzdkqxmpkgt72jhar0zse704r7	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG6105803616229052589WY9SDmXsUUnEnzU7ydsgVqd63042992", "channelCode": "QRIS"}	758b49667a33ee0fe63f614a189753050f9e8231046083099224171149583f3a	43812195849	\N	\N	pr-6ac49178-7fe8-4b7f-873f-435feeac24e6	2025-05-27 16:01:01.586+00	2025-05-27 18:23:33.901+00	MAINNET	BITCOIN	\N
cmdtjxgn90000k18uwcpdkdd2_migrated	DEPOSIT	COMPLETED	0.00051	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525HTJZ9odzLHZmYSV0PFV5LgzLH63042312", "channelCode": "QRIS"}	41f62cc7d739bb0c820d667b9ce2601b7af522d798fc9896e52fb47440be2034	46866407197	\N	\N	pr-6eecc6d0-fe28-4209-a91b-eb9d275419a4	2025-08-02 01:06:13.509+00	2025-08-02 03:45:25.473+00	MAINNET	BITCOIN	\N
cmc987ch20002k1bjyo1nnzg9_migrated	WITHDRAWAL	COMPLETED	0.001405	BTC	2312947	bc1qmz8suzqrqsg3evut6hd46vwraqy533a4c46dyc	{"method": "ID_BCA", "accountNumber": "3403732831", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "S***EN"}	e6870350bb37532ef1e6dae6b66b58314d8e6b8ed665e0877ce754aac1e96d3b	45158094375	\N	\N	disb-3ff1c603-6f5f-4062-a039-fecc443acf72	2025-06-23 15:02:53.413+00	2025-06-23 15:13:08.891+00	MAINNET	BITCOIN	\N
cmc77rca10002k1njqcay51j0_migrated	DEPOSIT	COMPLETED	0.001141	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298401215862", "channelCode": "MANDIRI"}	0e58f11fe11bc4ad009e53af8f8e5b882ed40c16340824479f586bf2ad2960a9	45067638684	\N	\N	pr-b86cfae0-5278-4622-8c3d-64c3a7779916	2025-06-22 05:14:54.314+00	2025-06-22 05:41:34.433+00	MAINNET	BITCOIN	\N
cmbq2af7h000ak1aun8y5s391_migrated	DEPOSIT	COMPLETED	0.000589	BTC	1100000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "13282277374950306", "channelCode": "BRI"}	49138be047b597d5a68e5b303d52b85d7821183e48a6baf4cf1304fa96225a2b	44466601966	\N	\N	pr-c7572dff-4ddc-4500-a22c-2f2a6e29abbd	2025-06-10 05:09:41.885+00	2025-06-10 05:20:32.988+00	MAINNET	BITCOIN	\N
cmg04qycy0000k16vti6rmhhm_migrated	DEPOSIT	COMPLETED	0.001316	BTC	2500000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298476482945", "channelCode": "MANDIRI"}	57d1c83d641f9ebc7893cf87c74da019449570c8bdfc43569c7d5e9fdfcab1ae	49164912343	\N	\N	pr-ce50386a-809e-482d-a646-b686dd5f2a6e	2025-09-26 00:55:03.538+00	2025-09-26 02:41:13.383+00	MAINNET	BITCOIN	\N
cmcen549u0006k1bj5zuq5zvo_migrated	DEPOSIT	COMPLETED	0.001101	BTC	2000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG610580361622905256WPe75icwdGmR5YsFDrZFNgwA630458CF", "channelCode": "QRIS"}	e7d429a241bab632ddd6c7ad9d657ca02a495d6d88e6c7f33ebc2760c568fef8	45344252587	\N	\N	pr-ff637cad-fe21-4fc5-ab03-b685484c15e2	2025-06-27 09:59:54.594+00	2025-06-27 10:05:10.06+00	MAINNET	BITCOIN	\N
cmdsu06tp0002k1vsni1spkdv_migrated	DEPOSIT	COMPLETED	0.000942	BTC	1858000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "88908298475896277", "channelCode": "MANDIRI"}	5288b2681d6f8bc9d63c1f644d4d93040786f50335dd23b6d4e3f64303ea305b	46824356750	\N	\N	pr-eb65f28d-80c8-40bf-a169-4b439a130ca7	2025-08-01 13:00:30.732+00	2025-08-01 13:12:55.922+00	MAINNET	BITCOIN	\N
cmbtbf26k000hk1auyapr0h2h_migrated	DEPOSIT	COMPLETED	0.000262	BTC	499000	bc1qyuznapyjtzcpq8mj6afdpkua5xghy5z0v6nckw	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054064990005802ID5908BitVault6006BADUNG61058036162290525oCiy22VxfZxk2jQo9bIpqXX7W6304A99B", "channelCode": "QRIS"}	75fa14e51d7110b60ef2a64a14a55e4a93e631826c9f272fefe2e38671537480	44576685854	\N	\N	pr-f6ec3959-4445-4826-9558-baf3b760202e	2025-06-12 11:48:33.356+00	2025-06-12 11:50:43.815+00	MAINNET	BITCOIN	\N
cmp2bndr8000hmj01g7dc4vwm	DEPOSIT	COMPLETED	112.586375	USDC	2000000	8pX62tfQVDSushgJvuEZvmpeS9Uxa549EaD9JTqm5Dyu	{"method": "VA", "vaNumber": "8930250131881354", "channelCode": "BNI"}	28x53XaaT4A7vFqiovUx4KDTdPQSqgvqxuB5zNW4j46U3z3dG6FXDpAicufRud338u473BUz2o7cRHjyHzGeeCDB	1498429557	\N	\N	pr-bafc8d69-ec86-46d9-b192-ab78d6507dd8	2026-05-12 07:41:07.557+00	2026-05-12 07:54:51.78+00	MAINNET	SOLANA	\N
cmoh5gwpm0001qp016xqmwft1	DEPOSIT	COMPLETED	0.00218857	BTC	3000000	bc1q6pdfg70a4nzavw8ll3msjnl00vcjxw0qsxmvq0	{"method": "VA", "vaNumber": "88908298460695843", "channelCode": "MANDIRI"}	1ec40faf3bbb1d58ed078bbb16ba9fd6b20a153bf0d931a4f2b51892863b3515	61106530436	\N	\N	pr-e88bff19-bbb0-487b-bd02-38068d9c3bad	2026-04-27 12:04:58.138+00	2026-04-27 12:14:52.69+00	MAINNET	BITCOIN	\N
cmpfhzcsv0002l1010hdph7xi	DEPOSIT	COMPLETED	74.425	HBAR	120000	0x32f1f016B155279F881B077bD81F364A490d9680	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525bRy3yvfL7ULPkSbrb1jC9V5yK6304755E"}	0.0.8555429@1779369458.800877828	495205	\N	\N	pr-86c87dee-b0cf-4b4f-8df7-fa16b6a3ddfc	2026-05-21 12:59:24.175+00	2026-05-21 13:17:50.687+00	TESTNET	HEDERA	\N
cmps94jbz000emq01obyu14uo	DEPOSIT	COMPLETED	53.645464	USDC	960000	3w4XXxkdFSVtYbXQD9uPAoRJJopGDWxYLpetRKSnrF9p	{"method": "VA", "vaNumber": "88908298499016677", "channelCode": "MANDIRI"}	3hcemTcBMorrAwjBHTcN1MSiTEVc28Z7u8jy7sc9t6wW9bxxgAnkBPkqfCHScaU4Jk1oacEzzxuUtmfmrPNK9CcF	1527183932	\N	\N	pr-43e9a588-5d7c-4068-b1a7-9ab8ba3c757a	2026-05-30 11:12:29.663+00	2026-05-30 11:15:39.644+00	MAINNET	SOLANA	\N
cmp2qg7qy000kmj01zv64n5u1	DEPOSIT	COMPLETED	56.642384	USDC	1000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294809072516", "channelCode": "PERMATA"}	4rPK54XmzTdnwr1mDmLBULNNUjurRRcLPjZbPQupCudxpc3N6Fqqp53oKUZ79SPymx2PmqA9b2BEaGeFaR9KNKjQ	1498884412	\N	\N	pr-159880b6-afb3-4ddd-97e7-e5a5c6c85cdd	2026-05-12 14:35:27.418+00	2026-05-12 14:36:36.767+00	MAINNET	SOLANA	\N
cmohxla760000qp016ktyofi4	DEPOSIT	COMPLETED	0.00072069	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250121007605", "channelCode": "BNI"}	32d76c7fb84949b5b21aeaccee847f65dcb76157d54c3e9e7fe1267eac82ca1b	61133095722	\N	\N	pr-02866847-4e20-4da9-b867-ad204eb4666b	2026-04-28 01:12:11.491+00	2026-04-28 02:41:34.875+00	MAINNET	BITCOIN	\N
cmpfhzfop0003l101a42mkxbb	DEPOSIT	COMPLETED	753.745	HBAR	1200000	0x7D28743A0354942AD797d7194E24d12bd8588B84	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540712000005802ID5908BitVault6006BADUNG61058036162290525hHTuwfn9sW2zUexUqkc7q11WB63042008"}	0.0.8555429@1779369458.800877828	495204	\N	\N	pr-965076e1-b6e2-4c40-aeaf-e0c5143a1853	2026-05-21 12:59:27.913+00	2026-05-21 13:17:50.701+00	TESTNET	HEDERA	\N
cmpyqgmge0001mt01hd8zkv77	DEPOSIT	COMPLETED	218.355462	USDC	4000000	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	{"method": "VA", "vaNumber": "88908298464867036", "channelCode": "MANDIRI"}	3QDPHKAGMew4nmtb8XT97HttrAUszV1TsisUZazsgxYmmCbiBJ4DV7ssDcd4i8MFpTCE8H4b877fP5XnQxRKDBQf	1534480955	\N	\N	pr-60711460-4bb3-4047-a2a4-7e42f619f379	2026-06-04 00:04:24.111+00	2026-06-04 00:06:09.078+00	MAINNET	SOLANA	\N
cmrryjnx3001gl301l1kiagqy	DEPOSIT	COMPLETED	0.1428505	SOL	200000	BQnyCdHLjMopEHKaXvSbJCG2BSz1EEVTUQqD8g9WKg8P	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054062000005802ID5908BitVault6006BADUNG61058036162290525pWUmxFA1JgmPMvEwCL2ayXoLB6304CD38"}	rdGEUdfSEjChzKzq25oZgbAojSvW1yBxTrDfrpTTHUWkk633qRTcADCSbx2QCPSFY8RSzdzGDGMK7HVUHoFujHy	2932756	\N	\N	pr-0ffe34e2-354d-4921-9d82-f5e3f2755cb4	2026-07-19 15:35:44.343+00	2026-07-19 15:35:57.632+00	TESTNET	SOLANA	\N
cmr351orr0018l301r0pkimoa	DEPOSIT	COMPLETED	0.0008828	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525ZVNyzSHyGLA7rZF7F7NfmAsUM6304B794"}	adab82bafae15dccdf4d8d77e1fb5a8f810b30364164aef8354f8712761e590d	64091751757	\N	\N	pr-91b1fd70-7f43-4d60-964c-e832dca41d2b	2026-07-02 06:43:28.551+00	2026-07-02 06:49:12.81+00	MAINNET	BITCOIN	\N
cmqdo8yv50009l3015zm6qfe3	DEPOSIT	COMPLETED	6.255016	USDC	120000	7RU6XwFZ2qT94UsyD6rJiUBf6wJz2StsZHipwshx6MCa	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525m4Snzs8CGeVM3xqciUbQNaJBj6304C44D"}	5jZVasvrxY27suhRAGGcGKQFMiKx4tULUg2Jekz6rvHkTVYRd1fK8goTM2dQXQ6qk3MxFkjHMNps6UwSKcTbXTM1	1551805111	\N	\N	pr-26639772-109a-44cd-9af9-feeaa475da6e	2026-06-14 10:59:00.353+00	2026-06-14 11:01:45.491+00	MAINNET	SOLANA	\N
cmpzo6hl80003o601qzzxgr7q	DEPOSIT	COMPLETED	0.00425942	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294801178893", "channelCode": "PERMATA"}	f0c027f0d322e80c7326231ecf35baf67a4d4ca2c13d6935864e3c0142e4c7b6	62698097938	\N	\N	pr-919a41bb-2efb-43c7-a11f-ec5ffe3cb017	2026-06-04 15:48:18.189+00	2026-06-04 16:02:22.665+00	MAINNET	BITCOIN	\N
cmqb0qcv80005l301p0jo8rs4	WITHDRAWAL	COMPLETED	0.096806236	SOL	112758	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	{"method": "ID_BCA", "accountNumber": "7445116700", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "kelwin"}	3J63FKkFZ4EvT51gxWxauZF4jL3GWfs8VH6icrzjD7K3kuE4ChfdAPWxR2nMixZCgjKXLwm566b3ybqD7faoUxvH	17293706715	\N	\N	disb-b8839ad3-f420-4d48-95d3-67cf402ce822	2026-06-12 14:25:08.516+00	2026-06-12 14:27:43.623+00	MAINNET	SOLANA	\N
f07ff357-c64d-4433-9192-1fdcfc1f41ca	DEPOSIT	COMPLETED	26.966157	USDC	500000	4wBsuuCvfTHmWSDRTwng6kBB69yo1cKSuAjnY6DgoqDL	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525kXUbhphU34asEwRViwrf8P4vG63044227"}	3RRd9ppt8pCnq9cmvHDzsJ13eG7LG4ta2zWrhd9XnmAESFA2JxvENiBxTNV6xFdgKahGg3Vsxfa5w6fWSFnG1fov	1623313612	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.067415	pr-06d09084-67e1-4467-bd77-407722cc92a7	2026-08-01 22:07:11.626+00	2026-08-01 22:08:47.294+00	MAINNET	SOLANA	3RRd9ppt8pCnq9cmvHDzsJ13eG7LG4ta2zWrhd9XnmAESFA2JxvENiBxTNV6xFdgKahGg3Vsxfa5w6fWSFnG1fov
cmqdra9ig000il3013k0xyafc	DEPOSIT	COMPLETED	6.524428	USDC	125000	4wBsuuCvfTHmWSDRTwng6kBB69yo1cKSuAjnY6DgoqDL	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061250005802ID5908BitVault6006BADUNG61058036162290525k1BtgnJzzfcpTkg2UGJnRUB1w63041EB4"}	5D296wh5fhQoXR5gQS6VbUmcHb3Nt8VeiZYuc9uPaaFAM2Z45ALmfCxGDPKj31oWt71q53zZhCfbLrJheq5PTq9F	1551882642	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.016311	pr-f5021bdd-3aaf-46ad-a0b4-adc6335b06ba	2026-06-14 12:23:59.656+00	2026-06-14 12:26:39.636+00	MAINNET	SOLANA	5D296wh5fhQoXR5gQS6VbUmcHb3Nt8VeiZYuc9uPaaFAM2Z45ALmfCxGDPKj31oWt71q53zZhCfbLrJheq5PTq9F
ba4beeda-47b4-426e-a614-9c718b39fb53	DEPOSIT	COMPLETED	0.00084522	BTC	1000000	bc1qkv4d63d0u7r8uz9tpthg3474393v3dxguxk7d5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525GjFs1RmB7vqjTYkSRVGaqas1Z63041F02"}	045b0ba15156c294231ae8b404612bc21de31a2d5b2ca4286f7c317ace8324ec	65066916115	\N	\N	pr-0ea55752-ec37-4342-87de-9e6c08936664	2026-08-01 15:47:23.68+00	2026-08-01 18:28:53.847+00	MAINNET	BITCOIN	\N
cmr35fwhb0019l30178x9qqb9	DEPOSIT	COMPLETED	0.0017819	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525q76AwjsQd5TFatMTzTYbXnJSQ63046DA5"}	85476a9771aa641e00dbbd0cc477b4e8a08eb71964996aef7a60c6692c47f4db	64092142565	\N	\N	pr-8452af2a-4cb7-4735-b01e-7ca59794adbc	2026-07-02 06:54:31.728+00	2026-07-02 06:58:48.489+00	MAINNET	BITCOIN	\N
cmp3jc57c000lmj01bqj3yo04	DEPOSIT	COMPLETED	11.7881925	SOL	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294803747613", "channelCode": "PERMATA"}	3kTnrKfX5abkR245BYbjGJRCHz96p4qy7cFPGGW1LGt4uf3avX5xYLunfJZwjXiUcoDkFvgCyUvBEGHBrgZ8SAPm	17077158360	\N	\N	pr-21202cc3-8c87-4bf5-acc9-8e3dd0956d95	2026-05-13 04:04:06.361+00	2026-05-13 04:05:06.812+00	MAINNET	SOLANA	\N
cmoi4j2sw0000ox01npjjjpfy	DEPOSIT	COMPLETED	0.00035333	BTC	500000	bc1q7eu84v58kxj0r9u72vmjze7wlrnsdg5n79uv2r	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525eCC6QjJNjviXPqzJU6d2V8S2s6304AD35"}	39b3c91a2ccc59abdd3c15bc74db3e49012906758bc160af7375ad5d65d4ef39	61138832458	\N	\N	pr-25b15d27-0a96-4eb3-a63c-e5609ea68639	2026-04-28 04:26:25.903+00	2026-04-28 04:39:24.479+00	MAINNET	BITCOIN	\N
cmpsakvc4000fmq0179i1m2i7	DEPOSIT	COMPLETED	0.00035333	BTC	500000	bc1qdhcq4dcyv7w4xsxzs2dgwf6jw0k6v60ztdhf9l	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525Xx6Fbpia5oJ3uXvfvM65sAxWk6304AB50"}	bffe1f9616eb92ab5b94286482f3d51daafd66b73e2babc65810642a17b2d950	62394045616	\N	\N	pr-d299e6ce-d78e-48ef-93a3-dcff2b66f0d4	2026-05-30 11:53:11.332+00	2026-05-30 12:53:38.33+00	MAINNET	BITCOIN	\N
cmpfixalm0004l101c70zge31	DEPOSIT	COMPLETED	0.096654863	SOL	150000	FghAY44kjdGg6XNvY4CjtcMhzvssA9d9Ts9m5Eh9mLGT	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061500005802ID5908BitVault6006BADUNG61058036162290525iJrB11Dw7KfVRbQW14oEJLHdo63040504"}	4KxMM8svD1MxqG8m7jpbgDBnjdgRc7iQ6SVQqKmXLeSE9gqSiZ8kxAqi7XYWJYVEAaH4mLKFcJMS6dd8VReUZ7Fo	840231	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	0.000241637	pr-797b55e9-0b99-463f-b093-daddb6d12103	2026-05-21 13:25:47.626+00	2026-05-21 13:26:00.707+00	TESTNET	SOLANA	4KxMM8svD1MxqG8m7jpbgDBnjdgRc7iQ6SVQqKmXLeSE9gqSiZ8kxAqi7XYWJYVEAaH4mLKFcJMS6dd8VReUZ7Fo
cmpi4or3l0002mq010gdomjr4	DEPOSIT	COMPLETED	1120.577466	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294813136340", "channelCode": "PERMATA"}	4RYbvTyzBVEkEZS96qW558JqLCWudMpGwqhU6MTzKA3djT2msj5tn9CPP3E9Qn2aDJa15Zzh3i9W8ygaMCBxh7iu	1516370656	\N	\N	pr-a775ca2f-0d9b-465e-93b3-ef2889c996fe	2026-05-23 09:10:33.009+00	2026-05-23 09:11:31.568+00	MAINNET	SOLANA	\N
cmqgbq19f000jl3013qdp4wb3	WITHDRAWAL	COMPLETED	89.650556	USDC	1567605	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "ID_BCA", "accountNumber": "7670720955", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "i gede eka laksmana putra"}	4P5NikLXLRboALMaCWYWUvm4WibGofyBm1GaZLwGi8gsFmZeCJwpVSAjR59SiEkEDdfgsVUTjSasXGsdKtjcAg5L	1554594647	\N	\N	disb-9e5a939a-4ae1-451a-8c6e-a41ddd698c0a	2026-06-16 07:31:40.132+00	2026-06-16 07:34:18.27+00	MAINNET	SOLANA	\N
cmrw9tjui001hl301l7r54fln	WITHDRAWAL	COMPLETED	0.317410888	SOL	436593	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "pasha renaisan"}	2m144HphSqbsYzEZ6hY7RpPKVDWkCeuaYjkDG3Bhv3SYpNgzdLXn6G7S5F3vkRB7va9hGokCTEASwvp1UoAo72VZ	17531124500	\N	\N	disb-0a80e46c-392a-423c-b7ae-7a5b71141333	2026-07-22 16:02:26.104+00	2026-07-22 21:10:39.245+00	MAINNET	SOLANA	\N
cmd5nw8r80005k1jqsscy0r9m_migrated	WITHDRAWAL	COMPLETED	0.000288	BTC	513501	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "ID_BNI", "accountNumber": "1773254709", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I P*** K**IN T*** S"}	b6e4e4225d4f6364099b5b58c716f118b50d7db1027a85072af429e47a830fb5	46094271738	\N	\N	disb-862d526c-cc3a-4297-a260-c305bce42355	2025-07-16 07:50:46.868+00	2025-07-16 07:56:31.217+00	MAINNET	BITCOIN	\N
cmdh53pxn0000k12x8inbph5b_migrated	WITHDRAWAL	COMPLETED	0.00021	BTC	360764	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "ID_BNI", "accountNumber": "1773254709", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I P*** K**IN T*** S"}	bad9db74f1b143930f2387da505d68c885af58ae0d80fac5b9940cbbe38c8d49	46465564451	\N	\N	disb-d9424364-af4e-4a59-8535-56152f8fd3de	2025-07-24 08:37:57.131+00	2025-07-24 09:27:31.753+00	MAINNET	BITCOIN	\N
cmb1qlsek0003k1xduh76buzz_migrated	DEPOSIT	COMPLETED	0.003287	BTC	6000000	bc1qu08q2f5ktr2qyk6fq0evnf6vrtv5kqyfl5974e	{"method": "VA", "vaNumber": "8930250121449306", "channelCode": "BNI"}	c0b6baa322761bbfaafe094750483ca6f9bfeba099113f4ede2cfe3e96c5a6fb	43636713364	\N	\N	pr-fec0c2de-c585-46f1-b6f4-a7713ec77592	2025-05-24 04:36:08.588+00	2025-05-24 05:03:31.066+00	MAINNET	BITCOIN	\N
cmbd9c5pb0000k17xwwgqtsq5_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qxz6x4j4680q8p39mp3jzer08hvun3hefszra09	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525FZhQmWvNDUg94DmCh0YwUZSaw6304B4F8", "channelCode": "QRIS"}	b58aff8a6e2228fe9d444ec71377dd09506d13026754f61509f8c328c725cf98	44065545719	\N	\N	pr-33e6a4c3-5756-43e5-a551-e0774e1ee7a2	2025-06-01 06:05:59.903+00	2025-06-01 06:57:10.144+00	MAINNET	BITCOIN	\N
cmalqmn8z0001k1qg2mnmugro_migrated	DEPOSIT	COMPLETED	8.7e-05	BTC	199000	bc1q4suh0wz3rj977a7nxa8fdplul6luyegdfh0y0n	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG610580361622905251FqT05NygqFfnr6MHDYdSVYdd6304B9FA", "channelCode": "QRIS"}	75fd0df01299ed7069b81d46ca4d88698a47e27b08f3cd0c69eaf3d994207b9d	42885205563	\N	\N	pr-d3820f32-de3c-4237-af32-efe293f7a63e	2025-05-12 23:52:29.747+00	2025-05-13 00:25:59.853+00	MAINNET	BITCOIN	\N
cmqdofi5n000cl3018g0r2vq0	DEPOSIT	COMPLETED	6.078352	USDC	120000	5D8KCYuDSurjFp6dAvTykaJSoZbcxkfwXBJ8P94pur4Z	{"method": "VA", "vaNumber": "8930250139837968", "channelCode": "BNI"}	29WjjcWjvEUGeG3bhjhpucSJ8oDV3A8FVHEkPk6Lx6NPTFkKYYJKd8sUgUEHi1soqzWbAEeUaEVFMst2W9T5zW16	1551807940	\N	\N	pr-c19b49a0-e869-4c15-a76f-b3ec80771186	2026-06-14 11:04:05.291+00	2026-06-14 11:05:11.085+00	MAINNET	SOLANA	\N
ea38d7a8-ecde-4f51-841e-0605013c11ab	DEPOSIT	COMPLETED	6.28049	USDC	120000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061200005802ID5908BitVault6006BADUNG61058036162290525GTz6zoj2HrDw8pH2F8uXdZgdf63046883"}	3io1GKqH6bePwfbyNjvgwcPVg8c6bd9moxeJXaWJhFWQvH2YpUzLeEGdUE7bYcmd2sEwhRDB1f9S7rt8FmSnDHGP	1613622249	\N	\N	pr-c05c4df2-67c1-480a-a1c6-338d84b48299	2026-07-26 15:44:29.158+00	2026-07-26 15:45:21.273+00	MAINNET	SOLANA	\N
cmamepdic0005k1qgotxvcmmm_migrated	DEPOSIT	COMPLETED	0.002238	BTC	4000000	bc1qmz8suzqrqsg3evut6hd46vwraqy533a4c46dyc	{"method": "VA", "vaNumber": "88908298403895777", "channelCode": "MANDIRI"}	918b8e4351348cbb3dd6d24f02cbb8b4045096077ff065918530dd1e99c31742	42913303495	\N	\N	pr-40ddc9c7-9764-4ede-9045-8d8a0429a296	2025-05-13 11:06:27.876+00	2025-05-13 11:20:42.04+00	MAINNET	BITCOIN	\N
cmd0xlxe10000k1oo7w7rp3pk_migrated	WITHDRAWAL	COMPLETED	0.0002806	BTC	488881	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "ID_BNI", "accountNumber": "1773254709", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I P*** K**IN T*** S"}	a6dc959c5d026c588986e5a5bec119d367a78a99b01279661b1549fdb4c285fd	45923136714	\N	\N	disb-a8e533da-95e3-4960-b081-9d1a8dec405b	2025-07-13 00:23:50.857+00	2025-07-13 00:26:03.769+00	MAINNET	BITCOIN	\N
cmhydj5ve0001k1cosyibacsu_migrated	DEPOSIT	COMPLETED	0.001778	BTC	3000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298482507779", "channelCode": "MANDIRI"}	a01f2d5a1c2673865b9b442713af9806ecec1a4f0618a1973a2e92f5ded4da0a	51948976429	\N	\N	pr-3dae076e-1932-4d21-846d-403b5f1f3b1d	2025-11-14 04:44:48.89+00	2025-11-14 05:18:06.667+00	MAINNET	BITCOIN	\N
cmbu6k6qi000jk1aura1hojyb_migrated	DEPOSIT	COMPLETED	0.000272	BTC	500000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG610580361622905259cFW39oEMlD3EGLaSdZd0aVaa63048C42", "channelCode": "QRIS"}	57bc682608f4ee6eb25db56f87cde7a7cbd90609094e98a52db0fc8aa65a5bfb	44627431461	\N	\N	pr-20557dcc-7417-4974-a9ae-5100ac6d7e21	2025-06-13 02:20:20.634+00	2025-06-13 02:47:21.422+00	MAINNET	BITCOIN	\N
cmap9w4q9000ak1qgxztepmvw_migrated	DEPOSIT	COMPLETED	8.7e-05	BTC	199000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525RCUrdzDw2vp2TC5gtvRk3qCLB63040C57", "channelCode": "QRIS"}	59c691970da846a4d9561350333dacce2faaec248c88fe911499a6bfb39a2a8e	43036342416	\N	\N	pr-14dc734b-6119-41dc-88e7-8d30c1ff8f8e	2025-05-15 11:15:03.537+00	2025-05-15 11:36:14.557+00	MAINNET	BITCOIN	\N
cmapajr6g000bk1qgt0h2v8qw_migrated	DEPOSIT	COMPLETED	8.7e-05	BTC	199000	bc1qars75khpv8es2u6kf4hd8krrk3yvs3uyrla626	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525F23Noc5ja8I9EiW9PBptDN7rl630440C7", "channelCode": "QRIS"}	5f1971307bd5e2d220371fd3dad7eea6ca82c832d3bdb31d7dffde3ec21faedd	43037192841	\N	\N	pr-5f5822a0-562b-4f13-8aa7-d39bd37de513	2025-05-15 11:33:25.72+00	2025-05-15 11:46:54.271+00	MAINNET	BITCOIN	\N
cmdbuw7ly0000k1dwhvxhiq7d_migrated	WITHDRAWAL	COMPLETED	0.000738	BTC	1375041	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "ID_MANDIRI", "accountNumber": "1780002248017", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "G*********TO P**RA N"}	8d5fe02f34d7e134d0e3aa69934de6b5acad56003f5efea581164446fd16f2a7	46292473756	\N	\N	disb-d705ae28-681d-4831-8a97-146b4796b8aa	2025-07-20 15:53:19.749+00	2025-07-20 23:10:43.332+00	MAINNET	BITCOIN	\N
cmapgapqb0000k15tamz6cg9g_migrated	DEPOSIT	COMPLETED	8.8e-05	BTC	199000	bc1qdxsrzqf39r20fe0qs86p58vjrvcjs3gr90d0js	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525TbszErxC5sWyurX9TJgZtHURV63040B08", "channelCode": "QRIS"}	9b735b1e3ac59fad0d9d08a88ff5da3153c83b63624d68004e0ed3ffa9ff21cc	43048075989	\N	\N	pr-e672a916-34ae-46bf-8afc-ede2c4f2368c	2025-05-15 14:14:21.635+00	2025-05-15 14:19:51.105+00	MAINNET	BITCOIN	\N
cmapj8qen0001k15tc47z7w5m_migrated	DEPOSIT	COMPLETED	0.005715999999999999	BTC	10000000	bc1q23nqln98v3aj74uja9ktzedd48fnsuvj2c5nyr	{"method": "VA", "vaNumber": "8930250139725701", "channelCode": "BNI"}	5b29da003f319db6ebb713bd9e584b8bdc7296948f36f29747a9ca83886cb0bc	43055138366	\N	\N	pr-028d9ab9-f079-423a-8426-e177c99fe98f	2025-05-15 15:36:48.047+00	2025-05-15 17:23:51.732+00	MAINNET	BITCOIN	\N
cmf1uuz090000k1cazca2zkex_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1qr6ewylta4q9em8qkaad6kjpcgz9hsfpp267xrv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525imR8qI1JCcdQbr96BXDk1Zn5d6304E44D", "channelCode": "QRIS"}	1f622fc711f5d6dd6be5a8ab7a007b15a2e4e57e37f21231a0fa91ddf61242db	48252923900	\N	\N	pr-e4fdb2c4-3572-4d1c-81ae-81f3ac141edb	2025-09-02 01:14:04.857+00	2025-09-02 01:28:52.98+00	MAINNET	BITCOIN	\N
cmgni288x0004k180bpzdmhfn_migrated	DEPOSIT	COMPLETED	0.002618	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294801449306", "channelCode": "PERMATA"}	9eb46ed9bc03b853c458611aed273e060363f05c939a74ce99ebb5d31ac325e9	49989899692	\N	\N	pr-7cf22d58-2f6a-4ea3-9f3e-811c25d7feee	2025-10-12 09:26:26.625+00	2025-10-12 10:01:44.371+00	MAINNET	BITCOIN	\N
cmeip4bwu0000k1j9aw5lxdvp_migrated	DEPOSIT	COMPLETED	0.001042	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298455677725", "channelCode": "MANDIRI"}	d1cba0fec798067f2cea9e2ca4b3133c1e24cc3162577b6f0c0a8ab775475dd2	47682699574	\N	\N	pr-80c1adc8-9bcb-4e9a-99fe-eef1f69d459b	2025-08-19 15:25:46.446+00	2025-08-20 09:09:34.388+00	MAINNET	BITCOIN	\N
cmiegwkvx0002k1impec9yp2u_migrated	DEPOSIT	COMPLETED	0.003337	BTC	5000000	bc1q6tl5c7u57hnv85swsmg90lvj9c6mgxyl6hemv0	{"method": "VA", "vaNumber": "8930250130372188", "channelCode": "BNI"}	30a97841125541f4626b7c5232979f131fd3fc70047d971236fcfbc7b35e0419	52834013479	\N	\N	pr-550467bf-e309-499d-a5ad-e8d096c82d08	2025-11-25 11:03:32.542+00	2025-11-25 11:20:51.029+00	MAINNET	BITCOIN	\N
cmf0fmol10000k1xqwch5hn4f_migrated	DEPOSIT	COMPLETED	0.000252	BTC	500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525T5HogQY6pCrq6Z07Ce1NZma2i6304F638", "channelCode": "QRIS"}	15f85fb9b85031066803c96eabfd1dfa7e6f12b1f7c26d625cee6471bb38751e	48211239374	\N	\N	pr-d31f51fb-90ea-41aa-b731-a27374456772	2025-09-01 01:19:57.685+00	2025-09-01 01:29:35.651+00	MAINNET	BITCOIN	\N
cmfuvx2v40000k14lz4i8yjkh_migrated	DEPOSIT	COMPLETED	0.0005	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250134346220", "channelCode": "BNI"}	8aa959a7f37d8baa45d4dade305d4a0e6148a431e0a868061fd467d38460eb1f	48992076799	\N	\N	pr-6a77d08e-88f5-4d82-9904-e1ed281ea216	2025-09-22 08:49:01.888+00	2025-09-22 09:28:29.035+00	MAINNET	BITCOIN	\N
cmivrts0a0009k1imll10c58c_migrated	DEPOSIT	COMPLETED	0.000637	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525ebUNlTsEh12c0HRS7JiFx6OQN6304CB63", "channelCode": "QRIS"}	040e43214456e3a0f9fb79b78246f9d8e9795382d304b3769fd5e62c36a9515f	53505411399	\N	\N	pr-3e28d930-7488-4ad1-8dd2-c91f5e5ed3c8	2025-12-07 13:41:22.57+00	2025-12-07 13:55:43.708+00	MAINNET	BITCOIN	\N
cmg7agnop0000k1ezcav5xltd_migrated	DEPOSIT	COMPLETED	0.000234	BTC	500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525v09dVSlP24RiaU2EekuSpR5fH63045489", "channelCode": "QRIS"}	9b73c9279cb1bcc1cccac94319b5ab4e082da95f49760efdf3f9ff492d60d067	49363113316	\N	\N	pr-672823bd-d56c-4c89-861f-a520c19692b4	2025-10-01 01:09:24.073+00	2025-10-01 05:28:51.32+00	MAINNET	BITCOIN	\N
cmgm3x77q0001k180u8vtk38v_migrated	DEPOSIT	COMPLETED	0.000352	BTC	700000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250128714032", "channelCode": "BNI"}	7bd9ad969f78c6b6c09c9af3030d8826aa6189e589f782ea091fe48231f3a665	49935873809	\N	\N	pr-e5cc0d97-f070-4f41-a579-847215d1c947	2025-10-11 10:02:51.206+00	2025-10-11 10:28:01.178+00	MAINNET	BITCOIN	\N
cmh47rzmm0000k1pivlz7gf6g_migrated	WITHDRAWAL	COMPLETED	0.00152623	BTC	2725799	bc1qxsd86pqe7np3h3tp5emeecwlfqn9va4tsa6cyj	{"method": "ID_BNI", "accountNumber": "1973584912", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "B** A**ON"}	67f62a10184fbe0d8891ab7908128a3cc8f025eeb2408f3d961438782688f37b	50743082525	\N	\N	disb-165fca46-0b1d-453d-bcc7-e3096d7a8a64	2025-10-24 02:10:37.726+00	2025-10-24 02:28:19.559+00	MAINNET	BITCOIN	\N
cmn92x8u10000k1o18mink85u_migrated	DEPOSIT	COMPLETED	0.000853	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250129665836", "channelCode": "BNI"}	746207485aa496bc2a4c7a17ec0e706da9ea67ad29fd0e735449558064549994	59782164744	\N	\N	pr-45b2ecff-d567-4439-9b38-45d670e18f56	2026-03-27 15:51:49.753+00	2026-03-27 16:01:30.524+00	MAINNET	BITCOIN	\N
cmhllodx00002k19l8de423t4_migrated	DEPOSIT	COMPLETED	0.000272	BTC	500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525wfixpNPDk82QTkDjtCokzfSYS6304385D", "channelCode": "QRIS"}	51c9d1f03db6584c7a73b546eb9990ffb4dac65af8313e4f3dc34164598e50b2	51372535831	\N	\N	pr-0a4b0531-6c9a-488c-8dd8-b5341921dd05	2025-11-05 06:11:49.235+00	2025-11-05 06:15:56.15+00	MAINNET	BITCOIN	\N
cmhxl2c240000k1co6u09vqzs_migrated	WITHDRAWAL	COMPLETED	0.003	BTC	5021539	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "ID_BCA", "accountNumber": "4350614155", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "K**EK T*** W******RI"}	321588890f2b2a4ffa832421f2d180a0a50ec1bdaf7319039b5fbf679f98cb4a	51892595231	\N	\N	disb-3a268c55-1be7-48fd-bfc8-9508c2df067a	2025-11-13 15:27:54.508+00	2025-11-13 15:39:59.227+00	MAINNET	BITCOIN	\N
cmi3myytl000bk1cogz2loh7v_migrated	DEPOSIT	COMPLETED	0.00315	BTC	5000000	bc1qwxvx6tf67k0pd9zd5wy6rmahzgwdje6ndpv8g8	{"method": "VA", "vaNumber": "8930250139017709", "channelCode": "BNI"}	d96c4a3aae61899927009c7004ad3ac2cfd78d2425b07ab58d9871e42ab3ad64	52211788305	\N	\N	pr-a4be6fe8-27bc-49a2-bec7-523c4ba5c4dc	2025-11-17 21:07:53.674+00	2025-11-17 21:17:05.363+00	MAINNET	BITCOIN	\N
cmjnwexow0000k1omaq76t02m_migrated	DEPOSIT	COMPLETED	0.001974	BTC	3000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540730000005802ID5908BitVault6006BADUNG61058036162290525jSB1ZQv3I3BuaiCqN1GKoipgO6304CE4F", "channelCode": "QRIS"}	f6e4ce8c2d29b5ed9cb0ac97e6d563422d8977ab493da812a813da2737c47e9f	54578823136	\N	\N	pr-b89ab890-be62-4b14-bd75-de8cd91d7726	2025-12-27 06:07:21.103+00	2025-12-27 15:17:32.454+00	MAINNET	BITCOIN	\N
cmi94tdhj0000k1imrr7bzlq4_migrated	DEPOSIT	COMPLETED	0.000115	BTC	199000	bc1qcjlfd5um4l38509a9w60ewj0u6n9xngvgyg5h3	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525it5t47rwhQhMWjwlGH5Bm3w7T6304508D", "channelCode": "QRIS"}	d5c541f89908c5e9ffed930e4f42719fcb391c53ac57a7424feb9e64525de126	52583123703	\N	\N	pr-0eaae7d1-aac5-4c63-bdfb-2c73cd2a83e7	2025-11-21 17:26:16.711+00	2025-11-21 17:50:00.174+00	MAINNET	BITCOIN	\N
cmjnwiw2d0001k1omvn36wii0_migrated	DEPOSIT	COMPLETED	0.001308	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525eRQsZxPas5ODVxIFC0kYx3G3W6304BF81", "channelCode": "QRIS"}	f6e4ce8c2d29b5ed9cb0ac97e6d563422d8977ab493da812a813da2737c47e9f	54578823158	\N	\N	pr-718b4213-8b39-4211-ad0e-78eaab94b42b	2025-12-27 06:10:25.622+00	2025-12-27 15:17:40.092+00	MAINNET	BITCOIN	\N
cmejrwu7e0000k197bbz2htfv_migrated	DEPOSIT	COMPLETED	0.001042	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298454670217", "channelCode": "MANDIRI"}	c6ff268de898a1e92a42f3516f2d4eaae666ee0c316d5678305d28f2db390e24	47683682140	\N	\N	pr-4f82b883-b687-4dd6-bd28-d408330c4e11	2025-08-20 09:31:41.93+00	2025-08-20 09:58:01.987+00	MAINNET	BITCOIN	\N
cmgt1341l0000k1vncoperzws_migrated	DEPOSIT	COMPLETED	0.002628	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294816977210", "channelCode": "PERMATA"}	57c6a9f34ed59fa3c60c018131d3c53803e2f7eb09419652708a950913cc6b1b	50270552070	\N	\N	pr-5e6e836b-2194-49d1-8b6e-d8bb5aa6bfa6	2025-10-16 06:17:51.417+00	2025-10-16 06:36:01.486+00	MAINNET	BITCOIN	\N
cmhydjbsx0002k1cohyla6t6h_migrated	DEPOSIT	COMPLETED	0.001778	BTC	3000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298446198464", "channelCode": "MANDIRI"}	a01f2d5a1c2673865b9b442713af9806ecec1a4f0618a1973a2e92f5ded4da0a	51948978488	\N	\N	pr-890424ca-acb8-4bfb-86b1-e10fe5b0b7f6	2025-11-14 04:44:56.578+00	2025-11-14 05:17:56.615+00	MAINNET	BITCOIN	\N
cmhm3wmg00003k19l4ge7stvo_migrated	DEPOSIT	COMPLETED	0.001523	BTC	2700000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250131527360", "channelCode": "BNI"}	7eaf9f52057b5de1f00237bd2abd70ccf041e77ec91333c56aafe844ab539b4a	51396446782	\N	\N	pr-51da2b98-2479-4f6b-83ea-e32cca9f338c	2025-11-05 14:42:06.624+00	2025-11-05 15:21:30.759+00	MAINNET	BITCOIN	\N
cmiegqae00001k1imcuea1iy5_migrated	DEPOSIT	COMPLETED	0.003337	BTC	5000000	bc1qx5hxcwphj8rf7lr9zemwwpwsr44reynmuxmzah	{"method": "VA", "vaNumber": "8930250139304557", "channelCode": "BNI"}	30a97841125541f4626b7c5232979f131fd3fc70047d971236fcfbc7b35e0419	52834013559	\N	\N	pr-36d6846b-8625-42f7-aa7f-9c15f3035af9	2025-11-25 10:58:39+00	2025-11-25 11:20:30.592+00	MAINNET	BITCOIN	\N
cml6sdgwr0000k137y1g0s47e_migrated	DEPOSIT	COMPLETED	0.000124	BTC	199000	bc1qcjlfd5um4l38509a9w60ewj0u6n9xngvgyg5h3	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG610580361622905255ck5zhClYTkXr37TRzgH2HElD63043CC1", "channelCode": "QRIS"}	6f23743c9323189770ab438c9b94796a1ba1b6c7fe752f678667f9e51d658d5e	56494185397	\N	\N	pr-48584ef0-b2a0-4b5f-a4fc-a18c59d8e3f8	2026-02-03 16:01:33.915+00	2026-02-03 16:29:28.545+00	MAINNET	BITCOIN	\N
cmkzn2qfp0003k100pzh7yph3_migrated	DEPOSIT	COMPLETED	0.000667	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525u2ln9MUpZQfN5UDxOC76DOO4s63043A0C", "channelCode": "QRIS"}	d01bb7803e473d4a015935b81f02635aa2eac8804a9bf54030506f71ec101891	56063215141	\N	\N	pr-7d72baee-18ed-406e-b52e-5084f29f7789	2026-01-29 15:58:51.733+00	2026-01-29 16:05:40.851+00	MAINNET	BITCOIN	\N
cml2ohlb70001k18r8ioqsnj7_migrated	DEPOSIT	COMPLETED	0.001476	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525iIlvup2016gqksIvgBOXPyZCO6304B7A7", "channelCode": "QRIS"}	d80c433c3333f3fcf91b3c5571ce80660dc7b27b9e07552ab64d2edee23c5113	56230226282	\N	\N	pr-e3d870bc-2213-41e6-b151-a254f771ad5f	2026-01-31 19:01:43.076+00	2026-01-31 19:05:50.428+00	MAINNET	BITCOIN	\N
cmhye262q0003k1co65yzoc20_migrated	DEPOSIT	COMPLETED	9.6e-05	BTC	199000	bc1qgx3wps4pefksr5v9fj7w9mpadf7g5jcnx5g56x	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525dIMjC3dtolb6UTQToApcwPBeA6304F2A4", "channelCode": "QRIS"}	867b4f6a4cef7cea836eefedcfc243cc1744652a32c12b6ff9df34c7c1163994	51950677676	\N	\N	pr-cc0ded68-7f02-467c-b9e3-5e91ba244a43	2025-11-14 04:59:35.618+00	2025-11-14 05:18:13.39+00	MAINNET	BITCOIN	\N
cmf6wyvqv0002k1j88qm5rrb7_migrated	WITHDRAWAL	COMPLETED	0.00090622	BTC	1610275	bc1qnunvj96qx03sx072qe233dtwcjgsjnnweem3mx	{"method": "ID_BNI", "accountNumber": "1231529998", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "Ketut Indira Maha Padmi"}	77c2dbc354de2318f2b94729859f085af3f9e65fb2f6aab9f07bca0eee8459bc	48404569215	\N	\N	disb-a205a760-e68d-4ab7-ba5a-e132057507c0	2025-09-05 14:11:57.367+00	2025-09-05 14:15:38.132+00	MAINNET	BITCOIN	\N
cmellg3850000k17r2sc0zq86_migrated	DEPOSIT	COMPLETED	0.000381	BTC	762000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "88908298477488222", "channelCode": "MANDIRI"}	b5451cdc267bd9c741257f0400292c8fe72a47554d1d76e02ffec4953b99d072	47746346122	\N	\N	pr-6378ba9a-092a-429c-a337-29ac4fef63b9	2025-08-21 16:06:15.125+00	2025-08-21 16:11:33.293+00	MAINNET	BITCOIN	\N
cmkznt3za0004k100jk74xjju_migrated	DEPOSIT	COMPLETED	0.000667	BTC	1000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525hji8YcDz8lecGvWaHKCaJrCWp63042018", "channelCode": "QRIS"}	c5b8842b9dd07a87796e7e6c300964bf82312f2bfcd093367d386220931047ca	56064699890	\N	\N	pr-953a5ac1-1cc1-4489-9611-1462935ed299	2026-01-29 16:19:22.343+00	2026-01-29 16:58:09.596+00	MAINNET	BITCOIN	\N
cmgtmeltk0000k10skuzfbg88_migrated	DEPOSIT	COMPLETED	0.000529	BTC	1000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298499835211", "channelCode": "MANDIRI"}	96342d1cf900d402fdfd76902aedc31e450f9a413d50354d12f8982e83bd871b	50333175099	\N	\N	pr-02999873-df82-4ae2-a197-72b3a88f94f2	2025-10-16 16:14:39.608+00	2025-10-17 00:11:22.988+00	MAINNET	BITCOIN	\N
cmho7lauv0004k19lqo6kda4m_migrated	DEPOSIT	COMPLETED	0.005745	BTC	10000000	bc1qx5hxcwphj8rf7lr9zemwwpwsr44reynmuxmzah	{"method": "VA", "vaNumber": "8930250139407835", "channelCode": "BNI"}	67af8f012c2162ff66727b333b7b3ab40829fe132bebdb32fa083e985d490712	51503992330	\N	\N	pr-ffe302d4-55bc-4dd3-bfc9-5c9cc360fda1	2025-11-07 02:00:49.206+00	2025-11-07 02:19:31.341+00	MAINNET	BITCOIN	\N
cmifys1s60004k1immehnkhkx_migrated	DEPOSIT	COMPLETED	0.001338	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "VA", "vaNumber": "88908298410155912", "channelCode": "MANDIRI"}	150d5310b0f438103ff5b4b731af598f6ec049a3a22f81bbf3052193950156d1	52897349547	\N	\N	pr-81808266-2259-4db1-ba2a-c200a75a393b	2025-11-26 12:11:40.422+00	2025-11-26 12:16:23.476+00	MAINNET	BITCOIN	\N
cmg0c8xxv0000k1srv72havfu_migrated	DEPOSIT	COMPLETED	0.002648	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294818021381", "channelCode": "PERMATA"}	0360a49c1bf68c253a29ee2ac7f7b0ba00df7cea6f866df197050ec3f4e3dff9	49169082642	\N	\N	pr-388426fc-be61-4bd6-901d-edde18e5f215	2025-09-26 04:25:00.115+00	2025-09-26 05:44:30.94+00	MAINNET	BITCOIN	\N
cmhj4jxr50000k1n3ogobsis3_migrated	DEPOSIT	COMPLETED	0.000529	BTC	1000000	bc1qx9f2j80m0c6ygmkdrp3yrg3umfevqv4d72s2e3	{"method": "VA", "vaNumber": "8930250123536802", "channelCode": "BNI"}	c3401e7b1ec2d97c618ee8bb0a27b390d883e713e5ba9be135b6bb0dfff78a7a	51220885853	\N	\N	pr-fe070e29-5c85-459e-a7da-19d2a5e89cca	2025-11-03 12:36:55.84+00	2025-11-03 13:19:52.993+00	MAINNET	BITCOIN	\N
cmi5lzti5000dk1coju61v9cu_migrated	DEPOSIT	COMPLETED	0.000627	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298456040873", "channelCode": "MANDIRI"}	6458e86b1be513a7e97662d01504bc17b75e4580195ebc42c651700d81c4984f	52324848307	\N	\N	pr-6c56195b-0fc2-4df4-9fb6-cd30903e2b94	2025-11-19 06:16:06.174+00	2025-11-19 06:23:23.93+00	MAINNET	BITCOIN	\N
cmi5lziwp000ck1colkgrlqdz_migrated	DEPOSIT	COMPLETED	0.000627	BTC	1000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298435615284", "channelCode": "MANDIRI"}	6458e86b1be513a7e97662d01504bc17b75e4580195ebc42c651700d81c4984f	52324848384	\N	\N	pr-6dbfcf79-70ee-4d29-8e83-893e129e60f9	2025-11-19 06:15:52.441+00	2025-11-19 06:23:29.828+00	MAINNET	BITCOIN	\N
cmmmjwldm0005k105sa3sxwcl_migrated	DEPOSIT	COMPLETED	0.000794	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525non7EFfZVr3ckzEUVguoZ0hcQ6304ED18", "channelCode": "QRIS"}	d3e668a315ed545e243682bf51ae1a904880431f268b819205b3c436e404fead	59034523973	\N	\N	pr-8c246b51-c557-48d6-9b1f-c9ef98d8d2e7	2026-03-11 21:28:30.778+00	2026-03-11 21:58:58.307+00	MAINNET	BITCOIN	\N
cmjvci41z0000k1mlamnsvovk_migrated	DEPOSIT	COMPLETED	0.003317	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294809852659", "channelCode": "PERMATA"}	9218034cec13619708acb19534beacce91b6e236fe554a424bdd17805f47081a	54755828324	\N	\N	pr-a3de7369-a6dd-4dc2-919e-fe647ba5c472	2026-01-01 11:12:06.407+00	2026-01-01 12:47:37.291+00	MAINNET	BITCOIN	\N
cmlaskmro0001k137blomvtaj_migrated	DEPOSIT	COMPLETED	0.000417	BTC	500000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054065000005802ID5908BitVault6006BADUNG61058036162290525EmMprhZ2Ag2fZt3ofXyBOD6Mk63040844", "channelCode": "QRIS"}	0ca0b52e54d8a8fa9c60026a0395de5671b9aab82c538f43dda1377cf47dcfed	56887182994	\N	\N	pr-65a8ebb7-9617-43c0-b925-37cb9f1470f3	2026-02-06 11:18:12.804+00	2026-02-06 11:53:07.579+00	MAINNET	BITCOIN	\N
cml2ogey40000k18ruyf79ijb_migrated	DEPOSIT	COMPLETED	0.003731	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294805461517", "channelCode": "PERMATA"}	b6cd0d7e20fe1899f0adddb58be8d6e8ee47f5ac3ae2de302a4f40411a4c2292	56230260543	\N	\N	pr-4c73474f-a2e5-41e8-af82-9a3fbb30510e	2026-01-31 19:00:48.172+00	2026-01-31 20:15:54.687+00	MAINNET	BITCOIN	\N
cmm62ada00002k105ph4tvud8_migrated	DEPOSIT	COMPLETED	0.001801	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525QVZsmcwDdfDcMOKpFdShRJxlb63046452", "channelCode": "QRIS"}	6347b6e80969833f03730a96d6da1e8498e841d930b8a65d9d15c64d90d15a58	58303187871	\N	\N	pr-e84c0f06-9314-48bd-89f5-caf0df91aa10	2026-02-28 08:31:01.561+00	2026-02-28 08:56:13.029+00	MAINNET	BITCOIN	\N
cme3ec5du0000k18suc2qjag5_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1pmrry4psjcuarxc4cjuxhdfz5xx8lute65hyt7263a6sn703ehdlqepyhkx	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525yrv5fXhYm8gay4GyWz4oUgLZE630425BC", "channelCode": "QRIS"}	388118118728e211c2166e1dff20df27f60cc8892c7095a9dec3cf75aa6ad41a	47160340074	\N	\N	pr-006c9148-8de0-45dc-befe-105e7fc01bbe	2025-08-08 22:27:22.818+00	2025-08-09 02:06:10.513+00	MAINNET	BITCOIN	\N
cmg0khfo00002k1hsblo3qs4t_migrated	DEPOSIT	COMPLETED	0.00052	BTC	1000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298482692910", "channelCode": "MANDIRI"}	30d0f8eb11becf6993b0b300fdbd1941f9caf76122a352075993964ce96e7e9d	49173983292	\N	\N	pr-c69e5efd-2fc2-4845-9e96-ad6e93f2db6f	2025-09-26 08:15:33.265+00	2025-09-26 08:37:22.648+00	MAINNET	BITCOIN	\N
cmetsrlt60000k13jqkkgehwl_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1qq7t39x98lc87gzgdgkv8s47qvz4unw2jlvgxrk	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525RN7svviR4vyR9ch8W1bhA4g5h63045C7E", "channelCode": "QRIS"}	d37b5a20c26097e514466c432a9e12587ae5eb77f6620cbf8b509019fe364c5c	48044259642	\N	\N	pr-0cdf9669-9846-45c3-84f3-1b87beb24389	2025-08-27 09:53:19.145+00	2025-08-27 10:10:34.463+00	MAINNET	BITCOIN	\N
cmgc4mqkz0000k1pig2ily9ho_migrated	WITHDRAWAL	COMPLETED	0.00378391	BTC	7522522	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "ID_MANDIRI", "accountNumber": "1780002248017", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "G*********TO P**RA N"}	48ba783dcf1114bb0aa162e16e92a9ea2a596f34757ddcd3c28493edd11d23f5	49520499174	\N	\N	disb-b4510038-1770-42dd-b5f7-bf9823bfc164	2025-10-04 10:25:00.948+00	2025-10-04 10:58:54.5+00	MAINNET	BITCOIN	\N
cmiha4qpc0005k1imhp64mlg5_migrated	DEPOSIT	COMPLETED	0.001837	BTC	2895000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250135000682", "channelCode": "BNI"}	e207bcf22e08cbb5542dd35b9494955d1c2efc6446449e10be3a500249dbb30f	52954651530	\N	\N	pr-5695da61-7f8f-4804-a4dd-50975c924c4f	2025-11-27 10:17:14.543+00	2025-11-27 10:56:16.467+00	MAINNET	BITCOIN	\N
cmgug97vg0001k1cbxtaojwty_migrated	DEPOSIT	COMPLETED	0.001072	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298464236291", "channelCode": "MANDIRI"}	139deefcacd506e80be75bbfcea8b346d03d811bc82e321a4ebe645c8496ae61	50347039159	\N	\N	pr-096712e7-8746-4e80-a4a8-56d9ab645ac5	2025-10-17 06:10:16.733+00	2025-10-17 06:18:47.874+00	MAINNET	BITCOIN	\N
cmhk12wbf0000k19l2jmm5etj_migrated	DEPOSIT	COMPLETED	0.001072	BTC	2000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298462364975", "channelCode": "MANDIRI"}	b3dbf7c1f957fc2dd693123f3f5bd383a8d0e5f5b5dd2483210683cc2a45509d	51268650784	\N	\N	pr-4c878abb-5c11-4e85-b3b0-01bd2db0d747	2025-11-04 03:47:28.155+00	2025-11-04 04:20:40.555+00	MAINNET	BITCOIN	\N
cmgug8ul00000k1cb4mbn96d9_migrated	DEPOSIT	COMPLETED	0.001072	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298405910940", "channelCode": "MANDIRI"}	139deefcacd506e80be75bbfcea8b346d03d811bc82e321a4ebe645c8496ae61	50347038966	\N	\N	pr-1efc5b69-1034-453e-9e49-62f5b9bc08ea	2025-10-17 06:09:59.508+00	2025-10-17 06:18:56.918+00	MAINNET	BITCOIN	\N
cmj0vj4i90000k1vanw5c6zp3_migrated	DEPOSIT	COMPLETED	0.003239	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294809647121", "channelCode": "PERMATA"}	7ef6849292965d9adb886eb6d5bbec5ab27db16a4c6706dcf0f475f300e95646	53740927412	\N	\N	pr-6350e7d4-6c0e-4459-bb0d-3f052433e159	2025-12-11 03:23:54.896+00	2025-12-11 03:48:03.379+00	MAINNET	BITCOIN	\N
cmi5mmbzs000ek1coqlb7g8hq_migrated	DEPOSIT	COMPLETED	0.000627	BTC	999000	bc1qs2kjjthhcc3nf8k5xt5gd89mpqudns7xlksxdv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG61058036162290525T8DqryFLjAykbyyieZO7ZXMdg63044AEE", "channelCode": "QRIS"}	a1402454f54f13edec4bdd4853136e9703861d6ae5fa1f6d2ab82883a7cff10b	52325940439	\N	\N	pr-e4b98df8-559f-49f2-9d08-f08684e95f19	2025-11-19 06:33:36.568+00	2025-11-19 06:49:54.543+00	MAINNET	BITCOIN	\N
cml0d8kkx0005k100ht4tafq4_migrated	DEPOSIT	COMPLETED	0.001387	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG610580361622905258rkewx05IPyv9kwV1VdE8ZZHc630416DC", "channelCode": "QRIS"}	2416e5586bc48bee512340997bf55ecad29086ea89d0ed088ad751a43bb644d5	56106935451	\N	\N	pr-27d3b567-0dd4-49cd-a342-09f8536a8e82	2026-01-30 04:11:14.097+00	2026-01-30 04:20:15.768+00	MAINNET	BITCOIN	\N
cmk9h0mgu0000k1idynkiw8ga_migrated	DEPOSIT	COMPLETED	0.0012	BTC	1900000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250123074113", "channelCode": "BNI"}	d15c2d267154fb6e4193d57aa2b4d0eeabda7e01d4263f09e8d6f913e891a259	55176672375	\N	\N	pr-685b74db-f85d-43a7-a789-0e129b79c70f	2026-01-11 08:27:15.006+00	2026-01-11 08:50:03.644+00	MAINNET	BITCOIN	\N
cmlxc01vs0000k1wvu9808chn_migrated	DEPOSIT	COMPLETED	0.000833	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250128227710", "channelCode": "BNI"}	4bf9224275855a1c409fb1580ac9861117e9cb6075c12c124cef82251b06e27c	57930747897	\N	\N	pr-4dd878a4-fd2f-4b7f-9fe7-75bd40bf013c	2026-02-22 05:53:00.808+00	2026-02-22 06:11:19.849+00	MAINNET	BITCOIN	\N
cmm60s3st0000k105s9qscz17_migrated	DEPOSIT	COMPLETED	0.001801	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525cTVMJSyvtFOs3Q6z4J14geF5v6304C26B", "channelCode": "QRIS"}	7269b6ad2d6eed737c3a2a217c01061694be47438e9d33673659956e3b5e7ca6	58301053378	\N	\N	pr-77dac453-a28b-42e9-8437-781a81293481	2026-02-28 07:48:49.853+00	2026-02-28 07:55:19.459+00	MAINNET	BITCOIN	\N
cme3mf5ro0001k1oh18o4otif_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1pmrry4psjcuarxc4cjuxhdfz5xx8lute65hyt7263a6sn703ehdlqepyhkx	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525GZn156CYWxlkB9YuSmHkBTfpa63040D7F", "channelCode": "QRIS"}	5a742810e9ec6c16f71aac56dda3f4f614a5dffffc4437ba4abe16d6f6430a81	47164813477	\N	\N	pr-8313ae68-928d-4b5d-8984-947c89e03170	2025-08-09 02:13:40.213+00	2025-08-09 02:35:30.873+00	MAINNET	BITCOIN	\N
cmm8z2gth0003k105q9057c5p_migrated	DEPOSIT	COMPLETED	0.004352	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294804316790", "channelCode": "PERMATA"}	621d24d503ca68f6b6bd7c57f530659187da2a2bc7ba15f069099b7b5d4fc642	58424693754	\N	\N	pr-de98d7a7-8a77-4c71-a8df-486474a5a7b2	2026-03-02 09:24:12.58+00	2026-03-02 09:54:17.217+00	MAINNET	BITCOIN	\N
cmexo34bv0000k1b38fz56fz6_migrated	DEPOSIT	COMPLETED	0.00549	BTC	10000000	bc1qx5hxcwphj8rf7lr9zemwwpwsr44reynmuxmzah	{"method": "VA", "vaNumber": "8930250135491640", "channelCode": "BNI"}	a3cafb59afc5737b4d2567ecfca280b47c9e8f2c8ae88dd91d119d124bfb32fc	48165286310	\N	\N	pr-32a2a98e-749d-48b5-a8d8-be51581dc7fb	2025-08-30 02:53:22.987+00	2025-08-30 03:01:55.176+00	MAINNET	BITCOIN	\N
cmhyh0syd0006k1coovbic0kp_migrated	DEPOSIT	COMPLETED	0.000281	BTC	499000	bc1qs2kjjthhcc3nf8k5xt5gd89mpqudns7xlksxdv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054064990005802ID5908BitVault6006BADUNG610580361622905253jh7aIjgsbXG3Ur98MYKmWj2Z6304EBBF", "channelCode": "QRIS"}	294b43b917b86c30a998b46b03ce71fbd8f0b94a13391e0923d9ce0be47b3111	51956167283	\N	\N	pr-6bde3563-8fde-405a-a809-ade6fc74a51d	2025-11-14 06:22:30.805+00	2025-11-14 06:28:17.163+00	MAINNET	BITCOIN	\N
cmfujsb750000k1ggdtm9vx7d_migrated	DEPOSIT	COMPLETED	0.001169	BTC	2300000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298408652014", "channelCode": "MANDIRI"}	fabea15e68f919025928638d5af8ef87e4181a60ac17211af9a48ec81b95306b	48981269132	\N	\N	pr-546cae8c-a391-4ddd-97f9-56cc33a0be44	2025-09-22 03:09:24.017+00	2025-09-22 05:58:17.233+00	MAINNET	BITCOIN	\N
cmgesebt60000k1viusg7zafd_migrated	DEPOSIT	COMPLETED	7.7e-05	BTC	199000	bc1qnmgrlpn2htngd0n6ggq43ekvp6dv7mwcwzlkwj	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525amJ2sWTiZ7ey8teP7KFf82MUe6304CA45", "channelCode": "QRIS"}	b0940a34e9d0e77b2a68ddcda5105f733673d38d6a628b2662c2f0c00058ea56	49603449125	\N	\N	pr-e5aee5ba-cc3d-4416-b753-b501fc93915d	2025-10-06 07:05:51.69+00	2025-10-06 07:39:59.285+00	MAINNET	BITCOIN	\N
cmkl6ty330000k1sbsy2izb5c_migrated	DEPOSIT	COMPLETED	0.000598	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250134089667", "channelCode": "BNI"}	6534d97b1198244a4f7164f0004982ae43e0dab88a89037160b71fc7fd26c107	55541019593	\N	\N	pr-e5e1ee64-7122-47cf-a8f8-0c7aafe864a3	2026-01-19 13:15:21.423+00	2026-01-19 16:17:46.996+00	MAINNET	BITCOIN	\N
cmguif6040004k1cbs7ue8vjt_migrated	DEPOSIT	COMPLETED	0.000539	BTC	1000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "88908298424648749", "channelCode": "MANDIRI"}	98db09c813cadebb4674360b221443084f99e0eb7ef5b0e8cdeb01369a8dda67	50352150113	\N	\N	pr-b4633359-b998-4fc1-b1b9-73791b50fbbb	2025-10-17 07:10:53.477+00	2025-10-17 07:41:09.6+00	MAINNET	BITCOIN	\N
cmmw5nxp80006k105x0c2hfum_migrated	DEPOSIT	COMPLETED	0.000627	BTC	800000	bc1q9x4wnxav7233trj7n3d3sxsp37d9qw96qhzsx5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054068000005802ID5908BitVault6006BADUNG61058036162290525G1Z2wj4DLaARsNpxbjqaTpKib63048A46", "channelCode": "QRIS"}	24d384ec99a479c53f006746ea79ce62d6f035f7dfb294b9731ab21f0b895217	59348224801	\N	\N	pr-0346f6cc-2476-4920-a99c-137e4c98f8b5	2026-03-18 14:47:33.98+00	2026-03-18 15:04:15.797+00	MAINNET	BITCOIN	\N
cmj3egw1u0001k1vasvj6iet8_migrated	DEPOSIT	COMPLETED	0.001544	BTC	2400000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250120430731", "channelCode": "BNI"}	b5aadf2935aaf447e2a803a593ab62810b2179063e58e43ba167e5576b62fed7	53848805248	\N	\N	pr-0d8d3ff6-e0fb-4e6e-92df-f0d3746d95e9	2025-12-12 21:49:35.682+00	2025-12-12 22:52:58.19+00	MAINNET	BITCOIN	\N
cml0itb620006k1004znuy4by_migrated	DEPOSIT	COMPLETED	0.000686	BTC	1000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG610580361622905256PecT1FkDUM5UZRwzj7NR8TIl6304192D", "channelCode": "QRIS"}	cc9368ba0fb55b657ebb816c96bdcca94cc49310b8be61da94e7d63596b85a97	56112655895	\N	\N	pr-a3a44721-14c4-49b5-8cc9-70b52e45874f	2026-01-30 06:47:19.754+00	2026-01-30 06:51:32.63+00	MAINNET	BITCOIN	\N
cml3n9ge50000k1lslxkqz6tc_migrated	DEPOSIT	COMPLETED	0.001838	BTC	2500000	bc1qwxvx6tf67k0pd9zd5wy6rmahzgwdje6ndpv8g8	{"method": "VA", "vaNumber": "8930250123016144", "channelCode": "BNI"}	f3124fbeeb3f2930fb0785837ca92a7843cebb7fc8bbdf1010e8dfd7233af137	56283997228	\N	\N	pr-c108a5a2-df45-4ff6-8229-cc3ea6d1dcdc	2026-02-01 11:15:10.012+00	2026-02-01 13:12:10.834+00	MAINNET	BITCOIN	\N
cmg0sn29y0000k1ez9khy9tlr_migrated	DEPOSIT	COMPLETED	0.001591	BTC	3000000	bc1qwxvx6tf67k0pd9zd5wy6rmahzgwdje6ndpv8g8	{"method": "VA", "vaNumber": "8930250135231407", "channelCode": "BNI"}	92031b2cb69da8f825a7d361fbd721d91e49d8f4296caca66b0c448217b2f6e4	49183931477	\N	\N	pr-cf451a9e-ae4e-4dc4-843e-87d565c683ab	2025-09-26 12:03:52.774+00	2025-09-26 17:07:51.819+00	MAINNET	BITCOIN	\N
cme59jy3z0000k12oy9oze5cp_migrated	DEPOSIT	COMPLETED	8.6e-05	BTC	199000	bc1pmrry4psjcuarxc4cjuxhdfz5xx8lute65hyt7263a6sn703ehdlqepyhkx	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525ducWvgc4sJ14FBmvUf7WvEZMf6304262C", "channelCode": "QRIS"}	becb635f865a2433a99b417ae7e50ca2a38f3a12935cf6c6ac79a07edb674be0	47207454999	\N	\N	pr-5ea0119e-d28c-439e-8815-10da3bd07b65	2025-08-10 05:49:00.91+00	2025-08-10 05:51:59.459+00	MAINNET	BITCOIN	\N
cmgulz51e0005k1cbsmhq261b_migrated	DEPOSIT	COMPLETED	0.000539	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250128220839", "channelCode": "BNI"}	af3e2857623fccff6ceb2055144b116eadba8309e347948e33b8443e0728de91	50362144986	\N	\N	pr-f44b533e-f2b9-4c64-93e2-da386b02b471	2025-10-17 08:50:24.194+00	2025-10-17 09:00:07.198+00	MAINNET	BITCOIN	\N
cmi8mn6g10000k150y207uuxs_migrated	DEPOSIT	COMPLETED	0.000686	BTC	1000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298440390211", "channelCode": "MANDIRI"}	883d5737993335775e671cf1d1e51ba5966cff4d347a5a2aa7f475beb5d5ae15	52533444041	\N	\N	pr-663e3f63-cb52-4edc-9c05-c26eb993aca0	2025-11-21 08:57:34.56+00	2025-11-21 11:26:46.405+00	MAINNET	BITCOIN	\N
cme59qbo00001k12o7qz65287_migrated	WITHDRAWAL	COMPLETED	0.00025508	BTC	454460	bc1pmrry4psjcuarxc4cjuxhdfz5xx8lute65hyt7263a6sn703ehdlqepyhkx	{"method": "ID_BCA", "accountNumber": "7445116700", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "K***IN"}	6849877296ca8250e040d8b82062cf5de621d73a6ceed528b1cd931bb4de134f	47208068599	\N	\N	disb-9e1d5019-b965-4a16-8b75-92d9adc01074	2025-08-10 05:53:58.416+00	2025-08-10 06:11:08.525+00	MAINNET	BITCOIN	\N
cmko2p0hf0000k10046n92pit_migrated	DEPOSIT	COMPLETED	0.001279	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525nYogJYpXidLOxietiZ2XrQEGq6304999C", "channelCode": "QRIS"}	fa5eaa882a708be83693fef97810a02c757fe9eb817fb09f24232d6814cee6c1	55646255351	\N	\N	pr-ecad049d-a214-4735-bca5-5f65e4b89d48	2026-01-21 13:42:51.315+00	2026-01-21 13:53:31.321+00	MAINNET	BITCOIN	\N
cmimigyxp0007k1imhgwo0s6m_migrated	DEPOSIT	COMPLETED	0.000647	BTC	1000000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525hWFMCGmu1dKNKRDX6vJrt085p63041E7E", "channelCode": "QRIS"}	923471f3c9e92c1688cd0dd30ddb5794e8717ed85256474c8d2ac86fadf78962	53115932120	\N	\N	pr-8ecdf045-c81b-444d-9824-6b1f0a61acde	2025-12-01 02:09:32.893+00	2025-12-01 02:25:25.475+00	MAINNET	BITCOIN	\N
cmexscqp80001k1b3p63m2wkg_migrated	DEPOSIT	COMPLETED	0.002726	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294806567520", "channelCode": "PERMATA"}	16d3974d2da4bde55c26dbe3dbcc6e504eb5706717c7e4338a5e198e98e5d9c1	48167937600	\N	\N	pr-174d4871-704d-4812-872e-5c39bd9924b5	2025-08-30 04:52:50.348+00	2025-08-30 05:01:18.764+00	MAINNET	BITCOIN	\N
cme5li67u0004k13lh1931s5b_migrated	WITHDRAWAL	COMPLETED	0.00027636	BTC	493261	bc1q26me48zhzfan92fex6z77ze6rvsxpqsj6qkf26	{"method": "ID_BNI", "accountNumber": "1773254709", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "I P*** K**IN T*** S"}	b5d940230d4e8e176222b0e471bb5969c104afea9bfe985fce4a065ba87733c8	47217068667	\N	\N	disb-eb9fd600-b99b-4b24-a860-9e4d362df216	2025-08-10 11:23:33.498+00	2025-08-10 11:32:43.175+00	MAINNET	BITCOIN	\N
cmhyiaiw10007k1coja2uabt7_migrated	DEPOSIT	COMPLETED	0.000578	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250120301558", "channelCode": "BNI"}	0ae1188ad96f93c47fab8659f885abf6890ea775b0f946cae251c79f6980ebad	51959420182	\N	\N	pr-9761de5e-7d04-4f3c-9e54-866673181955	2025-11-14 06:58:03.938+00	2025-11-14 07:08:56.253+00	MAINNET	BITCOIN	\N
cmglp51dx0000k1bimgsgspu5_migrated	DEPOSIT	COMPLETED	0.001032	BTC	2000000	bc1qrra3vc3jc7tzpl6audpmd99r2la0608m6fvpuu	{"method": "VA", "vaNumber": "8930250138567100", "channelCode": "BNI"}	b32be723e1f45351aa2aca79ad645047af11e766e1a528a9a06a68c9d69cfed8	49916243808	\N	\N	pr-df7cbc39-49ae-4cfc-9917-7f30dfe2c0b2	2025-10-11 03:09:02.661+00	2025-10-11 05:23:35.896+00	MAINNET	BITCOIN	\N
cmmbpmmnd0004k105mzsnmv29_migrated	DEPOSIT	COMPLETED	0.000823	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG610580361622905250XriRiVs5wAKe8ezni5yOJsEp6304524A", "channelCode": "QRIS"}	112a00f63e677d8b94b2f958c6ad31229e54b57598dd6ba61351ccb801fae0e9	58582298882	\N	\N	pr-6465d0c3-8abe-45dc-8a0c-acf7c2af0d06	2026-03-04 07:23:15.625+00	2026-03-04 07:36:29.862+00	MAINNET	BITCOIN	\N
cmj59wzpv0000k1oj77brmzpj_migrated	DEPOSIT	COMPLETED	0.000637	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250128824507", "channelCode": "BNI"}	eb6b5adbd447e958372da4763dcc9a7146606d4a4a0642e0817bb15406a70b3f	53880963525	\N	\N	pr-734fd387-27a3-4de5-a5f4-bb22d5f8edf8	2025-12-14 05:17:41.203+00	2025-12-14 05:20:02.529+00	MAINNET	BITCOIN	\N
cmn4mqoe10001k1459emcotev_migrated	DEPOSIT	COMPLETED	0.000547	BTC	700000	bc1q4drazgjv6aam7npqnl9mu6qslej64vkq88j353	{"method": "VA", "vaNumber": "8930250130731001", "channelCode": "BNI"}	5fdc163375b5c05c3549d7816162f609573e4b9e83b7c46c1f2679e9eb4a8197	59694613198	\N	\N	pr-91e9c041-904c-4441-b16d-c8c1c167af01	2026-03-24 13:07:44.761+00	2026-03-25 15:39:02.202+00	MAINNET	BITCOIN	\N
cml0mc7zq0007k100qrewefjz_migrated	DEPOSIT	COMPLETED	0.000686	BTC	999000	bc1qs2kjjthhcc3nf8k5xt5gd89mpqudns7xlksxdv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG61058036162290525phC7PKzrTxWXCC4L6oQdFOsCN6304BC4F", "channelCode": "QRIS"}	479c67a66f06b9a059929dc11b59b0a1e0b1cd6710043faeef8176c8191ccb1e	56116941455	\N	\N	pr-0781d301-e5a9-476a-937e-f93aef95cf0a	2026-01-30 08:26:00.949+00	2026-01-30 08:35:39.361+00	MAINNET	BITCOIN	\N
cmec55ysh0000k1du6rrfczby_migrated	DEPOSIT	COMPLETED	0.00049	BTC	999000	bc1qqsdcgnwvmj2y97hn85v7ylh2k47rz3eecaqxsv	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG610580361622905259cc49QYyrjtGSNw71F6xzbcM66304F170", "channelCode": "QRIS"}	754296f57638fbf2092565a0f3a12b0a7a834d7988d0f228e7578f39a1031b99	47458494579	\N	\N	pr-fb507c36-497e-43a1-b1b7-22a0b0bde4e2	2025-08-15 01:20:33.377+00	2025-08-15 01:23:38.85+00	MAINNET	BITCOIN	\N
cmguqf4w50001k1j69nfvc4dw_migrated	DEPOSIT	COMPLETED	0.002786	BTC	5000000	bc1qx5hxcwphj8rf7lr9zemwwpwsr44reynmuxmzah	{"method": "VA", "vaNumber": "13282277369852659", "channelCode": "BRI"}	946596b1567cce225a9bbfafe2b15a4c52a11d0edc899d034b1fe937e812cdc8	50372077584	\N	\N	pr-570bfccc-bc68-4be8-934b-c73f5d8e26a4	2025-10-17 10:54:48.965+00	2025-10-17 11:05:19.325+00	MAINNET	BITCOIN	\N
cmhyt1h4j0008k1coo66b8slo_migrated	DEPOSIT	COMPLETED	0.000893	BTC	1502000	bc1qyuncvz55dnlzeu2eh5xy89uj089v2wd6gt0v74	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540715020005802ID5908BitVault6006BADUNG61058036162290525BfkgUTmSpQ1TlrMF50c49hJpm6304A466", "channelCode": "QRIS"}	6356eb326b0f698d089159ae37abdf2d822e01a2906710833d0d05c397f64f46	51977360266	\N	\N	pr-20b5751c-d2e4-47be-a653-6b74e164fcfd	2025-11-14 11:58:57.522+00	2025-11-14 12:11:10.217+00	MAINNET	BITCOIN	\N
cmezv0f6y0000k17a9kk061hc_migrated	DEPOSIT	COMPLETED	0.003266	BTC	6000000	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "VA", "vaNumber": "8930250132072932", "channelCode": "BNI"}	812f843d002f39e663f74a721ef7d9df9c9776596826abcf5c16e401955601b0	48198987697	\N	\N	pr-b98520d8-39e7-4e33-a1d7-349e5578974b	2025-08-31 15:42:46.762+00	2025-08-31 23:41:52.12+00	MAINNET	BITCOIN	\N
cmguqcvq80000k1j6lz4s3qmv_migrated	DEPOSIT	COMPLETED	0.001111	BTC	2000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "VA", "vaNumber": "88908298450680723", "channelCode": "MANDIRI"}	72d684ce9a69e8b9ba263c6f084805d88399ffb7ac5ce4cc8cc3a48175d6ecb2	50372087895	\N	\N	pr-549a60d3-6264-463d-a8c0-3052b639258e	2025-10-17 10:53:03.775+00	2025-10-17 11:06:09.978+00	MAINNET	BITCOIN	\N
cmhukuhb10000k1fbbi3x3ik0_migrated	WITHDRAWAL	COMPLETED	0.00323755	BTC	5492071	bc1q2xqrrv7w5w8fnppmtfvrlakd5z8fpmr776vwq8	{"method": "ID_MANDIRI", "accountNumber": "1780002248017", "bitvaultAddress": "bc1q9gfxsv9l2fcczgnu0x27jpqq8ah3n7h2n32pas", "accountHolderName": "G*********TO P**RA N"}	7ee24f6ec0a3a8c6839a68b873d0960b5ae6fdb562fa13ba68514ceda0beb57d	51794385437	\N	\N	disb-9774165c-e261-4e33-ac5f-0d6e3d6f8342	2025-11-11 12:58:29.533+00	2025-11-12 03:51:40.139+00	MAINNET	BITCOIN	\N
cmn8i27tm0000k1uxsznvgrab_migrated	DEPOSIT	COMPLETED	0.000143	BTC	199000	bc1qcjlfd5um4l38509a9w60ewj0u6n9xngvgyg5h3	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054061990005802ID5908BitVault6006BADUNG61058036162290525oFL6D1xgbQgtzAWGSBnGhxwbz6304CB4C", "channelCode": "QRIS"}	4ba6bac59557bfc943c56cc03a0c5ea0bfb11f0fd0e5e05f2a049a23b6bfab65	59758755366	\N	\N	pr-37c5ad99-5b51-4eae-85c5-9bf3325297e6	2026-03-27 06:07:49.786+00	2026-03-27 06:21:26.044+00	MAINNET	BITCOIN	\N
cmglv8tk40000k1jn01jmu1h5_migrated	DEPOSIT	COMPLETED	0.00051	BTC	1000000	bc1qa2w5s8x049fyzrw3pnhfd892wa0k3xgxxm4d0j	{"method": "VA", "vaNumber": "8930250138895250", "channelCode": "BNI"}	96eb63081dbbd1eec8a44de982d3dde4851834514e6cef79c8ed5afb25d24f84	49922657411	\N	\N	pr-14c13ea3-96f5-4e07-a5ea-f86c1f27de93	2025-10-11 05:59:56.835+00	2025-10-11 06:54:58.85+00	MAINNET	BITCOIN	\N
cmi8naqc90001k150xcebclww_migrated	DEPOSIT	COMPLETED	0.001387	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "VA", "vaNumber": "88908298476643947", "channelCode": "MANDIRI"}	883d5737993335775e671cf1d1e51ba5966cff4d347a5a2aa7f475beb5d5ae15	52533444435	\N	\N	pr-320a73ab-108d-4d27-8202-06e701631b92	2025-11-21 09:15:53.433+00	2025-11-21 11:26:28.202+00	MAINNET	BITCOIN	\N
cmiolvu060008k1im1s3jo9ok_migrated	DEPOSIT	COMPLETED	0.001328	BTC	2000000	bc1qmz8suzqrqsg3evut6hd46vwraqy533a4c46dyc	{"method": "VA", "vaNumber": "88908298493392642", "channelCode": "MANDIRI"}	01b77b99c1220f9f7016f893ba67160dc7998f718aa899f62d14affc0517cb5f	53217397372	\N	\N	pr-b64cde80-bd0a-49f8-bf75-c6e1953eee6a	2025-12-02 13:20:37.542+00	2025-12-02 13:56:36.227+00	MAINNET	BITCOIN	\N
cmguqhbhb0002k1j6qgp57cer_migrated	DEPOSIT	COMPLETED	0.001111	BTC	2000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "VA", "vaNumber": "88908298452136662", "channelCode": "MANDIRI"}	946596b1567cce225a9bbfafe2b15a4c52a11d0edc899d034b1fe937e812cdc8	50372078117	\N	\N	pr-e374f244-fdbc-478c-98ee-a5fd1ed4c9e2	2025-10-17 10:56:30.816+00	2025-10-17 11:04:50.252+00	MAINNET	BITCOIN	\N
cmkuqrnlw0002k100kw11amt2_migrated	DEPOSIT	COMPLETED	0.000647	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG610580361622905255Kr9yoTsZXohRQCTUvuSSu7wA6304A1E8", "channelCode": "QRIS"}	d189b6329affe3f46b7ac79f4773ff9a458556c902138d9196b691760f5f1e0b	55883997303	\N	\N	pr-5e7a05ff-0897-4263-bd61-a17872dc7841	2026-01-26 05:43:22.436+00	2026-01-26 05:57:03.45+00	MAINNET	BITCOIN	\N
cmjcwbb1p0001k1ojuijp6zg4_migrated	DEPOSIT	COMPLETED	0.000647	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525nqMg6NBizYouEb3vG1DcvrVFQ630409F2", "channelCode": "QRIS"}	ea8a53a028c7eba61e25b2e2eb04eb43320b1578a91b715476a43d4559173654	54240697785	\N	\N	pr-51bc450b-5bea-47bb-9426-713cc13b9497	2025-12-19 13:19:03.852+00	2025-12-19 13:48:13.721+00	MAINNET	BITCOIN	\N
cmkuqohkv0001k100ze776fid_migrated	DEPOSIT	COMPLETED	0.001964	BTC	3000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540730000005802ID5908BitVault6006BADUNG61058036162290525EUA7mPtVx8005NMxXtHVrCQHI6304BD91", "channelCode": "QRIS"}	d189b6329affe3f46b7ac79f4773ff9a458556c902138d9196b691760f5f1e0b	55883996965	\N	\N	pr-1085faaa-408a-4456-aa47-7a30c34890ef	2026-01-26 05:40:54.655+00	2026-01-26 05:57:08.491+00	MAINNET	BITCOIN	\N
cml2c839g0008k1005agjk0m1_migrated	DEPOSIT	COMPLETED	0.000686	BTC	999000	bc1qgx3wps4pefksr5v9fj7w9mpadf7g5jcnx5g56x	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID202539929624852045099530336054069990005802ID5908BitVault6006BADUNG61058036162290525xV2czOHYMMqxZghGZ6PUcXJkA63041986", "channelCode": "QRIS"}	b090aaee5fd4ce91ea5b254173c15c2e3369656ca59982933ffbde22437b39c9	56195175798	\N	\N	pr-4eeb327a-58ad-470a-8357-3b0bb6db92b5	2026-01-31 13:18:24.387+00	2026-01-31 13:25:04.312+00	MAINNET	BITCOIN	\N
cmp3qrkl6000mmj01i89j5uvk	DEPOSIT	COMPLETED	56.642382	USDC	1000000	EoMqYMQGxxA9ogQgdxumKqVJHEMR9QjadKTo1SX3ui9X	{"method": "VA", "vaNumber": "8930250126271735", "channelCode": "BNI"}	59rRUTxiWu45WxaPDmzWid2wq3Un1Kkp1ShcQ64UGMJRgEVGwEKteBU1VfEHk5aayXWUkAP1t8YzinBBTRFAggKF	1499955570	\N	\N	pr-b3c49f4a-5c2f-4e41-8392-c20d4702e7fd	2026-05-13 07:32:03.45+00	2026-05-13 07:36:14.276+00	MAINNET	SOLANA	\N
cmonncpt6000cnl01w865lyhe	DEPOSIT	COMPLETED	6.8141715	SOL	10000000	EoMqYMQGxxA9ogQgdxumKqVJHEMR9QjadKTo1SX3ui9X	{"method": "VA", "vaNumber": "8930250136396953", "channelCode": "BNI"}	2NKjL1pttMABumWDP6batDDVQbk7pQA3mG9H2jsHqAao767BmPTRS5Nyae94WUqJcNyvq7Es3uGGBkr45pkuqUbd	17019837122	\N	\N	pr-fca81a8e-b93d-4c6a-834d-0aa67718290e	2026-05-02 01:12:12.715+00	2026-05-02 01:13:56.87+00	MAINNET	SOLANA	\N
cmpjjbt760003mq01y3am0ega	DEPOSIT	COMPLETED	1126.571438	USDC	20000000	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	{"method": "VA", "vaNumber": "7293294803312817", "channelCode": "PERMATA"}	3wXCX2kupVx1Jgns5QZTaDhFyQDXLjmCQAn2mm5eugyApxu7q6xjyYjfrL6nyH4BGugrB2HmdD44opsoHhwQ6hGE	1517866097	\N	\N	pr-f0a4ee05-843f-4a6b-b60b-be9c39ddf420	2026-05-24 08:48:09.619+00	2026-05-24 08:49:07.575+00	MAINNET	SOLANA	\N
cmq7swjbp0001oj01xss4pint	WITHDRAWAL	COMPLETED	94.5191	USDC	1678420	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "pasha renaisan"}	2RzBNjYBrAbM7Ap5sm3JNkwPKZk6DRHu3fPD2eebkDpFNbabDPcYXGsuniGtJYQYxM2FiAZ2XqV4GnMHiuM52pqk	1545475391	\N	\N	disb-4d979a55-aa32-4475-aeaa-30fd80de7b7c	2026-06-10 08:22:41.366+00	2026-06-10 08:26:36.273+00	MAINNET	SOLANA	\N
cmq4uecc7000ro601xoyo44uq	DEPOSIT	COMPLETED	0.00169198	BTC	2000000	bc1pqm6tfh33aj5pxz547ennu75lg29ghdtc5h64su03fq7u3xqf3x0s8na4l2	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540720000005802ID5908BitVault6006BADUNG61058036162290525Z5CqJ24pygm8CjfCaq1DbDowE6304D011"}	64e11b7b4c7625d87990efaa102bf9a5416e723817168dfc3345628fe7a3164b	63004425981	\N	\N	pr-4259af7b-2270-4f34-b09f-84f0b8c595da	2026-06-08 06:41:13.207+00	2026-06-08 07:02:57.039+00	MAINNET	BITCOIN	\N
f5743421-595d-45df-9a8d-28b4a9ad5e66	WITHDRAWAL	COMPLETED	9.5042668061	DOT	129452	14zRcrEEghsNF5msJ2HirCLnBTVtYVsLWCaXbWHfaZfdm77L	{"method": "ID_BCA", "accountNumber": "7445116700", "paradappAddress": "16htqbbaLEwMYWrW38jrtMypNUfNiiVtwSwzyyeV9RzsoZaK", "accountHolderName": "Kel****"}	0x8a31da3edb9926f134609f688bffb18d0153fa8f0f4ecd9d87b0a8dd6ef9f276	6158956290	\N	\N	6a6a68b625934f022d98d497	2026-07-29 20:22:15.563+00	2026-07-29 21:11:47.427+00	MAINNET	POLKADOT	\N
f2d70c89-bece-4c3c-8125-eef0bf8be439	DEPOSIT	COMPLETED	0.00438429	BTC	5000000	bc1q233mjzpf7mr0zpy4m03lnzn9kfap7wn39g3rw7	{"method": "VA", "vaNumber": "7293294814346220", "channelCode": "PERMATA"}	07d7a3fe50db89da4ceed3ca098ba7ff24d887666926ab272eb4b62333bbac8c	65067188049	\N	\N	pr-89c3b107-799f-4f63-9598-a6c7a554dd73	2026-08-01 18:31:23.972+00	2026-08-01 18:37:37.811+00	MAINNET	BITCOIN	\N
cmq0dlcs30004o601tm3ms8an	DEPOSIT	COMPLETED	108.549298	USDC	2000000	8pX62tfQVDSushgJvuEZvmpeS9Uxa549EaD9JTqm5Dyu	{"method": "VA", "vaNumber": "8930250132161737", "channelCode": "BNI"}	5BLhw5M7uigeehqVgrwsHAd3Mt7gAiNWGbaaxqbHkQNDw9CDCa4ChVSANGXePBR3cq8LgZ92g4GXr8d6wfXpE4Qs	1536557466	\N	\N	pr-e158f5ec-62ca-43f2-9205-3b4f22522f4a	2026-06-05 03:39:42.196+00	2026-06-05 03:43:37.252+00	MAINNET	SOLANA	\N
b5c21c0f-c3f8-423f-87b1-7810a6eee2fa	DEPOSIT	COMPLETED	0.00082784	BTC	1000000	bc1q9yzpmcayu626j5ke5ldwh3wp4qlzyj9gn6tny5	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540710000005802ID5908BitVault6006BADUNG61058036162290525uhncRRQdHpLdmDDMPRyf89ry763042C6B"}	1b10f5b7c81781e293aad98c3bf83a991c9dc700b7d9b287d3a8ceeb6345b3b3	65222016288	\N	\N	pr-b5045ed3-5729-4729-b1e7-bec9f36b51e1	2026-08-07 08:47:54.612+00	2026-08-07 08:51:59.777+00	MAINNET	BITCOIN	\N
16a62999-b050-46eb-87fe-5d3d46e22b44	DEPOSIT	COMPLETED	0.00253354	BTC	3000000	bc1qjt37pz559e6slecjrhdkm3sqzv4vsjk837ap2w	{"method": "QRIS", "qrString": "00020101021226650013CO.XENDIT.WWW011893600848000000404402158nK6jXKD5k9c7jf0303UME51370014ID.CO.QRIS.WWW0215ID2025399296248520450995303360540730000005802ID5908BitVault6006BADUNG61058036162290525LNCpzAA36VChynhw9umfKfTEx6304A28A"}	e74abdde83d82076cd7e5ab696dfc6ec77af1814a82459d33f25674f6689fa54	65165708977	\N	\N	pr-3e56201b-2704-433b-8ce1-fdd0c29acda6	2026-08-05 10:39:58.681+00	2026-08-05 10:51:25.439+00	MAINNET	BITCOIN	\N
5c209a3b-77fd-4764-94a2-67fd00639c0c	WITHDRAWAL	COMPLETED	5.5	USDC	89340	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Pas**** Ren****"}	dHsBjvre7939j5XpNKmqBSDePEH5kmRuQuYgAANpUHeVrEUoub4QG8ecYutDMXj4ZDkFSGV9zWV5LXc2QZ16QWv	1613624475	\N	\N	6a663a3385c2e5d5776f2705	2026-07-26 15:46:15.676+00	2026-07-26 21:03:52.414+00	MAINNET	SOLANA	\N
6c8497b3-e478-4f20-84c1-96d09dc01bf3	WITHDRAWAL	COMPLETED	15.832954	USDC	267148	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "ID_BCA", "accountNumber": "0490690069", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "Pas**** Ren****"}	2py8k4aKczcGSdWVZhUepjkeykGUr838vMQFiWeMyNQfLXDHHxi2pAE3PbAMV1vTTVNugQSwVLuVqWCvvufEa8X2	1641005815	\N	\N	6a8197b70ec2fdd8d85f5867	2026-08-15 04:24:54.512+00	2026-08-16 10:58:04.422+00	MAINNET	SOLANA	\N
358aed44-623e-46ac-9521-438f97dd5cdf	WITHDRAWAL	COMPLETED	0.5	SOL	110986	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081238465727", "accountNumber": "081238465727", "bankAccountName": "endang sukanto", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "endang sukanto", "idrxBankAccountAdded": false}	3EB1MTKwQvANi8vJAppJee8kDErt1PPhBBVe2caFDbqfhTX9XamNwNBGx9vbSUwg8ZnXw5gKZL4JG6ApEdjTazGR	\N	\N	\N	\N	2026-09-10 14:58:54.982983+00	2026-09-10 14:59:25.590277+00	TESTNET	SOLANA	\N
6c1334f0-c62d-42eb-8525-7b5a8d8c976f	WITHDRAWAL	COMPLETED	0.002298515116846999	ETH	77618	0xE3B910c931117EAe35684D2af78e69240031C69f	{"method": "501", "bankCode": "501", "bankName": "BANK BLU DIGITAL BCA", "bankAccount": "005250920570", "soldUsdcQty": 5.027673, "accountNumber": "005250920570", "bankAccountName": "pasha renaisan", "paradappAddress": "0x914EffCbd43c570ec5d59e8a3918b80439e6cb86", "solanaBurnTxHash": "2qFiu9VRZuiMS3WvV3cG9PbZJToRCYm1NxtAtuj6mazZjf7oNSgERyv3UW9E7zHQuNv8ixxBShFeTU2xf74cCowB", "accountHolderName": "pasha renaisan", "binanceWithdrawId": "8a97f7416ce445c9951735811f12862c", "jupiterSwapTxHash": "pMcmMDhtgN97XoU49oV6uBjDURJJTYwRXVhn2UUJbgiNdp4w4x1drzw9yVBCJGHuUg8QL3g8LSQMhYZK62BvuqA", "swappedIdrxAmount": 82618.76, "idrxTransferTxHash": "2uyAQtoftuzYtN5hkhkPRvLGQ8zLJSRneHpRVU3HJwccPeNXzuU3rA2GcqbsbKiXsPf5udXLDZNmyqsLZf8ES5uU", "platformProfitUsdc": 0.028366038000000003, "idrxRedeemRequestId": "18202", "solanaBurnBlockhash": "DpuYXVkgfWX3Hwddms1sDENM1HUHinNPBBE8YGbTT1mm", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "5phYZKtmeQQaTVFzQoZuWzjZRMuPgcqxijj3smrQ1W2Q", "binanceWithdrawTxHash": "26adJ8akWWq5U6BxmekdyKnSLguS82g3MV2gDrR3WjGTA6pXaB3bbtHbqYbVD54GkCn5caw2gqKJcADcZkCh5r7D", "idrxTransferBlockhash": "GzBygMbGZfKcCxbbABsyW544fQd5reui3PtXxMNkgMfC", "operatorToBinanceTxHash": "0x663cd478c5c3335b6cb3cbe62962734936975743f735adbed32859a263914baa"}	0xdde67a822def45eb3e52cfee606bacf548610fe4f64be12a9dcf6efdfd2bbd50	11020227062	\N	\N	\N	2026-09-02 18:10:02.114106+00	2026-09-02 18:36:17.905317+00	MAINNET	ETHEREUM	\N
2c0ab327-4c76-4a42-a855-ff45d1836818	DEPOSIT	COMPLETED	1.400997	USDC	25000	87JyDsMpP9TmajXRTtC7MEMKF2tf2hFvVJGto9qmzQMt	{"fees": [], "amount": "25000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-11T08:14:38.632045941+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540825000.00530336062300119QR26OXEBI5DDYBBI8L50703A01630444FB", "reference": "SNAP-20260911061438", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "25000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMTA2MTQzOCIsInBheW1lbnRBbW91bnQiOjI1MDAwLCJ0b0JlTWludGVkIjoiMjUwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5MTE2Mjc4NzAzLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkxMDcyNzgsImV4cCI6MTc4OTExNjI3OH0.8x84IB7IAE4mUFwkQYb8bj7IuR5cNV5N7SwCjirtsp4", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMTA2MTQzOCIsInBheW1lbnRBbW91bnQiOjI1MDAwLCJ0b0JlTWludGVkIjoiMjUwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5MTE2Mjc4NzAzLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkxMDcyNzgsImV4cCI6MTc4OTExNjI3OH0.8x84IB7IAE4mUFwkQYb8bj7IuR5cNV5N7SwCjirtsp4", "expiredDate": "2026-09-11T08:44:38.703Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26OXEBI5DDYBBI8L5", "referenceNo": "D1180826JN88HWJFK5LOMD6", "sweepTxHash": "4kRn54yyxJ4DSan49rvwvkdzZKeN57iaEGM6xtff6n4b9eWeLnJXcFiSKG2Ltid1DypYN6smsMP4Rz5myUq7SUPq", "customerName": "PASHA RENAISAN", "mintedAmount": 24825.0, "payoutTxHash": "3i3Xs1m42jYbHvhr9WwkyGgzi8v1zktf4ELevaPNbjiU7iQwvGfxqskRKLJ49i4L1uKEgFSzze9oNDKtvq2TRWo3", "depositTxHash": "2sZSe1tR1kbKiLFVBHgpzQKHgB4L3rys2JcStdffwLLXvnUP6BkvbkV2kbwTetcSamcWuoztgKEsSLYcvMLQBw1H", "paymentMethod": "qris", "swappedAmount": 1.4151489999999995, "idrxMintOrderId": "20260911061438", "payoutBlockhash": "6wZbYZHMTAWKCCbYj2TeTrz6KThuE9N8MuHbmPsuBqni", "refPayoutTxHash": "5YVANdJzKdsmemMYViNpforcQWsEzZZKEvssoEAmMeTpCw65Pb4BGX51GEojTe1tyftNpsmBpVGis5Qqic6SqUfm", "jupiterSwapTxHash": "2LqtHzApGfTP6cz55rxubcqNGkZRog2KyNj4wRsE2DhU5irCHDxdrBY8dHZmdVmLVUToq4b7EUKHDJob8aKUidSv", "refPayoutBlockhash": "8WRPf7XnYmHf12ysiJ9kReF9eMh5ypGZxpBPEEqYR5VF", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	3i3Xs1m42jYbHvhr9WwkyGgzi8v1zktf4ELevaPNbjiU7iQwvGfxqskRKLJ49i4L1uKEgFSzze9oNDKtvq2TRWo3	\N	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.003537	\N	2026-09-11 06:14:38.630649+00	2026-09-11 06:34:37.390629+00	MAINNET	SOLANA	5YVANdJzKdsmemMYViNpforcQWsEzZZKEvssoEAmMeTpCw65Pb4BGX51GEojTe1tyftNpsmBpVGis5Qqic6SqUfm
0679301e-0d36-45de-9b29-a2f7f25f1063	DEPOSIT	COMPLETED	6.45762	DOT	100000	12BNNy4BQu8tojSbj8WWh4BTi8rayQPm5YteoebxuPPWDQb6	{"fees": [], "amount": "100000", "method": "IDRX", "cexTxId": "6181574966", "channelId": "QR", "expiresAt": "2026-09-02T20:39:29.082147961+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409100000.00530336062300119QR261DY1V0P2N7Z34A80703A0163040282", "reference": "SNAP-20260902183929", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "100000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjE4MzkyOSIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzODMzNjk0ODQsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM3NDM2OSwiZXhwIjoxNzg4MzgzMzY5fQ.u3Of-Sw5tifZX4Ya6t-XEWuN_us6DvZT5qzAk-pRznI", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjE4MzkyOSIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzODMzNjk0ODQsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM3NDM2OSwiZXhwIjoxNzg4MzgzMzY5fQ.u3Of-Sw5tifZX4Ya6t-XEWuN_us6DvZT5qzAk-pRznI", "expiredDate": "2026-09-02T21:09:29.484Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR261DY1V0P2N7Z34A8", "referenceNo": "D1180826KYK8HPGJ31QIRLG", "sweepTxHash": "4PEQP4D59NkWgVWbv3ppDkrWhKminKpUEm9h8c1tEYuLpqpJQtRXSxPjnuMvRS6kw7bKZNs44sVT9JhZCcSiqyn5", "mintedAmount": 99300.0, "depositTxHash": "2AvRZ3WcPXB6gKaszVNmadyvX7tYky3T9BaGiBNY6GatchcHp7MreYLWgTWzSsmVd4XxDrhPhTNaPFVXvd5pfRSZ", "paymentMethod": "qris", "swappedAmount": 5.630052, "idrxMintOrderId": "20260902183929", "jupiterSwapTxHash": "3fFeqg7H3ngFMQ3YCVz34TfdPm33VWCDjvHnkGnhZ5AeA4g85QuCvJEaRWV2rqoAmYAWthPzmNYhMdQCMXSn6APC", "swappedUsdtAmount": 5.573395, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "2S1N7uPzGzAcBmT9wanKCBV7kXs31KCPkELLkULMyB4UzQEw6Xem7ftcQBT5cbuwUUASQ9HCviRPyQkU4tzDdbNx", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "49onyi4DvaYjUyQSizzfvsPxViUN2CX628Q9D6uUxpDFrLEX4N12dpqTekoSwVp6dP8HJieAPXrfWuM7pPhBMDRZ"}	0x77a298ac8a7941c76ab79f0251b1b7abe55077feaf466315b825f40d02bff0a9	6181574966	\N	\N	\N	2026-09-02 18:39:29.076059+00	2026-09-02 19:56:05.555879+00	MAINNET	POLKADOT	\N
a0d08c64-f937-484b-8174-1f4a1cc2dafe	DEPOSIT	EXPIRED	\N	USDC	5000000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"fees": [], "amount": "5000000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-13T16:23:12.174243593+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN61051219054105000000.00530336062300119QR2615QB7ZLXR3EHFSU0703A0163047A72", "reference": "SNAP-20260913142312", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "5000000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMzE0MjMxMiIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzMTgzOTIzMDUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTMwOTM5MiwiZXhwIjoxNzg5MzE4MzkyfQ.VcoM3k6pL_VarqDzWppsAzDmxNFIDYJmN53MaR2vS3Y", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMzE0MjMxMiIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzMTgzOTIzMDUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTMwOTM5MiwiZXhwIjoxNzg5MzE4MzkyfQ.VcoM3k6pL_VarqDzWppsAzDmxNFIDYJmN53MaR2vS3Y", "expiredDate": "2026-09-13T16:53:12.305Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR2615QB7ZLXR3EHFSU", "referenceNo": "D1180826Q3IOSCA08QBAPZY", "customerName": "IGEDEEKALAKSMANAPUTRA", "paymentMethod": "qris", "idrxMintOrderId": "20260913142312", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "DUpJJRfME1uGCKa1GAvvSRXt2UWstcfK5ioBGbgz4Wb"}	\N	\N	\N	\N	\N	2026-09-13 14:23:12.16912+00	2026-09-13 14:30:57.592511+00	MAINNET	SOLANA	\N
80602f7b-b651-4b59-8fe8-835022a8275e	DEPOSIT	COMPLETED	6.39	DOT	100000	12BNNy4BQu8tojSbj8WWh4BTi8rayQPm5YteoebxuPPWDQb6	{"fees": [], "amount": "100000", "method": "IDRX", "cexTxId": "6181601674", "channelId": "QR", "expiresAt": "2026-09-02T22:17:52.092726859+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409100000.00530336062300119QR2657BZK8UQQC34GC20703A016304E462", "reference": "SNAP-20260902201752", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "100000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIwMTc1MiIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzODkyNzI2MjIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM4MDI3MiwiZXhwIjoxNzg4Mzg5MjcyfQ.iQv3E87X4p5sMZvB_S5MYeWvaxuB7Rdk_kWNTxM2Rc0", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIwMTc1MiIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzODkyNzI2MjIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM4MDI3MiwiZXhwIjoxNzg4Mzg5MjcyfQ.iQv3E87X4p5sMZvB_S5MYeWvaxuB7Rdk_kWNTxM2Rc0", "expiredDate": "2026-09-02T22:47:52.622Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR2657BZK8UQQC34GC2", "referenceNo": "D1180826VFSRR4TO1B7VVCS", "sweepTxHash": "rGbDRpupm2zV1zmDQJe5zNFKyb8FuigHBYJSKCHjJa9QvUvWB5BoKogXFC2ZM9TNhrhe4ntYDMgHrDgPno45XTX", "mintedAmount": 99300.0, "depositTxHash": "31eNCZJ1MGa4u9aNeQin6dzFrZP41nTYxFaMoxqxW3iNMiEEjokuA2xKFvCyWQ4LFfspdKagfn5ys1wbj67GN79Z", "paymentMethod": "qris", "swappedAmount": 5.629885999999999, "idrxMintOrderId": "20260902201752", "jupiterSwapTxHash": "xPzczcmPQGvZgmaEiRR2BdHg9nuWPjWpoujP5g9bTZq1nACPwz6PTu6JXnyNMM49MbTaNMSN6Ez7biYANM7Kz3S", "swappedUsdtAmount": 5.575155, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "4D5iona25MFoJdBW7dCzjapUMhjLazYhb2DhgxceNUfWPGgYGqcZWikSe89rkhaWBqdPpoixxpDHELVRqia85nWz", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "3j2kBPJ3mg9kUszmd2bnP4Wg3eH6vD7swA8C43sY2pRvMwAxsyT3jPEhQXkodWbRZKkfRTNrozMKtDfBkGGPwzCT"}	0x828e3eb4435bd2058a1edea6c4712edae107741a27f222c0ace4de925991e254	6181601674	\N	\N	\N	2026-09-02 20:17:52.090504+00	2026-09-02 20:26:38.907049+00	MAINNET	POLKADOT	\N
da7514cc-06c0-40f0-be29-125bfb623341	DEPOSIT	EXPIRED	\N	USDC	5000000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "5003000", "method": "IDRX", "vaNumber": "91070040913143127", "channelId": "INA", "expiresAt": "2026-09-13T16:31:26.878810025+00:00", "reference": "SNAP-20260913143127", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "5000000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMzE0MzEyNyIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzMTg4ODcwNzgsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTMwOTg4NywiZXhwIjoxNzg5MzE4ODg3fQ.LasxgitwS8GmVI1O3EKFCT3hI0yShcWbgGDo9vjPB14", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxMzE0MzEyNyIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzMTg4ODcwNzgsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTMwOTg4NywiZXhwIjoxNzg5MzE4ODg3fQ.LasxgitwS8GmVI1O3EKFCT3hI0yShcWbgGDo9vjPB14", "expiredDate": "2026-09-13T17:01:27.078Z", "customerName": "IGEDEEKALAKSMANAPUTRA", "paymentMethod": "va", "idrxMintOrderId": "20260913143127", "virtualAccountNo": "91070040913143127", "virtualAccountName": "IGEDEEKALAKSMANAPUTR", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "DUpJJRfME1uGCKa1GAvvSRXt2UWstcfK5ioBGbgz4Wb"}	\N	\N	\N	\N	\N	2026-09-13 14:31:26.877068+00	2026-09-13 14:47:40.70933+00	MAINNET	SOLANA	\N
ea09a5b8-6c31-4d09-9a5f-8cc1267e6f71	DEPOSIT	EXPIRED	\N	USDC	5000000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "5003000", "method": "IDRX", "vaNumber": "91070040914053223", "channelId": "INA", "expiresAt": "2026-09-14T07:32:23.743208716+00:00", "reference": "SNAP-20260914053223", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "5000000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA1MzIyMyIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzNzI5NDM5MjMsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTM2Mzk0MywiZXhwIjoxNzg5MzcyOTQzfQ.LYK_m8vC3azjN5gIqg6rCPEBOSl8NIj1lVyo6Bq-zGA", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA1MzIyMyIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzNzI5NDM5MjMsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTM2Mzk0MywiZXhwIjoxNzg5MzcyOTQzfQ.LYK_m8vC3azjN5gIqg6rCPEBOSl8NIj1lVyo6Bq-zGA", "expiredDate": "2026-09-14T08:02:23.923Z", "customerName": "IGEDEEKALAKSMANAPUTRA", "paymentMethod": "va", "idrxMintOrderId": "20260914053223", "virtualAccountNo": "91070040914053223", "virtualAccountName": "IGEDEEKALAKSMANAPUTR", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "DUpJJRfME1uGCKa1GAvvSRXt2UWstcfK5ioBGbgz4Wb"}	\N	\N	\N	\N	\N	2026-09-14 05:32:23.738102+00	2026-09-14 05:44:41.295836+00	MAINNET	SOLANA	\N
09a77443-6988-4bd9-9854-28142a9c79e5	WITHDRAWAL	COMPLETED	12.8357541644	DOT	182509	12BNNy4BQu8tojSbj8WWh4BTi8rayQPm5YteoebxuPPWDQb6	{"method": "501", "bankCode": "501", "bankName": "BANK BLU DIGITAL BCA", "bankAccount": "005250920570", "soldUsdcQty": 11.05084, "accountNumber": "005250920570", "bankAccountName": "pasha renaisan", "paradappAddress": "16htqbbaLEwMYWrW38jrtMypNUfNiiVtwSwzyyeV9RzsoZaK", "solanaBurnTxHash": "4gBbnwyWuheGsrxWyPMNFLboqnwtChoiXXWQt2HWpKxdp5nuLE2rDPH8MCxQS7e3P6vZNosy8YTWAuy7Q8GqNStM", "withdrawnUsdcQty": 10.7403417, "accountHolderName": "pasha renaisan", "binanceWithdrawId": "ef0c2b514c794fcf93040eadd20bd1fe", "jupiterSwapTxHash": "4q2ApyRRfWgtznsbNhFqroK4aTppEDv4ZiSqf3X6SVxCNWkjrVayN3WRo4jpLbdfD1J65mBL2yUiWZhVLXQAXS4t", "swappedIdrxAmount": 187509.39, "idrxTransferTxHash": "5ckBmXmxJKgUrzZcXvJvmtnrnaDe9TiaFv6ervtbgu3e6q1WjWkiDKMTMwaj1Suas3G8xMf7jKjiMnDGCGmf2hqy", "platformProfitUsdc": 0.0644420502, "idrxRedeemRequestId": "18203", "solanaBurnBlockhash": "5RiBEuMWAmcNUeLotDuY9KMg2FNYbgYgebWwsRqAxFX4", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "3NYsm397ofLBT5MAs8oJAdm2muVwwjXrssSuxWFHbhC3", "binanceWithdrawTxHash": "2iGv6JJq2SBv1yXuYGiMFAJiKte2YvSKaeqiuxJu41uM7nBU5MBoChdJt987pTMubGFhyxruTJaGe26QsPiwDJQ9", "idrxTransferBlockhash": "7T4qsxWvbqhY4GsDDoXUKAoV9uEupvzbdNX1N1j6523R", "operatorToBinanceTxHash": "0xfc3aa85d02b6ae0482d255dc80c9a8181ff03e15f2a88af48c6bd4fc98af4bbf"}	0x8cab7fc8f66b1ff2a92b0aabcd8e76f0755ef2078d53a52ede1d7dfbdbc5589a	484031625	\N	\N	\N	2026-09-02 20:32:34.76441+00	2026-09-02 20:46:38.935688+00	MAINNET	POLKADOT	\N
d3fcac88-6f48-421b-9c12-7e2e55406ecc	DEPOSIT	EXPIRED	\N	USDC	22000	J576U6Fazq9j4fGx3x6y5j4vUaZJup9rarnbmY1nR8q7	{"fees": [], "amount": "22000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-14T08:48:28.134456366+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540822000.00530336062300119QR26QZ68MBEJU5I511P0703A0163041C04", "reference": "SNAP-20260914064828", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA2NDgyOCIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5Mzc3NTA4MzExLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzNjg1MDgsImV4cCI6MTc4OTM3NzUwOH0.dK-H1h7zrWYT3VhXdN9WHOq2EBLYSvGbY9bDgCbOfMo", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA2NDgyOCIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5Mzc3NTA4MzExLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzNjg1MDgsImV4cCI6MTc4OTM3NzUwOH0.dK-H1h7zrWYT3VhXdN9WHOq2EBLYSvGbY9bDgCbOfMo", "expiredDate": "2026-09-14T09:18:28.311Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26QZ68MBEJU5I511P", "referenceNo": "D11808265246RLPHZUODITL", "customerName": "PASHA RENAISAN", "paymentMethod": "qris", "idrxMintOrderId": "20260914064828", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	\N	\N	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	\N	\N	2026-09-14 06:48:28.128566+00	2026-09-14 06:48:36.688679+00	MAINNET	SOLANA	\N
02599a2e-ec99-4184-9986-7113c88f1af9	DEPOSIT	EXPIRED	\N	USDC	5000000	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "5003000", "method": "IDRX", "vaNumber": "91070040914085818", "channelId": "INA", "expiresAt": "2026-09-14T10:58:18.837775966+00:00", "reference": "SNAP-20260914085818", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "5000000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA4NTgxOCIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzODUyOTg5NjQsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTM3NjI5OCwiZXhwIjoxNzg5Mzg1Mjk4fQ.i5HQpGoh4RYuQFhDcJ0lD-g2N-WEnin1D7ll7_8WCxc", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzMwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA4NTgxOCIsInBheW1lbnRBbW91bnQiOjUwMDAwMDAsInRvQmVNaW50ZWQiOiI1MDAwMDAwIiwiY3VycmVuY3kiOiJJRFIiLCJjdXN0b21lck5hbWUiOiJJR0VERUVLQUxBS1NNQU5BUFVUUkEiLCJjdXN0b21lckVtYWlsIjoiZ2VkZWVrYXB1dHJhMzFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODkzODUyOTg5NjQsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4OTM3NjI5OCwiZXhwIjoxNzg5Mzg1Mjk4fQ.i5HQpGoh4RYuQFhDcJ0lD-g2N-WEnin1D7ll7_8WCxc", "expiredDate": "2026-09-14T11:28:18.964Z", "customerName": "IGEDEEKALAKSMANAPUTRA", "paymentMethod": "va", "idrxMintOrderId": "20260914085818", "virtualAccountNo": "91070040914085818", "virtualAccountName": "IGEDEEKALAKSMANAPUTR", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "DUpJJRfME1uGCKa1GAvvSRXt2UWstcfK5ioBGbgz4Wb"}	\N	\N	\N	\N	\N	2026-09-14 08:58:18.828587+00	2026-09-14 11:28:23.520427+00	MAINNET	SOLANA	\N
ce85df62-3d4c-413c-852b-38d8b62371b9	DEPOSIT	COMPLETED	6.41	DOT	100000	12BNNy4BQu8tojSbj8WWh4BTi8rayQPm5YteoebxuPPWDQb6	{"fees": [], "amount": "100000", "method": "IDRX", "cexTxId": "6181637177", "channelId": "QR", "expiresAt": "2026-09-02T23:55:14.414101547+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409100000.00530336062300119QR26PVSRLN7XRFAPRIZ0703A0163044CA3", "reference": "SNAP-20260902215514", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "100000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIxNTUxNCIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzOTUxMTQ5MjUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM4NjExNCwiZXhwIjoxNzg4Mzk1MTE0fQ.74Ay9LXdy_26BA1H7rD7EThq3fMMWz186_AMlkkGndE", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIxNTUxNCIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzOTUxMTQ5MjUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM4NjExNCwiZXhwIjoxNzg4Mzk1MTE0fQ.74Ay9LXdy_26BA1H7rD7EThq3fMMWz186_AMlkkGndE", "expiredDate": "2026-09-03T00:25:14.925Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26PVSRLN7XRFAPRIZ", "referenceNo": "D11808266F42I8MPQJROP3K", "sweepTxHash": "2GzTp38FDRJ9xCPTJKrQioycdZQALLa3Ty8rp3fHfXHTgDmjifyQvxt7LTgYT6geycd2PykcKX7ZSf8NDufVxoa3", "mintedAmount": 99300.0, "depositTxHash": "jYyVGqp5X47XBFhhSb3FXwLpHgsmaKFNcMcF1RRV1KXtxp2FBDpSucBvcmCorY6iDkryyJaEVwQXHNC4H45mers", "paymentMethod": "qris", "swappedAmount": 5.630033999999998, "idrxMintOrderId": "20260902215514", "jupiterSwapTxHash": "3QfCdYUDRuqy6AamnPm6dFemm98ZJVLEkwgf2KWFyuCtfHjuh1yk7hnd1jfR8tK9xk4kXLyVtS7S3NFTfWncWhwH", "swappedUsdtAmount": 5.5724469999999995, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "oYLCmufmu78F1z2oRRWXvHUnaHEYXPVHYGfRrZtWy1TUoSsdbywZ3WhUj9SNzjbATVuX6VqAxq8RhyiiySLeuRs", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "31vqrHkUqtrK3j8ruRw4zHcpqx82f2LTbYDVNKZFXVPsj8k5PNgf35mBbyNYLePuhWb5bJGo7vDWao52K66WhqXD"}	0x08d84ef16e0b9e290bf4af9c7fb5125614a850bdb248fb73f3380789c6f474e1	6181637177	\N	\N	\N	2026-09-02 21:55:14.412098+00	2026-09-02 22:04:24.202927+00	MAINNET	POLKADOT	\N
90ac7cf3-ac9a-47f6-9a23-f44e6c91b428	DEPOSIT	EXPIRED	\N	USDC	22000	87JyDsMpP9TmajXRTtC7MEMKF2tf2hFvVJGto9qmzQMt	{"fees": [], "amount": "22000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-14T11:01:42.853546853+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540822000.00530336062300119QR263PF2GMJDB6DLGGI0703A0163045005", "reference": "SNAP-20260914090142", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA5MDE0MiIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5Mzg1NTAyOTc1LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzNzY1MDIsImV4cCI6MTc4OTM4NTUwMn0.qIfNhlkP0CmHOm7hFNAzEK2HqFzuKYj154dY8NiQZv8", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDA5MDE0MiIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5Mzg1NTAyOTc1LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzNzY1MDIsImV4cCI6MTc4OTM4NTUwMn0.qIfNhlkP0CmHOm7hFNAzEK2HqFzuKYj154dY8NiQZv8", "expiredDate": "2026-09-14T11:31:42.975Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR263PF2GMJDB6DLGGI", "referenceNo": "D1180826C1ARLTQO8WUG13M", "customerName": "PASHA RENAISAN", "paymentMethod": "qris", "idrxMintOrderId": "20260914090142", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	\N	\N	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	\N	\N	2026-09-14 09:01:42.850738+00	2026-09-14 11:31:43.651722+00	MAINNET	SOLANA	\N
709d05c2-6238-4877-8c14-f07472b89ac4	DEPOSIT	COMPLETED	0.12375	SOL	25000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-19T06:41:37.898375062+00:00", "expiryPeriodMinutes": 120}	36MQ3rEtZAShaogUrRp1c9itvHqDVRBF44EMEc3hPBT8giDqgsh6bodtv3evxrduEKuvYdvUg1hD3HBRsf1aqxrc	\N	\N	\N	\N	2026-08-19 04:41:37.89541+00	2026-08-19 04:41:41.838416+00	TESTNET	SOLANA	\N
2e2fee0b-5813-4d73-b192-95a92ce746ed	DEPOSIT	COMPLETED	1.233549	USDC	22000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-28T14:52:38.805951923+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826K6LG5SOMVEGT8FU", "sweepTxHash": "41hsDPbSE6Ry1YxSLniq97L3GdAvi2GgrXjEz1LKkysggzyQeebKi7vPkrckqbVc975bkwiURkkXEZ8pLMqx7LVg", "mintedAmount": 22000.0, "payoutTxHash": "4ZpMgNFnHgXeGrpEaPBT8N1aBJt4c8cazknZzsJLtB4UGnAyfcBM84bqVLSFsPA58J6qorDxKPqCuR93C2URkopD", "depositTxHash": "2Q1bJes87aSy52NvGXoCymJXhFMEzh7PEA3RFDXMUra4tDRJcG95KSENAq7aVpDiRiE5qK9XefQLRjcJU1xrghsA", "swappedAmount": 1.2460119999999995, "preSwapBalance": 5.043357, "idrxMintOrderId": "20260828125238", "jupiterSwapTxHash": "53cY1gQDsVAXt928LJTNmqxHokfx7axmcxjGM9fFAfj4LqRKM6DeQvzro2gb4GsgEQRY5KGgTzrAEB5yp7XPjswK", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	4ZpMgNFnHgXeGrpEaPBT8N1aBJt4c8cazknZzsJLtB4UGnAyfcBM84bqVLSFsPA58J6qorDxKPqCuR93C2URkopD	\N	\N	\N	\N	2026-08-28 12:52:38.804087+00	2026-08-28 12:55:56.959923+00	MAINNET	SOLANA	\N
ff194236-08ed-41ae-b1d9-865e4f14fa8f	DEPOSIT	COMPLETED	0.00010857	BTC	186000	bc1qjjc4gv80kqjm5xc0qnk9yhe3mhtee2avehau33	{"method": "IDRX", "cexTxId": "65869881940", "expiresAt": "2026-08-26T14:05:57.920853953+00:00", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826XME81ZF8HA26KJB", "sweepTxHash": "4t8NJ6csPjqnMTcXsDYg3xJcHeCGMR7m6LvY2yTirSH3QyjrjynVL1ALspxpVHyLQbw4uzz6k5RUMf3hLi9KCHYm", "mintedAmount": 186000.0, "depositTxHash": "ABKRMy83t3Q6sn5qQeFPhhLxr5HVdu2BwNkNUFLqyhTJbzMM7pZ5n4MaNywf2j4Wz4KpxDrn3csrR3jPW8GduxE", "swappedAmount": 10.533233, "preSwapBalance": 0.0, "idrxMintOrderId": "20260826120558", "jupiterSwapTxHash": "4zxpJ9tSEZqJitEyevH1jcggxcBw6uvSz2rds5jRqBuhV4e4JYAaxF6mVcgiwzBMtnfp8j2jN7s2Ce2s5RSTpG2Q", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "wbGBbztCyrRnhMjah9zJEJuC8Vha4yPgyCH8VM9mvVXQCy1xLdwxUzQPjZFxPq3zWW74ZLgqAZ1ry5XhUnigEWY", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	a6e596e02f7952cb3d714f4a53bc267b91b30b0af9cbd7ceba6626be0b0db122	65869881940	\N	\N	\N	2026-08-26 12:05:57.918608+00	2026-08-26 12:20:31.669061+00	MAINNET	BITCOIN	\N
20c0dce9-d8a5-4144-a805-fe0ee3250fb4	DEPOSIT	COMPLETED	1.89503	USDC	34000	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"fees": [], "amount": "34000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-03T00:12:00.864851572+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540834000.00530336062300119QR26MFW74F2N4HWO02T0703A016304E690", "reference": "SNAP-20260902221201", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "34000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIyMTIwMSIsInBheW1lbnRBbW91bnQiOjM0MDAwLCJ0b0JlTWludGVkIjoiMzQwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg4Mzk2MTIxMjU2LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODgzODcxMjEsImV4cCI6MTc4ODM5NjEyMX0.potSl6E8Z9-sGFzoZCZauD64evVpV2hdjbpDIFo8HX0", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjIyMTIwMSIsInBheW1lbnRBbW91bnQiOjM0MDAwLCJ0b0JlTWludGVkIjoiMzQwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg4Mzk2MTIxMjU2LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODgzODcxMjEsImV4cCI6MTc4ODM5NjEyMX0.potSl6E8Z9-sGFzoZCZauD64evVpV2hdjbpDIFo8HX0", "expiredDate": "2026-09-03T00:42:01.256Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26MFW74F2N4HWO02T", "referenceNo": "D1180826GBZS7BA4EZNT6P8", "sweepTxHash": "3rQUdBkUqPpzjGCEniLDkrgY7VS1ifG35wM3pgsTibFmC4WbsEcLYPzMDR2Mn73fWDnc11Km4orfHZGKzFueSznW", "mintedAmount": 33762.0, "payoutTxHash": "49LmqYYd1HbVzwdKE36stv4sEguFS45CNNxLbrR2V7QtUA3kzeeSAC4jpBxCmwBgriEgv8iyCHdaDEBgjW6NNrAi", "depositTxHash": "4dBEznaCHquNQjJKQexUZD6aj97YczxjapjYstjbzNC8kQ7LdD8FWkURvgDR9uX5bwshYhNcwAi65Ccx3KUQ9Umw", "paymentMethod": "qris", "swappedAmount": 1.9141729999999981, "idrxMintOrderId": "20260902221201", "payoutBlockhash": "FYf7nznzeNPQ8shQrDuuBdp2r91R5x1JgTemjMqj9mri", "jupiterSwapTxHash": "PJEqP1q8SYqRK7PUxKhAijfaHiofwRg84BLCZXovt3KhxCTndZNdUM6abWMgiDTUWHKmoVzw7LBCvNDWzc3b6nH", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	49LmqYYd1HbVzwdKE36stv4sEguFS45CNNxLbrR2V7QtUA3kzeeSAC4jpBxCmwBgriEgv8iyCHdaDEBgjW6NNrAi	\N	\N	\N	\N	2026-09-02 22:12:00.862649+00	2026-09-03 00:01:21.792894+00	MAINNET	SOLANA	\N
27be8733-b4e8-4a4c-bf1d-218da4ba6af8	DEPOSIT	COMPLETED	0.00010857	BTC	183321	bc1qclfskzr0snpeytn29hvepz8jflre7tqkhp0sg5	{"method": "IDRX", "cexTxId": "65987817461", "expiresAt": "2026-08-28T18:19:40.243285982+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D11808260BLPX2H5KOIQXSK", "sweepTxHash": "5sEZUR6NxqfN9Xekuvi54N29DWHxq3WD76WgAXaAkcv3kCo5qgNwzRZTAaMRUWtse9XLbuxVFAgkunrKSpcShYyC", "mintedAmount": 183321.0, "depositTxHash": "3fn3XW5brDbE9pVxP714BVhSG6R94YzECGRe2MyAtziiSuYEjMHAnSKzvCt1MNULVxn549DfLm8PBsyqZF79vchC", "swappedAmount": 10.382898, "preSwapBalance": 10.533124, "idrxMintOrderId": "20260828161940", "jupiterSwapTxHash": "4c9LEkxPXBtuj4uUsX9wJ5mQpus1GA3jmPMUq2YNt88HmavhKfdHY4zKydK69cNdvjxBSzJK3e337gH7S58dnQtQ", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "3EdrM1brhwkve4yhmrSaCCn4Hq5TtyG2siE8sGzg895axEjgbgbduRSzY29nKSrQKcBsSC9VHRcEk5cfphon4j3W", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	ebb5210cbd9477b7cdc64a22599a38ecf988f163666f9bd332029a0b8555cc7a	65987817461	\N	\N	\N	2026-08-28 16:19:40.241804+00	2026-08-28 17:08:56.835525+00	MAINNET	BITCOIN	\N
b2bf0136-02b0-4112-82ad-0421382d5bdd	DEPOSIT	COMPLETED	1.233866	USDC	22000	4zzdvjNgVwSPxiYf8nC9bVRX1GmkDSz3GoGF6j7uM4y4	{"fees": [], "amount": "22000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-14T15:55:32.949379725+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540822000.00530336062300119QR2637D15HBVOCBOAVH0703A016304CBD3", "reference": "SNAP-20260914135533", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzkwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDEzNTUzMyIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IktFTFdJTiIsImN1c3RvbWVyRW1haWwiOiJrZWx3aW53aXRoc2hlbisxQGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5NDAzMTMzMTQwLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzOTQxMzMsImV4cCI6MTc4OTQwMzEzM30.wnXUH9VTjRqo84XU23FP4DTjj_KhLyHq-d02ps7valc", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NzkwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNDEzNTUzMyIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IktFTFdJTiIsImN1c3RvbWVyRW1haWwiOiJrZWx3aW53aXRoc2hlbisxQGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5NDAzMTMzMTQwLCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODkzOTQxMzMsImV4cCI6MTc4OTQwMzEzM30.wnXUH9VTjRqo84XU23FP4DTjj_KhLyHq-d02ps7valc", "expiredDate": "2026-09-14T16:25:33.140Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR2637D15HBVOCBOAVH", "referenceNo": "D11808260IO7KG07YCMHLYA", "sweepTxHash": "5Fc8XLEd79fcD15XSAi2LdjyNGvYVQ1iUHn2AWydFXMJi8ahKqLf8N3CugwoKhsenuisWrnyhwaZdkb29UHGSze3", "customerName": "KELWIN", "mintedAmount": 21846.0, "payoutTxHash": "XVWsGoE4JBs3cnNmvRe9ZJsqSpRT5y3mWvLdKqNu9aDg8mtydhRkt1CCthBR6md9vHTQod9j7WNnmuLyS8Wjbrf", "depositTxHash": "5C77dYX1LVyRaQvzVbhU9cAfcHYwdB6jFdTBnrAtFNugpCHbXvSYycDqwTqCS2irEZKxaAkVihMHjCe7UL3RpCTy", "paymentMethod": "qris", "swappedAmount": 1.2463309999999996, "idrxMintOrderId": "20260914135533", "payoutBlockhash": "DXwNH7yqeMnsiiGgDA9ABYWFJLB63YLcS5WxPdEHs48x", "jupiterSwapTxHash": "5R3LES1Utgis5UMo3YZo3cS1XUKrnhWwCTHa6npQZam1ZThDvBDLdD2K6BuQeA2EeSARmWcSLWGG3j2nvVnUxYHc", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "5Euxxr4KLLMXLC6gNCpyEv3xhZLnpQAzihHp5R6PaDcw"}	XVWsGoE4JBs3cnNmvRe9ZJsqSpRT5y3mWvLdKqNu9aDg8mtydhRkt1CCthBR6md9vHTQod9j7WNnmuLyS8Wjbrf	\N	\N	\N	\N	2026-09-14 13:55:32.944362+00	2026-09-14 13:57:56.944838+00	MAINNET	SOLANA	\N
cd0b56a7-7d3c-43df-a357-e2ea74f6b9d3	DEPOSIT	COMPLETED	0.00010857	BTC	185000	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "IDRX", "cexTxId": "65990614344", "expiresAt": "2026-08-28T19:47:06.037024580+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D11808266KT81DYYH6M0K7C", "sweepTxHash": "2gV4GmtL2fPfaXmfbm7Ueq84kftWSG8b9e3fEWCkLzy4XYSqzgLDUm5bGW6ut5e3DWTTdmJeJAnobawJYqEAFypZ", "mintedAmount": 185000.0, "depositTxHash": "5ecJkWSfdokYCbFf8oVbNFuYoXLD75ssKzPYkdep8p3CQaMr4i8vdcrEmmb4qcfM3o8pGwBuPw9aDCrWDS2Fh8Jx", "swappedAmount": 10.477182, "preSwapBalance": 0.0, "idrxMintOrderId": "20260828174706", "jupiterSwapTxHash": "24S2t8YJ4cfCD6hZABgQWxqQLjBwwqBm4PwkRpk1PwgieYTXLzVG9BqwSSHW81kWuireYF8UhkEHiCGhWV5ihLRb", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "5zZCHzKtuawxHBDoc4rraQWgKu9PoWKGbLQxYhyWrcby8FqaDNhrNA8qB2k7FK23sjz2ehStwQCRiipJUpHx5ZKe", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	0f2b5860121777dc38ae223ffde5173e7062d44df0a3ea776b20ee259ef2608c	65990614344	\N	\N	\N	2026-08-28 17:47:06.033571+00	2026-08-28 18:07:08.546708+00	MAINNET	BITCOIN	\N
09384290-c88b-405c-bba8-5bb2e5ce12b2	DEPOSIT	COMPLETED	56.032242	USDC	1000000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-29T11:31:53.969093833+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826X27DC3AT7Y8JW86", "sweepTxHash": "6QHrciAFaVKcLVr1VrRAJzVt2hHwjcFkuLoYNHo2qYvC2aJxypwXTWEvA4RWFtar4rk9Y9y2yvrx6tyv6vVytsZ", "mintedAmount": 1000000.0, "payoutTxHash": "5Qkmga3ZKjGgWUswLob3L3mjfGgk71De7FGmDhtZJUyoGW4mwEmuhVQBxyPWy4ZbSjeEMDAhv8r4dfCjz9Hq2zZb", "depositTxHash": "6UiXmQi3EB6iW1r8uXp5USF2zPd9g5yQebL4rrpzwSL1sEMYiSKi3Zjae56DdQaq2kjjT94x2gkWPPMGd7A3PyS", "swappedAmount": 56.598226999999994, "preSwapBalance": 16.402787, "idrxMintOrderId": "20260829093154", "jupiterSwapTxHash": "53ebULFh1V7BC9HFwpdX4TC939Pt3o6m15u6sCj6hW7uyHPC8ocZV8v1ceWyAHGANKkFZ6fFzdTH367CeTocY9Ya", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	5Qkmga3ZKjGgWUswLob3L3mjfGgk71De7FGmDhtZJUyoGW4mwEmuhVQBxyPWy4ZbSjeEMDAhv8r4dfCjz9Hq2zZb	\N	\N	\N	\N	2026-08-29 09:31:53.956654+00	2026-08-30 05:49:19.717267+00	MAINNET	SOLANA	\N
9ecfe551-79c2-4a8c-bd96-5d80fa8a04bd	WITHDRAWAL	COMPLETED	65.709756	USDC	1137160	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081239990810", "accountNumber": "081239990810", "bankAccountName": "pasha renaisan", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "4hz8arawbtkRBiA6ArKsbp3Ex2pit6Cgqfcvz1GTsCXiNBp4UmueAg6ZZHAvr7KRNr9Qm89X6xqX5ukJfEcmGc9K", "accountHolderName": "pasha renaisan", "jupiterSwapTxHash": "QDeG4ieghjqWepNXBuDKDEtvG8XReqfXcK9djLPJtmmYh38cW3E2v3foMy438gf6735ShbrQj13t9ufdhftGPjf", "swappedIdrxAmount": 1142160.74, "idrxTransferTxHash": "5h9va1oDbUvZcwHLP7mi3iVdrgnsvNkjPEugYYu4umxkwg8GqMBdXGj14J4pyxPXGzhK9c6pYx49iUuTyH4qLBtz", "idrxRedeemRequestId": "18465", "solanaBurnBlockhash": "BUPJxCUP4wt8h38SoT7JafLa85FTYezVGHEr3jxr28qB", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "8sqVroAjP6RMxLnUTaQ46FZhwPpNHSRQRfuz3dBXpP1F", "idrxTransferBlockhash": "561v2r782V99JhXhHAVw3sRPmSaMfs9Ro54CGaRpr37e"}	4kaownn95qQQ5mUnNuTdQjFbbaVCizqEzWeEDsHaYgNHQ9oYaSGXWWB8UDtszji7et9bZFZRGy8euEr3kkbkSsgE	\N	\N	\N	\N	2026-09-15 10:26:28.190552+00	2026-09-15 11:04:16.115985+00	MAINNET	SOLANA	\N
8cd6f939-828d-4fa3-93aa-f370d8bbba2e	WITHDRAWAL	COMPLETED	5.6	USDC	93400	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081239990810", "accountNumber": "081239990810", "bankAccountName": "GOPAY Pxxxx Rxxxxxxx", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "4DJ8FScyptmnFcdboPg7R2TpGeeviJaUgv1uQFRnQ7MiH5zSkuvLM3PpjGSpjNT18GHLdL1hqhtitHGbuTVEoZM6", "accountHolderName": "GOPAY Pxxxx Rxxxxxxx", "jupiterSwapTxHash": "W9Cvq7w1Mh1MKugr1Kh9mV4JFAGG5ojESVkr2KuLiMFom8dmpbhPvEH8sXmmdsnfXeEMY8fCcFGuQyHBqqc7ftA", "idrxTransferTxHash": "7o2quq7LFr6859H7YUTV7fRJYT69UaA9BGPZbQS6e9o65KAu5sA6prbZbVCXKwit9uTSSrhu4tTK3Fr4CHKv2Kh", "idrxRedeemRequestId": "17987", "idrxBankAccountAdded": true}	4MybPDLP3sK8cTQM3nDofpZGJ2b5ieqqCrdPg6bfecPgmgqRPbshz8MorekF1xqrvtnVoqSSoa9eUCbohxA6Yby	\N	\N	\N	\N	2026-08-25 03:50:23.411939+00	2026-08-25 03:57:43.548319+00	MAINNET	SOLANA	\N
b72823a2-db6b-40e9-b18d-e437c92ee1b6	WITHDRAWAL	COMPLETED	0.00036781	BTC	311121	bc1q7eu84v58kxj0r9u72vmjze7wlrnsdg5n79uv2r	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081239990810", "soldUsdcQty": 17.785027, "accountNumber": "081239990810", "bankAccountName": "pasha renaisan", "paradappAddress": "bc1q6e7he9rjfmr8fvy6439vnc3r57qfsupajdmfls", "solanaBurnTxHash": "5xmYV7kDNszhoEEeMhKe15eQLogQ4WANKVXz2fxMuibWcZka9CMj9TyPMkN3PRrPv2YVwewEgGqcsW1giPLUgfTk", "accountHolderName": "pasha renaisan", "binanceWithdrawId": "810d3e5a64964e048114614ccc5ea52c", "jupiterSwapTxHash": "26YZArLrwvbPmHDvgTHHgwpR5FanrAHvnsqxQmrtc8pYd6CDaCuDRZuxVHr3EoHusteP7bXxXS9zU98NdGrjcvPZ", "idrxTransferTxHash": "3GiWVGYKiugPuwsS8m3Sgsn8VP4iEmG8jm8CWh339JWY6wkRsRLyeHbv1r6DmqdWMxmdnBXpQcdZdGTUuReqv4Q3", "idrxRedeemRequestId": "17871", "idrxBankAccountAdded": true, "binanceWithdrawTxHash": "46nKM3Cry5nGb7iMoXnxjTpDSJbhhiyeLctHKAvELTCVGj3A9tTswm9ykWpPAwwYyb16WzmhiHwPqWT4FsjuKLt"}	8c1e8925a8714404d531ae54ae62d2bfa6b3baf70702dfde52a79ddce5ad1a2f	10073833543	\N	\N	\N	2026-08-19 18:18:51.020964+00	2026-08-23 04:30:03.570033+00	MAINNET	BITCOIN	\N
4140aeed-0a8e-49e4-b695-b18429d5a5d7	DEPOSIT	COMPLETED	1.230199	USDC	22000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-25T06:39:22.794715419+00:00", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D11808267FISIQR7F6LCTF0", "sweepTxHash": "5muKVbjUTcVL2dGSmEToqH2nz4Zw5PMi1WQbu7SuSY7d3RGxDtzSM6zH8pTY34MR9mUkbMo7Sx97T88qiKbChPMv", "mintedAmount": 22000.0, "payoutTxHash": "5zXTK4aEySkB7StpevfXU22mAbCkT2XjfCMy2edGJCX3SNYyeBDiF7VyC7tH1pRXdngyrH2gKfN1kpuakMNUSMm1", "depositTxHash": "3LNjEJqgZUtNN6fXxqkoAqzc6Z5Yqmi5qf9Qdt8EjP51pUpTe96ShaBTMhxM4rKnWCJg9PHKVjbDRBRHExC7dt8n", "swappedAmount": 1.2426270000000006, "preSwapBalance": 5.004306, "idrxMintOrderId": "20260825043923", "jupiterSwapTxHash": "2V5jooRVUhVUYbuJvDY3mVEoj2NGeCwMYqftLkwu5U95FaKH7y8Wf1Gzw6d5fjCbiiCsNyvExWnRMKkyxAffqybU", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	5zXTK4aEySkB7StpevfXU22mAbCkT2XjfCMy2edGJCX3SNYyeBDiF7VyC7tH1pRXdngyrH2gKfN1kpuakMNUSMm1	\N	\N	\N	\N	2026-08-25 04:39:22.791225+00	2026-08-25 04:48:47.070314+00	MAINNET	SOLANA	\N
4da48973-7553-46ff-8fcd-caecdf95921a	DEPOSIT	COMPLETED	0.00069207	BTC	1000000	bc1qkv4d63d0u7r8uz9tpthg3474393v3dxguxk7d5	{"method": "IDRX", "cexTxId": "66006196823", "expiresAt": "2026-08-29T11:37:30.967371370+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D118082656E7XU23EJZ6VJS", "sweepTxHash": "NSDVmHno2oxnWVT5AeSX7NEDdYxgwCFAR5BpdjgY2pGBtsCdZ3k52TBuUp9DGs72xaPskdE4W5BV41n4s23s5q4", "mintedAmount": 1000000.0, "depositTxHash": "2sX28mPjbBSitPhYgz5ZAbHyNhrWsCBu7QZV5sQNkyonY3TTLN1jSLHKM5F469a3yi6WPtizbSVbtWhZVBgupxXB", "swappedAmount": 56.614396, "preSwapBalance": 0.0, "idrxMintOrderId": "20260829093731", "jupiterSwapTxHash": "67CGFowdLMVzqcHRz2MXxS4EH39F1HnQWy1RN13az1xTyhyqGVMS8RSdHXUE1xDUXySpxKo5f9aBfhptTw2Lzv6s", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "3dKAU6L84DhbLw5LVi5aUdzBKfxYkytVvA91fpXeybhLfZ53Xs4JxAA9r2przfy86VYCMaQ6d71Xb92Ysn23dT8k", "kycOnboardingAddress": "4frRoyHGyyC59anawJkjk2Bwm1Buj1aM4aVCKZ79Lcpz"}	4d9acd186c84d04aaffe512f404ce4fb91c685fbacbf9b80ad1f42869512d51c	66006196823	\N	\N	\N	2026-08-29 09:37:30.963858+00	2026-08-29 09:50:09.219125+00	MAINNET	BITCOIN	\N
bb5042db-da6c-4585-ba85-34b84332b2ac	DEPOSIT	COMPLETED	1.400669	USDC	25000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-30T08:39:57.354329130+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826W3IVWHNYIFK1DOV", "sweepTxHash": "4xehVHnMjxWHkjk2EvZybHTyyWHeJ1bwJ5dYdYSrFYNFa7cCP1MaAgLLWE2bc2LG7N2Ypc1sqaDHj1E17iT3QNDj", "mintedAmount": 25000.0, "payoutTxHash": "2HxLHvFRbinaAs5RV6qounBpKZbXdDLGHugDu4V95mfqnZNmT8zh1No1JAA1K7EjHySEp9Gtnp6rLVgnxKuT6kEX", "depositTxHash": "3Wk3Bc41XZ4p78U4tMBtEUi3Pr5DczSS32ktJedoVzYKyL5Hd5RUbpb4MZH1K1St4B5b2Lt878CEFngcFUoEDH3h", "swappedAmount": 1.4148199999999989, "preSwapBalance": 16.968772, "idrxMintOrderId": "20260830063957", "payoutBlockhash": "2Na8LvFp3sRbRwrns1Q5YJqhKzQdtY56TxieQC6PoSrW", "jupiterSwapTxHash": "3aPijFM4TQe3aSiYvF5CtLKDyBRtCLEMzQiNL2QSdLtWqofdjQCsC2AN2PPxFtXwGpCfTgEe14VcA1KXbgw6VwUg", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	2HxLHvFRbinaAs5RV6qounBpKZbXdDLGHugDu4V95mfqnZNmT8zh1No1JAA1K7EjHySEp9Gtnp6rLVgnxKuT6kEX	\N	\N	\N	\N	2026-08-30 06:39:57.352976+00	2026-08-30 06:49:47.950314+00	MAINNET	SOLANA	\N
f2c28460-5e31-4658-8166-fa91a64b66ad	DEPOSIT	COMPLETED	0.00010857	BTC	185000	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "IDRX", "cexTxId": "66021648377", "expiresAt": "2026-08-30T08:48:29.596545383+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D11808267S1LCKH2UV6U5ZL", "sweepTxHash": "5kH3yUL2BdrZfDnokN9anAuCKHX9DRztKTkSaK372a5CAAZF4GsCxXjLzGnNrsBGSiEQVoaE7eKdgFXb3s4qa59Z", "mintedAmount": 185000.0, "depositTxHash": "45xti6TpLfJwRW8b3boNbbCqyQUHtYuTevpk3xwscYHkByAoXZxKLbzmqtiJGDzdHaCykyQ6891MWK6iqtusGYc8", "swappedAmount": 10.468912, "preSwapBalance": 0.0, "idrxMintOrderId": "20260830064829", "jupiterSwapTxHash": "4dmKTWJ2NGA1xGkzXomSd9wnZvJ38QM5YSvYAnwCBYRW1bNuChLP1G3hd2mNgzXosoaX12ztTvS41YUTbg4QNs8G", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "3VKNffxRKD6Byun41DuHwUQ71b1EQ8SDSRYkKcAsH28w9jmkgoRdrxt1ciBmnRroEVJVyuBq9Qf8t2WbBmc2wLup", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	3bda686b8df4c0849a92e536d1321bf390df44d149ebd3b0852d85c2806b1533	66021648377	\N	\N	\N	2026-08-30 06:48:29.593273+00	2026-08-30 06:54:20.588194+00	MAINNET	BITCOIN	\N
3ce8ded8-64e7-480e-9695-f4949136efcb	DEPOSIT	EXPIRED	\N	BTC	500000	bc1q7eu84v58kxj0r9u72vmjze7wlrnsdg5n79uv2r	{"fees": [], "amount": "500000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-15T17:59:19.902155314+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409500000.00530336062300119QR260AWDKRTRPWPMWDA0703A016304DC26", "reference": "SNAP-20260915155919", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "500000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2ODAzLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNTE1NTkxOSIsInBheW1lbnRBbW91bnQiOjUwMDAwMCwidG9CZU1pbnRlZCI6IjUwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoiY3JlYXRpdmVib3VudHl0ZWFtK2lkcnhfMTc4OTQ4Nzk1MEBnbWFpbC5jb20iLCJwcm9kdWN0RGV0YWlscyI6Ik1pbnRpbmcgSURSWCIsInJldHVyblVybCI6IiIsImV4cGlyZXNBdCI6MTc4OTQ5Njk2MDAyNCwiY2hhaW5JZCI6MiwiYnJhbmQiOiJwYXJ0bmVyIiwiaWF0IjoxNzg5NDg3OTYwLCJleHAiOjE3ODk0OTY5NjB9.Kv70ZVIcWzgyHzuoaB9Cs3Df1Tl-cJ8XILyJECW9Src", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2ODAzLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNTE1NTkxOSIsInBheW1lbnRBbW91bnQiOjUwMDAwMCwidG9CZU1pbnRlZCI6IjUwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoiY3JlYXRpdmVib3VudHl0ZWFtK2lkcnhfMTc4OTQ4Nzk1MEBnbWFpbC5jb20iLCJwcm9kdWN0RGV0YWlscyI6Ik1pbnRpbmcgSURSWCIsInJldHVyblVybCI6IiIsImV4cGlyZXNBdCI6MTc4OTQ5Njk2MDAyNCwiY2hhaW5JZCI6MiwiYnJhbmQiOiJwYXJ0bmVyIiwiaWF0IjoxNzg5NDg3OTYwLCJleHAiOjE3ODk0OTY5NjB9.Kv70ZVIcWzgyHzuoaB9Cs3Df1Tl-cJ8XILyJECW9Src", "expiredDate": "2026-09-15T18:29:20.024Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR260AWDKRTRPWPMWDA", "referenceNo": "D1180826EXX4LVR78XSDEMP", "customerName": "LORD BODIMIN", "paymentMethod": "qris", "idrxMintOrderId": "20260915155919", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "DD54engwg1BmZ92vN2U9YfLNqeshGkyGzoQS4isaSbPh"}	\N	\N	\N	\N	\N	2026-09-15 15:59:19.899465+00	2026-09-15 15:59:35.328609+00	MAINNET	BITCOIN	\N
c2b434ec-87ed-4d94-b5a9-a9424ad5a2a3	DEPOSIT	COMPLETED	1.232515	USDC	22000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-30T09:10:07.180222545+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826NJ2MTLI6HWBPHO7", "sweepTxHash": "4bU394csCT6wtxPk9Q9zpg8tX3KUHVXmBY2js38wYQQ46Fz94SVECzzyLtkMpgsSHbiGbcdBMKxRrftvHSvi2mpV", "mintedAmount": 22000.0, "payoutTxHash": "2dVGakhDrjg148a5sTNUfBRKHtNwbEwLZvoQPjyw5QZujv3a34UgkvB1FvJpowcLCXQxwwd7H7v3Gx4j7CM44pix", "depositTxHash": "4vFfa9YxyAsgqWouvU3FCRiTtmsVFUS7aPdKj2xqgpjX5Zi3Eoq28yuedoPj4iBgRppNawi5udxfL5f63SnKtrtc", "swappedAmount": 1.2449650000000005, "preSwapBalance": 16.982923, "idrxMintOrderId": "20260830071007", "payoutBlockhash": "5EQTskkGEFs4ono4riJozG3Uu4BfCsuyGVwscfsPW9sm", "jupiterSwapTxHash": "5r7vWVegjAbmx2a3yBGekLsxTm5n6vsdmCXe7j7MP4rJ3NSEm4VAvoH2tUcfNzY86CK8NwpMyY5cCBbCFkih1kTq", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	2dVGakhDrjg148a5sTNUfBRKHtNwbEwLZvoQPjyw5QZujv3a34UgkvB1FvJpowcLCXQxwwd7H7v3Gx4j7CM44pix	\N	\N	\N	\N	2026-08-30 07:10:07.17741+00	2026-08-30 07:13:23.187737+00	MAINNET	SOLANA	\N
ef381da5-02ba-470a-9d4a-a309cfeab3ca	DEPOSIT	COMPLETED	1.232506	USDC	22000	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"method": "IDRX", "expiresAt": "2026-08-30T09:40:38.365268186+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D11808268HQZRAHYI4Y8K06", "sweepTxHash": "3s4y2RSuDBJsutJS1kPYDdU9MxSAMYi2EKa7BwFjCcqmjR1Bqe3dH12CN72ijJBPcghZN6SFDUJ2sjQWf1FUBDBS", "mintedAmount": 22000.0, "payoutTxHash": "3wuqLe31MguhXRVPUqQiLEJRtEaTzdFW7uTwvZzB1Ams9Rd6qrqxQsMr1Yr8h3Ci1TJPCw7XApEFQE77S4TkEwAs", "depositTxHash": "4Ahu4Dj2xTY2PJxYJkHpL6nw4J7BbkpJALu8xNKbgxTkpMcjRc9gfXe2Kn6rxBVcGKJgJkN4hQbCDt2KiR5cNC9x", "swappedAmount": 1.2449569999999994, "preSwapBalance": 16.995373, "idrxMintOrderId": "20260830074038", "payoutBlockhash": "7f3emHSKEiVnGj5PzjQoSkGgM8yw3EdYYaRvpNvm8L5z", "jupiterSwapTxHash": "66E9agrkios1GkEruLrpVmGae7Cv7yRMW8kKahQgYV5DLUYYqVB9JrrEh7sBghKk8hsAMRFiK2MYKXHrCQD2vLQJ", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	3wuqLe31MguhXRVPUqQiLEJRtEaTzdFW7uTwvZzB1Ams9Rd6qrqxQsMr1Yr8h3Ci1TJPCw7XApEFQE77S4TkEwAs	\N	\N	\N	\N	2026-08-30 07:40:38.363201+00	2026-08-30 07:57:48.815079+00	MAINNET	SOLANA	\N
2faec213-99fb-40aa-a5e1-b760ce1a86d8	DEPOSIT	COMPLETED	0.00010857	BTC	185806	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "IDRX", "cexTxId": "66067725090", "expiresAt": "2026-08-31T13:17:43.594261682+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D118082646HZD581ZXL4NQ3", "sweepTxHash": "4PkqD8oDb2pFJKBu5pb4JdqrgL3U33wBjfygtjtvoF78CLe5e29enAQtuxcTwGm1MgoykAGnHeRLnhRQXfRjJ7VN", "mintedAmount": 185806.0, "depositTxHash": "EQabkVgdgbSrgfPqtwhDfQuvWLWwx5e7nyCDSz7w64kN6fQY7xGaa11NS7rxKzRcmDhk8HScmnpfXBJ1YDRiXxq", "swappedAmount": 10.537496, "preSwapBalance": 0.0, "idrxMintOrderId": "20260831111743", "jupiterSwapTxHash": "3iqQNsPueYKaRavJyyMxVGGC5Cv2PExaeGZtgnhzYLYv5iS5R7gSjQtGyWBJKFzYs2MJYvkyTEXT8ttz7FSHspGG", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "5p4xEuhzEQXCufcdEa3As6dfkkUX3mWHqitrLsrJX44QoynG9UP62c1dJSuRbwaDLRh4WRDLNU3vS8NptuKkW6dy", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	6f7d70892024080bfa6d26945f60e3e981d1cab392bb09cfea91fb6ff52a6390	66067725090	\N	\N	\N	2026-08-31 11:17:43.591578+00	2026-08-31 11:44:54.056392+00	MAINNET	BITCOIN	\N
43cae463-704c-4ad1-99d3-fe4a0e3252d0	DEPOSIT	COMPLETED	0.00010857	BTC	185000	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "IDRX", "cexTxId": "66070430315", "expiresAt": "2026-08-31T14:34:40.206624565+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://app-prod.duitku.com/redirect_checkout?reference=D1180826JG2KMBGDJI5T8S4", "sweepTxHash": "3kGCrMh2aEDXttrymQRWxUpcQwRAE37GwY6MG6XXCKgnDog4Am2V5jmBLsJi4VPq543HeDigwBWwpBuvSNh4wa9m", "mintedAmount": 185000.0, "depositTxHash": "4wJDgUv8nL4NCiJZrdgfGFRSrXe4rEfVBKXm6VgybGhrdcmRRezPcY7ZDdUrWjsCxHA6et1CPH4GA39wUQApDhS7", "swappedAmount": 10.491301, "preSwapBalance": 0.0, "idrxMintOrderId": "20260831123440", "jupiterSwapTxHash": "4k7uZEoZnZYX97An96sANp6VS3sFKpkPw15uWhtbfxicA1WwwEp44AXZvjyWvAXjheahobpq4E5Kef8ELUTr9KSE", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "3wp3W3g98fAkUWnB3tX3M5rMqCUaeQbRv5JvB2Jg5J8KdCjhFvsc1eaxKsTGqTBtx3kbuMvbVZJBsTXyEcjeSW1w", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1"}	d9f58c36dcf74839159d59ec1554c20f099f12c38a231f6c05893f7c48c3e0e5	66070430315	\N	\N	\N	2026-08-31 12:34:40.204213+00	2026-08-31 13:41:06.811572+00	MAINNET	BITCOIN	\N
c0a67eda-a38c-498b-8299-6ff43555cc17	DEPOSIT	EXPIRED	\N	USDC	22000	5TZy4gdeCQqUjPhqTANpZYeiVJnbXwhWyVjhoG553EbP	{"fees": [], "amount": "22000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-15T18:01:49.089555972+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN610512190540822000.00530336062300119QR26LEIZI1FPVNGWEGA0703A016304AFDF", "reference": "SNAP-20260915160149", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MjA2LCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNTE2MDE0OSIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IkJSQUxJTksuU1VXVU5HIEJBVEFOS0VOREFJIiwiY3VzdG9tZXJFbWFpbCI6ImtlbHdpbndpdGhzaGVuQGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5NDk3MTA5Mjg0LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODk0ODgxMDksImV4cCI6MTc4OTQ5NzEwOX0.717fI3DJ6__7SPUJmWMgPAQ9X9roBwwKAxdz1hP2V88", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MjA2LCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkxNTE2MDE0OSIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IkJSQUxJTksuU1VXVU5HIEJBVEFOS0VOREFJIiwiY3VzdG9tZXJFbWFpbCI6ImtlbHdpbndpdGhzaGVuQGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg5NDk3MTA5Mjg0LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODk0ODgxMDksImV4cCI6MTc4OTQ5NzEwOX0.717fI3DJ6__7SPUJmWMgPAQ9X9roBwwKAxdz1hP2V88", "expiredDate": "2026-09-15T18:31:49.284Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26LEIZI1FPVNGWEGA", "referenceNo": "D11808260BNDRUUC5O18ROH", "customerName": "BRALINK.SUWUNG BATANKENDAI", "paymentMethod": "qris", "idrxMintOrderId": "20260915160149", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6HXsMuH5WBSC5GeidSwDPTw5CEkA3bjHx5VPLYW6YwYQ"}	\N	\N	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	\N	\N	2026-09-15 16:01:49.086431+00	2026-09-15 18:31:51.462634+00	MAINNET	SOLANA	\N
57e8c38e-43a8-404e-bcd3-994536f2d2ed	DEPOSIT	COMPLETED	0.495	SOL	100000	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"method": "IDRX", "channelId": "INA", "expiresAt": "2026-09-05T12:47:52.584931377+00:00", "returnUrl": "https://paradapp.com/payment-return", "channelName": "Bank INA Virtual Account", "paymentMethod": "va", "expiryPeriodMinutes": 120}	3aZzTcNGjtsH58CPUwVXD8GWbqYGbHyfi8yHmTvyqtEGxXQgy6pKYVXDe1vdfg2o2D5M1MoXJutb4XGm7nrH8Puo	\N	\N	\N	\N	2026-09-05 10:47:52.578826+00	2026-09-05 10:47:57.787917+00	TESTNET	SOLANA	\N
770e3989-2112-484f-b709-0afb7293d2e0	DEPOSIT	COMPLETED	1.234734	USDC	22000	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"method": "IDRX", "expiresAt": "2026-08-31T23:51:28.028098580+00:00", "returnUrl": "https://paradapp.com/payment-return", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDgzMTIxNTEyOCIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiaHR0cHM6Ly9wYXJhZGFwcC5jb20vcGF5bWVudC1yZXR1cm4iLCJleHBpcmVzQXQiOjE3ODgyMjAyODg0MzUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIxMzA4OCwiZXhwIjoxNzg4MjIwMjg4fQ.o1i2_8VZnSAqubWzlZ7B26WYUBaKrlaqndcgXJKwvec", "sweepTxHash": "3GZHfRkauP3N4YeWYrr8xPWvxSCxGQyfSLDFpScPzLC3F3YvnnG1zKY1YeLTANExvv4R7uWCwoRkpsJY1ocsu8R4", "mintedAmount": 22000.0, "payoutTxHash": "3gPzKgmWxDzDRwtpNBmzKLpzXwuPsECaFAwu7R3JnH5BizdiGXEoukn3Qx7pZaoqV1QMAgPS12z28EPuQ2RK4azX", "depositTxHash": "5DhrKPU9F3n6yrZyHrDXA5qttHq9scwRFbmPMaz5PRi8ik8LJSeRwc1usLE3TvRJZ3uk1Hb4VZPi1Kdm2CanBrSx", "swappedAmount": 1.2472080000000005, "preSwapBalance": 17.020298, "idrxMintOrderId": "20260831215128", "payoutBlockhash": "FhnmGs9Wcvp83RkqrMLFkcMdn8PJ3o48mG7dKsuozuu4", "jupiterSwapTxHash": "3hjjs7Dnnphx8JKQoULY3h4g7fjdH7XKKgjWghCXfLU4VtAenmEvTR2mYve7ZxfkKnPKETVoabRBwqUHw7eqrk8U", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	3gPzKgmWxDzDRwtpNBmzKLpzXwuPsECaFAwu7R3JnH5BizdiGXEoukn3Qx7pZaoqV1QMAgPS12z28EPuQ2RK4azX	\N	\N	\N	\N	2026-08-31 21:51:28.024958+00	2026-08-31 22:10:37.848531+00	MAINNET	SOLANA	\N
c17c04af-98db-4906-ba4c-892b4f321aa7	DEPOSIT	COMPLETED	0.00011845	BTC	200000	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "203000", "method": "IDRX", "cexTxId": "66096828049", "vaNumber": "91070040901011510", "channelId": "INA", "expiresAt": "2026-09-01T03:15:10.239340803+00:00", "reference": "SNAP-20260901011510", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "200000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAxMTUxMCIsInBheW1lbnRBbW91bnQiOjIwMDAwMCwidG9CZU1pbnRlZCI6IjIwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyMzQzMTA2MTIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIyNTMxMCwiZXhwIjoxNzg4MjM0MzEwfQ.nkv8bBNe0a32zpuM2K8sCgrymJOt5LY1q3QV_tUYN74", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAxMTUxMCIsInBheW1lbnRBbW91bnQiOjIwMDAwMCwidG9CZU1pbnRlZCI6IjIwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyMzQzMTA2MTIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIyNTMxMCwiZXhwIjoxNzg4MjM0MzEwfQ.nkv8bBNe0a32zpuM2K8sCgrymJOt5LY1q3QV_tUYN74", "expiredDate": "2026-09-01T03:45:10.612Z", "sweepTxHash": "2o6UQPihysu5B8Y6YwcrGKbvLeLRk6KM2yUBz49dab4EQZhYiR3a8NKmwJq62iZrKsHXQbPhNwnoje9C9CbBLLpP", "mintedAmount": 200000.0, "depositTxHash": "2J7Juu9q3A8FBvDDnsKtzNQtZpTsNwBuWWADYEzP3XaLLiYkdP8tmSCKhwAD3eyzouEm1W8mkGFbJExAi4aBhwWa", "paymentMethod": "va", "swappedAmount": 11.337805999999995, "preSwapBalance": 17.045245, "idrxMintOrderId": "20260901011510", "virtualAccountNo": "91070040901011510", "jupiterSwapTxHash": "2kh1XTQspX72NSD9DHjimdmYtsP4PL47PFBySwVYCA3fWWum1hyChFJWTvBcDrEcrgCYnKfajuRfenH21ouqfnD6", "virtualAccountName": "PASHA RENAISAN", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "23eupngFw7svpm96AeyB5XrNXpWf78gMxk1vDsDTvgw93QKmvnBzLiXosigFzvMGXWqafDoGW88bnmpr5z3ihgdS", "kycOnboardingAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1", "usdcToUsdtSwapTxHash": "2oiU8Raui2PZDL5h8SUCCSKRjd5ebEL65pzmYLQGLwKLLi3Rwz612KMfK9w9Wqgk6ysiVhJbr5oD8tasp3dnDDUE"}	a431d62a042f6840565ad7666a1cc75590f84e043d84846132e72abea1c84344	66096828049	\N	\N	\N	2026-09-01 01:15:10.237836+00	2026-09-01 02:51:43.054203+00	MAINNET	BITCOIN	\N
3a717b70-e33f-4656-b718-51582a934867	WITHDRAWAL	COMPLETED	0.00043264	BTC	565342	bc1q09rpkqchl0yulen7wupf5uu05uk63wwx79pcfc	{"method": "501", "bankCode": "501", "bankName": "BANK BLU DIGITAL BCA", "bankAccount": "005250920570", "soldUsdcQty": 32.7351612, "accountNumber": "005250920570", "bankAccountName": "PASHA RENAISAN", "paradappAddress": "bc1q6e7he9rjfmr8fvy6439vnc3r57qfsupajdmfls", "solanaBurnTxHash": "2mqLQ14W8oDWbKYWifob14xPdHoumaE3ebKZ32DmvRoCVDWgdvjaKW9aMZD4NGPHdHt7CBLKu2tiSGVbAWnDQKFY", "accountHolderName": "PASHA RENAISAN", "binanceWithdrawId": "f719921fc2d24118b541226b5c10198c", "jupiterSwapTxHash": "4ZZ6GjBtiJQ4T6BX9ZNhhrvo8zL2JzcFQW6W8LkLWnYmR8JpWpheCqBc6NVjHa6QoZg2ztecwVG5JuTnGsGhFy1X", "swappedIdrxAmount": 570342.44, "idrxTransferTxHash": "3awTKjvUDz4ENXp1F8LS94WHN8Syp4FEK17CWfesNVCPXM4r54qjEiSWH8gxKyR3UqYwMscUF85D4EPkyBbu1ymv", "idrxRedeemRequestId": "18151", "solanaBurnBlockhash": "2chkMSZDJ4YUUUq1o8XjCYuoeDpMjbusstKu1mxs4eK4", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "3qhHmDPqTMsL6Cw4rHBY4N8PmjxeDPVY1CGEDjCxnM3k", "binanceWithdrawTxHash": "3HsG9iHMTgFrqZJ6KcWZEHoGFPYnTpqEbXojN5LrmFf2C8L9WqMj6nSwkftCKNpvxsuhXKw21ua7fGrnAtPUXt7d", "idrxTransferBlockhash": "2mmUhZ87vHfN45T4jVz74ceZmM3WN2MwniBuU9EpeUAS"}	093f9467935acbef977a3c1d2e4640d1a634d81d73e1af28a9c2875ea2af07e7	10215323104	\N	\N	\N	2026-09-01 07:53:49.262524+00	2026-09-01 09:54:18.938563+00	MAINNET	BITCOIN	\N
01c6115d-7fb6-4ff9-8864-58dde2d10c29	WITHDRAWAL	COMPLETED	9.451e-05	BTC	98615	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "501", "bankCode": "501", "bankName": "BANK BLU DIGITAL BCA", "bankAccount": "005250920570", "soldUsdcQty": 6.2296, "accountNumber": "005250920570", "bankAccountName": "pasha renaisan", "paradappAddress": "bc1q6e7he9rjfmr8fvy6439vnc3r57qfsupajdmfls", "solanaBurnTxHash": "4ZCqhpZDf13xH5cUQLdXNqfGwDqTYioFr9hz7Do9zmhRjNc3zKF2cFEGh7Jg1TwiTTQbJit1Wj4nTpFTeumPGkro", "accountHolderName": "pasha renaisan", "binanceWithdrawId": "4051e0cce724445eb8b1d7d4d93e5647", "jupiterSwapTxHash": "574HTH9ZmrPVjCZ6oJPic5Jhse9n6Zs5oMPMhpJRw8KrEJDy3CZz5iKtGNTo3PPdoRPuCQWYWqtWHy3FPs2nKpp5", "swappedIdrxAmount": 103615.83, "idrxTransferTxHash": "4wm8PUbuFfdu5PcEAge4sAed4Ei5dfXmpXf9Wx24H2CMo9t5ibLwBkiaWXtHDSvKnBHZf4RzhvaoqGKSTPio7oxm", "platformProfitUsdc": 0.0355776, "idrxRedeemRequestId": "18153", "solanaBurnBlockhash": "cKfwJm3bqiBy4bn2kYifkGsx9ujfbvhvGN2ghhyWDzH", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "3qcPT5bontiii3CpCVTmXUozYrhWs2LvX4XXXyEkKkQ7", "binanceWithdrawTxHash": "2fa713VDeuGEu8nJ181AKuXDN2iLxaSY9odBBGSKuT4cxYNYSuUNsonLc4vXzZd3CCG4oxipgaZf13MCzFLjmPRT", "idrxTransferBlockhash": "CUiGLHgjBdkuaKRPq2KHRe95GGBZfnPBLzxNjUoDL1xd"}	4776280d960a0c267be8432a56c01428648798e7ee63cb6b33e2488711c0ffae	10216429871	\N	\N	\N	2026-09-01 11:05:01.075481+00	2026-09-01 11:26:58.879649+00	MAINNET	BITCOIN	\N
2d4917f1-0996-4041-9063-7ea462c68b4b	DEPOSIT	COMPLETED	0.011949562	SOL	22000	J576U6Fazq9j4fGx3x6y5j4vUaZJup9rarnbmY1nR8q7	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "25000", "method": "IDRX", "vaNumber": "91070040901030104", "channelId": "INA", "expiresAt": "2026-09-01T05:01:04.415096810+00:00", "reference": "SNAP-20260901030104", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzMDEwNCIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg4MjQwNjY0ODI0LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODgyMzE2NjQsImV4cCI6MTc4ODI0MDY2NH0.lX1tlNf0tq-HskQkRdVPu6iNQLTfolaw_mG9uc4cujs", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzMDEwNCIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IlBBU0hBIFJFTkFJU0FOIiwiY3VzdG9tZXJFbWFpbCI6InBhc2hhLnJlbmFpc2FuKzI0QGdtYWlsLmNvbSIsInByb2R1Y3REZXRhaWxzIjoiTWludGluZyBJRFJYIiwicmV0dXJuVXJsIjoiIiwiZXhwaXJlc0F0IjoxNzg4MjQwNjY0ODI0LCJjaGFpbklkIjoyLCJicmFuZCI6InBhcnRuZXIiLCJpYXQiOjE3ODgyMzE2NjQsImV4cCI6MTc4ODI0MDY2NH0.lX1tlNf0tq-HskQkRdVPu6iNQLTfolaw_mG9uc4cujs", "expiredDate": "2026-09-01T05:31:04.824Z", "sweepTxHash": "2MWqesbuyxhnRKJz1PA4ZDtpQGvG2YD1QzA9fkJ2DHJV5Yu9U7t1U2uocg8ALC2PHwQjCpUiLQUjvYkQQzRh8Wxc", "mintedAmount": 22000.0, "payoutTxHash": "2zWMsKstvZ5wgVwFJzUruBHH8BUigridB3HWpUsHy2eSj7WeqJiYLmn6b91fxnP1HbUrbMbh57S4FRQwTWsyQfTs", "depositTxHash": "3oBgkZtktWHYKQ6J1Qw23wJ7QdudoXJdADjSTNxdLkUS8fQcSVja13y4m1yj1tgwZtzWN6RnfL19Uc2RCUfgVG1M", "paymentMethod": "va", "swappedAmount": 1.247189, "idrxMintOrderId": "20260901030104", "payoutBlockhash": "9K8ivz863e6Kdw4GMZUmz993avaUP9N9fnEoWyTmKEwd", "refPayoutTxHash": "5XmhpUfshwEc8GjersLZmyooz4CmJQPHYyMnAMDQhe14BCeakuE26kJB1BUwKkJ9eM52gquBJGoTLegnmxYx6UXM", "swappedSolAmount": 0.011979737, "virtualAccountNo": "91070040901030104", "jupiterSwapTxHash": "5atpFMZajdU1Cu4wg78T89GWoycZ9nHALkyeQWxhdJuDN13HTGCxV5ved5h9GcCTwHQHQES9bcsBKW1UgiFbBNSu", "refPayoutBlockhash": "H3sisThZGyfxvdRWVs5JCS9vrTHu4Sit4cAyab8MLJiR", "virtualAccountName": "PASHA RENAISAN", "expiryPeriodMinutes": 120, "usdcToSolSwapTxHash": "2Ln2AWrFMv5CFuJ9Se223pwTKu4j6XgN3TSy6uGyDZT3gYLYdkHZoB4bXovoV5W9W8M4RRLV6duwUcyoSr4riimx", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	2zWMsKstvZ5wgVwFJzUruBHH8BUigridB3HWpUsHy2eSj7WeqJiYLmn6b91fxnP1HbUrbMbh57S4FRQwTWsyQfTs	\N	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	3.0175e-05	\N	2026-09-01 03:01:04.412238+00	2026-09-01 03:17:33.454998+00	MAINNET	SOLANA	5XmhpUfshwEc8GjersLZmyooz4CmJQPHYyMnAMDQhe14BCeakuE26kJB1BUwKkJ9eM52gquBJGoTLegnmxYx6UXM
8a26610b-19c1-4bbd-9b3f-ca69ac30cd39	DEPOSIT	COMPLETED	0.00010857	BTC	186000	bc1q09rpkqchl0yulen7wupf5uu05uk63wwx79pcfc	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "189000", "method": "IDRX", "cexTxId": "66098348173", "vaNumber": "91070040901032759", "channelId": "INA", "expiresAt": "2026-09-01T05:27:59.383707715+00:00", "reference": "SNAP-20260901032759", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "186000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzMjc1OSIsInBheW1lbnRBbW91bnQiOjE4NjAwMCwidG9CZU1pbnRlZCI6IjE4NjAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyNDIyNzk3OTIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIzMzI3OSwiZXhwIjoxNzg4MjQyMjc5fQ.mbuHgklta_Ptz9Gec2m2rH9ylnsY3tuXm6_Tv8taOMk", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzMjc1OSIsInBheW1lbnRBbW91bnQiOjE4NjAwMCwidG9CZU1pbnRlZCI6IjE4NjAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyNDIyNzk3OTIsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIzMzI3OSwiZXhwIjoxNzg4MjQyMjc5fQ.mbuHgklta_Ptz9Gec2m2rH9ylnsY3tuXm6_Tv8taOMk", "expiredDate": "2026-09-01T05:57:59.792Z", "sweepTxHash": "nGFKxKFemo6cTJr77z1wvAEVVhaGFx2imVAhpFeXain5CrpJv8TcZdAnxCdRihcooEj35kdMUf1mVhKGMPHGZDy", "mintedAmount": 186000.0, "depositTxHash": "2YmiEZStBVAdt8AwfPzwxnmykbaaxM1DwfrNnsvhNc82WwcrPvUyniKH6aPC7pQR51S9XYThZyootQuR5P2Q7kR6", "paymentMethod": "va", "swappedAmount": 10.544092, "idrxMintOrderId": "20260901032759", "virtualAccountNo": "91070040901032759", "jupiterSwapTxHash": "2zyNifHyWzMZ3PqmTUQDW9N5m1BrF54GJeb6fkQynDsdfJiQ2mK1wQRsjivRATgZeEz4Pmh7HiaVcrgyuguy9nD2", "swappedUsdtAmount": 10.467789, "virtualAccountName": "PASHA RENAISAN", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "552r1LYAPkKwYaUtAfLgNxcC5LmtQWTMTdjjxYwbDwWbB891vcfCbrMbUep3ag3WR2MiSQacPvDJ9TseoDQYPKk7", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "41pTTnHqVUACdecgfU7xFgKrXQwrwYegPaLKWNZLXexsQ5qETqRMKxNd48dUvkfknpNvNwrWVLUMkSuQEawBWePh"}	d84c6e07788c0e4ab27c11de65c71dc5388fcc964414398ad20f2328c2679b75	66098348173	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	3.2e-07	\N	2026-09-01 03:27:59.379482+00	2026-09-01 03:51:58.13337+00	MAINNET	BITCOIN	skipped_dust
2d4085b2-bce4-4fd4-9031-ca05d37ac7f1	DEPOSIT	COMPLETED	0.00032615	BTC	500000	bc1q09rpkqchl0yulen7wupf5uu05uk63wwx79pcfc	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "503000", "method": "IDRX", "cexTxId": "66099118752", "vaNumber": "91070040901034922", "channelId": "INA", "expiresAt": "2026-09-01T05:49:22.410605188+00:00", "reference": "SNAP-20260901034922", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "500000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzNDkyMiIsInBheW1lbnRBbW91bnQiOjUwMDAwMCwidG9CZU1pbnRlZCI6IjUwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyNDM1NjI4MzYsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIzNDU2MiwiZXhwIjoxNzg4MjQzNTYyfQ.p1TVECT4UUrfLdIvAcGkcvEsugddhxWM67MxG6ldtho", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTAzNDkyMiIsInBheW1lbnRBbW91bnQiOjUwMDAwMCwidG9CZU1pbnRlZCI6IjUwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyNDM1NjI4MzYsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODIzNDU2MiwiZXhwIjoxNzg4MjQzNTYyfQ.p1TVECT4UUrfLdIvAcGkcvEsugddhxWM67MxG6ldtho", "expiredDate": "2026-09-01T06:19:22.836Z", "sweepTxHash": "2JCjGNP8UsxcuHaGuqYqdkEhjw93W7TLkz6MYYx6rBqMcDR3eoynywvkxjfBzDrHtv25W5kNFWz7MRum4Hzian4r", "mintedAmount": 500000.0, "depositTxHash": "3ydYpJ6ZmkD6rGS568wrCoDLdCb9RZtEq3hv1bzEGvhHC18NrwoNhEjtTvSd2MJ2EiG9E5TFHpzc9i7U2Zqaq8uy", "paymentMethod": "va", "swappedAmount": 28.341441, "idrxMintOrderId": "20260901034922", "virtualAccountNo": "91070040901034922", "jupiterSwapTxHash": "XkLn3b1ZBm1Ak24qyT5LWxuuGfCdXPd3LqnhRdMvLNCNPQGRd26h5GXRpCs2X3pXcYhyMV7rVoAomEPvy6ncFd5", "swappedUsdtAmount": 28.136447, "virtualAccountName": "PASHA RENAISAN", "expiryPeriodMinutes": 120, "binanceDepositTxHash": "2F1fJsiqgrXDMTa7wmWfRR2UDUNcgPj7swmKDWkiu6nY8UKcdGFw4NgZYTsTM5Y7iUc81WuxP75QTo7DmB4RYVwc", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "2p8kaFxBoxwthQd4SLXHw4tjLnSZESnfHdvE23kJ9Gy9JwFhmERVPFVw6cMuPeYWCz18YTw5kJpno4gRj9cCzd3A"}	41db514ef32921f0a58d2f0257217745fab228611b85803e072fd406353bc59f	66099118752	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	8.7e-07	\N	2026-09-01 03:49:22.409006+00	2026-09-01 04:35:22.169851+00	MAINNET	BITCOIN	skipped_dust
fa455304-e4c0-456e-99ca-021a002d3321	WITHDRAWAL	COMPLETED	7.563836	USDC	127958	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081239990810", "accountNumber": "081239990810", "swappedInAtoms": 7560481, "bankAccountName": "GOPAY Pxxxx Rxxxxxxx", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "3Ui5W6sjzAqvKxYbQxz5oj61eFW2kJce54cesvhL7bqRadZTvs6P7fwfJrkXkfPCbn96d3Q7b6Njz7Su7758Wrvj", "accountHolderName": "GOPAY Pxxxx Rxxxxxxx", "jupiterSwapTxHash": "2Z9AdCbdhX8Y1SvDFX4TjZVjA7Fs27qUtJdvx6yfH2EXjLR4s7nBHjAW2c8y2aCyTT4YJgzgtfyAoNct8BuKCs8G", "idrxTransferTxHash": "5Nchjor2LP5HvGnvbM9xs3TSTiGp9E1nNNGxxVx2ehFxrngHe5aQ15cne3hv37Nx9pY5WSpjoehaUDGXP83QWBoy", "idrxRedeemRequestId": "18150", "idrxBankAccountAdded": true, "idrxTransferBlockhash": "GkCah3j9a99Ld623yX2CtF21TfwXPQVHSQbRaimkBJ1H"}	3gduAnGBY9ivrYxTq6tnxPaYySaTddF9ZAucGQBZki9bnDCLSb6EhP5DuuPKdUMvjhsS44JUFrSVBBiKbdSPL7rZ	\N	\N	\N	\N	2026-09-01 05:25:01.789827+00	2026-09-01 07:54:40.870365+00	MAINNET	SOLANA	\N
b7a23a74-15f4-4f78-afa4-e05163c373f0	WITHDRAWAL	COMPLETED	0.00038353	BTC	492785	bc1q72s0depny9xqwavzsl2w6q4un9gnhrtu2g64vq	{"method": "501", "bankCode": "501", "bankName": "BANK BLU DIGITAL BCA", "bankAccount": "005250920570", "soldUsdcQty": 28.7842795, "accountNumber": "005250920570", "bankAccountName": "pasha renaisan", "paradappAddress": "bc1q6e7he9rjfmr8fvy6439vnc3r57qfsupajdmfls", "solanaBurnTxHash": "2TctYci5QmUviqeT66iRYVf6jZJHkqDkzXLConKgzZAv6CP7rnUg2Fd82vBq15sTQMMYEBSyhPtZ9hiuuVe4y4CD", "accountHolderName": "pasha renaisan", "binanceWithdrawId": "5a258d38ef3e49dca8437223be45b64f", "jupiterSwapTxHash": "2ENjbYxhKtkyJuqAwwM1DTq5BFGV266SF5J9fJE9NrdDYS99vkoVRymSyMpTgv5sfVjhWnYSbbt9Wku7iRrTw6me", "swappedIdrxAmount": 497785.37, "idrxTransferTxHash": "32dSMwdnzDwn6uymwfusF12ymPdvwbUQbeLc6ehwt3LgKJSqbjfjyydnueePiy2RQnsZZ4nBUA2aVxL9yXYeo9xN", "platformProfitUsdc": 0.170905677, "idrxRedeemRequestId": "18152", "solanaBurnBlockhash": "B1Ki87Ln1uu9Fte5NaapX5HNQr6bEbGRv8h4kPk8JgPF", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "Hd5rrskg4HmqbSfBCk2MjQTQQookD2zQaWTWM9KbVDm1", "binanceWithdrawTxHash": "o6tHijSxsiMbGkiaHnQwtkr6bVmUgZKmSJ69YU1REAFFZHWaFmfUHoqy1LfZnd71dukUpQ1yxv81jG8qmcJQ8eT", "idrxTransferBlockhash": "HZWL9LCPvdBW29HdG916yzpXpUWMaD6edA8q4cLF7XXc"}	c2315afd414ae25bba9156c54d0d51951513c452f82f256c6fde6010560ffcac	10216012997	\N	\N	\N	2026-09-01 10:02:13.915087+00	2026-09-01 10:15:18.965866+00	MAINNET	BITCOIN	\N
ec4f19d2-71e5-4111-9937-d77dd53ebbb7	WITHDRAWAL	COMPLETED	11.488257	USDC	194966	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "089654812465", "accountNumber": "089654812465", "bankAccountName": "GOPAY I Gxxx Exx Lxxxxxxx Pxxxx", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "3tgLTek1JCeMT92Hwz9AMzhk6UeL1iuinj6UruNeXTn8pNgePbJ6ywwLxWLjzsmb6uKYev3pTqHwBqvPk7qQKRZc", "accountHolderName": "GOPAY I Gxxx Exx Lxxxxxxx Pxxxx", "jupiterSwapTxHash": "WUiUSLYCXrXQbj2Goky22sHoM7sSZUbdQk2c7x1fxQm1QzVdnVZkYPd5xAdoeqcS2g7LgFM9cDoEvpNJYB78gxc", "swappedIdrxAmount": 199966.53, "idrxTransferTxHash": "2gFM4pMHM4UibWhqmNVKrjm2SnEZpH1dnnpw43vtvnBSQoPJwgQZRHzsmo7JbnxXKobpVGczLU2kg7LRKjcW6SRN", "idrxRedeemRequestId": "18367", "solanaBurnBlockhash": "8axdLBwmm7WMvCi4e1wKmZg8mKouwkX4wudMetFLyq5K", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "rsbK7JQMshjmsm2N46wweC8RL37cQo5qw8AjeLmejH1", "idrxTransferBlockhash": "3juFqQ91rY6sMqf5b2VcpbeDCQQAX1pqLtMtYL5Au3m9"}	PZdvTLftCw2jE8tTGg8gzjbQZSXQFBJr1EbjQJt3jCUwvdavYxjqRqkyyZHWp2LKiKZL6faLQaM2Ro6XMgx1GvM	\N	\N	\N	\N	2026-09-10 04:30:21.83397+00	2026-09-10 04:33:43.932507+00	MAINNET	SOLANA	\N
ef7b9bec-bb91-4dc2-822f-9d9f2ac25a0d	WITHDRAWAL	COMPLETED	11.14662	USDC	189978	87JyDsMpP9TmajXRTtC7MEMKF2tf2hFvVJGto9qmzQMt	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "081239990810", "accountNumber": "081239990810", "swappedInAtoms": 11090848, "bankAccountName": "Pasha Renaisan", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "5hkcaPWRQ7pv5qoVjA9CzGUFJLxbhGByWtLG6ei3KEQBKNFhJq8cCzXjzXx6wGkaVyL3wBaZcBRv1VLajtQ9Q5nF", "accountHolderName": "Pasha Renaisan", "jupiterSwapTxHash": "PpZ8NPZJ6Z7fcpXZxrPwXEJXuVL5XZq1AZD76xRkQHwCQeAzLjKisJ1qCXfC995B7WhGEDRh94s9nYxArbZMyTh", "idrxTransferTxHash": "4DXRer7MdJCi2EayrfqRMtZCq9aVdcQYdRTfQkRrikxeDzaTKyKrNv9k3B1VhShA4NZp2wuXPfV6tVrQUUdq8S8U", "idrxRedeemRequestId": "18172", "solanaBurnBlockhash": "9WmoyyKJCkNCHA4pU9sYxQs2K9hQX3hAaWJYjQYnsWEk", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "Fpcr857QfvRz1KWwh3jwJcYvSNYgTh9deTLmptBW9yuA", "idrxTransferBlockhash": "DFFUiR4tgAE2nV3CdDFStCvv4zVWTgtp4g1PqkhqXkb3"}	5zLhXVUtaWF92R2pJQPmZYtdAJN6SsWZL8xPeJGWB28769DqrbsvRviURzRyxAVEAUYotkJRhWFmmGmKKiESwi4q	\N	\N	\N	\N	2026-09-01 16:31:03.480929+00	2026-09-01 17:09:44.210695+00	MAINNET	SOLANA	\N
664ba068-910d-4ae2-ba75-dd664a531086	DEPOSIT	COMPLETED	11.148152	USDC	200000	87JyDsMpP9TmajXRTtC7MEMKF2tf2hFvVJGto9qmzQMt	{"fees": [], "amount": "200000", "method": "IDRX", "channelId": "QR", "expiresAt": "2026-09-01T17:53:37.888552820+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409200000.00530336062300119QR26VV2QX5PK3OEMYPS0703A0163043956", "reference": "SNAP-20260901155338", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "200000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTE1NTMzOCIsInBheW1lbnRBbW91bnQiOjIwMDAwMCwidG9CZU1pbnRlZCI6IjIwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyODcwMTgyNzksImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODI3ODAxOCwiZXhwIjoxNzg4Mjg3MDE4fQ.etWIxKu9BqX_BKr2XfSCGyRzQqWyWxLap_Bv9Wndx9U", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMTE1NTMzOCIsInBheW1lbnRBbW91bnQiOjIwMDAwMCwidG9CZU1pbnRlZCI6IjIwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgyODcwMTgyNzksImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODI3ODAxOCwiZXhwIjoxNzg4Mjg3MDE4fQ.etWIxKu9BqX_BKr2XfSCGyRzQqWyWxLap_Bv9Wndx9U", "expiredDate": "2026-09-01T18:23:38.279Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26VV2QX5PK3OEMYPS", "referenceNo": "D11808267WEMS76AQFRCD7U", "sweepTxHash": "xYMWD6vCi5V7MjM2CWPycDqzv6tzSD2C16cqAef4YCiasyYdBkZpk9qHGtKnZA2ewNTc99ASH3ryjsD1LNvE7JZ", "mintedAmount": 198600.0, "payoutTxHash": "3qScRzMehaKUuzzWiDWBxsNQ8NQmPZaGfcRfw3ipTtKBccMVBzMg9GQ8cXJydSEFXmR128m4xnijdabLBCZqLQ5m", "depositTxHash": "3USQVXabSF9CTGyMq6nmf5fTUWeu5tWW1QmCyz6MZggBQqgLe2W78hjWXaMtkYLZczxaGfhqXAuZ5hPaUgWo1gnK", "paymentMethod": "qris", "swappedAmount": 11.260759, "idrxMintOrderId": "20260901155338", "payoutBlockhash": "96hYzhdSSyA9qbDrrpff9HHrZBr4VpQFHEcH89cJoH7w", "refPayoutTxHash": "61MuW6iZzUEU17cF4XZJgc2HjjWVqGszpawrjfmN5u5KDZKNXFfdVSYRvJZFB9DnoPte6wFgx5S3QuVcqY9YAcA2", "jupiterSwapTxHash": "mgYYjhgMgFiPQr4MmGXTZsynxniBHtZx9orkDZWGpjmm4Xv8Ex2i8z6sqaCELj1C5GDcW7zxCWtMP2Bbj5vEkWC", "refPayoutBlockhash": "96scjvfn5B9D1L2a1Cv8wjecwqHdXax34mLvf2W3dTzJ", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd"}	3qScRzMehaKUuzzWiDWBxsNQ8NQmPZaGfcRfw3ipTtKBccMVBzMg9GQ8cXJydSEFXmR128m4xnijdabLBCZqLQ5m	\N	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	0.028151	\N	2026-09-01 15:53:37.884581+00	2026-09-01 16:00:57.87391+00	MAINNET	SOLANA	61MuW6iZzUEU17cF4XZJgc2HjjWVqGszpawrjfmN5u5KDZKNXFfdVSYRvJZFB9DnoPte6wFgx5S3QuVcqY9YAcA2
52c06dda-5c2c-4cf6-b9d7-5ac6b916ca29	DEPOSIT	COMPLETED	6.6059699998	DOT	100000	14rrwEnCnkfpWZzditUL7SJQNixqPyEAiQLjJJjsLP2tSoSF	{"fees": [], "amount": "100000", "method": "IDRX", "cexTxId": "6181283087", "channelId": "QR", "expiresAt": "2026-09-02T14:52:30.502733403+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409100000.00530336062300119QR268CEXA6JPV7RD75X0703A016304B4B2", "reference": "SNAP-20260902125230", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "100000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjEyNTIzMCIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNjI1NTA4OTUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM1MzU1MCwiZXhwIjoxNzg4MzYyNTUwfQ.cWzaGVibn4G1yVKzCQz4W3R6JoEbk4eMucfNYdllabA", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjEyNTIzMCIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNjI1NTA4OTUsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM1MzU1MCwiZXhwIjoxNzg4MzYyNTUwfQ.cWzaGVibn4G1yVKzCQz4W3R6JoEbk4eMucfNYdllabA", "expiredDate": "2026-09-02T15:22:30.895Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR268CEXA6JPV7RD75X", "referenceNo": "D1180826E6FEB6WB6EUCRRQ", "sweepTxHash": "5ZPY2wkAzjHRWFFkeXrSk2PNWWDfKJsxZQtaFqpfn9FxYZcKYyeAHew9RRz3ynesR8kL3aztUU6Y5qbBmEGna87H", "mintedAmount": 99300.0, "depositTxHash": "4d5u3xaDrvJYqYCnT4dcQLtVUjDpPXVmVgY5q5xK1Z2NfCbtH2F7JyMeXPn3mQcsxsGCufSm8e7DdQAaz14Jh1iH", "paymentMethod": "qris", "swappedAmount": 5.630408, "idrxMintOrderId": "20260902125230", "jupiterSwapTxHash": "2VFEC3ZvVVDMt8hjkGFaSKd8Rz1VU8bGJDjM82a9PiW7EkzZn3dq1U5ZNowjCafWkW2LiWLeAG9oSEWZza7Rpsf6", "swappedUsdtAmount": 5.576134, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "5baYcdU7kE2u9zvEYxoVDPeLi8gAyDgvj3zeVboXvjJEYNGW7SSCyj2T8LVvswjtthYyjubphsELPpBtpVFNBYCN", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "2GZiwATKBjJNJGk5NpbG1ChxeVppQr6Jw7JGsTfiQmzhcYDVD59jMKokPcfmAkk5VPYNXwSMKutA7eDHJYBo8C1A"}	0x9831151eb7ee57e98725eecb871fe59fca5aa4bc2be3a4878e3276b72eff1a04	6181283087	\N	\N	\N	2026-09-02 12:52:30.499043+00	2026-09-02 13:47:14.589626+00	MAINNET	POLKADOT	\N
3c754629-7c53-467d-9dfb-c2dc26f13108	DEPOSIT	COMPLETED	1.234968	USDC	22000	6cWiZTQTSCyqivSuorZsBaHxrc2L9ZxXHvcpHiZwwKgy	{"fees": [{"name": "VA INA", "amount": "3000"}], "amount": "25000", "method": "IDRX", "vaNumber": "91070040902115017", "channelId": "INA", "expiresAt": "2026-09-02T13:50:17.350683282+00:00", "reference": "SNAP-20260902115017", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "22000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NTQ4LCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjExNTAxNyIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IkkgUFVUVSBGQUpBUiBUQVBBIE1BSEVORFJBIiwiY3VzdG9tZXJFbWFpbCI6ImZ0YXBhbWFoZW5kcmFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNTg4MTc3NTksImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM0OTgxNywiZXhwIjoxNzg4MzU4ODE3fQ.P1uORh7c79mcM6fsbdGSIbaDv-8MvP1O5vtQIfDCQ9E", "channelName": "Bank INA Virtual Account", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2NTQ4LCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjExNTAxNyIsInBheW1lbnRBbW91bnQiOjIyMDAwLCJ0b0JlTWludGVkIjoiMjIwMDAiLCJjdXJyZW5jeSI6IklEUiIsImN1c3RvbWVyTmFtZSI6IkkgUFVUVSBGQUpBUiBUQVBBIE1BSEVORFJBIiwiY3VzdG9tZXJFbWFpbCI6ImZ0YXBhbWFoZW5kcmFAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNTg4MTc3NTksImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM0OTgxNywiZXhwIjoxNzg4MzU4ODE3fQ.P1uORh7c79mcM6fsbdGSIbaDv-8MvP1O5vtQIfDCQ9E", "expiredDate": "2026-09-02T14:20:17.759Z", "sweepTxHash": "3chHSsvbNEbdbS46GcGiyFhZiSpuqoJdDWB32kk7AkXN9Tr1F7jfFSvA7PrSrrSd5bW2bmqowDLw8aJagdZjRW1J", "mintedAmount": 22000.0, "payoutTxHash": "2uZRP1W8TWUgaSynopnBgCd24C3L3qYF26PPBcdyFSW7vn6rb4niL98e3gogQQ9ECmuFYyaN31dM6vagzUodhRvZ", "depositTxHash": "5iYUMZBn7xxA7ZrnKtJ1yVYck3CfXJwKgALpV6qwBbzQg7PEKADWZgLDBM6RiBXjgaWCGiksVssQxXXKDmt1FfRi", "paymentMethod": "va", "swappedAmount": 1.247444, "idrxMintOrderId": "20260902115017", "payoutBlockhash": "Brj6aD68WgiLEeXc4G3czoa8Exqj9BHxzPaqpLnGJ6Gp", "virtualAccountNo": "91070040902115017", "jupiterSwapTxHash": "2PC2H93y6dLqPipUF53qrW3YC8xCF3fLLMAgxvBTdKWMVkcn2mDFXroroAqn6wvhKhfKDDAQZtbBb9BEmiNQUWkj", "virtualAccountName": "I PUTU FAJAR TAPA MA", "expiryPeriodMinutes": 120, "kycOnboardingAddress": "Fi7qcNGASn7iuH7n96XZ2FV42X9wiY9Qk9xSCYNcYraP"}	2uZRP1W8TWUgaSynopnBgCd24C3L3qYF26PPBcdyFSW7vn6rb4niL98e3gogQQ9ECmuFYyaN31dM6vagzUodhRvZ	\N	\N	\N	\N	2026-09-02 11:50:17.342808+00	2026-09-02 11:56:57.244773+00	MAINNET	SOLANA	\N
ed0dfcd0-4fcf-4406-aab7-2163cacfa79f	DEPOSIT	COMPLETED	6.5268499999	DOT	100000	14rrwEnCnkfpWZzditUL7SJQNixqPyEAiQLjJJjsLP2tSoSF	{"fees": [], "amount": "100000", "method": "IDRX", "cexTxId": "6181334822", "channelId": "QR", "expiresAt": "2026-09-02T15:48:31.643859500+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409100000.00530336062300119QR260IHJZNDWH0R71FD0703A0163046FBE", "reference": "SNAP-20260902134831", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "100000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjEzNDgzMSIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNjU5MTIwNTMsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM1NjkxMiwiZXhwIjoxNzg4MzY1OTEyfQ.qgXSq66XAqi98Wzrwr8LKUdrY46GR9tVziKfGPWww2Q", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjEzNDgzMSIsInBheW1lbnRBbW91bnQiOjEwMDAwMCwidG9CZU1pbnRlZCI6IjEwMDAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNjU5MTIwNTMsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM1NjkxMiwiZXhwIjoxNzg4MzY1OTEyfQ.qgXSq66XAqi98Wzrwr8LKUdrY46GR9tVziKfGPWww2Q", "expiredDate": "2026-09-02T16:18:32.053Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR260IHJZNDWH0R71FD", "referenceNo": "D1180826P5MWW2CW45R64NY", "sweepTxHash": "5KdgaWsfz75F168zhRUyzMTTZnfadP7ECchftfTKeBkRS6h8sHp65xxyAFnWswT2PLPEye7PCXjNp9sV9AAGgcrV", "mintedAmount": 99300.0, "depositTxHash": "2try9q2sVtkQqwvj8raowAyvLftmCNdMDBRtZ2KBPMnj6CwcFUBWoJQy35AEYmtbM3oTYaxrBo7gU3BdezHHVhUc", "paymentMethod": "qris", "swappedAmount": 5.630236, "idrxMintOrderId": "20260902134831", "jupiterSwapTxHash": "33FzX7j6hkPKWKY4ceC6n9BnC9SmfYxqi7KpjR6pvrioSC6ptvAfm9puwiDggNGdAEAVsmJGwiWvF2PFN6Zc2zkh", "swappedUsdtAmount": 5.576079, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "61vRHSw5CLUadSsT6yaLxRch45A2nfBSrWkLiWV9KGJT7T4sDvLQUKryZWYWhMvJPJPJvgv3fVtRSVq78NXqtRYp", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "3hixwxUdnfEe9pBeajB3UtFZ3i5giZcvezNLeVm3ZvuCGj6pRZjUCMj7d7jWnr35VcrDEGTpJhCmS34Ah1T2Bi2n"}	0x1af7c9dacd16813323de344c0008f181d3a94c4a0ae2511d229ab61748bf4403	6181334822	\N	\N	\N	2026-09-02 13:48:31.638386+00	2026-09-02 14:11:42.500526+00	MAINNET	POLKADOT	\N
8940255c-92d0-4cd0-8c6f-4ac3e2722834	WITHDRAWAL	COMPLETED	0.706001075	SOL	1248854	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "089654812465", "accountNumber": "089654812465", "bankAccountName": "I GEDE EKA LAKSMANA PUTRA", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "solanaBurnTxHash": "2HCKsmbUME5dpYtSPqe5DcqwWbuvSU58eWAAQ6DF9VPrhJtvdFG3MofMDi7mpucYe6Di5UQvDAbMixehwLqZcJ79", "accountHolderName": "I GEDE EKA LAKSMANA PUTRA", "jupiterSwapTxHash": "3c3FX8p81V5ewi51qed7i5qq5GrC5mHXAnSrvWzrb6QM98JXRvbne9v9PsdvsZKPCBRKYXxmZ5exK2tMXSPbDM1v", "swappedIdrxAmount": 1253854.0, "idrxTransferTxHash": "3foVxiCydKHa1AFCQ3xQub5b9CET33Uk29LkBdiAryrapVMheiZuLzkdugzCZ3fob4b7p5CLnMUoLPsKshkMmxi4", "idrxRedeemRequestId": "18368", "solanaBurnBlockhash": "BrGVspGfv1HZWkduTmjMewM4hkG1aLi31Nnrs4zDqmws", "idrxBankAccountAdded": true, "jupiterSwapBlockhash": "PAj1oXWMUTbJb9Zs3MqJ4bjHm8KEMW6FL6yqXJ5em2r", "idrxTransferBlockhash": "AjixCqvas7dJszQACpG1m3zmgDy2dJrCofWWRB71EGdi"}	2ZkCSjZFqcQCLNLCTYBUhW49kDXgCphSBSfdznu8bpA3kErQnQxSDYdfhbNMF56AiDdZRdRkawxtsKPyBAsD7imN	\N	\N	\N	\N	2026-09-10 04:38:24.141182+00	2026-09-10 04:48:11.933775+00	MAINNET	SOLANA	\N
df23edd4-f947-427f-97e6-c9674f3b71fe	DEPOSIT	COMPLETED	0.0023036	ETH	102000	0xE3B910c931117EAe35684D2af78e69240031C69f	{"fees": [], "amount": "102000", "method": "IDRX", "cexTxId": "49554180556", "channelId": "QR", "expiresAt": "2026-09-02T19:12:12.953285014+00:00", "qrContent": "00020101021226630014COM.DUITKU.WWW01189360085306619952690212DK2607UF6O1L0303UME51440014ID.CO.QRIS.WWW0215ID20265566326050303UME520460515802ID5907IDRX CO6015JAKARTA SELATAN6105121905409102000.00530336062300119QR26L3WD01ET6TSTOKB0703A016304E441", "reference": "SNAP-20260902171213", "returnUrl": "https://paradapp.com/payment-return", "baseAmount": "102000", "paymentUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjE3MTIxMyIsInBheW1lbnRBbW91bnQiOjEwMjAwMCwidG9CZU1pbnRlZCI6IjEwMjAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNzgxMzM0MDcsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM2OTEzMywiZXhwIjoxNzg4Mzc4MTMzfQ.8TUDqEUJaDaEdQnbTeDls9CanpM9a5egj_f56aM50oo", "channelName": "QRIS", "checkoutUrl": "https://checkout.idrx.co?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY2hlY2tvdXQiLCJzdWIiOjE2MzYwLCJtZXJjaGFudE9yZGVySWQiOiIyMDI2MDkwMjE3MTIxMyIsInBheW1lbnRBbW91bnQiOjEwMjAwMCwidG9CZU1pbnRlZCI6IjEwMjAwMCIsImN1cnJlbmN5IjoiSURSIiwiY3VzdG9tZXJOYW1lIjoiUEFTSEEgUkVOQUlTQU4iLCJjdXN0b21lckVtYWlsIjoicGFzaGEucmVuYWlzYW4rMjRAZ21haWwuY29tIiwicHJvZHVjdERldGFpbHMiOiJNaW50aW5nIElEUlgiLCJyZXR1cm5VcmwiOiIiLCJleHBpcmVzQXQiOjE3ODgzNzgxMzM0MDcsImNoYWluSWQiOjIsImJyYW5kIjoicGFydG5lciIsImlhdCI6MTc4ODM2OTEzMywiZXhwIjoxNzg4Mzc4MTMzfQ.8TUDqEUJaDaEdQnbTeDls9CanpM9a5egj_f56aM50oo", "expiredDate": "2026-09-02T19:42:13.407Z", "redirectUrl": "https://passport.duitku.com/TopUp/v2/TopUpQrisPaymentPage.aspx?reference=QR26L3WD01ET6TSTOKB", "referenceNo": "D1180826U1MY7OCGZEQ64TT", "sweepTxHash": "26JQE6wQS7v1EBCW8Qwax4DRH6uZxFzqpLvbXYJ72JA9oywqH6acujeBBGjkHU5h6tDmnB1vfma3smenU8uQqJTQ", "mintedAmount": 101286.0, "depositTxHash": "sNk2wdeKseYD56UimoMUFmeNfqQt2tsQVm9z9Er98ix2VB5HHDqXczms5krnr4Nhf8MHuLV4sx3bxGx7BEAwWdn", "paymentMethod": "qris", "swappedAmount": 5.742683, "idrxMintOrderId": "20260902171213", "jupiterSwapTxHash": "8X3gmzGB1AVQs61rEZ6jUcVejn9r5nvPz8gRpmQtASsEPkVawivknswbiCrbTkkmBZk7dxvoqdvezfRuqMoorCN", "swappedUsdtAmount": 5.687516, "expiryPeriodMinutes": 120, "binanceDepositTxHash": "4AHv9gVYZ5j5UXy2dAP6p5QNxAy384Jmh3veBnZN79HAgtcC2RAhxFwoMiMUJE4me9adVPcyyQFcPcQnwY1GBXen", "kycOnboardingAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "usdcToUsdtSwapTxHash": "4rF9aksqpM17SzWF1xm4EBtbPGKTqKDE1AQ6zqS6nx8WAFPPbQtG7NTB3T6Ryo84ng9n7RQUeDsQV6GVGfkCJ7TQ"}	0xdf53900909268fd61e8feceade9bb6d93c0c20c1ea4c83568eb30c2c390693ed	49554180556	\N	\N	\N	2026-09-02 17:12:12.951165+00	2026-09-02 18:07:50.441999+00	MAINNET	ETHEREUM	\N
9b8e196b-2500-48b8-bc4c-d9d4cb9ea085	WITHDRAWAL	COMPLETED	0.744974999	SOL	167814	3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa	{"method": "1011", "bankCode": "1011", "bankName": "GOPAY", "bankAccount": "0128938123812", "accountNumber": "0128938123812", "bankAccountName": "kontol kering", "paradappAddress": "29dkDAneDrXWgPAQSEksYc8bqrEEM2Nuyx1zMFojghNR", "accountHolderName": "kontol kering", "idrxBankAccountAdded": false}	417L5VwBR75B22ELg41Eb5RGgf156LdJ42PoQhKq84rLPn8hDc1KjcSgPJAr2eTfy3ZZ32dqTyE8rokJaQ79Uemc	\N	\N	\N	\N	2026-09-10 13:32:56.478678+00	2026-09-10 14:58:10.187705+00	TESTNET	SOLANA	\N
\.


--
-- Data for Name: UserFavoriteDapp; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public."UserFavoriteDapp" (id, "userAddress", "dappId", "createdAt", network) FROM stdin;
cmmq57ztc0001ls016bxae9ua	0xd74012e54b054093563249a2b4fd1e3b3cbf6a12	4	2026-03-14 09:48:33.168+00	HEDERA
cmn50stw30002lv01g3fq2wge	0xca73918ebeaf4dccff703e3e7cb2f5b1591a20ae	4	2026-03-24 19:41:19.827+00	HEDERA
cmn5nsm8u000alv019tsjpcsb	0xde8b1bc533aec8b4077eeec5db0f5293b04c31a5	2	2026-03-25 06:25:01.086+00	HEDERA
cmn7gwxju000flv01nfq59g5n	0x19375c62875e1236ae9c667ae3613d8d0a0ce1d0	4	2026-03-26 12:47:57.402+00	HEDERA
cmn8qbooe000llv01gm1sreot	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	4	2026-03-27 09:59:08.462+00	HEDERA
cmn8qbsnr000nlv011tu57wff	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	3	2026-03-27 09:59:13.624+00	HEDERA
cmn8qby26000plv0199w8xaip	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	2	2026-03-27 09:59:20.622+00	HEDERA
cmn8qc1o4000rlv019gxtkd7v	0xb88dc2771d7a66493de8ac2f6114915d681c9e41	1	2026-03-27 09:59:25.3+00	HEDERA
cmnafdkms0004re0158yns4tn	0x0000000000000000000000000000000000656384	2	2026-03-28 14:28:13.109+00	HEDERA
cmnafdpf30006re01yqvz4njn	0x0000000000000000000000000000000000656384	1	2026-03-28 14:28:19.311+00	HEDERA
cmnafdvnm0008re015762le72	0x0000000000000000000000000000000000656384	3	2026-03-28 14:28:27.394+00	HEDERA
cmncy13jv000bre01z6qgbhyu	0x0000000000000000000000000000000000656384	4	2026-03-30 08:45:56.155+00	HEDERA
cmnnvpyb0000jre01cks8rjq4	0x7d28743a0354942ad797d7194e24d12bd8588b84	4	2026-04-07 00:26:44.844+00	HEDERA
cmnwm2jsg000lre014qv1ex9d	0x7d28743a0354942ad797d7194e24d12bd8588b84	2	2026-04-13 03:06:31.984+00	HEDERA
cmnwm2of4000nre01m354igs0	0x7d28743a0354942ad797d7194e24d12bd8588b84	1	2026-04-13 03:06:37.985+00	HEDERA
cmnzgqpy20002pn010pn2q7p5	0xf0a37a7b419a63fc4075eb173525b820b5b5391e	4	2026-04-15 03:00:40.538+00	HEDERA
cmola4ccn0001nl01locn1xz7	33dyn3pPMtdExJp7MxPcADkWXTZABxLSowLH2WwwDaep	8	2026-04-30 09:26:14.664+00	SOLANA
cmolo2vm20003nl01zcodp458	33dyn3pPMtdExJp7MxPcADkWXTZABxLSowLH2WwwDaep	11	2026-04-30 15:57:00.939+00	SOLANA
cmomhpqm30005nl01mid5k600	532Ax4G6AaVjC6z3uC5x9Us6VAohwVwLeGwXuys4MNY	11	2026-05-01 05:46:36.411+00	SOLANA
cmomhpw0r0007nl01ccdya2c6	532Ax4G6AaVjC6z3uC5x9Us6VAohwVwLeGwXuys4MNY	10	2026-05-01 05:46:43.42+00	SOLANA
cmomhq04f0009nl01myc5kiig	532Ax4G6AaVjC6z3uC5x9Us6VAohwVwLeGwXuys4MNY	9	2026-05-01 05:46:48.735+00	SOLANA
cmomj5ill000bnl01e3gkx1y3	44KcbsbZPPqxSNhtyWC7o8JbBvEvC2o4nDA4Ad9BoFWC	11	2026-05-01 06:26:52.137+00	SOLANA
cmonnpga3000enl01qc9r8w82	EoMqYMQGxxA9ogQgdxumKqVJHEMR9QjadKTo1SX3ui9X	10	2026-05-02 01:22:06.892+00	SOLANA
cmono9tbh000gnl01172egerr	EoMqYMQGxxA9ogQgdxumKqVJHEMR9QjadKTo1SX3ui9X	9	2026-05-02 01:37:56.91+00	SOLANA
cmorx1tuh000lnl01i4thut4t	44KcbsbZPPqxSNhtyWC7o8JbBvEvC2o4nDA4Ad9BoFWC	9	2026-05-05 00:54:45.593+00	SOLANA
cmp1x16ts0001mj01121nrx8a	44KcbsbZPPqxSNhtyWC7o8JbBvEvC2o4nDA4Ad9BoFWC	12	2026-05-12 00:51:57.519+00	SOLANA
cmp21oin9000bmj01wvofgco7	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	11	2026-05-12 03:02:04.389+00	SOLANA
cmp28oikt000dmj01d4b4tjin	4zzdvjNgVwSPxiYf8nC9bVRX1GmkDSz3GoGF6j7uM4y4	12	2026-05-12 06:18:01.613+00	SOLANA
cmp28pwb8000fmj019z0usc7n	4zzdvjNgVwSPxiYf8nC9bVRX1GmkDSz3GoGF6j7uM4y4	10	2026-05-12 06:19:06.069+00	SOLANA
cmp2px9uq000jmj019gcjtslw	6wx2TedWGTyDcuHNbo1mxzfYqdPSXDryayjKejFw2HDJ	9	2026-05-12 14:20:43.682+00	SOLANA
cmpbzhyzk000vmj01t1zobuiw	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	12	2026-05-19 01:58:41.504+00	SOLANA
cmpbzi3uz000xmj012kyap6fm	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	10	2026-05-19 01:58:47.819+00	SOLANA
cmpbzi8gj000zmj01sf2ad4v0	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	7	2026-05-19 01:58:53.779+00	SOLANA
cmpbzic0t0011mj017i8s5idh	5WRd7Bwti3cEH1qCXX2yzU9Zr4MVpj4p7krLbCEGbdN8	6	2026-05-19 01:58:58.397+00	SOLANA
cmq691lmo0003pf01gixl5aer	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	9	2026-06-09 06:18:59.136+00	SOLANA
cmqm04siy000yl301rjnghctr	65mufTpBd7ktPBBTP3Jhg9kgGjSxWKUnLgYY5L5j4wp4	11	2026-06-20 06:53:50.314+00	SOLANA
cmqm04y1t0010l301ljvew2nk	65mufTpBd7ktPBBTP3Jhg9kgGjSxWKUnLgYY5L5j4wp4	9	2026-06-20 06:53:57.474+00	SOLANA
9d0e9ef9-2c6e-4e72-a8d8-0676fe4b83f7	6BXWFQo1zdysPBZFyDaUjLC4Myy2oFDjMx1LZNkTYYYH	12	2026-07-29 16:08:35.265+00	SOLANA
4dcbe714-c765-4644-ad19-e3d16ad982f4	EH5H7q39P6ptiV3o9ZQN5nCcHWkQX8BjuEBkm1Z9pqb2	10	2026-08-23 20:37:39.444985+00	SOLANA
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
89df8649-4ca0-4869-afc6-e2ab5f9abf40	d86da284b8690f529f973f78ca1dacf0b831f46fbf62737e09fc7ff00a02ad32	2026-04-24 22:34:43.738081+00	000000000000_baseline		\N	2026-04-24 22:34:43.738081+00	0
0dd87c58-6d6f-4e4b-a829-342142dfcf46	d71188731b7df8d45c620f4932d960df84ce2c27077cfd54dff0fb5cc7fd9e0f	2026-05-21 12:55:55.095456+00	20260521124648_add_ref_tx_hash	\N	\N	2026-05-21 12:55:55.082844+00	1
7513e1a4-0717-4243-acde-39f3855009e0	0eaf021878b8947c91d84dbc1fb24be0c6e8a448c5f875d4d418420caa8dec70	2026-06-02 16:59:37.204231+00	20260603000000_add_gldx_token	\N	\N	2026-06-02 16:59:37.195133+00	1
\.


--
-- Data for Name: _sqlx_migrations; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public._sqlx_migrations (version, description, installed_on, success, checksum, execution_time) FROM stdin;
20260723000000	initial schema	2026-07-24 17:07:24.343533+00	t	\\xaad703a529b601f73622f842ba29a2fcfd08f92784dadc1aff0e630848da42e6867a4acc73795e0465cd72fd1cdf4ad0	20892331
20260725000000	add polkadot	2026-07-24 17:07:24.367007+00	t	\\xbbe80eba1ecc0613ccb6b87fb5913149af0f48e251a09f4dbe3178bae307883a81717a46fc206439508b9a10cf4b6e2e	3885290
20260727000000	create idrx account	2026-08-16 11:17:38.082863+00	t	\\xc099e82ace0fe4f59f645bd6645094a9d796e398d5bf7ee874a560e7d9fea5b24a9f168a8d521e8508632de639f132c6	36106351
20260728000001	idrx account add email	2026-08-16 11:17:38.120752+00	t	\\xede3b08b8a603e67a39b15d51614d1eceddd325391a8321ec6187feb1bbbe38ee8f3e70fbec010fb5dcbc5c9164d7520	5211992
20260804000000	drop idrx account email unique	2026-08-16 11:17:38.126642+00	t	\\xb3ea503fcaec1bc9b386148186e6f5b5d24ffe10a52a5dbc8d39dcdc63b7ab17a10240a20f364467790bb0bcda037fc8	6697332
20260816000000	fix timestamp types	2026-08-16 11:26:07.158052+00	t	\\x4b577d0dc4527e9e842652c5d7a77b078471290c0b5e5d0070b3eb04f23e5417f48c5b81be0f38de157872d586ed1f95	86969237
20260916000000	idrx account add idrx email	2026-09-15 15:55:22.991093+00	t	\\x02384e1fb7c13950b868dd6fa612b68f00190197e2b3e54c9043219348ded4569bf2dd975826f01dcca17256999168e5	32194317
\.


--
-- Data for Name: admin_audit_logs; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public.admin_audit_logs (id, admin_id, admin_username, action, target_table, target_id, details, ip_address, created_at) FROM stdin;
048734c6-3228-45a1-8d72-8d067056a015	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "59.153.131.85", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	59.153.131.85	2026-09-06 09:08:28.751875+00
99d66dd3-3e50-4f07-9656-39b68fa81c7d	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "59.153.131.85", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	59.153.131.85	2026-09-06 09:12:21.191259+00
40b2fe4c-8ada-427f-bde6-4f0959ba6bd2	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	59.153.131.85	2026-09-06 09:14:44.682615+00
ad146c82-c7b3-4f40-9a52-61a9dcb18c82	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	59.153.131.85	2026-09-06 18:08:28.366694+00
8a1278a3-19a0-45df-852d-4a9d0c5ba65b	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "103.175.213.164", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.164	2026-09-07 11:08:12.686233+00
6a47e42f-b5a3-4d40-939c-7d0dac35ea38	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CHANGE_SUPERADMIN_PASSWORD	admin_users	9d183389-eb5f-4d55-b49c-8a03806f7afe	{"status": "success"}	103.175.214.249	2026-09-07 11:08:40.864394+00
a74b38e6-e648-4b36-af07-0256f46cd288	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	114.122.138.42	2026-09-07 11:08:43.699855+00
ca78a37d-2094-4938-8153-12296908c69e	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "103.175.213.200", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.200	2026-09-07 11:09:12.05575+00
9a9e1619-f664-4c18-bf01-edb1f85a0472	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "103.175.213.167", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.167	2026-09-07 11:12:46.316016+00
b92c65b0-016d-44db-b073-458fbea02f13	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CREATE_ADMIN	admin_users	0abe097b-f082-4193-a0c1-40c4c8c0aea2	{"role": "VIEWER", "createdEmail": "adiztraa@gmail.com", "createdUsername": "adiztra"}	103.175.213.207	2026-09-07 11:14:47.654302+00
484c0f71-0803-497d-860a-7012a837926c	\N	adiztra	LOGIN	admin_users	\N	{"ip": "103.175.213.196", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.196	2026-09-07 11:15:16.585967+00
b07b2315-3a8c-47ac-bad7-06b890b79592	\N	adiztra	UPDATE_TRANSACTION_DETAILS	Transaction	e9f690d8-10c3-4054-8f81-2ec24b13a14a	{"reason": "hai", "status": "EXPIRED", "txHash": "", "cexTxId": "", "idrAmount": 500000, "tokenAmount": null, "walletAddress": "3NTHn2mBA4UAFo3D1p2J1uewwd32qDZ3tJgDma5xxFsa", "paymentDetails": {"idrxMintOrderId": "20260905110112"}}	103.175.213.152	2026-09-07 11:15:40.471294+00
e2f17bc8-11ae-4a7c-a61e-75e6c1e84c69	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	DELETE_ADMIN	admin_users	0abe097b-f082-4193-a0c1-40c4c8c0aea2	\N	103.175.213.160	2026-09-07 11:45:23.732903+00
4ea7388f-35d7-4f34-8207-50aa51936db1	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CREATE_ADMIN	admin_users	fbb6e666-676f-4e98-8065-b0cdcbb2bd5a	{"role": "VIEWER", "permissions": ["transactions:read", "dapps:read", "idrx:read", "referrals:read", "system:read", "audit:read"], "createdEmail": "adiztraa@gmail.com", "createdUsername": "adiztra"}	103.175.213.160	2026-09-07 11:46:06.584591+00
ca53c3b6-8330-4bdb-95b1-7746b9077d6c	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CREATE_ADMIN	admin_users	1440a036-57e4-4b6f-a1e3-414dc7e1e6b6	{"role": "VIEWER", "permissions": ["transactions:read", "dapps:read", "idrx:read", "referrals:read", "system:read", "audit:read"], "createdEmail": "brewpending@gmail.com", "createdUsername": "pendingbrew"}	103.175.213.160	2026-09-07 11:47:14.260199+00
0f1a21f0-b2c5-4b94-8b1e-0cf3b811dc8d	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CREATE_ADMIN	admin_users	d97c6797-b2b1-4cce-8acc-11e3d9f4e385	{"role": "ADMIN", "permissions": ["transactions:read", "transactions:write", "dapps:read", "dapps:write", "idrx:read", "referrals:read", "system:read", "admins:read", "admins:manage", "audit:read"], "createdEmail": "pasha.renaisan@gmail.com", "createdUsername": "renrensan"}	103.175.213.190	2026-09-07 11:51:52.637867+00
c8d2075b-6de1-40ea-8e4f-b38004ca4822	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	103.175.213.153	2026-09-07 11:52:16.759248+00
0f68cda9-7f29-4f76-9752-5e648492e08a	d97c6797-b2b1-4cce-8acc-11e3d9f4e385	renrensan	LOGIN	admin_users	\N	{"ip": "103.175.213.153", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.153	2026-09-07 11:52:23.728059+00
efaa52c9-0c92-464b-83d8-b5ad45aa2824	d97c6797-b2b1-4cce-8acc-11e3d9f4e385	renrensan	LOGOUT	admin_users	\N	\N	103.175.213.153	2026-09-07 11:52:40.531859+00
ccf99de4-122b-4937-b9d6-42c0ae77d23a	1440a036-57e4-4b6f-a1e3-414dc7e1e6b6	pendingbrew	LOGIN	admin_users	\N	{"ip": "103.175.213.153", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.153	2026-09-07 11:52:54.892249+00
0e880fe5-e776-4fcb-9eaf-2488658eaa1e	1440a036-57e4-4b6f-a1e3-414dc7e1e6b6	pendingbrew	LOGOUT	admin_users	\N	\N	103.175.213.193	2026-09-07 11:53:08.68893+00
9e60c819-d782-4c17-bd6a-88f335ca741a	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "103.175.213.184", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.184	2026-09-07 11:53:34.857226+00
724fe726-806c-4a6e-88f6-4273c8cf613b	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	CREATE_ADMIN	admin_users	a5b9a709-580f-4476-9e7c-7a5827247e0d	{"role": "ADMIN", "permissions": ["transactions:read", "transactions:write", "dapps:read", "dapps:write", "idrx:read", "referrals:read", "system:read", "admins:read", "admins:manage", "audit:read"], "createdEmail": "kelwinwithshen@gmail.com", "createdUsername": "kelwinshen"}	103.175.213.192	2026-09-07 11:54:15.172434+00
9e213abf-2371-4200-8c0a-2c50104ca068	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	103.175.213.192	2026-09-07 11:54:24.377182+00
62e84bfd-7b65-4e30-9b19-1586ea860224	d97c6797-b2b1-4cce-8acc-11e3d9f4e385	renrensan	LOGIN	admin_users	\N	{"ip": "103.175.213.224", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	103.175.213.224	2026-09-07 12:08:49.110304+00
cc0dfe19-57d3-4746-a3a8-6c03b3b8e636	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "38.86.221.115", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"}	38.86.221.115	2026-09-07 18:28:43.410058+00
d4ee6e89-4d6a-4b2d-b2c4-4aa54335e575	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGOUT	admin_users	\N	\N	38.86.221.140	2026-09-07 18:31:33.306406+00
a202959a-b0a8-4b33-b22e-261caa4785d4	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "114.122.141.232", "userAgent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"}	114.122.141.232	2026-09-09 14:47:37.60883+00
60a77aa9-47a6-4e58-83e9-15672c060541	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "180.254.11.128", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"}	180.254.11.128	2026-09-10 11:28:20.511918+00
257a4b3d-07ec-4eb7-81ca-43913fd79827	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "180.254.11.128", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	180.254.11.128	2026-09-10 12:53:20.290591+00
4deb6b67-b7aa-4665-af77-0f23a5bccaaa	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	180.254.11.128	2026-09-10 12:53:27.458402+00
30b7885e-acae-4b32-8769-58bae60a2f86	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "180.254.11.128", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	180.254.11.128	2026-09-10 12:54:27.036194+00
fecebdaa-5db2-4b3d-86de-60f1483ba5df	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	180.254.11.128	2026-09-10 12:56:47.592272+00
98704c9e-d92a-4479-b2b4-34ddefa7789f	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "114.122.139.178", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	114.122.139.178	2026-09-10 15:02:51.765992+00
2fe6d314-1de1-4538-ae8c-8cbf2e62d9aa	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "114.122.138.20", "userAgent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"}	114.122.138.20	2026-09-11 06:43:04.050774+00
d4088898-8c53-4faf-9a88-1ffbb00ae5c4	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "112.215.219.8", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	112.215.219.8	2026-09-11 16:56:13.779906+00
8a409351-ec17-4654-a4a5-d95ba57f65f5	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGOUT	admin_users	\N	\N	112.215.219.8	2026-09-11 17:09:36.402182+00
36df074e-8372-429d-8727-7f9cd262d6cd	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "38.86.221.83", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	38.86.221.83	2026-09-11 21:03:06.736902+00
88fd0e09-0de8-49dc-9354-e8d609ea0894	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	CHANGE_PASSWORD	admin_users	a5b9a709-580f-4476-9e7c-7a5827247e0d	{"status": "success"}	38.86.221.196	2026-09-11 21:05:24.160513+00
2ed311cf-11af-4def-93c9-67e20f32b5da	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "59.153.131.85", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	59.153.131.85	2026-09-12 09:45:46.55706+00
7dcdf869-c14c-4815-8f3b-c852ff46a520	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "38.86.221.158", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	38.86.221.158	2026-09-13 08:09:49.41724+00
9d3e1fc0-2b80-4fb3-87c5-b97ed8164396	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "59.153.131.85", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	59.153.131.85	2026-09-13 12:59:09.528326+00
6e7514cc-493a-41d4-8088-333a9105f730	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "110.139.68.76", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	110.139.68.76	2026-09-14 08:16:29.73597+00
41ffd4d2-ca37-4349-bc4d-72105e26d2f1	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGOUT	admin_users	\N	\N	110.139.68.76	2026-09-14 08:17:46.145853+00
bd99cd3a-a76e-488d-8078-17107b737384	1440a036-57e4-4b6f-a1e3-414dc7e1e6b6	pendingbrew	LOGIN	admin_users	\N	{"ip": "110.139.68.76", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	110.139.68.76	2026-09-14 09:08:32.77084+00
c44cbd53-7e2d-4d01-9100-a41053c44236	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "203.78.114.26", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	203.78.114.26	2026-09-14 13:41:56.655233+00
08e303c1-119d-4bd5-91db-76a226a4e1c8	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	LOGIN	admin_users	\N	{"ip": "59.153.131.85", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}	59.153.131.85	2026-09-15 10:00:22.93142+00
047a672b-f7d6-491b-96f4-90db7b35de51	9d183389-eb5f-4d55-b49c-8a03806f7afe	superadmin	REASSIGN_IDRX_KYC_PROFILE	IdrxAccount	6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H	{"action": "REASSIGN_KYC_PROFILE", "reason": "Previous IDRX imail is revoked by IDRX", "newEmail": "pasha.renaisan+24@gmail.com", "oldEmail": "pasha.renaisan@gmail.com", "newApiKey": "b2e9bbddf1ef3b4a", "oldApiKey": "ef9feeb734f94640", "targetKey": "12BNNy4BQu8tojSbj8WWh4BTi8rayQPm5YteoebxuPPWDQb6", "newKycAddress": "6LGvLjRy5thP9Xn9FcDQXtKBRyCoFhZykYHW9m1m8kEd", "oldKycAddress": "hKebVvg9RD3ZxRT2MCjV5PyPKVguB7MJ44XwYi6zzw1", "walletAddress": "6Zkgq8LT1c3e6JPxD3H7aUJtsRGxeg1MVF8UcgAZmV2H"}	59.153.131.85	2026-09-15 10:25:23.639525+00
657d540b-b597-425c-93ad-83ea7e9c4444	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "112.215.220.104", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	112.215.220.104	2026-09-16 15:45:33.871604+00
9a65d7da-7020-4ac8-a98b-662151e463d9	a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinshen	LOGIN	admin_users	\N	{"ip": "179.65.207.21", "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}	179.65.207.21	2026-09-17 16:02:20.013902+00
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public.admin_users (id, email, username, password_hash, role, is_active, last_login_at, created_at, updated_at, permissions) FROM stdin;
1440a036-57e4-4b6f-a1e3-414dc7e1e6b6	brewpending@gmail.com	pendingbrew	$2a$12$aaJfUrh70ZI8hwW5xYH7feAThdKX1xXsTByvNLtRVUTZILVR8rs/G	VIEWER	t	2026-09-14 09:08:32.739321+00	2026-09-07 11:47:14.255421+00	2026-09-14 09:08:32.739321+00	["transactions:read", "dapps:read", "idrx:read", "referrals:read", "system:read", "audit:read"]
9d183389-eb5f-4d55-b49c-8a03806f7afe	admin@paradapp.com	superadmin	$2a$12$8X4MwnCYa4RCoV7RrZbF0.Hk4nHFDk6kDbKCg16GoCeRPQ.Fc6CdC	SUPER_ADMIN	t	2026-09-15 10:00:22.90585+00	2026-09-06 08:38:43.896564+00	2026-09-15 10:00:22.90585+00	[]
a5b9a709-580f-4476-9e7c-7a5827247e0d	kelwinwithshen@gmail.com	kelwinshen	$2a$12$8uHbepgOvODpbW63nc2aY.i3tbc4WyZUXXGKAi6ASWyGSg5JnaEqO	ADMIN	t	2026-09-17 16:02:20.00467+00	2026-09-07 11:54:15.169373+00	2026-09-17 16:02:20.00467+00	["transactions:read", "transactions:write", "dapps:read", "dapps:write", "idrx:read", "referrals:read", "system:read", "admins:read", "admins:manage", "audit:read"]
fbb6e666-676f-4e98-8065-b0cdcbb2bd5a	adiztraa@gmail.com	adiztra	$2a$12$qd/NokIApQ6ciS27.BYMguZQxaozpMc890MKYUJcUtH7tSwfiHJPa	VIEWER	t	\N	2026-09-07 11:46:06.58043+00	2026-09-07 11:46:06.58043+00	["transactions:read", "dapps:read", "idrx:read", "referrals:read", "system:read", "audit:read"]
d97c6797-b2b1-4cce-8acc-11e3d9f4e385	pasha.renaisan@gmail.com	renrensan	$2a$12$WkvEw3RaW/Of7beKZNosKuIZEf57jz6Ay7Lkkq0dawx7kt19tGwZ.	ADMIN	t	2026-09-07 12:08:49.106753+00	2026-09-07 11:51:52.632093+00	2026-09-07 12:08:49.106753+00	["transactions:read", "transactions:write", "dapps:read", "dapps:write", "idrx:read", "referrals:read", "system:read", "admins:read", "admins:manage", "audit:read"]
\.


--
-- Data for Name: marketing_tasks; Type: TABLE DATA; Schema: public; Owner: paradapp_user
--

COPY public.marketing_tasks (id, name, phone_number, task_type, payload, status, created_at, updated_at) FROM stdin;
1	Renrensan	6281239990810	SEND_PDF	{"text": "Production cluster fully operational! 🎉"}	COMPLETED	2026-06-21 14:43:29.673513+00	2026-06-21 14:43:37.316649+00
28	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-01 05:15:54.616929+00	2026-08-01 05:15:54.700312+00
2	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-21 15:08:11.472587+00	2026-06-21 15:08:20.00067+00
29	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-01 05:22:43.01743+00	2026-08-01 05:22:49.867195+00
3	ParaHub Guest	6285117722465	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-21 15:12:56.919352+00	2026-06-21 15:13:05.123202+00
4	ParaHub Guest	6287860202653	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-21 15:17:50.006324+00	2026-06-21 15:17:58.408896+00
30	ParaHub Guest	6281239990819	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-01 05:25:18.821731+00	2026-08-01 05:25:25.760799+00
5	ParaHub Guest	6282247973243	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-21 15:28:09.523558+00	2026-06-21 15:28:18.100533+00
31	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-08-01 05:25:40.234584+00	2026-08-01 05:25:47.902732+00
6	ParaHub Guest	6285738102839	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-22 10:52:11.847048+00	2026-06-22 10:52:20.199161+00
7	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-06-23 08:26:33.375421+00	2026-06-23 08:26:33.861956+00
32	ParaHub Guest	6281338772338	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-08-08 08:26:33.701683+00	2026-08-08 08:26:41.859655+00
8	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-06-23 08:31:48.293877+00	2026-06-23 08:32:03.959389+00
33	ParaHub Guest	6281239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-08-08 18:16:25.87685+00	2026-08-08 18:16:32.506254+00
9	Pasha Renaisan	6281239990810	SEND_PDF	{"text": ""}	COMPLETED	2026-06-23 08:39:37.981991+00	2026-06-23 08:39:43.654333+00
10	Pasha Renaisan	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 08:53:15.694728+00	2026-06-23 08:53:30.124978+00
34	ParaHub Guest	81239990810	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-08 18:26:19.440057+00	2026-08-08 18:26:25.633033+00
11	Adi Saputra	6282247973243	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 08:57:22.22693+00	2026-06-23 08:57:22.535804+00
35	ParaHub Guest	6282146504913	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	COMPLETED	2026-08-08 18:26:41.619389+00	2026-08-08 18:26:48.813005+00
12	Pasha R	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 09:01:45.555569+00	2026-06-23 09:01:59.739893+00
13	Pasha R	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 09:04:49.762778+00	2026-06-23 09:05:06.909215+00
14	pasha	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 09:25:11.476008+00	2026-06-23 09:25:21.300018+00
15	Pasha	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 09:30:31.991864+00	2026-06-23 09:30:37.938732+00
16	Pasha	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	FAILED	2026-06-23 09:35:08.311948+00	2026-06-23 09:35:09.566654+00
17	pasha	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	COMPLETED	2026-06-23 09:36:30.804792+00	2026-06-23 09:36:56.255684+00
18	Pasha	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	COMPLETED	2026-06-23 10:07:55.934955+00	2026-06-23 10:08:01.397726+00
19	Pasha Renaisan	6281239990810	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-23 10:08:50.444573+00	2026-06-23 10:08:56.637239+00
20	Pasha Renaisan	6281239990810	SEND_PDF	{"text": "", "locale": "id"}	COMPLETED	2026-06-23 10:09:21.852966+00	2026-06-23 10:09:27.494224+00
21	adistra	6282247973243	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-23 10:16:38.929234+00	2026-06-23 10:16:44.909197+00
22	pasha	6281239990810	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-23 10:22:10.117647+00	2026-06-23 10:22:16.522754+00
23	kelwin shen	6287860202653	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-24 09:51:24.891998+00	2026-06-24 09:51:31.990675+00
24	Pasha R	6281239990810	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-25 01:42:58.707268+00	2026-06-25 01:43:06.214955+00
25	Fajar Tapa	6282146077890	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-06-25 02:28:59.39486+00	2026-06-25 02:29:08.38124+00
26	diva	6281338772338	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-07-04 10:42:23.028184+00	2026-07-04 10:42:29.05138+00
27	Pasha Renaisan	6281239990810	SEND_PDF	{"text": "", "locale": "en"}	COMPLETED	2026-07-16 07:59:05.032488+00	2026-07-16 07:59:11.89168+00
36	ParaHub Guest	6282247973243	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-18 17:29:16.565685+00	2026-08-18 17:29:19.219684+00
37	ParaHub Guest	6287860202653	SEND_PDF	{"text": "Halo! 👋\\n\\nIni adalah materi onboarding \\"Memahami Blockchain dari Dasar\\" dari ParaHub yang Anda minta.\\n\\nSelamat membaca dan pelajari materinya! 🚀"}	FAILED	2026-08-18 17:29:41.913738+00	2026-08-18 17:29:45.442107+00
\.


--
-- Name: DappFeature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: paradapp_user
--

SELECT pg_catalog.setval('public."DappFeature_id_seq"', 122, true);


--
-- Name: DappSection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: paradapp_user
--

SELECT pg_catalog.setval('public."DappSection_id_seq"', 41, true);


--
-- Name: Dapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: paradapp_user
--

SELECT pg_catalog.setval('public."Dapp_id_seq"', 13, true);


--
-- Name: marketing_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: paradapp_user
--

SELECT pg_catalog.setval('public.marketing_tasks_id_seq', 37, true);


--
-- Name: Chat Chat_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Chat"
    ADD CONSTRAINT "Chat_pkey" PRIMARY KEY (id);


--
-- Name: Chatwoot Chatwoot_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Chatwoot"
    ADD CONSTRAINT "Chatwoot_pkey" PRIMARY KEY (id);


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: DifySetting DifySetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."DifySetting"
    ADD CONSTRAINT "DifySetting_pkey" PRIMARY KEY (id);


--
-- Name: Dify Dify_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Dify"
    ADD CONSTRAINT "Dify_pkey" PRIMARY KEY (id);


--
-- Name: EvoaiSetting EvoaiSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvoaiSetting"
    ADD CONSTRAINT "EvoaiSetting_pkey" PRIMARY KEY (id);


--
-- Name: Evoai Evoai_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Evoai"
    ADD CONSTRAINT "Evoai_pkey" PRIMARY KEY (id);


--
-- Name: EvolutionBotSetting EvolutionBotSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvolutionBotSetting"
    ADD CONSTRAINT "EvolutionBotSetting_pkey" PRIMARY KEY (id);


--
-- Name: EvolutionBot EvolutionBot_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvolutionBot"
    ADD CONSTRAINT "EvolutionBot_pkey" PRIMARY KEY (id);


--
-- Name: FlowiseSetting FlowiseSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."FlowiseSetting"
    ADD CONSTRAINT "FlowiseSetting_pkey" PRIMARY KEY (id);


--
-- Name: Flowise Flowise_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Flowise"
    ADD CONSTRAINT "Flowise_pkey" PRIMARY KEY (id);


--
-- Name: Instance Instance_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Instance"
    ADD CONSTRAINT "Instance_pkey" PRIMARY KEY (id);


--
-- Name: IntegrationSession IntegrationSession_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."IntegrationSession"
    ADD CONSTRAINT "IntegrationSession_pkey" PRIMARY KEY (id);


--
-- Name: IsOnWhatsapp IsOnWhatsapp_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."IsOnWhatsapp"
    ADD CONSTRAINT "IsOnWhatsapp_pkey" PRIMARY KEY (id);


--
-- Name: Kafka Kafka_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Kafka"
    ADD CONSTRAINT "Kafka_pkey" PRIMARY KEY (id);


--
-- Name: Label Label_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Label"
    ADD CONSTRAINT "Label_pkey" PRIMARY KEY (id);


--
-- Name: Media Media_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Media"
    ADD CONSTRAINT "Media_pkey" PRIMARY KEY (id);


--
-- Name: MessageUpdate MessageUpdate_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."MessageUpdate"
    ADD CONSTRAINT "MessageUpdate_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: N8nSetting N8nSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."N8nSetting"
    ADD CONSTRAINT "N8nSetting_pkey" PRIMARY KEY (id);


--
-- Name: N8n N8n_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."N8n"
    ADD CONSTRAINT "N8n_pkey" PRIMARY KEY (id);


--
-- Name: Nats Nats_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Nats"
    ADD CONSTRAINT "Nats_pkey" PRIMARY KEY (id);


--
-- Name: OpenaiBot OpenaiBot_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiBot"
    ADD CONSTRAINT "OpenaiBot_pkey" PRIMARY KEY (id);


--
-- Name: OpenaiCreds OpenaiCreds_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiCreds"
    ADD CONSTRAINT "OpenaiCreds_pkey" PRIMARY KEY (id);


--
-- Name: OpenaiSetting OpenaiSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiSetting"
    ADD CONSTRAINT "OpenaiSetting_pkey" PRIMARY KEY (id);


--
-- Name: Proxy Proxy_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Proxy"
    ADD CONSTRAINT "Proxy_pkey" PRIMARY KEY (id);


--
-- Name: Pusher Pusher_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Pusher"
    ADD CONSTRAINT "Pusher_pkey" PRIMARY KEY (id);


--
-- Name: Rabbitmq Rabbitmq_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Rabbitmq"
    ADD CONSTRAINT "Rabbitmq_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: Sqs Sqs_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Sqs"
    ADD CONSTRAINT "Sqs_pkey" PRIMARY KEY (id);


--
-- Name: Template Template_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Template"
    ADD CONSTRAINT "Template_pkey" PRIMARY KEY (id);


--
-- Name: TypebotSetting TypebotSetting_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."TypebotSetting"
    ADD CONSTRAINT "TypebotSetting_pkey" PRIMARY KEY (id);


--
-- Name: Typebot Typebot_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Typebot"
    ADD CONSTRAINT "Typebot_pkey" PRIMARY KEY (id);


--
-- Name: Webhook Webhook_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Webhook"
    ADD CONSTRAINT "Webhook_pkey" PRIMARY KEY (id);


--
-- Name: Websocket Websocket_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Websocket"
    ADD CONSTRAINT "Websocket_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: DappFeature DappFeature_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappFeature"
    ADD CONSTRAINT "DappFeature_pkey" PRIMARY KEY (id);


--
-- Name: DappSection DappSection_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappSection"
    ADD CONSTRAINT "DappSection_pkey" PRIMARY KEY (id);


--
-- Name: Dapp Dapp_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."Dapp"
    ADD CONSTRAINT "Dapp_pkey" PRIMARY KEY (id);


--
-- Name: IdrxAccount IdrxAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."IdrxAccount"
    ADD CONSTRAINT "IdrxAccount_pkey" PRIMARY KEY ("walletAddress");


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY (id);


--
-- Name: UserFavoriteDapp UserFavoriteDapp_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."UserFavoriteDapp"
    ADD CONSTRAINT "UserFavoriteDapp_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: _sqlx_migrations _sqlx_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public._sqlx_migrations
    ADD CONSTRAINT _sqlx_migrations_pkey PRIMARY KEY (version);


--
-- Name: admin_audit_logs admin_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: marketing_tasks marketing_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.marketing_tasks
    ADD CONSTRAINT marketing_tasks_pkey PRIMARY KEY (id);


--
-- Name: Chat_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Chat_instanceId_idx" ON evolution."Chat" USING btree ("instanceId");


--
-- Name: Chat_instanceId_remoteJid_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Chat_instanceId_remoteJid_key" ON evolution."Chat" USING btree ("instanceId", "remoteJid");


--
-- Name: Chat_remoteJid_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Chat_remoteJid_idx" ON evolution."Chat" USING btree ("remoteJid");


--
-- Name: Chatwoot_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Chatwoot_instanceId_key" ON evolution."Chatwoot" USING btree ("instanceId");


--
-- Name: Contact_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Contact_instanceId_idx" ON evolution."Contact" USING btree ("instanceId");


--
-- Name: Contact_remoteJid_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Contact_remoteJid_idx" ON evolution."Contact" USING btree ("remoteJid");


--
-- Name: Contact_remoteJid_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Contact_remoteJid_instanceId_key" ON evolution."Contact" USING btree ("remoteJid", "instanceId");


--
-- Name: DifySetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "DifySetting_instanceId_key" ON evolution."DifySetting" USING btree ("instanceId");


--
-- Name: EvoaiSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "EvoaiSetting_instanceId_key" ON evolution."EvoaiSetting" USING btree ("instanceId");


--
-- Name: EvolutionBotSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "EvolutionBotSetting_instanceId_key" ON evolution."EvolutionBotSetting" USING btree ("instanceId");


--
-- Name: FlowiseSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "FlowiseSetting_instanceId_key" ON evolution."FlowiseSetting" USING btree ("instanceId");


--
-- Name: Instance_name_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Instance_name_key" ON evolution."Instance" USING btree (name);


--
-- Name: IsOnWhatsapp_remoteJid_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "IsOnWhatsapp_remoteJid_key" ON evolution."IsOnWhatsapp" USING btree ("remoteJid");


--
-- Name: Kafka_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Kafka_instanceId_key" ON evolution."Kafka" USING btree ("instanceId");


--
-- Name: Label_labelId_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Label_labelId_instanceId_key" ON evolution."Label" USING btree ("labelId", "instanceId");


--
-- Name: Media_messageId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Media_messageId_key" ON evolution."Media" USING btree ("messageId");


--
-- Name: MessageUpdate_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "MessageUpdate_instanceId_idx" ON evolution."MessageUpdate" USING btree ("instanceId");


--
-- Name: MessageUpdate_messageId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "MessageUpdate_messageId_idx" ON evolution."MessageUpdate" USING btree ("messageId");


--
-- Name: Message_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Message_instanceId_idx" ON evolution."Message" USING btree ("instanceId");


--
-- Name: N8nSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "N8nSetting_instanceId_key" ON evolution."N8nSetting" USING btree ("instanceId");


--
-- Name: Nats_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Nats_instanceId_key" ON evolution."Nats" USING btree ("instanceId");


--
-- Name: OpenaiCreds_apiKey_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "OpenaiCreds_apiKey_key" ON evolution."OpenaiCreds" USING btree ("apiKey");


--
-- Name: OpenaiCreds_name_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "OpenaiCreds_name_key" ON evolution."OpenaiCreds" USING btree (name);


--
-- Name: OpenaiSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "OpenaiSetting_instanceId_key" ON evolution."OpenaiSetting" USING btree ("instanceId");


--
-- Name: OpenaiSetting_openaiCredsId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "OpenaiSetting_openaiCredsId_key" ON evolution."OpenaiSetting" USING btree ("openaiCredsId");


--
-- Name: Proxy_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Proxy_instanceId_key" ON evolution."Proxy" USING btree ("instanceId");


--
-- Name: Pusher_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Pusher_instanceId_key" ON evolution."Pusher" USING btree ("instanceId");


--
-- Name: Rabbitmq_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Rabbitmq_instanceId_key" ON evolution."Rabbitmq" USING btree ("instanceId");


--
-- Name: Session_sessionId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Session_sessionId_key" ON evolution."Session" USING btree ("sessionId");


--
-- Name: Setting_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Setting_instanceId_idx" ON evolution."Setting" USING btree ("instanceId");


--
-- Name: Setting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Setting_instanceId_key" ON evolution."Setting" USING btree ("instanceId");


--
-- Name: Sqs_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Sqs_instanceId_key" ON evolution."Sqs" USING btree ("instanceId");


--
-- Name: Template_name_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Template_name_key" ON evolution."Template" USING btree (name);


--
-- Name: Template_templateId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Template_templateId_key" ON evolution."Template" USING btree ("templateId");


--
-- Name: TypebotSetting_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "TypebotSetting_instanceId_key" ON evolution."TypebotSetting" USING btree ("instanceId");


--
-- Name: Webhook_instanceId_idx; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE INDEX "Webhook_instanceId_idx" ON evolution."Webhook" USING btree ("instanceId");


--
-- Name: Webhook_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Webhook_instanceId_key" ON evolution."Webhook" USING btree ("instanceId");


--
-- Name: Websocket_instanceId_key; Type: INDEX; Schema: evolution; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Websocket_instanceId_key" ON evolution."Websocket" USING btree ("instanceId");


--
-- Name: Transaction_cexTxId_key; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Transaction_cexTxId_key" ON public."Transaction" USING btree ("cexTxId");


--
-- Name: Transaction_xenditTxId_key; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE UNIQUE INDEX "Transaction_xenditTxId_key" ON public."Transaction" USING btree ("xenditTxId");


--
-- Name: UserFavoriteDapp_dappId_idx; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX "UserFavoriteDapp_dappId_idx" ON public."UserFavoriteDapp" USING btree ("dappId");


--
-- Name: UserFavoriteDapp_userAddress_idx; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX "UserFavoriteDapp_userAddress_idx" ON public."UserFavoriteDapp" USING btree ("userAddress");


--
-- Name: UserFavoriteDapp_userAddress_network_dappId_key; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE UNIQUE INDEX "UserFavoriteDapp_userAddress_network_dappId_key" ON public."UserFavoriteDapp" USING btree ("userAddress", network, "dappId");


--
-- Name: idx_admin_audit_logs_admin_id; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_admin_audit_logs_admin_id ON public.admin_audit_logs USING btree (admin_id);


--
-- Name: idx_admin_audit_logs_created_at; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_admin_audit_logs_created_at ON public.admin_audit_logs USING btree (created_at DESC);


--
-- Name: idx_admin_audit_logs_target; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_admin_audit_logs_target ON public.admin_audit_logs USING btree (target_table, target_id);


--
-- Name: idx_admin_users_email; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_admin_users_email ON public.admin_users USING btree (email);


--
-- Name: idx_admin_users_username; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_admin_users_username ON public.admin_users USING btree (username);


--
-- Name: idx_marketing_tasks_status_type; Type: INDEX; Schema: public; Owner: paradapp_user
--

CREATE INDEX idx_marketing_tasks_status_type ON public.marketing_tasks USING btree (status, task_type);


--
-- Name: IdrxAccount IdrxAccount_updatedAt_trigger; Type: TRIGGER; Schema: public; Owner: paradapp_user
--

CREATE TRIGGER "IdrxAccount_updatedAt_trigger" BEFORE UPDATE ON public."IdrxAccount" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: Transaction Transaction_updatedAt_trigger; Type: TRIGGER; Schema: public; Owner: paradapp_user
--

CREATE TRIGGER "Transaction_updatedAt_trigger" BEFORE UPDATE ON public."Transaction" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: Chat Chat_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Chat"
    ADD CONSTRAINT "Chat_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chatwoot Chatwoot_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Chatwoot"
    ADD CONSTRAINT "Chatwoot_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Contact Contact_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Contact"
    ADD CONSTRAINT "Contact_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DifySetting DifySetting_difyIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."DifySetting"
    ADD CONSTRAINT "DifySetting_difyIdFallback_fkey" FOREIGN KEY ("difyIdFallback") REFERENCES evolution."Dify"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DifySetting DifySetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."DifySetting"
    ADD CONSTRAINT "DifySetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Dify Dify_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Dify"
    ADD CONSTRAINT "Dify_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EvoaiSetting EvoaiSetting_evoaiIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvoaiSetting"
    ADD CONSTRAINT "EvoaiSetting_evoaiIdFallback_fkey" FOREIGN KEY ("evoaiIdFallback") REFERENCES evolution."Evoai"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EvoaiSetting EvoaiSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvoaiSetting"
    ADD CONSTRAINT "EvoaiSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Evoai Evoai_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Evoai"
    ADD CONSTRAINT "Evoai_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EvolutionBotSetting EvolutionBotSetting_botIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvolutionBotSetting"
    ADD CONSTRAINT "EvolutionBotSetting_botIdFallback_fkey" FOREIGN KEY ("botIdFallback") REFERENCES evolution."EvolutionBot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EvolutionBotSetting EvolutionBotSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvolutionBotSetting"
    ADD CONSTRAINT "EvolutionBotSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EvolutionBot EvolutionBot_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."EvolutionBot"
    ADD CONSTRAINT "EvolutionBot_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FlowiseSetting FlowiseSetting_flowiseIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."FlowiseSetting"
    ADD CONSTRAINT "FlowiseSetting_flowiseIdFallback_fkey" FOREIGN KEY ("flowiseIdFallback") REFERENCES evolution."Flowise"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FlowiseSetting FlowiseSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."FlowiseSetting"
    ADD CONSTRAINT "FlowiseSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Flowise Flowise_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Flowise"
    ADD CONSTRAINT "Flowise_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IntegrationSession IntegrationSession_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."IntegrationSession"
    ADD CONSTRAINT "IntegrationSession_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Kafka Kafka_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Kafka"
    ADD CONSTRAINT "Kafka_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Label Label_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Label"
    ADD CONSTRAINT "Label_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Media Media_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Media"
    ADD CONSTRAINT "Media_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Media Media_messageId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Media"
    ADD CONSTRAINT "Media_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES evolution."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageUpdate MessageUpdate_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."MessageUpdate"
    ADD CONSTRAINT "MessageUpdate_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageUpdate MessageUpdate_messageId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."MessageUpdate"
    ADD CONSTRAINT "MessageUpdate_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES evolution."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Message"
    ADD CONSTRAINT "Message_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_sessionId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Message"
    ADD CONSTRAINT "Message_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES evolution."IntegrationSession"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: N8nSetting N8nSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."N8nSetting"
    ADD CONSTRAINT "N8nSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: N8nSetting N8nSetting_n8nIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."N8nSetting"
    ADD CONSTRAINT "N8nSetting_n8nIdFallback_fkey" FOREIGN KEY ("n8nIdFallback") REFERENCES evolution."N8n"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: N8n N8n_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."N8n"
    ADD CONSTRAINT "N8n_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Nats Nats_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Nats"
    ADD CONSTRAINT "Nats_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenaiBot OpenaiBot_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiBot"
    ADD CONSTRAINT "OpenaiBot_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenaiBot OpenaiBot_openaiCredsId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiBot"
    ADD CONSTRAINT "OpenaiBot_openaiCredsId_fkey" FOREIGN KEY ("openaiCredsId") REFERENCES evolution."OpenaiCreds"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenaiCreds OpenaiCreds_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiCreds"
    ADD CONSTRAINT "OpenaiCreds_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenaiSetting OpenaiSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiSetting"
    ADD CONSTRAINT "OpenaiSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenaiSetting OpenaiSetting_openaiCredsId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiSetting"
    ADD CONSTRAINT "OpenaiSetting_openaiCredsId_fkey" FOREIGN KEY ("openaiCredsId") REFERENCES evolution."OpenaiCreds"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OpenaiSetting OpenaiSetting_openaiIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."OpenaiSetting"
    ADD CONSTRAINT "OpenaiSetting_openaiIdFallback_fkey" FOREIGN KEY ("openaiIdFallback") REFERENCES evolution."OpenaiBot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Proxy Proxy_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Proxy"
    ADD CONSTRAINT "Proxy_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pusher Pusher_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Pusher"
    ADD CONSTRAINT "Pusher_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Rabbitmq Rabbitmq_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Rabbitmq"
    ADD CONSTRAINT "Rabbitmq_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_sessionId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Session"
    ADD CONSTRAINT "Session_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Setting Setting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Setting"
    ADD CONSTRAINT "Setting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Sqs Sqs_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Sqs"
    ADD CONSTRAINT "Sqs_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Template Template_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Template"
    ADD CONSTRAINT "Template_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TypebotSetting TypebotSetting_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."TypebotSetting"
    ADD CONSTRAINT "TypebotSetting_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TypebotSetting TypebotSetting_typebotIdFallback_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."TypebotSetting"
    ADD CONSTRAINT "TypebotSetting_typebotIdFallback_fkey" FOREIGN KEY ("typebotIdFallback") REFERENCES evolution."Typebot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Typebot Typebot_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Typebot"
    ADD CONSTRAINT "Typebot_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Webhook Webhook_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Webhook"
    ADD CONSTRAINT "Webhook_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Websocket Websocket_instanceId_fkey; Type: FK CONSTRAINT; Schema: evolution; Owner: paradapp_user
--

ALTER TABLE ONLY evolution."Websocket"
    ADD CONSTRAINT "Websocket_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES evolution."Instance"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DappFeature DappFeature_dappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappFeature"
    ADD CONSTRAINT "DappFeature_dappId_fkey" FOREIGN KEY ("dappId") REFERENCES public."Dapp"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DappSection DappSection_dappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."DappSection"
    ADD CONSTRAINT "DappSection_dappId_fkey" FOREIGN KEY ("dappId") REFERENCES public."Dapp"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserFavoriteDapp UserFavoriteDapp_dappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public."UserFavoriteDapp"
    ADD CONSTRAINT "UserFavoriteDapp_dappId_fkey" FOREIGN KEY ("dappId") REFERENCES public."Dapp"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: admin_audit_logs admin_audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paradapp_user
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict EIKGUJGgmyIKEmidYcAdukQxUHZdJ9uhhIxCFley7LrNArRghShANXZwBVWa6Y6

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 8f5bBRTlXk2eAPYdhFDKbkQ1fzt1SShBA8xfNMHFuwp72Krwdg1wuqrkrbGAVSL

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 8f5bBRTlXk2eAPYdhFDKbkQ1fzt1SShBA8xfNMHFuwp72Krwdg1wuqrkrbGAVSL

--
-- PostgreSQL database cluster dump complete
--

